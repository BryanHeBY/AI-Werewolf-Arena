# 历史公共 package 退桥与 sourceAsset 准入缺口

当前仅提案／诊断准备，未执行／未改仓库。前一个672物理迁移与37非module包保持原冻结来源。

## 已静态确认的真实差量

两个 sourceAsset 的 originCommit 都是 `442703cded8a5eb8c749bfcd3ce29b1d6a04e1cc`，不是27a adapter来源。

1. audit_summary_fixture.ts → builders/audit-summary.ts：只有首 type-only Locale import 从 game-catalog 退到 game-contract（另有 leading中文注释）。实际6025到本次当前文件字节相同；退旧出口的提交为694a2593。
2. mist_raven_transport_oracle.ts → features/mist-raven/oracles/transport.ts：两个 named value（MIST_RAVEN_EVENT_TYPES/readMistRavenFact）从 game-text 退到 game-contract/facts/mist-raven（另有 leading中文注释）；提交6d069243。它们是浏览器共享纯契约，不是新获准的 backend 生产value。

原 sourceProgramContract 只逆相对路径，不识别这两个已批准的公开包退桥，因此当前 raw statement/module binding 与原摘要不符。不能把新摘要写成“原摘要”。

## 最小后继设计（待Root裁定后才产仓库delta）

- 不新增泛package映射、schema或moduleRelocation白名单。只在 `sourceProgramContract` 为上述**两个精确current sourceAsset文件**、两个精确current specifier声明有限历史规则。
- 必须为 named import、无default/namespace；第一项仅一个 `Locale` 且整clause type-only（与原形态相同），第二项恰两个原name且均value（与原形态相同），重复／漏用／额外binding不准。
- 只把其 literal 逆为原 package specifier。完整 statements/moduleBindings 再比**已存原摘要**；函数／字面／调用／alias改变仍自然失败。
- generate 的新历史证明先在固定442 Git核真实 public export 链，再读同一GC物理owner：
  - 旧 catalog根 named type Locale → game-contract根 named type Locale → locale.ts；current game-contract根仍指该叶。
  - 旧 text根 `export * ./mist-raven` → 旧mist-raven薄出口 named values → game-contract/facts/mist-raven；旧／当前GC package exact export都指facts/mist-raven.ts。
- 完整声明printer SHA前后必须同：Locale alias＋LOCALES；MIST_RAVEN_EVENT_TYPES、readMistRavenFact、其局部ids/exact、MistRavenEventType/MistRavenFact。其明确值依赖copyEventData也单独读原／当前完整声明并比；不以两公开名字相同冒依赖或全模块图等价。
- 仅为这个证明读取显式 `packages/game-contract/src/{locale.ts,facts/mist-raven.ts,inert-event-data.ts}`，仍mode/逐层symlink校验；不授任意package或backend生产源读取，不执行这些模块。
- current字节可按实际刷新，但原programSha/moduleBindingsSha/origin全部不动。此为**历史准入修复**，有新归一化接受面，独立阶段不藏在“纯机械”标签。
- 最小新字面风险：两个精确合法import能逆回旧contract；错误sourceAsset／specifier／type-only/value模式／binding集合不能被归一化；完整函数或字面变化仍与原不同。不复已有3+新MCP3绿例。

## Root唯一诊断命令（尚未执行）

```sh
bun --no-env-file /tmp/awa-owned-layout-fixture-history-repair/diagnostic.cjs --repository /home/hby/dev/AI-Werewolf-Arena --output /tmp/awa-owned-layout-fixture-history-repair/diagnostic-results.json > /tmp/awa-owned-layout-fixture-history-repair/diagnostic-output.txt 2>&1
```

输出五sourceAsset的真实a/b/stored摘要、statement/module差异、只逆这两历史输入后的摘要及完整物理声明证据。它不写manifest、不执行adapter/玩法/类型/gate。

## 独立后继 checkpoint 提案已准备位置

`/tmp/awa-app-checkpoint-owner-followup/proposal.json`：5完整module迁app/checkpoint，7受影响program／33 module片段（包含5内部模块路径与2外部consumer，6条内部binding），未应用／未检查。Trace的七入口无需新增nonmodule字段，仍从app/simulation/reproduction-context进入。Root可并行读，当前先解决上述历史准入阻塞。
