from pathlib import Path
import json,hashlib
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-owned-layout-fixture-history-repair');p='tooling/refactor/fixture-manifest.ts';raw=(R/p).read_bytes();text=raw.decode();edits=[]
def edit(a,b,why):
 global text
 if text.count(a)!=1:raise ValueError((why,text.count(a)))
 text=text.replace(a,b);edits.append({'before':a,'after':b,'count':1,'purpose':why})
addition=r'''
// 两次已提交公共包退桥的历史输入，仅这两个 sourceAsset／specifier／具名模式可逆回原摘要。
const historicalSourcePackages = [
  {
    originPath: "backend/tests/support/audit_summary_fixture.ts",
    currentPath: "backend/tests/support/builders/audit-summary.ts",
    originalSpecifier: "@ai-werewolf-arena/game-catalog",
    currentSpecifier: "@ai-werewolf-arena/game-contract",
    names: ["Locale"], typeOnly: true,
    originalFiles: ["packages/game-catalog/package.json", "packages/game-catalog/src/index.ts", "packages/game-contract/package.json", "packages/game-contract/src/index.ts", "packages/game-contract/src/locale.ts"],
    currentFiles: ["packages/game-contract/package.json", "packages/game-contract/src/index.ts", "packages/game-contract/src/locale.ts"],
  },
  {
    originPath: "backend/tests/support/mist_raven_transport_oracle.ts",
    currentPath: "backend/tests/support/features/mist-raven/oracles/transport.ts",
    originalSpecifier: "@ai-werewolf-arena/game-text",
    currentSpecifier: "@ai-werewolf-arena/game-contract/facts/mist-raven",
    names: ["MIST_RAVEN_EVENT_TYPES", "readMistRavenFact"], typeOnly: false,
    originalFiles: ["packages/game-text/package.json", "packages/game-text/src/index.ts", "packages/game-text/src/mist-raven.ts", "packages/game-contract/package.json", "packages/game-contract/src/facts/mist-raven.ts", "packages/game-contract/src/inert-event-data.ts"],
    currentFiles: ["packages/game-contract/package.json", "packages/game-contract/src/facts/mist-raven.ts", "packages/game-contract/src/inert-event-data.ts"],
  },
] as const;
const historicalSourceCommit = "442703cded8a5eb8c749bfcd3ce29b1d6a04e1cc";

/**
 * 核对两个固定历史 sourceAsset 的公共包退桥证据；输入是调用方从固定 Git／精确公开文件读取的文本。
 * 只接受原公共 reexport 链到同一 GC 叶，完整声明和明确局部依赖逐项相同；不执行契约或推导玩法，
 * 不承诺旧聚合包与新叶的完整初始化图等价。返回完整打印声明供调用方摘要；原程序／绑定摘要不得更新。
 */
export function sourcePackageRelocationEvidence(
  ts: typeof import("typescript"),
  asset: Pick<FixtureSourceAsset, "originPath" | "currentPath" | "originCommit">,
  originalFiles: readonly { path: string; text: string }[],
  currentFiles: readonly { path: string; text: string }[],
): Array<{ path: string; name: string; statement: string }> {
  const route = historicalSourcePackages.find((entry) => entry.originPath === asset.originPath && entry.currentPath === asset.currentPath);
  if (!route) return [];
  if (asset.originCommit !== historicalSourceCommit) fail("historical_package_origin_commit");
  const original = new Map(originalFiles.map((entry) => [entry.path, entry.text]));
  const current = new Map(currentFiles.map((entry) => [entry.path, entry.text]));
  const read = (files: Map<string, string>, filename: string) => {
    const value = files.get(filename);
    if (value === undefined) fail("historical_package_evidence_missing");
    return value;
  };
  const ast = (files: Map<string, string>, filename: string) =>
    ts.createSourceFile(filename, read(files, filename), ts.ScriptTarget.Latest, true);
  const packageExport = (files: Map<string, string>, filename: string, key: string, target: string) => {
    const value: unknown = JSON.parse(read(files, filename));
    if (!record(value) || !record(value.exports) || value.exports[key] !== target)
      fail("historical_package_export_endpoint");
  };
  const namedExport = (files: Map<string, string>, filename: string, specifier: string, names: readonly string[], typeOnly: boolean) => {
    const matches = ast(files, filename).statements.filter((node) => ts.isExportDeclaration(node) && node.moduleSpecifier &&
      ts.isStringLiteralLike(node.moduleSpecifier) && node.moduleSpecifier.text === specifier &&
      node.isTypeOnly === typeOnly && node.exportClause && ts.isNamedExports(node.exportClause) &&
      names.every((name) => node.exportClause && ts.isNamedExports(node.exportClause) &&
        node.exportClause.elements.some((entry) => entry.name.text === name && (entry.propertyName?.text ?? entry.name.text) === name)));
    if (matches.length !== 1) fail("historical_package_reexport_endpoint");
  };
  const declarations: Array<{ path: string; name: string; statement: string }> = [];
  const compare = (filename: string, names: readonly string[], imported = false) => {
    const a = ast(original, filename), b = ast(current, filename);
    const print = ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed });
    for (const name of names) {
      const select = (source: import("typescript").SourceFile) => {
        const found = source.statements.filter((node) =>
          ((ts.isFunctionDeclaration(node) || ts.isTypeAliasDeclaration(node) || ts.isInterfaceDeclaration(node)) && node.name?.text === name) ||
          (ts.isVariableStatement(node) && node.declarationList.declarations.some((entry) => ts.isIdentifier(entry.name) && entry.name.text === name)));
        if (found.length !== 1) fail("historical_package_declaration_missing");
        return print.printNode(ts.EmitHint.Unspecified, found[0]!, source);
      };
      const before = select(a), after = select(b);
      if (before !== after) fail("historical_package_complete_declaration_drift");
      declarations.push({ path: filename, name, statement: before });
    }
    // Locale 与 copyEventData 的实际依赖叶无 import；新增依赖不得借正文摘要相同偷偷扩张。
    if (!imported && (a.statements.some(ts.isImportDeclaration) || b.statements.some(ts.isImportDeclaration)))
      fail("historical_package_leaf_dependency_drift");
  };
  packageExport(original, "packages/game-contract/package.json", ".", "./src/index.ts");
  packageExport(current, "packages/game-contract/package.json", ".", "./src/index.ts");
  if (route.typeOnly) {
    packageExport(original, "packages/game-catalog/package.json", ".", "./src/index.ts");
    namedExport(original, "packages/game-catalog/src/index.ts", "@ai-werewolf-arena/game-contract", ["Locale"], true);
    namedExport(original, "packages/game-contract/src/index.ts", "./locale", ["Locale"], true);
    namedExport(current, "packages/game-contract/src/index.ts", "./locale", ["Locale"], true);
    compare("packages/game-contract/src/locale.ts", ["LOCALES", "Locale"]);
  } else {
    packageExport(original, "packages/game-text/package.json", ".", "./src/index.ts");
    const stars = ast(original, "packages/game-text/src/index.ts").statements.filter((node) => ts.isExportDeclaration(node) &&
      !node.isTypeOnly && !node.exportClause && node.moduleSpecifier && ts.isStringLiteralLike(node.moduleSpecifier) && node.moduleSpecifier.text === "./mist-raven");
    if (stars.length !== 1) fail("historical_package_star_endpoint");
    namedExport(original, "packages/game-text/src/mist-raven.ts", "@ai-werewolf-arena/game-contract/facts/mist-raven", route.names, false);
    for (const files of [original, current]) {
      packageExport(files, "packages/game-contract/package.json", "./facts/mist-raven", "./src/facts/mist-raven.ts");
      const matches = ast(files, "packages/game-contract/src/facts/mist-raven.ts").statements.filter((node) => ts.isImportDeclaration(node) &&
        ts.isStringLiteralLike(node.moduleSpecifier) && node.moduleSpecifier.text === "../inert-event-data" &&
        node.importClause && !node.importClause.isTypeOnly && !node.importClause.name && node.importClause.namedBindings &&
        ts.isNamedImports(node.importClause.namedBindings) && node.importClause.namedBindings.elements.length === 1 &&
        node.importClause.namedBindings.elements[0]!.name.text === "copyEventData" && !node.importClause.namedBindings.elements[0]!.isTypeOnly &&
        (node.importClause.namedBindings.elements[0]!.propertyName?.text ?? "copyEventData") === "copyEventData");
      if (matches.length !== 1) fail("historical_package_dependency_endpoint");
    }
    // id 也是 ids 的原依赖；新增 DTO／BoardConfig type 不在这两个旧值的声明依赖闭包内。
    compare("packages/game-contract/src/facts/mist-raven.ts", ["MIST_RAVEN_EVENT_TYPES", "readMistRavenFact", "MistRavenEventType", "MistRavenFact", "id", "ids", "exact"], true);
    compare("packages/game-contract/src/inert-event-data.ts", ["copyEventData"]);
  }
  return declarations;
}
'''
edit('function sourceAssetPath(value: unknown): value is string {',addition+'\nfunction sourceAssetPath(value: unknown): value is string {','只两精确历史sourceAsset和公开导入路线；纯声明证据接口不加载模块')
edit('''  const observedRelocations = new Set<string>();
  const ast =''','''  const observedRelocations = new Set<string>();
  const packageRoute = current ? historicalSourcePackages.find((entry) => entry.currentPath === filename) : undefined;
  let observedPackageRoute = false;
  const ast =''','仅当前两个精确资产启用既有package退桥逆路由')
anchor='''      changes.push({
        start: literal.getStart(ast),'''
replace='''      if (packageRoute && identity === packageRoute.currentSpecifier) {
        if (!ts.isImportDeclaration(node) || !node.importClause || node.importClause.name ||
          !node.importClause.namedBindings || !ts.isNamedImports(node.importClause.namedBindings))
          fail("historical_package_requires_named_import");
        const elements = node.importClause.namedBindings.elements;
        if (!!node.importClause.isTypeOnly !== packageRoute.typeOnly || elements.some((entry) => entry.isTypeOnly))
          fail("historical_package_import_mode");
        const names = elements.map((entry) => (entry.propertyName ?? entry.name).text).sort();
        if (JSON.stringify(names) !== JSON.stringify([...packageRoute.names].sort()))
          fail("historical_package_import_binding");
        if (observedPackageRoute) fail("historical_package_duplicate_import");
        observedPackageRoute = true;
        identity = packageRoute.originalSpecifier;
      }
      changes.push({
        start: literal.getStart(ast),'''
edit(anchor,replace,'只有原named/type模式逆literal；alias、body、非module字面保持完整进入原摘要')
edit('''  if (current && observedRelocations.size !== relocations.length)
    fail("source_module_relocation_unused");
  let normalized =''','''  if (current && observedRelocations.size !== relocations.length)
    fail("source_module_relocation_unused");
  if (packageRoute && !observedPackageRoute) fail("historical_package_import_missing");
  let normalized =''','已知历史资产必须恰一实际导入，不吞错误specifier或漏接')
edit('''  const registeredTypeInputs = new Set<string>();
  async function safeFile''','''  const registeredTypeInputs = new Set<string>();
  const registeredContractInputs = new Set<string>();
  async function safeFile''','公开GC证据另用有限集合，不扩大backend生产类型白名单')
edit('''      !registeredTypeInputs.has(relative)
    )''','''      !registeredTypeInputs.has(relative) &&
      !registeredContractInputs.has(relative)
    )''','safeFile只额外读取匹配历史资产所需精确公共契约证据；原symlink逐层检查不变')
anchor='''        registeredTypeInputs.add(relocation.currentPath);
  if ('''
replace='''        registeredTypeInputs.add(relocation.currentPath);
  for (const asset of layout.sourceAssets) {
    const route = historicalSourcePackages.find((entry) => entry.originPath === asset.originPath && entry.currentPath === asset.currentPath);
    if (route) for (const filename of route.currentFiles) registeredContractInputs.add(filename);
  }
  if ('''
edit(anchor,replace,'仅parse后的两实际sourceAsset启用5精确GC文件读取，不接任意包路径')
anchor='''    const before = program(Buffer.from(original).toString("utf8"), asset.originPath, false),'''
replace='''    const packageRoute = historicalSourcePackages.find((entry) => entry.originPath === asset.originPath && entry.currentPath === asset.currentPath);
    if (packageRoute) {
      if (asset.originCommit !== historicalSourceCommit) fail("historical_package_origin_commit");
      const originalFiles: { path: string; text: string }[] = [], currentFiles: { path: string; text: string }[] = [];
      for (const filename of packageRoute.originalFiles) {
        const entry = childProcess.execFileSync("git", ["ls-tree", historicalSourceCommit, "--", filename], {
          cwd: root, encoding: "utf8", maxBuffer: 1024 * 1024,
        }).trim();
        const match = /^100644 blob [a-f0-9]{40}\\t(.+)$/.exec(entry);
        if (!match || match[1] !== filename) fail("historical_package_git_file_required");
        originalFiles.push({ path: filename, text: childProcess.execFileSync("git", ["show", `${historicalSourceCommit}:${filename}`], {
          cwd: root, encoding: "utf8", maxBuffer: 4 * 1024 * 1024,
        }) });
      }
      for (const filename of packageRoute.currentFiles) currentFiles.push({ path: filename, text: (await safeFile(filename)).toString("utf8") });
      sourcePackageRelocationEvidence(ts, asset, originalFiles, currentFiles);
    }
    const before = program(Buffer.from(original).toString("utf8"), asset.originPath, false),'''
edit(anchor,replace,'generate实际核固定Git export链/同GC完整依赖声明后，仍要求原program/binding摘要')
row={'path':p,'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':hashlib.sha256(text.encode()).hexdigest(),'before':raw.decode(),'after':text,'edits':edits}
(O/'source-edits.json').write_text(json.dumps({'status':'TMP_PREPARED_NOT_APPLIED_NOT_RUN','stage':'afterRoot37apply_beforeHistoricalAdmissionRepair','files':[row]},ensure_ascii=False,indent=2)+'\n');q=O/'candidates'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(text)
print('prepared fixture tool',len(edits),'exact snippets')
