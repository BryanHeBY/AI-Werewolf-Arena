# 两个历史公共包退桥的有限准入修复

状态：TMP source-ready，未应用／未执行。Root原metadata首失败、唯一诊断和原37包均保留，不重写为绿色收据。

## Root已实证的来源

唯一诊断0b816b／0：前三sourceAsset原完整程序同；后两个仅逆精确历史package literal后，原statements/moduleBindings与**已存原摘要**同。原442两公共出口最终指同一GC owner，首诊断Locale2、Mist6＋copyEventData完整声明同。本后继额外纳ids所依赖的id，首诊断原结果不覆盖。

## 两源与后处理

- `source-edits.json`：after Root37阶段的两个完整前态／后态与11顺序精确片段。
- `candidates/tooling/refactor/fixture-manifest.ts`：仅精确2sourceAsset、2specifier、原named/type模式逆literal；完整程序其它内容仍进原摘要。
- `candidates/tooling/refactor/fixture-source-relocations.test.ts`：原6声明完整不动，另增3个`historical fixture package retirement`声明；不复旧3或MCP3。
- `fixture-metadata-successor.cjs`：原metadata脚本另存原字节；写任何current元数据前先走新公开链／声明证据，再要求原5sourceAsset program/module摘要。不会把原摘要改为新值。

## 证明范围

固定442703cd原Git package roots／reexport链与当前GC package/root必须终止于实际原契约叶。当前只在匹配这两个真实sourceAsset时登记5个精确公开GC文件（package.json、src/index.ts、locale.ts、facts/mist-raven.ts、inert-event-data.ts），原mode／当前逐层symlink拒绝；不授backend生产value／任意package映射。

10个完整打印声明：Locale/LOCALES；Mist的MIST_RAVEN_EVENT_TYPES/readMistRavenFact/MistRavenEventType/MistRavenFact/id/ids/exact；copyEventData。三物理叶的**全部运行语句**额外比较，允许新增明确擦除的接口／type alias／type-only import/export，不允许新增value import或顶层绑定遮蔽原词法依赖。Mist新PlayerAlchemist/PlayerRaven DTO和BoardConfig类型是另外已交付契约，不伪称整模块全文相同。

原MCP mode/symlink故障仍在第一个audit asset的module relocation处抛出；GC历史证据按asset在原module relocation后检查，全局只登记路径字符串。因此原临时clone无需复制无关GC文件，不改变原错误优先。

## Root唯一后续命令（均未执行）

```sh
bun --no-env-file /tmp/awa-owned-layout-fixture-history-repair/apply.cjs --repository /home/hby/dev/AI-Werewolf-Arena --apply --receipt /tmp/awa-owned-layout-fixture-history-repair/applied-receipt.json
bun --no-env-file /tmp/awa-owned-layout-fixture-history-repair/fixture-metadata-successor.cjs --repository /home/hby/dev/AI-Werewolf-Arena --before-commit 6025b64bca6d57c1d0965fdecf5328a8b897ef4c --map /tmp/awa-owned-layout-map.json --apply --receipt /tmp/awa-owned-layout-fixture-history-repair/metadata-receipt.json
bun --no-env-file test tooling/refactor/fixture-source-relocations.test.ts --test-name-pattern 'historical fixture package retirement'
```

原37包的MCP3可按其原唯一filter首次执行；无需运行原3声明。后继2tool source的类型／完整文本差量由Root合流安排，作者不执行检查。不复672机械fullproof，不修改原origin／acceptance／suite／payload／模型字面或旧转发API。

## 首运行前的输入配对自审

首TMP deb94/source-edits dc480 已保 first-prepared 快照。自审发现仅以 current filename 做纯程序逆路由时，清单若换origin不能绕过固定证明；后继parser对这两currentPath强制原originPath/442，纯证据函数也明确拒wrong origin。第3新声明加两个独立负面断言；没有运行红，也未变更任何已执行输入。

纯sourceProgramContract也复用调用方已有sourceAssets/mappings核原／当前pair后才启逆路由，已知current文件配错orig即拒；新3声明传真实pair，另有wrong pair字面负例。parser/固定Git证据的原点约束继续保留。此为Pref与作者同一静态边界的首执行前集中校准，没有额外生产API或新映射框架。
