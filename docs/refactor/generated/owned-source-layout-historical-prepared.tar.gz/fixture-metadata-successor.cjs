#!/usr/bin/env node
/** Root 显式执行的有限 current 元数据迁移器。只读冻结 Git 与当前公开声明，不运行fixture适配器／玩法。 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const cp = require('node:child_process');
const {createRequire} = require('node:module');
const {pathToFileURL} = require('node:url');
const args = process.argv.slice(2);
const option = (k) => {const i=args.indexOf(k);return i < 0 ? undefined : args[i+1];};
const root=path.resolve(option('--repository') || '.');
const beforeCommit=option('--before-commit');
if (!beforeCommit || !/^[a-f0-9]{40}$/.test(beforeCommit) || !option('--map')) throw Error('explicit_full_before_commit_and_map_required');
const mappings=JSON.parse(fs.readFileSync(option('--map'),'utf8')).mapping;
const moves=new Map(mappings.map((r)=>[r.from,r.to]));
const digest=(b)=>crypto.createHash('sha256').update(b).digest('hex');
const mainPath='tooling/refactor/fixtures/manifest.json';
const originalType='backend/src/ai/integrations/acp/acp_mcp_bridge.ts';
const currentType='backend/src/adapters/acp/acp-mcp-bridge.ts';
if (moves.get(originalType)!==currentType) throw Error('type_route_changed');
function safe(relative) {
 if (path.isAbsolute(relative) || relative.includes('\\') || relative.split('/').some((x)=>!x||x==='.'||x==='..'||
  ['.git','.codex','.agents','.aws','node_modules'].includes(x)||x.startsWith('.env'))) throw Error('public_path_required:'+relative);
 const parts=relative.split('/');
 for(let i=1;i<=parts.length;i++) {
  const stat=fs.lstatSync(path.join(root,...parts.slice(0,i)));
  if(stat.isSymbolicLink() || (i<parts.length?!stat.isDirectory():!stat.isFile())) throw Error('regular_public_file_required:'+relative);
 }
 return fs.readFileSync(path.join(root,relative));
}
function gitFile(commit,relative) {
 if(!/^[a-f0-9]{40}$/.test(commit) || relative.includes('..') || relative.startsWith('/') || relative.includes('\\')) throw Error('git_identity_required');
 const line=cp.execFileSync('git',['ls-tree',commit,'--',relative],{cwd:root,encoding:'utf8',maxBuffer:1024*1024}).trim();
 const match=/^(100644|100755) blob ([a-f0-9]{40})\t(.+)$/.exec(line);
 if(!match || match[3]!==relative)throw Error('regular_git_blob_required:'+relative);
 return {mode:match[1],blob:match[2],bytes:cp.execFileSync('git',['show',`${commit}:${relative}`],{cwd:root,maxBuffer:64*1024*1024})};
}
(async()=>{
 // 只加载纯工具声明读取器；不通过新模块名 import 生产 bridge。
 const {parseFixtureManifest,sourceDeclarationContract,sourceProgramContract,sourcePackageRelocationEvidence,deriveLocalFixtureManifest}=
  await import(pathToFileURL(path.join(root,'tooling/refactor/fixture-manifest.ts')).href);
 const ts=createRequire(path.join(root,'backend/package.json'))('typescript');
 const initialBytes=safe(mainPath), initial=parseFixtureManifest(initialBytes.toString('utf8'));
 const next=structuredClone(initial);
 const immutableBefore=digest(JSON.stringify({baseline:initial.baseline,policy:initial.policy,
  origins:initial.files.map(({originPath,sha256,bytes,owner,kind,suiteId,metadata})=>({originPath,sha256,bytes,owner,kind,suiteId,metadata})),suites:initial.suites}));
 const previous=gitFile(beforeCommit,originalType),moved=safe(currentType);
 if(previous.mode!=='100644')throw Error('type_origin_mode_100644_required');
 const beforeDecl=sourceDeclarationContract(ts,previous.bytes.toString('utf8'),originalType,'AcpMcpServerConfig',true);
 const afterDecl=sourceDeclarationContract(ts,moved.toString('utf8'),currentType,'AcpMcpServerConfig',true);
 if(beforeDecl!==afterDecl)throw Error('actual_complete_type_declaration_changed');
 const typeRelocation={originPath:originalType,currentPath:currentType,originCommit:beforeCommit,
  bindings:[{name:'AcpMcpServerConfig',declarationSha256:digest(beforeDecl)}]};
 const adapters=new Set(['backend/tests/fixtures/acp/audit-agent.ts','backend/tests/fixtures/acp/game-agent.ts']);
 const sourceProofs=[], historicalPackageProofs=[];
 const historicalInputs={
  'backend/tests/support/audit_summary_fixture.ts':{
   original:['packages/game-catalog/package.json','packages/game-catalog/src/index.ts','packages/game-contract/package.json','packages/game-contract/src/index.ts','packages/game-contract/src/locale.ts'],
   current:['packages/game-contract/package.json','packages/game-contract/src/index.ts','packages/game-contract/src/locale.ts']},
  'backend/tests/support/mist_raven_transport_oracle.ts':{
   original:['packages/game-text/package.json','packages/game-text/src/index.ts','packages/game-text/src/mist-raven.ts','packages/game-contract/package.json','packages/game-contract/src/facts/mist-raven.ts','packages/game-contract/src/inert-event-data.ts'],
   current:['packages/game-contract/package.json','packages/game-contract/src/facts/mist-raven.ts','packages/game-contract/src/inert-event-data.ts']},
 };
 for(const asset of next.sourceAssets) {
  const original=gitFile(asset.originCommit,asset.originPath).bytes;
  if(digest(original)!==asset.originalSha256 || original.length!==asset.originalBytes)throw Error('immutable_source_origin_changed:'+asset.originPath);
  if(adapters.has(asset.currentPath)) {
   if((asset.moduleRelocations || []).some((r)=>r.currentPath===currentType))throw Error('type_relocation_already_recorded');
   asset.moduleRelocations=[...(asset.moduleRelocations || []),structuredClone(typeRelocation)];
  }
  const current=safe(asset.currentPath);
  const historical=historicalInputs[asset.originPath];
  if(historical){
   const originalFiles=historical.original.map((p)=>{const item=gitFile(asset.originCommit,p);if(item.mode!=='100644')throw Error('historical_package_git_mode');return {path:p,text:item.bytes.toString('utf8')};});
   const currentFiles=historical.current.map((p)=>({path:p,text:safe(p).toString('utf8')}));
   const declarations=sourcePackageRelocationEvidence(ts,asset,originalFiles,currentFiles);
   historicalPackageProofs.push({originAsset:asset.originPath,currentAsset:asset.currentPath,originCommit:asset.originCommit,
    declarations:declarations.map(({path,name,statement})=>({path,name,completePrinterSha256:digest(statement)})),
    originalFiles:originalFiles.map(({path,text})=>({path,sha256:digest(text)})),currentFiles:currentFiles.map(({path,text})=>({path,sha256:digest(text)}))});
  }
  for(const relocation of asset.moduleRelocations || []) {
   const a=gitFile(relocation.originCommit,relocation.originPath).bytes.toString('utf8'),b=safe(relocation.currentPath).toString('utf8');
   const onlyTypes=relocation.originPath===originalType && relocation.currentPath===currentType;
   for(const binding of relocation.bindings) {
    const x=digest(sourceDeclarationContract(ts,a,relocation.originPath,binding.name,onlyTypes));
    const y=digest(sourceDeclarationContract(ts,b,relocation.currentPath,binding.name,onlyTypes));
    if(x!==binding.declarationSha256 || x!==y)throw Error('registered_complete_declaration_changed:'+binding.name);
   }
  }
  const a=sourceProgramContract(ts,original.toString('utf8'),asset.originPath,false,next.sourceAssets);
  const b=sourceProgramContract(ts,current.toString('utf8'),asset.currentPath,true,next.sourceAssets,asset.moduleRelocations);
  const program=digest(JSON.stringify(a.statements)),bindings=digest(JSON.stringify(a.moduleBindings));
  if(JSON.stringify(a)!==JSON.stringify(b) || program!==asset.programSha256 || bindings!==asset.moduleBindingsSha256)
   throw Error('original_program_or_module_binding_changed:'+asset.originPath);
  const old={sha256:asset.currentSha256,bytes:asset.currentBytes};
  asset.currentSha256=digest(current);asset.currentBytes=current.length;
  const artifact=next.files.find((r)=>r.originPath===asset.originPath);
  if(artifact){artifact.currentSha256=asset.currentSha256;artifact.currentBytes=asset.currentBytes;}
  sourceProofs.push({originPath:asset.originPath,currentPath:asset.currentPath,oldCurrent:old,
   currentSha256:asset.currentSha256,currentBytes:asset.currentBytes,originalProgramSha256:program,originalModuleBindingsSha256:bindings,
   originalDigestsRetained:true,newProductionTypeRelocation:adapters.has(asset.currentPath)});
 }
 const payloads=[];
 for(const artifact of next.files) {
  const target=moves.get(artifact.currentPath);
  if(!target)continue;
  if(!artifact.currentPath.endsWith('.json') || !artifact.currentPath.includes('time-consort'))throw Error('unexpected_fixture_move:'+artifact.currentPath);
  const bytes=safe(target);
  if(digest(bytes)!==artifact.currentSha256 || bytes.length!==artifact.currentBytes)throw Error('literal_archive_bytes_changed:'+target);
  payloads.push({originPath:artifact.originPath,from:artifact.currentPath,to:target,sha256:artifact.currentSha256,bytes:artifact.currentBytes});
  artifact.currentPath=target;
 }
 if(payloads.length!==8)throw Error('expected_exact_time_payload8');
 const derivedTargets=[];
 for(const descriptor of next.derivedManifests) {
  const target=moves.get(descriptor.path);
  if(target){derivedTargets.push({from:descriptor.path,to:target});descriptor.path=target;}
 }
 if(derivedTargets.length!==4)throw Error('expected_exact_time_derived4');
 next.coverage.currentBytes=next.files.reduce((n,r)=>n+r.currentBytes,0);
 next.coverage.exactBytesFiles=next.files.filter((r)=>r.sha256===r.currentSha256&&r.bytes===r.currentBytes).length;
 next.coverage.mechanicalSourceFiles=next.files.length-next.coverage.exactBytesFiles;
 const final=parseFixtureManifest(JSON.stringify(next));
 const immutableAfter=digest(JSON.stringify({baseline:final.baseline,policy:final.policy,
  origins:final.files.map(({originPath,sha256,bytes,owner,kind,suiteId,metadata})=>({originPath,sha256,bytes,owner,kind,suiteId,metadata})),suites:final.suites}));
 if(immutableBefore!==immutableAfter)throw Error('origin_or_semantic_metadata_changed');
 const outputs=[{path:mainPath,bytes:Buffer.from(JSON.stringify(final,null,2)+'\n')}];
 // 只有 ACP 子清单和四个 Time 子清单受这次 current 变化影响；不格式化其余251份。
 const selected=['backend/tests/fixtures/acp/manifest.json',...derivedTargets.map((r)=>r.to)];
 for(const target of selected) outputs.push({path:target,bytes:Buffer.from(JSON.stringify(deriveLocalFixtureManifest(final,target),null,2)+'\n')});
 const changes=outputs.map((r)=>{const before=safe(r.path);return {path:r.path,beforeSha256:digest(before),beforeBytes:before.length,
  afterSha256:digest(r.bytes),afterBytes:r.bytes.length,bytes:r.bytes};});
 if(args.includes('--apply'))for(const r of changes)fs.writeFileSync(path.join(root,r.path),r.bytes);
 const receipt={status:args.includes('--apply')?'APPLIED_METADATA_NOT_ACCEPTED':'PREPARED_METADATA_NOT_APPLIED',beforeCommit,
  typeEvidence:{originPath:originalType,currentPath:currentType,originMode:previous.mode,originBlob:previous.blob,
   originFileSha256:digest(previous.bytes),currentFileSha256:digest(moved),completeDeclarationSha256:digest(beforeDecl)},
  sourceAssets:sourceProofs,historicalPackageProofs,timePayloads:payloads,derivedTargets,immutableOriginalMetadataSha256:immutableAfter,
  files:changes.map(({bytes,...r})=>r),limits:['不执行fixture脚本、玩法、模型、types或结构gate。',
   '原source program/moduleBinding摘要必须匹配，不能重算成新接受值。','仅current路径／字节摘要和新同声明relocation可变；原source/metadata/suite/policy/acceptance保持。']};
 if(option('--receipt'))fs.writeFileSync(path.resolve(option('--receipt')),JSON.stringify(receipt,null,2)+'\n');
 process.stdout.write(JSON.stringify({status:receipt.status,sourceAssets:sourceProofs.length,timePayloads:payloads.length,derivedManifests:selected.length,files:changes.length})+'\n');
})().catch((e)=>{process.stderr.write(String(e.stack || e)+'\n');process.exitCode=1;});
