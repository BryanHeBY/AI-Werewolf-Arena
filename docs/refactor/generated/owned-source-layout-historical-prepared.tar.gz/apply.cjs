/** Root 专用两源窄应用器；仅 after37 实际beforeSHA匹配后应用，失败不刷新原历史摘要。 */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const a=process.argv.slice(2),arg=(k)=>{const i=a.indexOf(k);return i<0?undefined:a[i+1];};
const root=path.resolve(arg('--repository')||'.'),d=JSON.parse(fs.readFileSync(path.join(__dirname,'source-edits.json'),'utf8'));
const hash=(b)=>crypto.createHash('sha256').update(b).digest('hex');
function safe(p){const parts=p.split('/');if(path.isAbsolute(p)||parts.some(x=>!x||x==='.'||x==='..'||x.startsWith('.env')||['.git','.aws','.codex','node_modules'].includes(x)))throw Error('history_repair_path');
for(let i=1;i<=parts.length;i++){const s=fs.lstatSync(path.join(root,...parts.slice(0,i)));if(s.isSymbolicLink()||(i<parts.length?!s.isDirectory():!s.isFile()))throw Error('history_repair_regular_file');}return path.join(root,p);}
const writes=d.files.map((r)=>{
 const before=fs.readFileSync(safe(r.path));if(hash(before)!==r.beforeSha256)throw Error('history_repair_stage_drift:'+r.path);
 let text=before.toString('utf8');for(const e of r.edits){if(e.append)text+=e.after;else{if(text.split(e.before).length-1!==e.count)throw Error('history_repair_anchor:'+e.purpose);text=text.split(e.before).join(e.after);}}
 if(hash(text)!==r.afterSha256)throw Error('history_repair_candidate_drift');return {path:r.path,text,beforeSha256:r.beforeSha256,afterSha256:r.afterSha256,edits:r.edits.length};});
if(a.includes('--apply'))for(const r of writes)fs.writeFileSync(safe(r.path),r.text);
const receipt={status:a.includes('--apply')?'APPLIED_NOT_CHECKED':'PREPARED_NOT_APPLIED',files:writes.map(({text,...r})=>r),limits:['只两tool源和原6+新增3声明，未修改fixture metadata或原program/binding。','此为历史退桥准入差异，不冒672机械同算法证明。']};
if(arg('--receipt'))fs.writeFileSync(arg('--receipt'),JSON.stringify(receipt,null,2)+'\n');process.stdout.write(JSON.stringify(receipt)+'\n');
