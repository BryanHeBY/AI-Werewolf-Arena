from pathlib import Path
import json,hashlib
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-owned-layout-fixture-history-repair');d=json.load(open(O/'source-edits.json'))
# 精确公共package名也属于终点，避免名字变更仍借原物理文件获准。
r=d['files'][0];a='''if (!record(value) || !record(value.exports) || value.exports[key] !== target)''';b='''if (!record(value) || value.name !== `@ai-werewolf-arena/${filename.split("/")[1]}` || !record(value.exports) || value.exports[key] !== target)'''
if r['after'].count(a)!=1:raise ValueError('package name anchor')
r['after']=r['after'].replace(a,b)
for e in r['edits']:e['after']=e['after'].replace(a,b)
r['afterSha256']=hashlib.sha256(r['after'].encode()).hexdigest();(O/'candidates'/r['path']).write_text(r['after'])
p='tooling/refactor/fixture-source-relocations.test.ts';raw=(R/p).read_bytes();text=raw.decode();edits=[]
a='''  sourceDeclarationContract,
  type FixtureManifest,''';b='''  sourceDeclarationContract,
  sourcePackageRelocationEvidence,
  type FixtureManifest,'''
if text.count(a)!=1:raise ValueError('test import anchor')
text=text.replace(a,b);edits.append({'before':a,'after':b,'count':1,'purpose':'新有限历史package退桥证据接口；原6声明完整保持'})
append=r'''

// 新历史公共退桥仅逆两个真实资产的导入；不修改原源程序摘要，也不扩大生产模块读取。
const historicalAudit = "backend/tests/support/builders/audit-summary.ts";
const historicalMist = "backend/tests/support/features/mist-raven/oracles/transport.ts";

test("historical fixture package retirement normalizes only the two exact named import forms", () => {
  const beforeAudit = 'import type { Locale } from "@ai-werewolf-arena/game-catalog"; export const heading: Locale = "en";';
  const currentAudit = beforeAudit.replace("@ai-werewolf-arena/game-catalog", "@ai-werewolf-arena/game-contract");
  expect(sourceProgramContract(ts, currentAudit, historicalAudit, true, []))
    .toEqual(sourceProgramContract(ts, beforeAudit, "backend/tests/support/audit_summary_fixture.ts", false, []));
  const beforeMist = 'import { MIST_RAVEN_EVENT_TYPES, readMistRavenFact } from "@ai-werewolf-arena/game-text"; const wire = "raven_unsealed"; const fact = readMistRavenFact(wire, { day: 1 });';
  const currentMist = beforeMist.replace("@ai-werewolf-arena/game-text", "@ai-werewolf-arena/game-contract/facts/mist-raven");
  expect(sourceProgramContract(ts, currentMist, historicalMist, true, []))
    .toEqual(sourceProgramContract(ts, beforeMist, "backend/tests/support/mist_raven_transport_oracle.ts", false, []));
  expect(sourceProgramContract(ts, currentMist.replace('"raven_unsealed"', '"literal_changed"'), historicalMist, true, []))
    .not.toEqual(sourceProgramContract(ts, beforeMist, "old.ts", false, []));
});

test("historical fixture package retirement retains path binding mode alias and body rejection", () => {
  const current = 'import type { Locale } from "@ai-werewolf-arena/game-contract"; export const heading: Locale = "en";';
  const original = current.replace("@ai-werewolf-arena/game-contract", "@ai-werewolf-arena/game-catalog");
  const expected = sourceProgramContract(ts, original, "old.ts", false, []);
  expect(sourceProgramContract(ts, current, "backend/tests/support/builders/other.ts", true, [])).not.toEqual(expected);
  expect(() => sourceProgramContract(ts, current.replace("game-contract", "other-contract"), historicalAudit, true, []))
    .toThrow("historical_package_import_missing");
  expect(() => sourceProgramContract(ts, current.replace("import type", "import"), historicalAudit, true, []))
    .toThrow("historical_package_import_mode");
  expect(() => sourceProgramContract(ts, current.replace("Locale }", "Role }"), historicalAudit, true, []))
    .toThrow("historical_package_import_binding");
  expect(() => sourceProgramContract(ts, current.replace("{ Locale }", "* as Types"), historicalAudit, true, []))
    .toThrow("historical_package_requires_named_import");
  expect(sourceProgramContract(ts, current.replaceAll("Locale", "Local").replace("{ Local }", "{ Locale as Local }"), historicalAudit, true, []))
    .not.toEqual(expected);
  expect(sourceProgramContract(ts, current.replace('"en"', '"zh-CN"'), historicalAudit, true, [])).not.toEqual(expected);
  expect(() => sourceProgramContract(ts,
    'import type { MIST_RAVEN_EVENT_TYPES, readMistRavenFact } from "@ai-werewolf-arena/game-contract/facts/mist-raven";', historicalMist, true, []))
    .toThrow("historical_package_import_mode");
});

test("historical fixture package retirement requires the original export chain and complete dependency declarations", () => {
  const asset = { originPath: "backend/tests/support/audit_summary_fixture.ts", currentPath: historicalAudit,
    originCommit: "442703cded8a5eb8c749bfcd3ce29b1d6a04e1cc" };
  const locale = 'export const LOCALES = ["zh-CN", "en"] as const; export type Locale = (typeof LOCALES)[number];';
  const originalFiles = [
    { path: "packages/game-catalog/package.json", text: '{"name":"@ai-werewolf-arena/game-catalog","exports":{".":"./src/index.ts"}}' },
    { path: "packages/game-catalog/src/index.ts", text: 'export type { Locale } from "@ai-werewolf-arena/game-contract";' },
    { path: "packages/game-contract/package.json", text: '{"name":"@ai-werewolf-arena/game-contract","exports":{".":"./src/index.ts"}}' },
    { path: "packages/game-contract/src/index.ts", text: 'export type { Locale } from "./locale";' },
    { path: "packages/game-contract/src/locale.ts", text: locale },
  ];
  const currentFiles = originalFiles.filter((entry) => entry.path.startsWith("packages/game-contract/"));
  expect(sourcePackageRelocationEvidence(ts, asset, originalFiles, currentFiles).map((entry) => entry.name))
    .toEqual(["LOCALES", "Locale"]);
  expect(() => sourcePackageRelocationEvidence(ts, asset, originalFiles, currentFiles.map((entry) =>
    entry.path.endsWith("/index.ts") ? { ...entry, text: 'export type { Locale } from "./other";' } : entry)))
    .toThrow("historical_package_reexport_endpoint");
  expect(() => sourcePackageRelocationEvidence(ts, asset, originalFiles, currentFiles.map((entry) =>
    entry.path.endsWith("/locale.ts") ? { ...entry, text: locale.replace('["zh-CN", "en"]', '["en"]') } : entry)))
    .toThrow("historical_package_complete_declaration_drift");
  expect(() => sourcePackageRelocationEvidence(ts, { ...asset, originCommit: "a".repeat(40) }, originalFiles, currentFiles))
    .toThrow("historical_package_origin_commit");
});
'''
text+=append;edits.append({'before':'','after':append,'count':1,'append':True,'purpose':'只新增三条历史准入独立声明，原6声明不重复'})
d['files'].append({'path':p,'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':hashlib.sha256(text.encode()).hexdigest(),'before':raw.decode(),'after':text,'edits':edits});q=O/'candidates'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(text)
(O/'source-edits.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
# 原metadata脚本历史保留；后继在写任何current数据前核固定公开转发/声明闭包。
p0=Path('/tmp/awa-owned-layout-operational-adaptations/fixture-metadata.cjs');before=p0.read_text();after=before
old='const {parseFixtureManifest,sourceDeclarationContract,sourceProgramContract,deriveLocalFixtureManifest}='
new='const {parseFixtureManifest,sourceDeclarationContract,sourceProgramContract,sourcePackageRelocationEvidence,deriveLocalFixtureManifest}='
if after.count(old)!=1:raise ValueError('metadata import')
after=after.replace(old,new)
old=''' const sourceProofs=[];
 for(const asset of next.sourceAssets) {'''
new=''' const sourceProofs=[], historicalPackageProofs=[];
 const historicalInputs={
  'backend/tests/support/audit_summary_fixture.ts':{
   original:['packages/game-catalog/package.json','packages/game-catalog/src/index.ts','packages/game-contract/package.json','packages/game-contract/src/index.ts','packages/game-contract/src/locale.ts'],
   current:['packages/game-contract/package.json','packages/game-contract/src/index.ts','packages/game-contract/src/locale.ts']},
  'backend/tests/support/mist_raven_transport_oracle.ts':{
   original:['packages/game-text/package.json','packages/game-text/src/index.ts','packages/game-text/src/mist-raven.ts','packages/game-contract/package.json','packages/game-contract/src/facts/mist-raven.ts','packages/game-contract/src/inert-event-data.ts'],
   current:['packages/game-contract/package.json','packages/game-contract/src/facts/mist-raven.ts','packages/game-contract/src/inert-event-data.ts']},
 };
 for(const asset of next.sourceAssets) {'''
if after.count(old)!=1:raise ValueError('metadata history inputs')
after=after.replace(old,new)
old='''  const current=safe(asset.currentPath);
  for(const relocation'''
new='''  const current=safe(asset.currentPath);
  const historical=historicalInputs[asset.originPath];
  if(historical){
   const originalFiles=historical.original.map((p)=>{const item=gitFile(asset.originCommit,p);if(item.mode!=='100644')throw Error('historical_package_git_mode');return {path:p,text:item.bytes.toString('utf8')};});
   const currentFiles=historical.current.map((p)=>({path:p,text:safe(p).toString('utf8')}));
   const declarations=sourcePackageRelocationEvidence(ts,asset,originalFiles,currentFiles);
   historicalPackageProofs.push({originAsset:asset.originPath,currentAsset:asset.currentPath,originCommit:asset.originCommit,
    declarations:declarations.map(({path,name,statement})=>({path,name,completePrinterSha256:digest(statement)})),
    originalFiles:originalFiles.map(({path,text})=>({path,sha256:digest(text)})),currentFiles:currentFiles.map(({path,text})=>({path,sha256:digest(text)}))});
  }
  for(const relocation'''
if after.count(old)!=1:raise ValueError('metadata proof call')
after=after.replace(old,new)
old='''  sourceAssets:sourceProofs,timePayloads:payloads''';new='''  sourceAssets:sourceProofs,historicalPackageProofs,timePayloads:payloads'''
if after.count(old)!=1:raise ValueError('metadata receipt')
after=after.replace(old,new)
(O/'fixture-metadata-successor.cjs').write_text(after)
(O/'metadata-successor-before.cjs').write_text(before)
(O/'metadata-successor-edits.json').write_text(json.dumps({'status':'PREPARED_NOT_RUN','originalPath':str(p0),'originalSha256':hashlib.sha256(before.encode()).hexdigest(),'successorPath':str(O/'fixture-metadata-successor.cjs'),'successorSha256':hashlib.sha256(after.encode()).hexdigest(),'note':'原cde145失败脚本原字节保，先真正public链/10完整声明依赖，再要求五source原program/binding摘要；不更新原接受值'},ensure_ascii=False,indent=2)+'\n')
print('prepared 2 tool sources',sum(len(r['edits'])for r in d['files']),'exact edits, new3 declarations; metadata successor not run')
