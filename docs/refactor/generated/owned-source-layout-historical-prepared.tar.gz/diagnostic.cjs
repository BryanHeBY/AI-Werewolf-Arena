/** Root 唯一执行的有限诊断。只读Git/当前公开输入，输出a/b与既有摘要；不写manifest或源码。 */
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const {createRequire}=require('node:module'),{pathToFileURL}=require('node:url');
const args=process.argv.slice(2),arg=(k)=>{const i=args.indexOf(k);return i<0?undefined:args[i+1];};
const root=path.resolve(arg('--repository')||'.'),beforeCommit='6025b64bca6d57c1d0965fdecf5328a8b897ef4c';
const hash=(b)=>crypto.createHash('sha256').update(b).digest('hex');
const git=(commit,p)=>cp.execFileSync('git',['show',`${commit}:${p}`],{cwd:root,maxBuffer:16*1024*1024}).toString('utf8');
(async()=>{
 const {sourceProgramContract,sourceDeclarationContract}=await import(pathToFileURL(path.join(root,'tooling/refactor/fixture-manifest.ts')).href);
 const ts=createRequire(path.join(root,'backend/package.json'))('typescript');
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'tooling/refactor/fixtures/manifest.json'),'utf8'));
 const typeOrigin='backend/src/ai/integrations/acp/acp_mcp_bridge.ts',typeCurrent='backend/src/adapters/acp/acp-mcp-bridge.ts';
 const typeDecl=sourceDeclarationContract(ts,git(beforeCommit,typeOrigin),typeOrigin,'AcpMcpServerConfig',true);
 const typeRelocation={originPath:typeOrigin,currentPath:typeCurrent,originCommit:beforeCommit,bindings:[{name:'AcpMcpServerConfig',declarationSha256:hash(typeDecl)}]};
 const packageRoutes=[
  {originAsset:'backend/tests/support/audit_summary_fixture.ts',currentAsset:'backend/tests/support/builders/audit-summary.ts',
   original:'@ai-werewolf-arena/game-catalog',current:'@ai-werewolf-arena/game-contract',names:['Locale'],typeOnly:true,
   physical:'packages/game-contract/src/locale.ts',declarations:['LOCALES','Locale'],
   oldChain:['packages/game-catalog/src/index.ts','packages/game-contract/src/index.ts']},
  {originAsset:'backend/tests/support/mist_raven_transport_oracle.ts',currentAsset:'backend/tests/support/features/mist-raven/oracles/transport.ts',
   original:'@ai-werewolf-arena/game-text',current:'@ai-werewolf-arena/game-contract/facts/mist-raven',names:['MIST_RAVEN_EVENT_TYPES','readMistRavenFact'],typeOnly:false,
   physical:'packages/game-contract/src/facts/mist-raven.ts',declarations:['MIST_RAVEN_EVENT_TYPES','readMistRavenFact','MistRavenEventType','MistRavenFact','ids','exact'],
   oldChain:['packages/game-text/src/index.ts','packages/game-text/src/mist-raven.ts']}
 ];
 function declarations(text,file,names){
  const ast=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true),p=ts.createPrinter({removeComments:true,newLine:ts.NewLineKind.LineFeed});
  return names.map((name)=>{
   const nodes=ast.statements.filter((n)=>n.name?.text===name || (ts.isVariableStatement(n)&&n.declarationList.declarations.some((d)=>ts.isIdentifier(d.name)&&d.name.text===name)));
   if(nodes.length!==1)throw Error('diagnostic_named_declaration_missing:'+file+':'+name);
   const printed=p.printNode(ts.EmitHint.Unspecified,nodes[0],ast);
   return {name,text:printed,sha256:hash(printed)};
  });
 }
 const rows=[];
 for(const asset of manifest.sourceAssets){
  const original=git(asset.originCommit,asset.originPath),current=fs.readFileSync(path.join(root,asset.currentPath),'utf8');
  const relocations=[...(asset.moduleRelocations||[])];
  if(['backend/tests/fixtures/acp/audit-agent.ts','backend/tests/fixtures/acp/game-agent.ts'].includes(asset.currentPath))relocations.push(typeRelocation);
  const a=sourceProgramContract(ts,original,asset.originPath,false,manifest.sourceAssets),b=sourceProgramContract(ts,current,asset.currentPath,true,manifest.sourceAssets,relocations);
  const route=packageRoutes.find((r)=>r.originAsset===asset.originPath&&r.currentAsset===asset.currentPath);
  let restored,restoredContract;
  if(route){
   const literal=`"${route.current}"`;
   if(current.split(literal).length-1!==1)throw Error('diagnostic_exact_package_literal_count');
   restored=current.replace(literal,`"${route.original}"`);
   restoredContract=sourceProgramContract(ts,restored,asset.currentPath,true,manifest.sourceAssets,relocations);
  }
  rows.push({originPath:asset.originPath,currentPath:asset.currentPath,originCommit:asset.originCommit,
   currentSameAs6025:current===git(beforeCommit,asset.currentPath),stored:{program:asset.programSha256,bindings:asset.moduleBindingsSha256},
   original:{program:hash(JSON.stringify(a.statements)),bindings:hash(JSON.stringify(a.moduleBindings))},
   current:{program:hash(JSON.stringify(b.statements)),bindings:hash(JSON.stringify(b.moduleBindings))},aEqualsB:JSON.stringify(a)===JSON.stringify(b),
   statementDifferences:a.statements.flatMap((v,i)=>v===b.statements[i]?[]:[{index:i,original:v,current:b.statements[i]}]),
   moduleBindingDifferences:a.moduleBindings.flatMap((v,i)=>v===b.moduleBindings[i]?[]:[{index:i,original:v,current:b.moduleBindings[i]}]),
   diagnosticOnlyRestoredPackage:restoredContract?{aEqualsRestored:JSON.stringify(a)===JSON.stringify(restoredContract),program:hash(JSON.stringify(restoredContract.statements)),bindings:hash(JSON.stringify(restoredContract.moduleBindings))}:undefined});
 }
 const proofs=[];
 for(const route of packageRoutes){
  const asset=manifest.sourceAssets.find((a)=>a.originPath===route.originAsset);
  const old=git(asset.originCommit,route.physical),current=fs.readFileSync(path.join(root,route.physical),'utf8');
  const a=declarations(old,route.physical,route.declarations),b=declarations(current,route.physical,route.declarations);
  const dependencyPath=route.typeOnly?undefined:'packages/game-contract/src/inert-event-data.ts';
  let dependency;
  if(dependencyPath){
   const x=declarations(git(asset.originCommit,dependencyPath),dependencyPath,['copyEventData']);
   const y=declarations(fs.readFileSync(path.join(root,dependencyPath),'utf8'),dependencyPath,['copyEventData']);
   dependency={path:dependencyPath,original:x,current:y,same:JSON.stringify(x)===JSON.stringify(y),note:'仅明确原readMist依赖，不代表任意全仓或未来依赖等价'};
  }
  proofs.push({...route,originCommit:asset.originCommit,original:a,current:b,sameCompleteDeclarations:JSON.stringify(a)===JSON.stringify(b),dependency,
   originalForwardingFiles:route.oldChain.map((p)=>({path:p,text:git(asset.originCommit,p)})),
   originalPackageFiles:(route.typeOnly?['packages/game-catalog/package.json','packages/game-contract/package.json']:['packages/game-text/package.json','packages/game-contract/package.json']).map((p)=>({path:p,text:git(asset.originCommit,p)})),
   currentContractPackage:fs.readFileSync(path.join(root,'packages/game-contract/package.json'),'utf8'),
   currentContractRoot:route.typeOnly?fs.readFileSync(path.join(root,'packages/game-contract/src/index.ts'),'utf8'):undefined});
 }
 const result={stage:'READ_ONLY_DIAGNOSTIC_NO_MUTATION',beforeCommit,rows,proofs,
  limits:['恢复specifier只是诊断，未授任意package映射或backend生产值导入。','未修改origin/program/binding摘要或任何manifest。','不执行fixture、生产、类型、门禁或旧测试。','独立原forwarding退休改变模块加载拓扑，不宣称整环境JS等价。']};
 if(arg('--output'))fs.writeFileSync(path.resolve(arg('--output')),JSON.stringify(result,null,2)+'\n');
 process.stdout.write(JSON.stringify({stage:result.stage,rows:rows.map(({originPath,aEqualsB,diagnosticOnlyRestoredPackage})=>({originPath,aEqualsB,diagnosticOnlyRestoredPackage})),proofs:proofs.map((p)=>({path:p.physical,same:p.sameCompleteDeclarations,dependencySame:p.dependency?.same}))})+'\n');
})().catch((e)=>{process.stderr.write(String(e.stack||e)+'\n');process.exitCode=1;});
