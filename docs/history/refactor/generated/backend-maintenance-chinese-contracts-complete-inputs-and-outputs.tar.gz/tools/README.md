# 553 条已审中文注释：Root 执行工具

状态：**工具和规范输入已准备；prepare/apply/prove/heads 均未执行，仓库未写入**。

三份原稿共553候选、439旧源：非场景372／283文件＋场景172／150文件＋生产9／6文件。N4 的 English 首头已由 ops 及 Root 职责精度修订换为准确中文，必须锁 actual `a55e675be1d607825188038ae737c4b90a0e6113` 已提交首头验证并记 covered；其余552项（含7条新增重要逻辑注释）计划应用，预计438实际变源。数量是计划，不是已通过结果。

## 真实前态与写入边界

1. 必填 `--base` 完整40位 Git，必须等于实际 HEAD，并是6025的后继；6025本身会在任何工具库／源码解析前拒绝。Root先提交672＋ops，再提交5个 app/checkpoint owner后使用新Git；不在当前WIP捕“正式before”。
2. 必填 `--primary-map` 672路线和独立 `--checkpoint-map` 5路线，可另加显式 `--map` 承接Root已批准小命名后继；只精确链式解析，不搜索basename／旧路径fallback。
3. 每个目标文件都从该新Git捕完整文本、mode、blob、SHA、bytes，普通工作树文件必须逐字同Git，并按 Git 的 owner executable 位核 `100644/100755`；不把仅SHA相同的chmod漂移当同源，也不宣称记录全部POSIX权限。原6025仅核已审评论的原真实AST范围／重复ordinal，不把原imports写回。
4. `prepare` 只写 `--out` 计划；`apply` 在**全部文件/控制/原Git/SHA/mode断言结束后**，先从 loaded plan 的真实Git before 重算552精确评论范围、完整 after／SHA／bytes／逆范围、553唯一记录和N4覆盖计数，核真实评论边界、完整代码tokens及保护字段，再写重算结果；不独立信任 plan.after。不得整文件copy旧draft。它按真实后继完整源构成 after，保现 imports、声明、机器字段及body。
5. I/O写入本身不是事务；apply中途错误保存已写前缀，不自动回滚。Root持Git/进度。

## 评论定位

- 使用 TypeScript 实际 AST 节点／token 的 leading/trailing comment ranges，合并真实范围；不将字符串／正则／template正文里的 `//` 当评论。
- 每条替换先在6025原源核UTF16 anchor与包围的真实comment，再按同raw评论的重复次数／ordinal在真实新Git重定位；重复数不符即失败，不取“首个相同字符串”。P02这种JSDoc单行精度先变为整comment的局部改文，P01同缩进边界精确处理。
- 七个插注锚必须对应真实AST代码节点起点、原kind／enclosing owner及相同ordinal，不可命中字符串或注释中伪代码。
- 只N4可covered，必须实际首comment精确等于 actual a55 已提交的「这组架构测试负责…」中文头；`n4-covered-head.json` 捕完整源/mode/blob/SHA，prepare 从该固定 Git 复核每字段及实际AST首头。旧 ops 候选缺测试层级词，不再作为覆盖依据；原工具稿保存在 `first-f0c76/`。记录旧稿未应用。不自动把其它找不到的锚当covered。
- 新替换必须保持原comment种类并且仅形成一份真实comment；插注强制行终止，不能把后续代码并进line comment；所有范围重叠／同起点歧义在任何写入前拒绝。

## 保护与完整证明

`prove` 在Root实际应用后只核这一batch：

- 全439完整程序的552范围精确逆回新Git before；covered文件也保持同源。
- 完整 typed AST（递归 `forEachChild`）、所有NodeArray及trailingComma；实际 `getChildren` 代码tokens（跳JSDoc文本，保独立JSDoc契约）逐项一致。
- directive／许可证完整评论原字节、JSDoc tag名／param和type表达式／类型参数／import标签，test/it/describe调用的实际首参数与所有ArrayLiteral结构保持。全部机器字符串、标题、矩阵同时由完整AST/tokens兜底；人类说明是否准确仍依据已经冻结的两peer与Root生产稿。
- 两种完整单文件 `transpileModule(removeComments)` ESNext＋CommonJS 输出逐字同；保存4个全量输出集合。这里不是“完整双build”或类型检查。
- manifest只读：从新Git捕当前登记，核受影响moduleReloc目标完整声明printer及原摘要，特别 `fixtureObject` 和 `ActorTransportPlan`。它们不是wholeleaf sourceAsset：**不伪造currentSHA、不改manifest**。若实际有sourceAsset current文件落进变源则prepare明确拒绝，交Root另裁。
- 同时保护工具控制与fixture manifest实际SHA及捕获Git executable mode；prepare/apply/prove/heads各读点均核mode，发现漂移就拒绝。

`heads` 只调用真实 `checkComments` 做这439源的首职责头shape核对，文档路径取同一新Git普通`.md`叶；不读取文档内容、不把形状当中文语义验收。后续若首红，只失败源精确修／窄桥，不重既有绿；本工具不自动启动任何后续命令。

## Root命令（尚未执行）

将 `<FULL_POST_LAYOUT_AND_CHECKPOINT_GIT>` 换Root实际提交后的完整SHA，`<ROOT_OUT>` 换Root选择的新证据目录。不得把文本占位原样执行。

```sh
bun --no-env-file /tmp/awa-chinese-comment-cohort-tools/comments.cjs prepare --repository /home/hby/dev/AI-Werewolf-Arena --base <FULL_POST_LAYOUT_AND_CHECKPOINT_GIT> --primary-map /tmp/awa-owned-layout-map.json --checkpoint-map /tmp/awa-app-checkpoint-owner-followup/proposal.json --out <ROOT_OUT>
bun --no-env-file /tmp/awa-chinese-comment-cohort-tools/comments.cjs apply --repository /home/hby/dev/AI-Werewolf-Arena --base <FULL_POST_LAYOUT_AND_CHECKPOINT_GIT> --plan <ROOT_OUT>/plan.json --out <ROOT_OUT>
bun --no-env-file /tmp/awa-chinese-comment-cohort-tools/comments.cjs prove --repository /home/hby/dev/AI-Werewolf-Arena --base <FULL_POST_LAYOUT_AND_CHECKPOINT_GIT> --plan <ROOT_OUT>/plan.json --out <ROOT_OUT>
bun --no-env-file /tmp/awa-chinese-comment-cohort-tools/comments.cjs heads --repository /home/hby/dev/AI-Werewolf-Arena --base <FULL_POST_LAYOUT_AND_CHECKPOINT_GIT> --plan <ROOT_OUT>/plan.json --out <ROOT_OUT>
```

Root可以prepare后先人工审计划，再授权apply。prove和heads独立命令可由Root并行首执行；不跑types、业务、模型或全gate。首脚本／raw／receipt均须保实际执行版本，任何工具红不冒产品红、不覆盖首失败。

## 尚未声称的结果

没有运行工具语法检查、TSC、test、commentCategory/checkComments、生成式完整proof或产品。`build-spec.py`只在TMP合并已审JSON，不读取当前WIP源码；其运行不等于任何上列验证。工具真正读源／proof／应用全部等Root新Git。

## N4 首工具稿后的精度修订

`first-f0c76/` 保存原完整工具稿及 ready `f0c76f3592ff93f18d536f3efd0455f2f888712059b861ecc2f6133470219842`。此次仅将 N4 精确覆盖锚改为已提交 a55 实际中文首头并补固定 Git 来源核；未运行工具，不将旧锚问题冒成运行失败。未来 `--base` 仍必须等待 Root 另笔 5 checkpoint owner 提交，不能因为 a55 已有准确首头就在该未完成阶段运行。

## 同行静态预检修订（未执行）

`first-fd633/` 保留 N4 修订后首准备 `fd6331a5dc6a3c098f20bcf5e688ecc6535fe19c954e2669c3d8f2f2573c39f3`。同行指出 loaded plan.after 应在全体写前由范围重算，以及仅核文本SHA未核 executable mode；此后继集中修两项。不是已执行的产品／工具失败，也没有新增测试或自跑命令。N4 仍锁 actual a55 的精确已提交首头；Root 另完成 5 checkpoint 后仍需按其稍后选定的新Git `--base` 执行。
