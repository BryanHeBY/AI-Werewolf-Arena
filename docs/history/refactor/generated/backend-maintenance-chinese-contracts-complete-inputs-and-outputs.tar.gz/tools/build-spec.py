"""只读三份已审译稿生成规范输入；不读取当前WIP源，不执行任何检查。"""
from pathlib import Path
import json,hashlib
O=Path('/tmp/awa-chinese-comment-cohort-tools');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=['/tmp/awa-backend-test-tooling-comments-non-scenarios-draft.json','/tmp/awa-scenario-chinese-comment-draft/comment-deltas.json','/tmp/awa-post-q2-backend-comments-proposal.json']
n,s,p=[json.load(open(f))for f in paths];records=[]
coveragePath=O/'n4-covered-head.json'
coverage=json.load(open(coveragePath));head=coverage['expectedHead']
if coverage['commit']!='a55e675be1d607825188038ae737c4b90a0e6113' or coverage['path']!='backend/tests/architecture/identity-import-initialization.test.ts':raise ValueError('fixed N4 committed source required')
for r in n['records']:
 records.append({'id':'N'+str(r['inventoryCandidateId']),'group':'non-scenarios','from':r['path'],'declaredTarget':r['targetPath'],'originCommit':n['baseCommit'],'originSha256':r['sourceSHA256'],'originBlob':r['gitBlob'],'oldText':r['before'],'newText':r['after'],'originalUTF16Offset':r['start'],'kind':'covered-existing-head'if r['inventoryCandidateId']==4 else'replace-comment','coveredExpectedHead':head if r['inventoryCandidateId']==4 else None,'coordination':r.get('applicationCoordination')})
for r in s['edits']:
 records.append({'id':r['id'],'group':'scenarios','from':r['from'],'declaredTarget':r['to'],'originCommit':s['baseCommit'],'originSha256':r['originalSHA256'],'originBlob':r['originalGitBlob'],'oldText':r['oldText'],'newText':r['newText'],'originalUTF16Offset':r['startUTF16'],'kind':'replace-comment'})
for r in p['candidates']:
 records.append({'id':r['id'],'group':'production','from':r['from'],'declaredTarget':r['to'],'originCommit':r['original']['baseCommit'],'originSha256':r['original']['sha256'],'originBlob':r['original']['gitBlob'],'oldText':r['edit']['oldText'],'newText':r['edit']['newText'],'originalUTF16Offset':r['edit']['utf16Offset'],'kind':'insert-comment'if r['kind']=='insert-comment'else'replace-comment','anchorText':r['edit']['anchorText'],'anchorOccurrence':r['edit']['anchorOccurrence']})
if len(records)!=553 or len({x['id']for x in records})!=553:raise ValueError('candidate identity count')
peers=[]
for f in ['/tmp/awa-backend-test-tooling-comments-non-scenarios-independent-review.json','/tmp/awa-scenario-chinese-comment-draft-independent-review.json']:
 peers.append({'path':f,'sha256':h(f)})
d={'status':'PREPARED_NOT_EXECUTED','inputReferences':[{'path':f,'sha256':h(f)}for f in paths],'peerReferences':peers,'counts':{'candidates':553,'originalSourceFiles':len({x['from']for x in records}),'coveredCandidates':1,'plannedAppliedCandidates':552,'insertions':7},'coveredExpectedHeadSource':{'path':str(coveragePath),'sha256':h(coveragePath),'commit':coverage['commit'],'sourcePath':coverage['path'],'rule':'只N4保持已提交actual a55架构测试中文首头；核完整Git来源与实际后继Git首注释精确同'},'records':records}
(O/'draft-spec.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(d['counts']))
