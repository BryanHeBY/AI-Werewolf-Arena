"""仅编辑 TMP 工具，不执行准备器／应用器／证明器／头检查。"""
from pathlib import Path
import json,hashlib,shutil
p=Path('/tmp/awa-chinese-comment-cohort-tools');h=lambda b:hashlib.sha256(b).hexdigest()
first=p/'first-fd633';first.mkdir(exist_ok=False)
for name in ['ready.json','draft-spec.json','comments.cjs','README.md','build-spec.py','n4-covered-head.json']:
 shutil.copyfile(p/name,first/name)
assert h((first/'ready.json').read_bytes())=='fd6331a5dc6a3c098f20bcf5e688ecc6535fe19c954e2669c3d8f2f2573c39f3'
c=p/'comments.cjs';s=c.read_text()
old="""function currentFile(relative){
 sourcePath(relative);const parts=relative.split('/');
 for(let i=1;i<=parts.length;i++){
  const stat=fs.lstatSync(path.join(root,...parts.slice(0,i)));
  if(stat.isSymbolicLink()||(i<parts.length?!stat.isDirectory():!stat.isFile()))die('ordinary_source_required:'+relative);
 }
 return fs.readFileSync(path.join(root,relative));
}"""
new="""function currentFile(relative,expectedMode){
 sourcePath(relative);if(!['100644','100755'].includes(expectedMode))die('captured_regular_Git_mode_required:'+relative);
 const parts=relative.split('/');let leaf;
 for(let i=1;i<=parts.length;i++){
  const stat=fs.lstatSync(path.join(root,...parts.slice(0,i)));
  if(stat.isSymbolicLink()||(i<parts.length?!stat.isDirectory():!stat.isFile()))die('ordinary_source_required:'+relative);
  if(i===parts.length)leaf=stat;
 }
 // Git 的普通源 mode 记录 executable 位，不宣称记录完整 POSIX 权限。
 const actualMode=(leaf.mode&0o100)?'100755':'100644';
 if(actualMode!==expectedMode)die('working_tree_Git_executable_mode_changed:'+relative);
 return fs.readFileSync(path.join(root,relative));
}"""
assert s.count(old)==1;s=s.replace(old,new)
substitutions={
 'actual=currentFile(target);':'actual=currentFile(target,current.mode);',
 'hash(currentFile(p))!==row.sha256':'hash(currentFile(p,row.mode))!==row.sha256',
 "const manifest=gitFile(base,'tooling/refactor/fixtures/manifest.json'),data=JSON.parse(manifest.text),affected=new Map();":"const manifest=gitFile(base,'tooling/refactor/fixtures/manifest.json'),data=JSON.parse(manifest.text),affected=new Map();\n if(hash(currentFile(manifest.path,manifest.mode))!==manifest.sha256)die('prepare_fixture_manifest_not_same_Git');",
 'hash(currentFile(c.path))!==c.sha256':'hash(currentFile(c.path,c.mode))!==c.sha256',
 'hash(currentFile(plan.fixtureManifest.path))!==plan.fixtureManifest.sha256':'hash(currentFile(plan.fixtureManifest.path,plan.fixtureManifest.mode))!==plan.fixtureManifest.sha256',
 "const actual=currentFile(r.path).toString('utf8');if(hash(actual)!==r.afterSha256":"const actual=currentFile(r.path,r.mode).toString('utf8');if(hash(actual)!==r.afterSha256",
 "const actual=currentFile(r.path).toString('utf8'),statement=declaration(ts,actual,r.path,r.name);":"const source=plan.files.find((f)=>f.path===r.path);if(!source)die('registered_declaration_missing_plan_source:'+r.path);\n  const actual=currentFile(r.path,source.mode).toString('utf8'),statement=declaration(ts,actual,r.path,r.name);",
 "const text=currentFile(r.path).toString('utf8');if(hash(text)!==r.afterSha256)":"const text=currentFile(r.path,r.mode).toString('utf8');if(hash(text)!==r.afterSha256)"
}
for old,new in substitutions.items():
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
old="""function apply(){
 const loaded=loadPlan(),{plan}=loaded;controls(plan);if(!out)die('explicit_out_required');
 // 完整全体断言先结束，再开始任何仓库写入。
 for(const r of plan.files){const actual=currentFile(r.path);if(hash(actual)!==r.beforeSha256||actual.toString('utf8')!==r.before)die('apply_source_SHA_guard:'+r.path);}
 for(const r of plan.files){const before=gitFile(base,r.path);if(before.mode!==r.mode||before.blob!==r.blob||before.sha256!==r.beforeSha256)die('apply_Git_identity_guard:'+r.path);}
 const receipt={status:'APPLY_STARTED',baseCommit:base,plan:{path:loaded.path,sha256:loaded.sha256},applied:[],covered:plan.files.flatMap((r)=>r.covered.map((c)=>({path:r.path,...c}))),limits:['文件写入本身非事务；失败保已写前缀，不自动回滚。','没有types/业务/全gate执行。']};
 fs.mkdirSync(out,{recursive:true});
 try{
  for(const r of plan.files){if(!r.edits.length)continue;fs.writeFileSync(path.join(root,r.path),r.after);receipt.applied.push({path:r.path,beforeSha256:r.beforeSha256,afterSha256:r.afterSha256,comments:r.edits.length});}
  receipt.status='APPLIED_NOT_PROVED';
 }catch(error){receipt.status='FAILED_PARTIAL_APPLY';receipt.error=String(error.stack||error);writeJson(path.join(out,'apply-receipt.json'),receipt);throw error;}
 writeJson(path.join(out,'apply-receipt.json'),receipt);process.stdout.write(JSON.stringify({status:receipt.status,files:receipt.applied.length,comments:552,covered:1})+'\\n');
}"""
new="""// loaded plan 不是独立可信的 after 文本；写前须从真实 before 和有限评论逐项重建全体输出。
function checkedPlannedFiles(plan){
 same(plan.counts,{candidates:553,files:439,changedFiles:438,appliedEdits:552,covered:1,insertions:7},'plan_exact_approved_counts');
 if(!Array.isArray(plan.files)||plan.files.length!==439||new Set(plan.files.map((r)=>r.path)).size!==439)die('plan_unique439_files');
 const rows=[],allIds=[];let changed=0,editCount=0,coveredCount=0,insertCount=0;
 for(const r of plan.files){
  sourcePath(r.path);
  if(!Array.isArray(r.edits)||!Array.isArray(r.covered)||!Array.isArray(r.records))die('plan_file_arrays_required:'+r.path);
  if(typeof r.before!=='string'||typeof r.after!=='string'||hash(r.before)!==r.beforeSha256||Buffer.byteLength(r.before)!==r.beforeBytes)die('plan_before_hash_or_bytes:'+r.path);
  const before=gitFile(base,r.path);
  if(before.mode!==r.mode||before.blob!==r.blob||before.sha256!==r.beforeSha256||before.text!==r.before||before.bytes!==r.beforeBytes)die('plan_complete_Git_before_changed:'+r.path);
  const ranges=comments(r.before,r.path).ranges,edits=r.edits.map((e)=>({...e}));
  for(const e of edits){
   if(!Number.isInteger(e.start)||!Number.isInteger(e.end)||e.start<0||e.end<e.start||e.end>r.before.length||typeof e.before!=='string'||typeof e.after!=='string')die('plan_comment_range_shape:'+e.id);
   const replacement=comments(e.after,r.path).ranges;
   if(e.kind==='replace-comment'){
    const original=ranges.filter((c)=>c.start===e.start&&c.end===e.end&&c.text===e.before);
    if(original.length!==1||replacement.length!==1||replacement[0].start!==0||replacement[0].end!==e.after.length||replacement[0].kind!==original[0].kind)die('plan_exact_real_comment_replacement:'+e.id);
   }else if(e.kind==='insert-comment'){
    if(e.start!==e.end||e.before!==''||!e.after.endsWith('\\n')||replacement.length!==1||!/^[\\s]*$/.test(e.after.slice(0,replacement[0].start))||!/^[\\s]*$/.test(e.after.slice(replacement[0].end)))die('plan_one_complete_comment_insertion:'+e.id);
    insertCount++;
   }else die('plan_only_approved_comment_kinds:'+e.id);
  }
  const after=applyEdits(r.before,edits);
  if(after!==r.after||hash(after)!==r.afterSha256||Buffer.byteLength(after)!==r.afterBytes)die('plan_recomputed_after_hash_or_bytes:'+r.path);
  for(let i=0;i<edits.length;i++)if(edits[i].afterStart!==r.edits[i].afterStart||edits[i].afterEnd!==r.edits[i].afterEnd)die('plan_recomputed_inverse_range:'+edits[i].id);
  const a=parse(r.before,r.path),b=parse(after,r.path);
  same(codeTokens(a,a),codeTokens(b,b),'plan_complete_code_tokens_changed:'+r.path);
  same(protections(r.before,r.path),protections(after,r.path),'plan_protected_directive_JSDoc_title_matrix_changed:'+r.path);
  for(const c of r.covered){
   const first=ranges[0];
   if(c.id!=='N4'||r.path!=='backend/tests/architecture/identity-import-initialization.test.ts'||c.approvedHeadCommit!=='a55e675be1d607825188038ae737c4b90a0e6113'||
    !first||first.start!==0||c.head!==first.text||c.headSha256!==hash(first.text)||c.headSha256!==plan.approvedCoveredHead?.headSha256)die('plan_only_exact_N4_covered');
  }
  const ids=[...r.edits,...r.covered].map((e)=>e.id);
  same([...ids].sort(),[...r.records].sort(),'plan_records_not_exact_edit_or_coverage:'+r.path);
  allIds.push(...ids);editCount+=edits.length;coveredCount+=r.covered.length;if(edits.length)changed++;
  rows.push({source:r,after});
 }
 if(editCount!==552||coveredCount!==1||insertCount!==7||changed!==438||allIds.length!==553||new Set(allIds).size!==553)die('plan_recomputed_whole_scope_counts');
 return rows;
}
function apply(){
 const loaded=loadPlan(),{plan}=loaded;controls(plan);if(!out)die('explicit_out_required');
 // 全体完整Git／552评论／保护字段／重算输出断言先结束，再开始任何仓库写入。
 const checked=checkedPlannedFiles(plan);
 for(const {source:r}of checked){const actual=currentFile(r.path,r.mode);if(hash(actual)!==r.beforeSha256||actual.toString('utf8')!==r.before)die('apply_source_SHA_guard:'+r.path);}
 const receipt={status:'APPLY_STARTED',baseCommit:base,plan:{path:loaded.path,sha256:loaded.sha256},applied:[],covered:plan.files.flatMap((r)=>r.covered.map((c)=>({path:r.path,...c}))),limits:['文件写入本身非事务；失败保已写前缀，不自动回滚。','没有types/业务/全gate执行。']};
 fs.mkdirSync(out,{recursive:true});
 try{
  for(const {source:r,after}of checked){if(!r.edits.length)continue;fs.writeFileSync(path.join(root,r.path),after);receipt.applied.push({path:r.path,beforeSha256:r.beforeSha256,afterSha256:hash(after),comments:r.edits.length});}
  receipt.status='APPLIED_NOT_PROVED';
 }catch(error){receipt.status='FAILED_PARTIAL_APPLY';receipt.error=String(error.stack||error);writeJson(path.join(out,'apply-receipt.json'),receipt);throw error;}
 writeJson(path.join(out,'apply-receipt.json'),receipt);process.stdout.write(JSON.stringify({status:receipt.status,files:receipt.applied.length,comments:552,covered:1})+'\\n');
}"""
assert s.count(old)==1;s=s.replace(old,new)
c.write_text(s)
r=p/'README.md';s=r.read_text().replace('普通工作树文件必须逐字同Git。','普通工作树文件必须逐字同Git，并按 Git 的 owner executable 位核 `100644/100755`；不把仅SHA相同的chmod漂移当同源，也不宣称记录全部POSIX权限。')
s=s.replace('`apply` 在**全部文件/控制/原Git/SHA断言结束后**才写552个评论范围。','`apply` 在**全部文件/控制/原Git/SHA/mode断言结束后**，先从 loaded plan 的真实Git before 重算552精确评论范围、完整 after／SHA／bytes／逆范围、553唯一记录和N4覆盖计数，核真实评论边界、完整代码tokens及保护字段，再写重算结果；不独立信任 plan.after。')
s=s.replace('同时保护工具控制与fixture manifest实际SHA，证明时发现漂移就拒绝。','同时保护工具控制与fixture manifest实际SHA及捕获Git executable mode；prepare/apply/prove/heads各读点均核mode，发现漂移就拒绝。')
s+='\n## 同行静态预检修订（未执行）\n\n`first-fd633/` 保留 N4 修订后首准备 `fd6331a5dc6a3c098f20bcf5e688ecc6535fe19c954e2669c3d8f2f2573c39f3`。同行指出 loaded plan.after 应在全体写前由范围重算，以及仅核文本SHA未核 executable mode；此后继集中修两项。不是已执行的产品／工具失败，也没有新增测试或自跑命令。N4 仍锁 actual a55 的精确已提交首头；Root 另完成 5 checkpoint 后仍需按其稍后选定的新Git `--base` 执行。\n'
r.write_text(s)
ready=json.loads((first/'ready.json').read_text())
ready['preflightSuccessor']={'kind':'EXACT_PLAN_RECOMPUTATION_AND_GIT_EXECUTABLE_MODE','firstReadySha256':h((first/'ready.json').read_bytes()),'firstSnapshotDirectory':str(first),'reviewFindings':'两个同行静态预检finding，未执行工具／产品反例；Root批准TMP修复。','sameN4CommittedHead':True,'validationCommandsExecuted':[]}
ready['artifacts']=[{'path':str(p/name),'sha256':h((p/name).read_bytes()),'bytes':len((p/name).read_bytes())}for name in ['README.md','build-spec.py','comments.cjs','draft-spec.json','n4-covered-head.json','repair-preflight.py']]
ready['preflightSnapshotArtifacts']=[{'path':str(x),'sha256':h(x.read_bytes()),'bytes':len(x.read_bytes())}for x in sorted(first.iterdir())]
(p/'ready.json').write_text(json.dumps(ready,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'readySha256':h((p/'ready.json').read_bytes()),'toolSHA256':h(c.read_bytes()),'READMEsha256':h(r.read_bytes()),'specSHA256':h((p/'draft-spec.json').read_bytes()),'checksExecuted':[]},ensure_ascii=False,indent=2))
