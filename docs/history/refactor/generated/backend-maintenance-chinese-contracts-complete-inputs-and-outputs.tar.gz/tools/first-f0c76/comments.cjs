#!/usr/bin/env node
/**
 * Root 显式执行的有限中文注释应用／证明入口。原稿只提供已审评论，当前完整Git是唯一写入前态。
 * prepare不写仓库；apply先核全体SHA再写有限trivia范围；prove核全程序/保护契约，不运行生产或类型。
 */
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const {createRequire}=require('node:module'),{pathToFileURL}=require('node:url');
const argv=process.argv.slice(2),mode=argv[0];
const option=(name)=>{const i=argv.indexOf(name);return i<0?undefined:argv[i+1];};
const options=(name)=>argv.flatMap((value,index)=>value===name?[argv[index+1]]:[]);
const root=path.resolve(option('--repository')||'.'),base=option('--base'),out=option('--out')&&path.resolve(option('--out'));
const hash=(v)=>crypto.createHash('sha256').update(v).digest('hex');
const die=(message)=>{throw Error(message);};
const writeJson=(file,value)=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n');};
const git=(args,extra={})=>cp.execFileSync('git',args,{cwd:root,maxBuffer:128*1024*1024,...extra});
function sourcePath(relative){
 if(typeof relative!=='string'||path.isAbsolute(relative)||relative.includes('\\')||
  relative.split('/').some((part)=>!part||part==='.'||part==='..'||['.git','.codex','.agents','.aws','node_modules'].includes(part)||part.startsWith('.env')))
  die('public_source_path_required:'+relative);
 return relative;
}
function currentFile(relative){
 sourcePath(relative);const parts=relative.split('/');
 for(let i=1;i<=parts.length;i++){
  const stat=fs.lstatSync(path.join(root,...parts.slice(0,i)));
  if(stat.isSymbolicLink()||(i<parts.length?!stat.isDirectory():!stat.isFile()))die('ordinary_source_required:'+relative);
 }
 return fs.readFileSync(path.join(root,relative));
}
function gitFile(commit,relative){
 sourcePath(relative);if(!/^[a-f0-9]{40}$/.test(commit))die('full_git_commit_required');
 const entries=git(['ls-tree','-z',commit,'--',relative]).toString('utf8').split('\0').filter(Boolean);
 if(entries.length!==1)die('exact_git_file_required:'+relative);
 const match=/^(100644|100755) blob ([a-f0-9]{40})\t(.+)$/.exec(entries[0]);
 if(!match||match[3]!==relative)die('git_regular_mode_required:'+relative);
 const bytes=git(['cat-file','blob',match[2]]);
 return {path:relative,mode:match[1],blob:match[2],sha256:hash(bytes),bytes:bytes.length,text:bytes.toString('utf8')};
}
function guardBase(){
 const parts=root.slice(path.parse(root).root.length).split(path.sep).filter(Boolean);
 let prefix=path.parse(root).root;
 for(const part of parts){
  if(['.git','.codex','.agents','.aws','node_modules'].includes(part)||part.startsWith('.env'))die('repository_private_segment');
  prefix=path.join(prefix,part);const stat=fs.lstatSync(prefix);
  if(stat.isSymbolicLink()||!stat.isDirectory())die('repository_ordinary_directory_required');
 }
 if(fs.realpathSync(root)!==root)die('repository_realpath_changed');
 if(!base||!/^[a-f0-9]{40}$/.test(base))die('explicit_full_base_required');
 if(base==='6025b64bca6d57c1d0965fdecf5328a8b897ef4c')die('post_layout_git_base_required_not_original_6025_WIP');
 const head=git(['rev-parse','HEAD']).toString('utf8').trim();
 if(head!==base)die('HEAD_must_equal_explicit_comment_base');
 git(['merge-base','--is-ancestor','6025b64bca6d57c1d0965fdecf5328a8b897ef4c',base]);
}
// 在任何库／源码解析之前拒绝原6025 WIP或非显式完整HEAD。
guardBase();
const ts=createRequire(path.join(root,'backend/package.json'))('typescript');
const scriptKind=(f)=>/\.[jt]sx$/.test(f)?ts.ScriptKind.TSX:/\.[cm]?js$/.test(f)?ts.ScriptKind.JS:ts.ScriptKind.TS;
const parse=(text,file)=>ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,scriptKind(file));
const isDoc=(n)=>n.kind===ts.SyntaxKind.JSDocComment||
 (typeof ts.SyntaxKind.FirstJSDocNode==='number'&&n.kind>=ts.SyntaxKind.FirstJSDocNode&&n.kind<=ts.SyntaxKind.LastJSDocNode);
// 从真实AST节点／token边界取得trivia；字符串/正则/template的正文不会被当注释定位。
function comments(text,file){
 const sf=parse(text,file),found=new Map();
 const add=(ranges)=>{for(const r of ranges||[])found.set(r.pos+':'+r.end,{start:r.pos,end:r.end,kind:r.kind,text:text.slice(r.pos,r.end)});};
 const walk=(node)=>{
  add(ts.getLeadingCommentRanges(text,node.pos));add(ts.getTrailingCommentRanges(text,node.end));
  for(const child of node.getChildren(sf))walk(child);
 };
 walk(sf);add(ts.getLeadingCommentRanges(text,0));
 const sorted=[...found.values()].sort((a,b)=>a.start-b.start||b.end-a.end),result=[];
 for(const r of sorted){
  const prev=result[result.length-1];
  if(prev&&r.start>=prev.start&&r.end<=prev.end)continue;
  if(prev&&r.start<prev.end)die('overlapping_AST_comment_ranges:'+file);
  result.push(r);
 }
 return {source:sf,ranges:result};
}
function same(a,b,label){if(JSON.stringify(a)!==JSON.stringify(b))die(label);}
function typed(node,sf,counters={nodes:0,arrays:0,leaves:0}){
 if(isDoc(node))return null;
 counters.nodes++;const children=[];
 ts.forEachChild(node,(child)=>{if(!isDoc(child))children.push(['node',typed(child,sf,counters)]);},(array)=>{
  counters.arrays++;children.push(['array',!!array.hasTrailingComma,array.map((child)=>typed(child,sf,counters))]);
 });
 if(!children.length){counters.leaves++;return [node.kind,node.kind===ts.SyntaxKind.EndOfFileToken?'':node.getText(sf)];}
 return [node.kind,children];
}
function codeTokens(node,sf){
 const result=[];const walk=(n)=>{
  if(isDoc(n))return;
  const children=n.getChildren(sf);
  if(children.length){for(const c of children)walk(c);return;}
  if(n.kind===ts.SyntaxKind.SyntaxList)return;
  result.push([n.kind,n.kind===ts.SyntaxKind.EndOfFileToken?'':n.getText(sf)]);
 };walk(node);return result;
}
function jsdocContracts(sf){
 const rows=[];
 const text=(node)=>node&&typeof node.getText==='function'?node.getText(sf):undefined;
 const walk=(node)=>{
  for(const doc of node.jsDoc||[]){
   for(const tag of doc.tags||[])rows.push({kind:tag.kind,tag:tag.tagName.text,
    name:text(tag.name),fullName:text(tag.fullName),type:text(tag.typeExpression?.type),
    typeExpressionKind:tag.typeExpression?.kind,isBracketed:tag.isBracketed,isNameFirst:tag.isNameFirst,
    typeParameters:tag.typeParameters?.map((p)=>({name:text(p.name),constraint:text(p.constraint),default:text(p.default)})),
    importClause:text(tag.importClause),moduleSpecifier:text(tag.moduleSpecifier)});
  }
  ts.forEachChild(node,(child)=>{walk(child);});
 };walk(sf);return rows;
}
function protections(text,file){
 const {source:sf,ranges}=comments(text,file),directives=ranges.filter((r)=>
  /@ts-(?:check|nocheck|ignore|expect-error)\b|\beslint\b|\bprettier\b|\bistanbul\b|\bc8\b|\bSPDX\b|\bcopyright\b|\blicen[cs]e(?:d)?\b|@license\b|<reference\b|@jsx(?:ImportSource|Runtime|Factory|Frag)?\b|(?:@|#)__(?:PURE|NO_SIDE_EFFECTS|INLINE|NOINLINE)__|sourceMappingURL|sourceURL|@vite-ignore|webpack(?:Ignore|ChunkName|Mode)|@(?:no)?flow\b/i.test(r.text)).map((r)=>r.text);
 const testCalls=[],arrays=[];const rootName=(expr)=>{
  while(ts.isCallExpression(expr)||ts.isPropertyAccessExpression(expr)||ts.isElementAccessExpression(expr))expr=ts.isCallExpression(expr)?expr.expression:expr.expression;
  return ts.isIdentifier(expr)?expr.text:undefined;
 };
 const walk=(node)=>{
  if(ts.isCallExpression(node)&&['test','it','describe'].includes(rootName(node.expression)))
   testCalls.push({calleeTokens:hash(JSON.stringify(codeTokens(node.expression,sf))),
    title:node.arguments[0]&&(ts.isStringLiteralLike(node.arguments[0])?node.arguments[0].getText(sf):hash(JSON.stringify(typed(node.arguments[0],sf))))});
  if(ts.isArrayLiteralExpression(node))arrays.push(hash(JSON.stringify(typed(node,sf))));
  ts.forEachChild(node,(child)=>{walk(child);});
 };walk(sf);
 return {directives,jsdoc:jsdocContracts(sf),testCalls,arrayExpressions:arrays};
}
function astNodes(sf){const nodes=[];const visit=(n)=>{nodes.push(n);ts.forEachChild(n,(c)=>{visit(c);});};visit(sf);return nodes;}
function owner(node,sf){
 const rows=[];for(let n=node;n;n=n.parent){
  if(ts.isFunctionDeclaration(n)||ts.isFunctionExpression(n)||ts.isMethodDeclaration(n)||ts.isClassDeclaration(n)||ts.isArrowFunction(n))
   rows.push([n.kind,n.name?.getText(sf)||null]);
 }return rows;
}
function spanForRecord(original,record){
 const parsed=comments(original.text,record.from),start=record.originalUTF16Offset;
 if(original.text.slice(start,start+record.oldText.length)!==record.oldText)die('original_utf16_comment_anchor:'+record.id);
 const end=start+record.oldText.length;
 const matches=parsed.ranges.filter((r)=>
  (r.start<=start&&r.end>=end)||
  (r.start>=start&&r.end<=end&&/^\s*$/.test(original.text.slice(start,r.start))&&/^\s*$/.test(original.text.slice(r.end,end))));
 if(matches.length!==1)die('draft_not_single_real_AST_comment:'+record.id);
 const range=matches[0],duplicates=parsed.ranges.filter((r)=>r.text===range.text),ordinal=duplicates.findIndex((r)=>r.start===range.start);
 let replacement;
 if(start>=range.start&&end<=range.end)replacement=range.text.slice(0,start-range.start)+record.newText+range.text.slice(end-range.start);
 else{
  const prefix=original.text.slice(start,range.start),suffix=original.text.slice(range.end,end);
  if(!record.newText.startsWith(prefix)||!record.newText.endsWith(suffix))die('comment_indent_or_tail_changed:'+record.id);
  replacement=record.newText.slice(prefix.length,record.newText.length-suffix.length||undefined);
 }
 const newRanges=comments(replacement,record.from).ranges;
 if(newRanges.length!==1||newRanges[0].start!==0||newRanges[0].end!==replacement.length||newRanges[0].kind!==range.kind)die('replacement_not_one_same_kind_complete_comment:'+record.id);
 return {oldWholeComment:range.text,newWholeComment:replacement,oldRange:range,rawOrdinal:ordinal,rawCount:duplicates.length};
}
function insertLocation(original,current,record,target){
 if(record.oldText!=='')die('insert_old_text_must_be_empty');
 if(!record.newText.endsWith('\n'))die('insert_comment_requires_line_termination:'+record.id);
 if(original.text.slice(record.originalUTF16Offset,record.originalUTF16Offset+record.anchorText.length)!==record.anchorText)die('original_insert_anchor:'+record.id);
 const locate=(text,file)=>{
  const sf=parse(text,file),nodes=astNodes(sf),matches=[];let from=0;
  while(true){const at=text.indexOf(record.anchorText,from);if(at<0)break;from=at+1;
   const prefix=/^\s*/.exec(record.anchorText)[0];
   const exact=nodes.filter((n)=>n.getStart(sf)===at+prefix.length&&n.getText(sf).startsWith(record.anchorText.slice(prefix.length)));
   if(exact.length){
    const first=exact.sort((a,b)=>(b.end-b.pos)-(a.end-a.pos))[0];
    matches.push({at,kind:first.kind,owner:owner(first,sf)});
   }
  }return matches;
 };
 const a=locate(original.text,record.from),b=locate(current.text,target),index=record.anchorOccurrence-1;
 if(!a[index]||a[index].at!==record.originalUTF16Offset||b.length!==a.length||!b[index])die('AST_insert_anchor_ordinal:'+record.id);
 same(a[index].owner,b[index].owner,'AST_insert_owner_changed:'+record.id);
 if(a[index].kind!==b[index].kind)die('AST_insert_kind_changed:'+record.id);
 const snippets=comments(record.newText,target).ranges;
 if(snippets.length!==1||!/^[\s]*$/.test(record.newText.slice(0,snippets[0].start))||!/^\s*$/.test(record.newText.slice(snippets[0].end)))die('insert_must_be_one_comment:'+record.id);
 return {start:b[index].at,end:b[index].at,before:'',after:record.newText,astAnchorKind:a[index].kind,astOwner:a[index].owner,anchorOrdinal:index,anchorMatches:a.length};
}
function applyEdits(text,edits){
 const sorted=[...edits].sort((a,b)=>a.start-b.start||a.end-b.end);
 for(let i=0;i<sorted.length;i++){
  const r=sorted[i];if(text.slice(r.start,r.end)!==r.before)die('plan_before_range_changed:'+r.id);
  if(i&&r.start<sorted[i-1].end)die('plan_comment_overlap:'+r.id);
  if(i&&r.start===sorted[i-1].start)die('plan_same_start_ambiguous:'+r.id);
 }
 let after=text;for(const r of [...sorted].reverse())after=after.slice(0,r.start)+r.after+after.slice(r.end);
 let delta=0;for(const r of sorted){r.afterStart=r.start+delta;r.afterEnd=r.afterStart+r.after.length;delta+=r.after.length-(r.end-r.start);}
 return after;
}
function pathMappings(){
 const main=option('--primary-map'),checkpoint=option('--checkpoint-map');
 if(!main||!checkpoint)die('explicit_672_and_checkpoint5_maps_required');
 const references=[],map=new Map();
 for(const file of [main,checkpoint,...options('--map')]){
  const bytes=fs.readFileSync(file),doc=JSON.parse(bytes),rows=Array.isArray(doc)?doc:(doc.mapping||doc.moves);
  if(!Array.isArray(rows))die('explicit_mapping_array_required:'+file);
  if(file===main&&rows.length!==672)die('fixed_primary_map672_required');
  if(file===checkpoint&&(rows.length!==5||rows.some((r)=>!r.from.startsWith('backend/src/recording/reproduction/checkpoint/')||!r.to.startsWith('backend/src/app/checkpoint/'))))die('explicit_checkpoint_owner5_required');
  references.push({path:path.resolve(file),sha256:hash(bytes),routes:rows.length});
  for(const row of rows){sourcePath(row.from);sourcePath(row.to);if(map.has(row.from)&&map.get(row.from)!==row.to)die('mapping_conflict:'+row.from);map.set(row.from,row.to);}
 }
 const resolve=(file)=>{const seen=new Set();while(map.has(file)){if(seen.has(file))die('mapping_cycle');seen.add(file);file=map.get(file);}return file;};
 return {references,resolve};
}
async function declarationFunction(){return (await import(pathToFileURL(path.join(root,'tooling/refactor/fixture-manifest.ts')).href)).sourceDeclarationContract;}
async function prepare(){
 if(!out)die('explicit_out_required');
 const specPath=option('--spec')||path.join(__dirname,'draft-spec.json'),specBytes=fs.readFileSync(specPath),spec=JSON.parse(specBytes);
 if(spec.records.length!==553)die('approved_candidate553_required');
 for(const input of [...spec.inputReferences,...spec.peerReferences,spec.coveredExpectedHeadSource])if(hash(fs.readFileSync(input.path))!==input.sha256)die('draft_or_peer_reference_drift:'+input.path);
 const mapping=pathMappings(),originals=new Map(),groups=new Map();
 for(const record of spec.records){
  if(!originals.has(record.from))originals.set(record.from,gitFile(record.originCommit,record.from));
  const original=originals.get(record.from);
  if(original.sha256!==record.originSha256||original.blob!==record.originBlob)die('draft_original_git_identity:'+record.id);
  const target=mapping.resolve(record.from);
  if(mapping.resolve(record.declaredTarget)!==target)die('draft_target_mapping_conflict:'+record.id);
  if(!/^(?:backend\/(?:src|tests)\/|tooling\/refactor\/).+\.[cm]?[jt]sx?$/.test(target))die('comment_target_scope:'+target);
  if(!groups.has(target)){
   const current=gitFile(base,target),actual=currentFile(target);
   if(hash(actual)!==current.sha256||actual.toString('utf8')!==current.text)die('current_target_not_same_Git_base:'+target);
   groups.set(target,{...current,records:[],edits:[],covered:[]});
  }
  const current=groups.get(target);current.records.push(record.id);
  if(record.kind==='covered-existing-head'){
   if(record.id!=='N4')die('only_approved_N4_coverage');
   const originalHead=spanForRecord(original,record);
   const first=comments(current.text,target).ranges[0];
   if(!first||first.text!==record.coveredExpectedHead)die('N4_actual_approved_Chinese_head_changed');
   current.covered.push({id:record.id,reason:'already covered by operational first-head translation',originalCommentRange:{start:originalHead.oldRange.start,end:originalHead.oldRange.end},originalCommentSha256:hash(originalHead.oldWholeComment),head:first.text,headSha256:hash(first.text),discardedDraftTranslation:record.newText});
   continue;
  }
  let edit;
  if(record.kind==='insert-comment')edit=insertLocation(original,current,record,target);
  else{
   const old=spanForRecord(original,record),matches=comments(current.text,target).ranges.filter((r)=>r.text===old.oldWholeComment);
   if(matches.length!==old.rawCount||!matches[old.rawOrdinal])die('current_AST_comment_raw_ordinal:'+record.id);
   const range=matches[old.rawOrdinal];
   edit={start:range.start,end:range.end,before:range.text,after:old.newWholeComment,
    originalCommentRange:{start:old.oldRange.start,end:old.oldRange.end},sameRawOrdinal:old.rawOrdinal,sameRawCount:old.rawCount};
  }
  current.edits.push({id:record.id,group:record.group,kind:record.kind,originPath:record.from,...edit});
 }
 const files=[];
 for(const current of groups.values()){
  const after=applyEdits(current.text,current.edits);
  same(protections(current.text,current.path),protections(after,current.path),'protected_directive_JSDoc_title_matrix_changed:'+current.path);
  files.push({path:current.path,baseCommit:base,mode:current.mode,blob:current.blob,beforeSha256:current.sha256,beforeBytes:current.bytes,
   afterSha256:hash(after),afterBytes:Buffer.byteLength(after),before:current.text,after,records:current.records,edits:current.edits,covered:current.covered});
 }
 files.sort((a,b)=>a.path.localeCompare(b.path));
 if(files.length!==439||files.reduce((n,r)=>n+r.edits.length,0)!==552||files.reduce((n,r)=>n+r.covered.length,0)!==1)die('approved_scope_count_changed');
 const manifest=gitFile(base,'tooling/refactor/fixtures/manifest.json'),data=JSON.parse(manifest.text),affected=new Map();
 const declaration=await declarationFunction();
 const touched=new Map(files.map((r)=>[r.path,r]));
 for(const asset of data.sourceAssets){
  if(touched.has(asset.currentPath))die('sourceAsset_current_byte_metadata_coordination_required:'+asset.currentPath);
  for(const relocation of asset.moduleRelocations||[]){
   const row=touched.get(relocation.currentPath);if(!row)continue;
   for(const binding of relocation.bindings){
    const key=relocation.currentPath+':'+binding.name,before=declaration(ts,row.before,row.path,binding.name),after=declaration(ts,row.after,row.path,binding.name);
    if(hash(before)!==binding.declarationSha256||before!==after)die('registered_complete_declaration_changed:'+key);
    if(!affected.has(key))affected.set(key,{path:row.path,name:binding.name,expectedPrinterSha256:binding.declarationSha256,beforeStatement:before,afterStatement:after,
     registrationSources:[],noWholeLeafCurrentShaAdded:true});
    affected.get(key).registrationSources.push(asset.originPath);
   }
  }
 }
 for(const key of ['backend/tests/support/oracles/fixture-values.ts:fixtureObject','backend/tests/support/transport/contracts.ts:ActorTransportPlan'])if(!affected.has(key))die('required_registered_declaration_missing:'+key);
 const controls=[];for(const p of ['tooling/refactor/fixture-manifest.ts','tooling/refactor/architecture/comment-check.ts','tooling/refactor/architecture/contracts.ts']){
  const row=gitFile(base,p);if(hash(currentFile(p))!==row.sha256)die('tool_control_not_Git:'+p);controls.push(row);
 }
 const plan={status:'PREPARED_NOT_APPLIED_NOT_PROVED',baseCommit:base,draftBaseCommit:'6025b64bca6d57c1d0965fdecf5328a8b897ef4c',
  draftSpec:{path:path.resolve(specPath),sha256:hash(specBytes)},mappingReferences:mapping.references,
  counts:{candidates:553,files:files.length,changedFiles:files.filter((r)=>r.edits.length).length,appliedEdits:552,covered:1,insertions:7},
  originals:[...originals.values()],files,controls,registeredDeclarations:[...affected.values()],
  fixtureManifest:{path:manifest.path,mode:manifest.mode,blob:manifest.blob,sha256:manifest.sha256},
  limits:['实际写入前态只来自显式post-layout Git。旧稿imports不写回。','准备核定位/保护文字，不等价于完成fullproof/heads。','本工具不修改fixture manifest，不伪造moduleReloc叶currentSHA。']};
 fs.mkdirSync(out,{recursive:true});writeJson(path.join(out,'plan.json'),plan);
 process.stdout.write(JSON.stringify({status:plan.status,base,counts:plan.counts,plan:path.join(out,'plan.json'),sha256:hash(fs.readFileSync(path.join(out,'plan.json')))})+'\n');
}
function loadPlan(){
 const p=option('--plan');if(!p)die('explicit_plan_required');const raw=fs.readFileSync(p),plan=JSON.parse(raw);
 if(plan.baseCommit!==base||plan.counts.candidates!==553)die('plan_base_or_scope_mismatch');
 return {plan,path:path.resolve(p),sha256:hash(raw)};
}
function controls(plan){
 for(const c of plan.controls)if(hash(currentFile(c.path))!==c.sha256)die('proof_control_drift:'+c.path);
 if(hash(currentFile(plan.fixtureManifest.path))!==plan.fixtureManifest.sha256)die('fixture_manifest_changed_unapproved');
}
function apply(){
 const loaded=loadPlan(),{plan}=loaded;controls(plan);if(!out)die('explicit_out_required');
 // 完整全体断言先结束，再开始任何仓库写入。
 for(const r of plan.files){const actual=currentFile(r.path);if(hash(actual)!==r.beforeSha256||actual.toString('utf8')!==r.before)die('apply_source_SHA_guard:'+r.path);}
 for(const r of plan.files){const before=gitFile(base,r.path);if(before.mode!==r.mode||before.blob!==r.blob||before.sha256!==r.beforeSha256)die('apply_Git_identity_guard:'+r.path);}
 const receipt={status:'APPLY_STARTED',baseCommit:base,plan:{path:loaded.path,sha256:loaded.sha256},applied:[],covered:plan.files.flatMap((r)=>r.covered.map((c)=>({path:r.path,...c}))),limits:['文件写入本身非事务；失败保已写前缀，不自动回滚。','没有types/业务/全gate执行。']};
 fs.mkdirSync(out,{recursive:true});
 try{
  for(const r of plan.files){if(!r.edits.length)continue;fs.writeFileSync(path.join(root,r.path),r.after);receipt.applied.push({path:r.path,beforeSha256:r.beforeSha256,afterSha256:r.afterSha256,comments:r.edits.length});}
  receipt.status='APPLIED_NOT_PROVED';
 }catch(error){receipt.status='FAILED_PARTIAL_APPLY';receipt.error=String(error.stack||error);writeJson(path.join(out,'apply-receipt.json'),receipt);throw error;}
 writeJson(path.join(out,'apply-receipt.json'),receipt);process.stdout.write(JSON.stringify({status:receipt.status,files:receipt.applied.length,comments:552,covered:1})+'\n');
}
function emit(text,file,module){
 const result=ts.transpileModule(text,{fileName:file,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ESNext,module,removeComments:true,sourceMap:false,inlineSourceMap:false,esModuleInterop:true}});
 return {output:result.outputText,diagnostics:(result.diagnostics||[]).map((d)=>({code:d.code,category:d.category,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')}))};
}
async function prove(){
 const loaded=loadPlan(),{plan}=loaded;controls(plan);if(!out)die('explicit_out_required');
 const outputs={beforeES:[],afterES:[],beforeCJS:[],afterCJS:[]},rows=[];const declaration=await declarationFunction();
 for(const r of plan.files){
  const actual=currentFile(r.path).toString('utf8');if(hash(actual)!==r.afterSha256||actual!==r.after)die('proof_after_source_SHA:'+r.path);
  let inverse=actual;for(const e of [...r.edits].sort((a,b)=>b.afterStart-a.afterStart)){
   if(inverse.slice(e.afterStart,e.afterEnd)!==e.after)die('proof_after_comment_range:'+e.id);
   inverse=inverse.slice(0,e.afterStart)+e.before+inverse.slice(e.afterEnd);
  }
  if(inverse!==r.before)die('proof_full_exact_inverse:'+r.path);
  const a=parse(r.before,r.path),b=parse(actual,r.path),ca={nodes:0,arrays:0,leaves:0},cb={nodes:0,arrays:0,leaves:0};
  const ta=typed(a,a,ca),tb=typed(b,b,cb);same(ta,tb,'proof_complete_typed_tree:'+r.path);
  const tokensA=codeTokens(a,a),tokensB=codeTokens(b,b);same(tokensA,tokensB,'proof_complete_code_tokens:'+r.path);
  const pa=protections(r.before,r.path),pb=protections(actual,r.path);same(pa,pb,'proof_directive_JSDoc_titles_matrices:'+r.path);
  const emissions=[];
  for(const [name,module]of [['ES',ts.ModuleKind.ESNext],['CJS',ts.ModuleKind.CommonJS]]){
   const before=emit(r.before,r.path,module),after=emit(actual,r.path,module);same(before,after,'proof_complete_removeComments_'+name+':'+r.path);
   outputs['before'+name].push({path:r.path,output:before.output});outputs['after'+name].push({path:r.path,output:after.output});
   emissions.push({module:name,same:true,sha256:hash(before.output),bytes:Buffer.byteLength(before.output),diagnostics:before.diagnostics});
  }
  rows.push({path:r.path,beforeSha256:r.beforeSha256,afterSha256:r.afterSha256,edits:r.edits.length,covered:r.covered.length,
   typedBefore:ca,typedAfter:cb,tokensBefore:tokensA.length,tokensAfter:tokensB.length,wholeTypedSha256:hash(JSON.stringify(ta)),tokensSha256:hash(JSON.stringify(tokensA)),
   protected:{directives:pa.directives.length,JSDocTags:pa.jsdoc.length,testCalls:pa.testCalls.length,arrayExpressions:pa.arrayExpressions.length,sha256:hash(JSON.stringify(pa))},emissions});
 }
 const registrations=[];
 for(const r of plan.registeredDeclarations){
  const actual=currentFile(r.path).toString('utf8'),statement=declaration(ts,actual,r.path,r.name);
  if(statement!==r.beforeStatement||hash(statement)!==r.expectedPrinterSha256)die('proof_registered_full_declaration:'+r.path+':'+r.name);
  registrations.push({path:r.path,name:r.name,printerSha256:hash(statement),same:true,wholeLeafCurrentShaNotAdded:true});
 }
 fs.mkdirSync(out,{recursive:true});for(const [key,value]of Object.entries(outputs))writeJson(path.join(out,'complete-emits-'+key+'.json'),value);
 const report={status:'PROVED',baseCommit:base,plan:{path:loaded.path,sha256:loaded.sha256},counts:plan.counts,compiler:{version:ts.version},rows,registeredDeclarations:registrations,
  outputArtifacts:Object.keys(outputs).map((key)=>({path:'complete-emits-'+key+'.json',sha256:hash(fs.readFileSync(path.join(out,'complete-emits-'+key+'.json')))})),
  limits:['只此注释batch的完整单程序结构/语法词项/NodeArray/保护字段与两个removeComments单文件输出。','不是完整双构建差分、类型、玩法、模型或全结构gate；注释业务真义仍须人工。']};
 writeJson(path.join(out,'proof.json'),report);process.stdout.write(JSON.stringify({status:report.status,files:rows.length,comments:552,covered:1,outputs:rows.length*4,registeredDeclarations:registrations.length})+'\n');
}
async function heads(){
 const loaded=loadPlan(),{plan}=loaded;controls(plan);if(!out)die('explicit_out_required');
 const {checkComments}=await import(pathToFileURL(path.join(root,'tooling/refactor/architecture/comment-check.ts')).href);
 const files=plan.files.map((r)=>{const text=currentFile(r.path).toString('utf8');if(hash(text)!==r.afterSha256)die('heads_after_source_SHA:'+r.path);return {path:r.path,text,sha256:r.afterSha256};});
 const paths=git(['ls-tree','-r','-z',base]).toString('utf8').split('\0').flatMap((entry)=>{
  const match=/^(?:100644|100755) blob [a-f0-9]{40}\t(.+)$/.exec(entry);
  return match&&match[1].endsWith('.md')&&/^(?:docs\/|[^/]+\.md$)/.test(match[1])?[match[1]]:[];
 });
 const failures=checkComments(ts,{files,documentationPaths:paths});
 const report={status:failures.length?'FAILED':'PASSED',baseCommit:base,plan:{path:loaded.path,sha256:loaded.sha256},files:files.length,documentationPaths:paths.length,failures,
  limits:['仅职责头形状/路径校验，不读取文档内容、不证明中文语义或完整职责交付。','只当前439源，不调用其它gate/类型/业务。']};
 writeJson(path.join(out,'heads.json'),report);process.stdout.write(JSON.stringify({status:report.status,files:files.length,docs:paths.length,diagnostics:failures.length})+'\n');
 if(failures.length)process.exitCode=1;
}
(async()=>{
 if(!['prepare','apply','prove','heads'].includes(mode))die('mode_prepare_apply_prove_heads_required');
 if(mode==='prepare')await prepare();else if(mode==='apply')apply();else if(mode==='prove')await prove();else await heads();
})().catch((error)=>{process.stderr.write(String(error.stack||error)+'\n');process.exitCode=1;});
