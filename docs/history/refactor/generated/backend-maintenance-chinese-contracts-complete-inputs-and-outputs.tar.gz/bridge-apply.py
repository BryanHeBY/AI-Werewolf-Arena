"""显式应用首轮失败头、三源结构说明及独立检查词项修正。

40 个头的前态来自刚通过的主注释阶段，三源来自固定 Git；不把中间工作树冒成新的 Git。
全体字节、精确增量与前态归属核对后才写文件；发生 I/O 错误保留 journal，不自动回滚。
"""
import pathlib, json, hashlib, subprocess
root = pathlib.Path('/home/hby/dev/AI-Werewolf-Arena')
base = 'd7b5f51b770d1b5713ffe8b62fd671cac36e92eb'
out = pathlib.Path('/tmp/awa-chinese-bridge-actual')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == base
assert not out.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
main = json.loads(pathlib.Path('/tmp/awa-chinese-comment-actual-d7b5f51b/plan.json').read_text())
main_rows = {r['path']:r for r in main['files']}
closure = json.loads(pathlib.Path('/tmp/awa-chinese-comment-head-closure-proposal.json').read_text())
extra = json.loads(pathlib.Path('/tmp/awa-chinese-effective-structure-proposal.json').read_text())
comments = closure['sourceHeads'] + extra['source']
policies = closure['policySources']
assert len(comments) == 43 and len(policies) == 2
assert len({r['path'] for r in comments + policies}) == 45
for r in comments + policies:
    p = root/r['path']
    assert not p.is_symlink() and p.is_file()
    current = p.read_bytes()
    assert sha(current) == r['beforeSHA256'] and current.decode() == r['before']
    if r['path'] in main_rows:
        assert r['before'] == main_rows[r['path']]['after']
    else:
        assert current == subprocess.check_output(['git','show',base+':'+r['path']],cwd=root)
    after = r['before']
    if 'append' in r:
        after += r['append']
    else:
        for edit in r['edits']:
            assert after.count(edit['before']) == 1
            after = after.replace(edit['before'], edit['after'])
    assert after == r['after'] and sha(after.encode()) == r['afterSHA256']
controls = []
for p in ['bun.lock','package.json','backend/tsconfig.json']:
    b = (root/p).read_bytes()
    assert b == subprocess.check_output(['git','show',base+':'+p],cwd=root)
    controls.append({'path':p,'sha256':sha(b)})
out.mkdir()
write = lambda name,x: (out/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
write('before.json',{'baseCommit':base,'phase':'40源为主439注释通过后的工作树，其余3源为同Git；不是另一Git前态',
 'source':[{'path':r['path'],'text':r['before'],'sha256':r['beforeSHA256']} for r in comments], 'controls':controls})
write('policy-before-after.json',{'baseCommit':base,'phase':'独立检查器准入差分；不计入注释语法等价证明','source':policies})
edits = []
for r in comments:
    old, after, delta, events = r['before'], r['after'], 0, []
    positioned = sorted([{'beforeStart':old.index(e['before']), 'beforeEnd':old.index(e['before'])+len(e['before']), **e} for e in r['edits']], key=lambda e:e['beforeStart'])
    for e in positioned:
        e['afterStart'] = e['beforeStart']+delta
        e['afterEnd'] = e['afterStart']+len(e['after'])
        assert after[e['afterStart']:e['afterEnd']] == e['after']
        delta += len(e['after'])-len(e['before'])
        events.append(e)
    edits.append({'path':r['path'],'edits':events})
write('edits.json',edits)
write('source-ready.json',{'baseCommit':base,'source':[{'path':r['path'],'sha256':r['afterSHA256']} for r in comments]})
with (out/'journal.jsonl').open('x') as journal:
    for r in comments + policies:
        (root/r['path']).write_text(r['after'])
        journal.write(json.dumps({'path':r['path'],'sha256':r['afterSHA256']})+'\n')
        journal.flush()
print(json.dumps({'comments':43,'commentExactEdits':sum(len(r['edits']) for r in comments),'policyPrograms':2,'baseCommit':base}))
