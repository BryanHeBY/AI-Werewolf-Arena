/** 仅重查首轮失败的155个职责头；前态及两条检查器政策改动分别核对，不重复284个已绿文件。 */
import fs from "node:fs";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { createRequire } from "node:module";
const root = "/home/hby/dev/AI-Werewolf-Arena";
const hash = (text: string) => createHash("sha256").update(text).digest("hex");
const first = JSON.parse(fs.readFileSync("/tmp/awa-chinese-comment-actual-d7b5f51b/heads.json", "utf8"));
const main = JSON.parse(fs.readFileSync("/tmp/awa-chinese-comment-actual-d7b5f51b/plan.json", "utf8"));
const closure = JSON.parse(fs.readFileSync("/tmp/awa-chinese-comment-head-closure-proposal.json", "utf8"));
const expected = new Map(main.files.map((r: any) => [r.path, r.afterSha256]));
for (const r of closure.sourceHeads) expected.set(r.path, r.afterSHA256);
for (const r of closure.policySources) {
  if (hash(fs.readFileSync(root + "/" + r.path, "utf8")) !== r.afterSHA256) throw Error("policy_drift:" + r.path);
}
const paths = [...new Set<string>(first.failures.map((r: any) => r.path))].sort();
if (paths.length !== 155) throw Error("expected_actual_155_failed_files");
const files = paths.map(path => {
  const text = fs.readFileSync(root + "/" + path, "utf8"), sha256 = hash(text);
  if (sha256 !== expected.get(path)) throw Error("current_source_drift:" + path);
  return { path, text, sha256 };
});
const tree = execFileSync("git", ["ls-tree", "-rz", first.baseCommit], {cwd: root, maxBuffer:64*1024*1024}).toString();
const documentationPaths = tree.split("\0").flatMap(row => {
  const p = row.slice(row.indexOf("\t") + 1);
  return p.endsWith(".md") && (p.startsWith("docs/") || !p.includes("/")) ? [p] : [];
});
const ts = createRequire(root + "/backend/package.json")("typescript");
const {checkComments} = await import(root + "/tooling/refactor/architecture/comment-check.ts");
const failures = checkComments(ts, { files, documentationPaths });
const report = {baseCommit:first.baseCommit, files:paths.length, notRepeatedGreen:284,
  source:files.map(({path,sha256})=>({path,sha256})), failures,
  limits:["仅职责头形状，不替代中文真实性人工审查、类型、业务或全门禁。"]};
fs.writeFileSync("/tmp/awa-chinese-bridge-actual/failed-heads-check.json", JSON.stringify(report,null,2)+"\n");
console.log(JSON.stringify({files:paths.length,notRepeatedGreen:284,diagnostics:failures.length}));
if (failures.length) process.exitCode = 1;
