"""准备有限职责头及中英测试词项差分；不应用源码，也不运行检查器。"""
import pathlib, json, hashlib
root = pathlib.Path('/home/hby/dev/AI-Werewolf-Arena')
sha = lambda s: hashlib.sha256(s.encode()).hexdigest()
rows = json.load(open('/tmp/awa-chinese-comment-failed-heads.json'))
out = []
for r in rows:
    if '/tests/support/' not in r['path'] or '测试' in r['head']:
        continue
    old = r['head']
    new = old.replace(' * ', ' * 测试支持模块负责', 1)
    if r['path'].endswith('builders/transport/self-destruct-plan.ts'):
        new = new.replace('脚本中自爆出现的位置', '字面脚本中自爆出现的位置')
    if r['path'].endswith('gravekeeper/builders/scenario.ts'):
        new = new.replace('输出原反馈对象和固定板子', '输出由调用方字面字段组成的反馈对象和固定板子')
    before = (root/r['path']).read_text()
    assert before.count(old) == 1
    after = before.replace(old, new)
    out.append({'path':r['path'], 'before':before, 'after':after,
                'beforeSHA256':sha(before), 'afterSHA256':sha(after),
                'edits':[{'before':old, 'after':new}], 'firstFailures':r['rules']})
assert len(out) == 40
changes = []
p = 'tooling/refactor/architecture/comment-check.ts'
before = (root/p).read_text()
old, new = '解析|渲染/i,', '解析|渲染|测试/i,'
assert before.count(old) == 1
after = before.replace(old, new)
changes.append({'path':p, 'before':before, 'after':after,
                'beforeSHA256':sha(before), 'afterSHA256':sha(after),
                'edits':[{'before':old, 'after':new}]})
p = 'tooling/refactor/architecture.test.ts'
before = (root/p).read_text()
addition = '''
// 使用真实检查器核对自然中文测试职责；层级、预期来源和缺失职责仍分别检查。
test("中文测试职责说明与英文测试保持同等约束", () => {
  const review = (head: string) => checkComments(ts, input({
    "backend/tests/unit/example.test.ts": head + "\\nexport const value = 1;",
  })).map((row) => row.rule);
  expect(review("/** 单元测试以字面输入核对公开结果。 */")).toEqual([]);
  expect(review("/** 场景测试通过固定样本执行记录与复现。 */")).toEqual([]);
  expect(review("/** 单元测试接收输入并输出结果。 */")).toEqual(["comment.oracle"]);
  expect(review("/** 单元；输入为字面样本，输出为固定预期。 */")).toEqual([
    "comment.first-paragraph", "comment.responsibility",
  ]);
});
'''
after = before + addition
changes.append({'path':p, 'before':before, 'after':after,
                'beforeSHA256':sha(before), 'afterSHA256':sha(after), 'append':addition})
document = {'status':'TMP_NOT_APPLIED',
    'baseCommit':'d7b5f51b770d1b5713ffe8b62fd671cac36e92eb',
    'phaseBefore':'主439应用与完整proof通过之后，首heads失败后；不是新Git原文',
    'sourceHeads':out, 'policySources':changes,
    'diagnostics':{'first':318, 'files':155, 'changedSupport':40, 'unchangedNaturalTestHeads':115},
    'limits':['分类、required与其它词项保持，中文测试仅与既有English test同等识别。',
              '真正缺少层级或来源的support头补实际说明，不以新词识别绕过。']}
p = pathlib.Path('/tmp/awa-chinese-comment-head-closure-proposal.json')
p.write_text(json.dumps(document, ensure_ascii=False, indent=2)+'\n')
print(p, sha(p.read_text()))
