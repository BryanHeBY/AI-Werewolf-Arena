/**
 * 负责盘点公开 fixture 字节，并按字面元数据、玩家身份与共享录制事件关联档案。
 * 纯读取器和选择器消费 JSON 清单，输出测试用描述；显式生成入口拥有 Git／文件读取，不运行游戏、适配器或规则预期算法。
 * 冻结来源路径决定稳定 suite 身份，当前位置只描述迁移落点。字节保持与元数据关联不能授予验收通过；
 * 未知来源继续显式保留，生成的 suite 等待独立审查，本模块不重写 fixture。
 */

export type FixtureOwner = "backend" | "frontend" | "replay-contract";
export type FixtureKind =
  | "god-replay"
  | "checkpoint"
  | "player-view"
  | "player-view-bundle"
  | "adapter-script"
  | "unknown-json";
export interface FixtureEvidence {
  path: string;
  pointer: string;
  detail: string;
}
export type FixtureObservation<T> =
  // observed 必须带字面证据；unknown 保留缺失原因，不能以生产默认值补成已观察结果。
  | { state: "observed"; value: T; evidence: FixtureEvidence[] }
  | { state: "unknown"; reason: string };
export interface FixtureActor {
  playerId: number;
  role: string;
  camp: string;
}
export interface FixtureMetadata {
  board: FixtureObservation<string>;
  policy: FixtureObservation<string[]>;
  seed: FixtureObservation<string | number>;
  locale: FixtureObservation<string>;
  actors: FixtureObservation<FixtureActor[]>;
  source: FixtureObservation<{ commit: string; path: string; sha256: string }>;
  build: FixtureObservation<string>;
  formatVersion: FixtureObservation<number>;
}
export interface FixtureArtifact {
  // 来源身份永久绑定冻结样本；current 两字段单独记录迁移后的实际字节，不覆盖原 SHA／长度。
  originPath: string;
  currentPath: string;
  sha256: string;
  bytes: number;
  currentSha256: string;
  currentBytes: number;
  owner: FixtureOwner;
  kind: FixtureKind;
  suiteId: string;
  metadata: FixtureMetadata;
}
export interface FixtureAcceptance {
  // 关联与字节证据只支持盘点；accepted／rejected 还须明确独立审查证据。
  status: "pending-review" | "accepted" | "rejected";
  evidence: {
    kind: "baseline-byte-match" | "metadata-association" | "independent-review";
    reference: string;
    detail: string;
  }[];
  unresolved: string[];
}
export interface FixtureSuite {
  suiteId: string;
  anchorOriginPath: string;
  owner: FixtureOwner;
  kind: "recorded-archive" | "adapter-script" | "unassociated-json";
  files: string[];
  metadata: FixtureMetadata;
  membership: {
    originPath: string;
    state: "literal-associated" | "standalone";
    evidence: FixtureEvidence[];
  }[];
  acceptance: FixtureAcceptance;
}
export interface FixtureSourceAsset {
  originPath: string;
  currentPath: string;
  originCommit: string;
  originalSha256: string;
  originalBytes: number;
  currentSha256: string;
  currentBytes: number;
  programSha256: string;
  moduleBindingsSha256: string;
  kind: "adapter-script" | "test-support";
  moduleRelocations?: FixtureSourceModuleRelocation[];
}
/** 已审查的 support 归属迁移所移动的精确导入声明；每个绑定保留独立声明摘要。 */
export interface FixtureSourceModuleRelocation {
  originPath: string;
  currentPath: string;
  originCommit: string;
  bindings: { name: string; declarationSha256: string }[];
}
export interface FixtureDerivedManifest {
  path: string;
  suiteIds: string[];
}
export interface FixtureManifest {
  schema: "awa-fixture-manifests-v2";
  generatedBy: "tooling/refactor/fixture-manifest.ts";
  baseline: { commit: string; inventoryPath: string; inventorySha256: string };
  coverage: {
    expectedFiles: number;
    exactBytesFiles: number;
    mechanicalSourceFiles: number;
    originalBytes: number;
    currentBytes: number;
  };
  sourceAssets: FixtureSourceAsset[];
  derivedManifests: FixtureDerivedManifest[];
  policy: string;
  files: FixtureArtifact[];
  suites: FixtureSuite[];
}

const baselineCommit = "27a97cb66e8f30fceb7cb20130154291559dd14a";
const inventoryPath = "docs/refactor/generated/baseline-fixtures.json";
export const fixtureManifestPath = "tooling/refactor/fixtures/manifest.json";
const fixtureRoots = [
  "backend/tests/fixtures",
  "frontend/tests/fixtures",
  "packages/replay-contract/fixtures",
] as const;
type JsonRecord = Record<string, unknown>;
const record = (value: unknown): value is JsonRecord =>
  value !== null && typeof value === "object" && !Array.isArray(value);
const nonempty = (value: unknown): value is string =>
  typeof value === "string" && value.trim().length > 0;
const hash = (value: unknown): value is string =>
  typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
const privateSegment = (part: string) =>
  [
    ".git",
    ".codex",
    ".agents",
    ".aws",
    ".ssh",
    ".gnupg",
    ".claude",
    "auth.json",
    ".netrc",
  ].includes(part) ||
  part.startsWith(".env") ||
  /^(?:credentials|authentication)(?:\.|$)/i.test(part);
function publicSupportSourcePath(value: unknown): value is string {
  return (
    typeof value === "string" &&
    /^backend\/tests\/support\/.+\.ts$/.test(value) &&
    !value.includes("\\") &&
    !value.split("/").some((part) => !part || part === "." || part === ".." || privateSegment(part))
  );
}
function sourceAssetPath(value: unknown): value is string {
  return publicSupportSourcePath(value) || (publicFixturePath(value) && /\.ts$/.test(value));
}
function publicFixturePath(value: unknown): value is string {
  return (
    typeof value === "string" &&
    !value.includes("\\") &&
    !value
      .split("/")
      .some((part) => !part || part === "." || part === ".." || privateSegment(part)) &&
    fixtureRoots.some((root) => value.startsWith(root + "/"))
  );
}
function fail(reason: string): never {
  throw new Error("fixture_manifest_invalid: " + reason);
}
function strictKeys(value: JsonRecord, keys: string[], label: string) {
  if (Object.keys(value).some((key) => !keys.includes(key))) fail(label + ":unknown_field");
  if (keys.some((key) => !Object.hasOwn(value, key))) fail(label + ":missing_field");
}
function evidence(value: unknown): value is FixtureEvidence[] {
  return (
    Array.isArray(value) &&
    value.length > 0 &&
    value.every((item: unknown) => {
      if (!record(item)) return false;
      strictKeys(item, ["path", "pointer", "detail"], "evidence");
      return nonempty(item.path) && typeof item.pointer === "string" && nonempty(item.detail);
    })
  );
}
function actor(value: unknown): value is FixtureActor {
  if (!record(value)) return false;
  strictKeys(value, ["playerId", "role", "camp"], "actor");
  return (
    Number.isSafeInteger(value.playerId) &&
    Number(value.playerId) > 0 &&
    nonempty(value.role) &&
    nonempty(value.camp)
  );
}
function checkMetadata(value: unknown): asserts value is FixtureMetadata {
  if (!record(value)) fail("metadata");
  const names = ["board", "policy", "seed", "locale", "actors", "source", "build", "formatVersion"];
  strictKeys(value, names, "metadata");
  for (const name of names) {
    const item = value[name];
    if (!record(item)) fail("observation:" + name);
    if (item.state === "unknown") {
      strictKeys(item, ["state", "reason"], "unknown");
      if (!nonempty(item.reason)) fail("unknown_reason:" + name);
      continue;
    }
    strictKeys(item, ["state", "value", "evidence"], "observed");
    if (item.state !== "observed" || !evidence(item.evidence)) fail("observed_evidence:" + name);
    const observed = item.value;
    if (["board", "locale", "build"].includes(name) && !nonempty(observed))
      fail("metadata:" + name);
    if (
      name === "seed" &&
      !(nonempty(observed) || (typeof observed === "number" && Number.isFinite(observed)))
    )
      fail("metadata:seed");
    if (
      name === "policy" &&
      !(
        Array.isArray(observed) &&
        observed.length > 0 &&
        observed.every(nonempty) &&
        new Set(observed).size === observed.length
      )
    )
      fail("metadata:policy");
    if (
      name === "actors" &&
      !(
        Array.isArray(observed) &&
        observed.length > 0 &&
        observed.every(actor) &&
        new Set(observed.map((entry) => entry.playerId)).size === observed.length
      )
    )
      fail("metadata:actors");
    if (name === "formatVersion" && !(Number.isSafeInteger(observed) && Number(observed) >= 1))
      fail("metadata:formatVersion");
    if (name === "source") {
      if (!record(observed)) fail("metadata:source");
      strictKeys(observed, ["commit", "path", "sha256"], "source");
      if (
        typeof observed.commit !== "string" ||
        !/^[a-f0-9]{40}$/.test(observed.commit) ||
        !publicFixturePath(observed.path) ||
        !hash(observed.sha256)
      )
        fail("metadata:source");
    }
  }
}

/** 只解析序列化清单并返回冻结数据；带访问器的运行对象不属于此入口的输入。 */
export function parseFixtureManifest(serialized: string): FixtureManifest {
  const value: unknown = JSON.parse(serialized);
  if (!record(value)) fail("document");
  strictKeys(
    value,
    [
      "schema",
      "generatedBy",
      "baseline",
      "coverage",
      "sourceAssets",
      "derivedManifests",
      "policy",
      "files",
      "suites",
    ],
    "document",
  );
  if (
    value.schema !== "awa-fixture-manifests-v2" ||
    value.generatedBy !== "tooling/refactor/fixture-manifest.ts" ||
    !nonempty(value.policy)
  )
    fail("schema");
  if (!record(value.baseline)) fail("baseline");
  strictKeys(value.baseline, ["commit", "inventoryPath", "inventorySha256"], "baseline");
  if (
    value.baseline.commit !== baselineCommit ||
    value.baseline.inventoryPath !== inventoryPath ||
    !hash(value.baseline.inventorySha256)
  )
    fail("baseline_identity");
  if (!record(value.coverage)) fail("coverage");
  strictKeys(
    value.coverage,
    ["expectedFiles", "exactBytesFiles", "mechanicalSourceFiles", "originalBytes", "currentBytes"],
    "coverage",
  );
  if (!Array.isArray(value.files) || !Array.isArray(value.suites)) fail("collections");
  const artifacts = new Map<string, FixtureArtifact>();
  for (const item of value.files) {
    if (!record(item)) fail("file");
    strictKeys(
      item,
      [
        "originPath",
        "currentPath",
        "sha256",
        "bytes",
        "currentSha256",
        "currentBytes",
        "owner",
        "kind",
        "suiteId",
        "metadata",
      ],
      "file",
    );
    if (
      !publicFixturePath(item.originPath) ||
      !publicFixturePath(item.currentPath) ||
      !hash(item.sha256) ||
      !hash(item.currentSha256) ||
      !Number.isSafeInteger(item.currentBytes) ||
      Number(item.currentBytes) < 0 ||
      !Number.isSafeInteger(item.bytes) ||
      Number(item.bytes) < 0 ||
      !nonempty(item.suiteId)
    )
      fail("file_identity");
    if (artifacts.has(item.originPath)) fail("duplicate_origin_path");
    if (ownerFor(item.originPath) !== item.owner || ownerFor(item.currentPath) !== item.owner)
      fail("file_owner");
    if (
      typeof item.kind !== "string" ||
      ![
        "god-replay",
        "checkpoint",
        "player-view",
        "player-view-bundle",
        "adapter-script",
        "unknown-json",
      ].includes(item.kind)
    )
      fail("file_kind");
    checkMetadata(item.metadata);
    const file = item as unknown as FixtureArtifact;
    if (
      file.metadata.source.state !== "observed" ||
      file.metadata.source.value.commit !== baselineCommit ||
      file.metadata.source.value.path !== file.originPath ||
      file.metadata.source.value.sha256 !== file.sha256
    )
      fail("file_source_identity");
    artifacts.set(file.originPath, file);
  }
  if (!Array.isArray(value.sourceAssets) || !Array.isArray(value.derivedManifests))
    fail("source_asset_collections");
  const sourceOrigins = new Set<string>(),
    sourceTargets = new Set<string>();
  for (const entry of value.sourceAssets) {
    if (!record(entry)) fail("source_asset");
    strictKeys(
      entry,
      [
        "originPath",
        "currentPath",
        "originCommit",
        "originalSha256",
        "originalBytes",
        "currentSha256",
        "currentBytes",
        "programSha256",
        "moduleBindingsSha256",
        "kind",
        ...(Object.hasOwn(entry, "moduleRelocations") ? ["moduleRelocations"] : []),
      ],
      "source_asset",
    );
    if (
      typeof entry.originPath !== "string" ||
      typeof entry.currentPath !== "string" ||
      !sourceAssetPath(entry.originPath) ||
      !sourceAssetPath(entry.currentPath) ||
      typeof entry.originCommit !== "string" ||
      !/^[a-f0-9]{40}$/.test(entry.originCommit) ||
      !hash(entry.originalSha256) ||
      !hash(entry.currentSha256) ||
      !hash(entry.programSha256) ||
      !hash(entry.moduleBindingsSha256) ||
      !Number.isSafeInteger(entry.originalBytes) ||
      Number(entry.originalBytes) < 0 ||
      !Number.isSafeInteger(entry.currentBytes) ||
      Number(entry.currentBytes) < 0 ||
      sourceOrigins.has(entry.originPath) ||
      sourceTargets.has(entry.currentPath) ||
      typeof entry.kind !== "string" ||
      !["adapter-script", "test-support"].includes(entry.kind)
    )
      fail("source_asset_identity");
    if (Object.hasOwn(entry, "moduleRelocations")) {
      if (!Array.isArray(entry.moduleRelocations)) fail("source_module_relocations");
      const relocationTargets = new Set<string>();
      for (const relocation of entry.moduleRelocations) {
        if (!record(relocation)) fail("source_module_relocation");
        strictKeys(relocation, ["originPath", "currentPath", "originCommit", "bindings"], "source_module_relocation");
        if (
          !publicSupportSourcePath(relocation.originPath) ||
          !publicSupportSourcePath(relocation.currentPath) ||
          typeof relocation.originCommit !== "string" ||
          !/^[a-f0-9]{40}$/.test(relocation.originCommit) ||
          relocationTargets.has(relocation.currentPath) ||
          !Array.isArray(relocation.bindings) || relocation.bindings.length === 0
        ) fail("source_module_relocation_identity");
        relocationTargets.add(relocation.currentPath);
        const names = new Set<string>();
        for (const binding of relocation.bindings) {
          if (!record(binding)) fail("source_module_binding");
          strictKeys(binding, ["name", "declarationSha256"], "source_module_binding");
          if (
            typeof binding.name !== "string" || !/^[A-Za-z_$][\w$]*$/.test(binding.name) ||
            names.has(binding.name) || !hash(binding.declarationSha256)
          ) fail("source_module_binding_identity");
          names.add(binding.name);
        }
      }
    }
    sourceOrigins.add(entry.originPath);
    sourceTargets.add(entry.currentPath);
    const artifact = artifacts.get(entry.originPath);
    if (
      entry.kind === "adapter-script" &&
      (!artifact ||
        artifact.kind !== "adapter-script" ||
        entry.originCommit !== baselineCommit ||
        artifact.currentPath !== entry.currentPath ||
        artifact.sha256 !== entry.originalSha256 ||
        artifact.bytes !== entry.originalBytes ||
        artifact.currentSha256 !== entry.currentSha256 ||
        artifact.currentBytes !== entry.currentBytes)
    )
      fail("source_asset_artifact_consistency");
    if (
      entry.kind === "test-support" &&
      (!publicSupportSourcePath(entry.originPath) || !publicSupportSourcePath(entry.currentPath))
    )
      fail("source_asset_support_identity");
  }
  // JSON 档案必须字节不变；只有登记了独立程序证明的脚本允许机械路径迁移。
  for (const file of artifacts.values())
    if (
      file.kind !== "adapter-script" &&
      (file.sha256 !== file.currentSha256 || file.bytes !== file.currentBytes)
    )
      fail("json_archive_byte_drift");
  for (const file of artifacts.values())
    if (
      file.kind === "adapter-script" &&
      (file.sha256 !== file.currentSha256 || file.bytes !== file.currentBytes) &&
      !sourceOrigins.has(file.originPath)
    )
      fail("source_asset_proof_missing");
  const suiteIds = new Set<string>(),
    assigned = new Set<string>(),
    currentPaths = new Set<string>();
  for (const file of artifacts.values()) {
    if (currentPaths.has(file.currentPath)) fail("duplicate_current_path");
    currentPaths.add(file.currentPath);
  }
  for (const item of value.suites) {
    if (!record(item)) fail("suite");
    strictKeys(
      item,
      [
        "suiteId",
        "anchorOriginPath",
        "owner",
        "kind",
        "files",
        "metadata",
        "membership",
        "acceptance",
      ],
      "suite",
    );
    if (
      !publicFixturePath(item.anchorOriginPath) ||
      typeof item.suiteId !== "string" ||
      item.suiteId !== suiteIdFor(item.anchorOriginPath) ||
      suiteIds.has(item.suiteId)
    )
      fail("suite_identity");
    suiteIds.add(item.suiteId);
    if (
      typeof item.kind !== "string" ||
      !["recorded-archive", "adapter-script", "unassociated-json"].includes(item.kind) ||
      !Array.isArray(item.files) ||
      item.files.length === 0 ||
      !item.files.includes(item.anchorOriginPath)
    )
      fail("suite_files");
    checkMetadata(item.metadata);
    const memberArtifacts: FixtureArtifact[] = [];
    for (const filePath of item.files) {
      if (typeof filePath !== "string" || assigned.has(filePath)) fail("duplicate_membership");
      const file = artifacts.get(filePath);
      if (!file || file.suiteId !== item.suiteId || file.owner !== item.owner)
        fail("membership_owner");
      assigned.add(filePath);
      memberArtifacts.push(file);
    }
    if (!Array.isArray(item.membership) || item.membership.length !== item.files.length)
      fail("membership_evidence");
    const membershipPaths = new Set<string>();
    for (const member of item.membership) {
      if (!record(member)) fail("member");
      strictKeys(member, ["originPath", "state", "evidence"], "member");
      if (
        typeof member.originPath !== "string" ||
        membershipPaths.has(member.originPath) ||
        !item.files.includes(member.originPath) ||
        typeof member.state !== "string" ||
        !["literal-associated", "standalone"].includes(member.state) ||
        !evidence(member.evidence)
      )
        fail("member_evidence");
      membershipPaths.add(member.originPath);
    }
    const acceptance = item.acceptance;
    if (!record(acceptance)) fail("acceptance");
    strictKeys(acceptance, ["status", "evidence", "unresolved"], "acceptance");
    if (
      typeof acceptance.status !== "string" ||
      !["pending-review", "accepted", "rejected"].includes(acceptance.status) ||
      !Array.isArray(acceptance.evidence) ||
      !acceptance.evidence.length ||
      !Array.isArray(acceptance.unresolved) ||
      !acceptance.unresolved.every(nonempty)
    )
      fail("acceptance_status");
    for (const entry of acceptance.evidence) {
      if (!record(entry)) fail("acceptance_evidence");
      strictKeys(entry, ["kind", "reference", "detail"], "acceptance_evidence");
      if (
        typeof entry.kind !== "string" ||
        !["baseline-byte-match", "metadata-association", "independent-review"].includes(
          entry.kind,
        ) ||
        !nonempty(entry.reference) ||
        !nonempty(entry.detail)
      )
        fail("acceptance_evidence");
    }
    if (
      acceptance.status !== "pending-review" &&
      !acceptance.evidence.some((entry) => record(entry) && entry.kind === "independent-review")
    )
      fail("acceptance_requires_independent_review");
    const unresolved = acceptance.unresolved;
    if (
      Object.entries(item.metadata).some(
        ([name, observation]) =>
          observation.state === "unknown" &&
          !unresolved.some((issue) => issue.startsWith(name + ":")),
      )
    )
      fail("unknown_metadata_requires_unresolved_issue");
    const anchor = artifacts.get(item.anchorOriginPath)!;
    if (
      item.metadata.source.state !== "observed" ||
      canonical(item.metadata.source.value) !==
        canonical(anchor.metadata.source.state === "observed" ? anchor.metadata.source.value : null)
    )
      fail("suite_source_identity");
    // 文件与 suite 不能联合捏造新元数据；这里只核两层记录一致，实际档案仍需另行重读核对。
    const aggregate = mergeMetadata(
      { file: anchor, value: undefined },
      memberArtifacts.map((file) => ({ file, value: undefined })),
    );
    for (const name of Object.keys(aggregate) as (keyof FixtureMetadata)[]) {
      const expected = aggregate[name],
        actual = item.metadata[name];
      if (
        expected.state !== actual.state ||
        (expected.state === "observed" &&
          actual.state === "observed" &&
          canonical(expected.value) !== canonical(actual.value))
      )
        fail("suite_metadata_inconsistent:" + name);
    }
  }
  const originalBytes = [...artifacts.values()].reduce((total, file) => total + file.bytes, 0);
  const currentBytes = [...artifacts.values()].reduce(
    (total, file) => total + file.currentBytes,
    0,
  );
  const exactBytesFiles = [...artifacts.values()].filter(
    (file) => file.sha256 === file.currentSha256 && file.bytes === file.currentBytes,
  ).length;
  const mechanicalSourceFiles = artifacts.size - exactBytesFiles;
  if (
    assigned.size !== artifacts.size ||
    value.coverage.expectedFiles !== artifacts.size ||
    value.coverage.exactBytesFiles !== exactBytesFiles ||
    value.coverage.mechanicalSourceFiles !== mechanicalSourceFiles ||
    value.coverage.originalBytes !== originalBytes ||
    value.coverage.currentBytes !== currentBytes
  )
    fail("coverage_mismatch");
  const derivedPaths = new Set<string>();
  const validatedSuites = value.suites;
  for (const entry of value.derivedManifests) {
    if (!record(entry)) fail("derived_manifest");
    strictKeys(entry, ["path", "suiteIds"], "derived_manifest");
    if (
      !publicFixturePath(entry.path) ||
      !entry.path.endsWith("/manifest.json") ||
      derivedPaths.has(entry.path) ||
      currentPaths.has(entry.path) ||
      !Array.isArray(entry.suiteIds) ||
      !entry.suiteIds.length ||
      new Set(entry.suiteIds).size !== entry.suiteIds.length ||
      entry.suiteIds.some((id) => typeof id !== "string" || !suiteIds.has(id))
    )
      fail("derived_manifest_identity");
    const parent = entry.path.slice(0, entry.path.lastIndexOf("/") + 1);
    if (
      entry.suiteIds.some((id) =>
        validatedSuites.some(
          (suite) =>
            record(suite) &&
            suite.suiteId === id &&
            Array.isArray(suite.files) &&
            suite.files.some(
              (origin) =>
                typeof origin !== "string" ||
                !artifacts.get(origin)!.currentPath.startsWith(parent),
            ),
        ),
      )
    )
      fail("derived_manifest_membership");
    derivedPaths.add(entry.path);
  }
  // value 来自本次 JSON.parse，完整校验后递归冻结；不把此逻辑当作任意运行对象的安全读取器。
  const freeze = (entry: unknown): void => {
    if (entry && typeof entry === "object") {
      Object.values(entry).forEach(freeze);
      Object.freeze(entry);
    }
  };
  freeze(value);
  return value as unknown as FixtureManifest;
}

export function fixtureSuitesForOwner(
  manifest: FixtureManifest,
  owner: FixtureOwner,
): readonly FixtureSuite[] {
  return manifest.suites.filter((suite) => suite.owner === owner);
}
export function fixtureSuiteById(manifest: FixtureManifest, suiteId: string): FixtureSuite {
  const suite = manifest.suites.find((entry) => entry.suiteId === suiteId);
  if (!suite) throw new Error("fixture_suite_missing: " + suiteId);
  return suite;
}
function ownerFor(file: string): FixtureOwner {
  if (file.startsWith("backend/")) return "backend";
  if (file.startsWith("frontend/")) return "frontend";
  return "replay-contract";
}
function suiteIdFor(anchor: string): string {
  return "fixture:" + anchor;
}
const unknown = <T>(reason: string): FixtureObservation<T> => ({ state: "unknown", reason });
const observed = <T>(value: T, evidence: FixtureEvidence[]): FixtureObservation<T> => ({
  state: "observed",
  value,
  evidence,
});
const ref = (path: string, pointer: string, detail: string): FixtureEvidence => ({
  path,
  pointer,
  detail,
});
function canonical(value: unknown): string {
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (record(value))
    return (
      "{" +
      Object.keys(value)
        .sort()
        .map((key) => JSON.stringify(key) + ":" + canonical(value[key]))
        .join(",") +
      "}"
    );
  return JSON.stringify(value) ?? "undefined";
}
function actorsFrom(value: unknown, kind: FixtureKind): FixtureActor[] {
  let entries: unknown[] = [];
  if (kind === "player-view-bundle" && Array.isArray(value)) entries = value;
  if (kind === "player-view" && record(value)) entries = [value];
  if (
    (kind === "god-replay" || kind === "checkpoint") &&
    record(value) &&
    Array.isArray(value.players)
  )
    entries = value.players;
  return entries.flatMap((entry) => {
    if (!record(entry)) return [];
    const playerId = entry.player_id ?? entry.id;
    if (
      !Number.isSafeInteger(playerId) ||
      Number(playerId) <= 0 ||
      !nonempty(entry.role) ||
      !nonempty(entry.camp)
    )
      return [];
    return [{ playerId: Number(playerId), role: entry.role, camp: entry.camp }];
  });
}
function classify(value: unknown, script: boolean): FixtureKind {
  if (script) return "adapter-script";
  if (
    record(value) &&
    Array.isArray(value.events) &&
    record(value.meta) &&
    value.perspective === "god"
  )
    return "god-replay";
  if (record(value) && record(value.snapshot) && Array.isArray(value.players)) return "checkpoint";
  if (record(value) && Array.isArray(value.timeline)) return "player-view";
  if (
    Array.isArray(value) &&
    value.length > 0 &&
    value.every((entry) => record(entry) && Array.isArray(entry.timeline))
  )
    return "player-view-bundle";
  return "unknown-json";
}
interface LoadedFixture {
  file: FixtureArtifact;
  value: unknown;
}
function literalMetadata(file: FixtureArtifact, value: unknown): FixtureMetadata {
  const path = file.originPath;
  const collect = (name: string) => {
    const values = new Map<string, { value: string | number; evidence: FixtureEvidence }>();
    const walk = (node: unknown, pointer: string) => {
      if (Array.isArray(node)) node.forEach((entry, index) => walk(entry, pointer + "/" + index));
      else if (record(node))
        for (const [key, entry] of Object.entries(node)) {
          const next = pointer + "/" + key.replaceAll("~", "~0").replaceAll("/", "~1");
          if (
            key === name &&
            (nonempty(entry) || (typeof entry === "number" && Number.isFinite(entry)))
          )
            values.set(canonical(entry), {
              value: entry,
              evidence: ref(
                path,
                next,
                "Literal serialized " + name + "; not inferred from a filename or production rule.",
              ),
            });
          walk(entry, next);
        }
    };
    walk(value, "");
    return [...values.values()];
  };
  // 单值字段只接受唯一字面观察；同名字段冲突保留 unknown，不按文件名或规则默认值猜测。
  const scalar = (name: string): FixtureObservation<string> => {
    const entries = collect(name);
    return entries.length === 1 && nonempty(entries[0]!.value)
      ? observed(entries[0]!.value, [entries[0]!.evidence])
      : unknown(
          entries.length
            ? "Multiple literal " + name + " values require review."
            : "No literal " + name + " is recorded in this artifact.",
        );
  };
  const policies = collect("policy"),
    seeds = collect("seed"),
    actors = actorsFrom(value, file.kind);
  const version = record(value) ? value.schemaVersion : undefined;
  return {
    board: scalar("board"),
    policy:
      policies.length && policies.every((entry) => nonempty(entry.value))
        ? observed(
            policies.map((entry) => entry.value as string).sort(),
            policies.map((entry) => entry.evidence),
          )
        : unknown("No literal policy identity is serialized; a board name is not policy evidence."),
    seed:
      seeds.length === 1
        ? observed(seeds[0]!.value, [seeds[0]!.evidence])
        : unknown(
            seeds.length
              ? "Conflicting literal seeds require review."
              : "No seed is serialized; producer defaults are not evidence of the original invocation.",
          ),
    locale: scalar("locale"),
    actors: actors.length
      ? observed(actors, [
          ref(
            path,
            file.kind === "player-view-bundle"
              ? ""
              : file.kind === "player-view"
                ? "/player_id"
                : "/players",
            "Literal actor id, role and camp, preserving serialized identities.",
          ),
        ])
      : unknown("No complete actor identity is serialized."),
    source: observed({ commit: baselineCommit, path, sha256: file.sha256 }, [
      ref(
        inventoryPath,
        "/files",
        "Frozen public Git origin and exact artifact byte digest; this does not identify a producer build.",
      ),
    ]),
    build: scalar("build"),
    formatVersion:
      Number.isSafeInteger(version) && Number(version) >= 1
        ? observed(Number(version), [
            ref(path, "/schemaVersion", "Serialized format version, not a producer build version."),
          ])
        : unknown("No schemaVersion is serialized; legacy status does not identify a build."),
  };
}
function mergeMetadata(anchor: LoadedFixture, members: LoadedFixture[]): FixtureMetadata {
  const merged = { ...anchor.file.metadata };
  for (const name of ["board", "seed", "locale", "build", "formatVersion"] as const) {
    const observations = members.flatMap((member) => {
      const item = member.file.metadata[name];
      return item.state === "observed" ? [item] : [];
    });
    const values = new Set(observations.map((item) => canonical(item.value)));
    if (values.size > 1)
      merged[name] = unknown(
        "Associated artifacts record conflicting " + name + " values; manual review required.",
      ) as never;
    else if (observations.length)
      merged[name] = observed(
        observations[0]!.value,
        observations.flatMap((item) => item.evidence),
      ) as never;
  }
  const policies = members.flatMap((member) =>
    member.file.metadata.policy.state === "observed" ? [member.file.metadata.policy] : [],
  );
  if (policies.length)
    merged.policy = observed(
      [...new Set(policies.flatMap((item) => item.value))].sort(),
      policies.flatMap((item) => item.evidence),
    );
  const actors = members.flatMap((member) =>
    member.file.metadata.actors.state === "observed" ? [member.file.metadata.actors] : [],
  );
  if (actors.length)
    merged.actors = observed(
      [
        ...new Map(
          actors.flatMap((item) => item.value).map((item) => [canonical(item), item]),
        ).values(),
      ].sort((a, b) => a.playerId - b.playerId),
      actors.flatMap((item) => item.evidence),
    );
  return merged;
}

/** 关联调用方提供的纯数据描述；此纯函数不读取文件或核对实际字节，也不计算游戏结果预期。 */
export function describeFixtureCohorts(
  inputs: { originPath: string; sha256: string; bytes: number; value: unknown; script: boolean }[],
): Pick<FixtureManifest, "files" | "suites"> {
  const loaded: LoadedFixture[] = inputs.map((input) => {
    if (
      !publicFixturePath(input.originPath) ||
      !hash(input.sha256) ||
      !Number.isSafeInteger(input.bytes) ||
      input.bytes < 0
    )
      fail("input_identity");
    const file = {
      originPath: input.originPath,
      currentPath: input.originPath,
      sha256: input.sha256,
      bytes: input.bytes,
      currentSha256: input.sha256,
      currentBytes: input.bytes,
      owner: ownerFor(input.originPath),
      kind: classify(input.value, input.script),
      suiteId: suiteIdFor(input.originPath),
    } as FixtureArtifact;
    file.metadata = literalMetadata(file, input.value);
    return { file, value: input.value };
  });
  // 共享事件只作为候选索引；后续还核真实录制的玩家身份与语言，不能由事件命中直接授予归属。
  const gods = loaded.filter((item) => item.file.kind === "god-replay"),
    eventIndex = new Map<string, Set<LoadedFixture>>();
  for (const god of gods) {
    if (!record(god.value) || !Array.isArray(god.value.events)) continue;
    for (const event of god.value.events)
      if (record(event) && typeof event.timestamp === "string" && typeof event.type === "string") {
        const key = canonical([event.timestamp, event.type, event.payload]);
        const entries = eventIndex.get(key) ?? new Set<LoadedFixture>();
        entries.add(god);
        eventIndex.set(key, entries);
      }
  }
  const groups = new Map<LoadedFixture, LoadedFixture[]>(),
    memberships = new Map<LoadedFixture, FixtureSuite["membership"][number]>();
  for (const god of gods) groups.set(god, [god]);
  for (const item of loaded) {
    let candidates: LoadedFixture[] = [],
      detail = "Standalone artifact; no cross-file relationship was asserted.";
    if (["player-view", "player-view-bundle"].includes(item.file.kind)) {
      const views = Array.isArray(item.value) ? item.value : [item.value];
      let shared: Set<LoadedFixture> | undefined;
      for (const view of views) {
        const hits = new Set<LoadedFixture>();
        if (record(view) && Array.isArray(view.timeline))
          for (const entry of view.timeline)
            if (record(entry) && record(entry.event)) {
              for (const god of eventIndex.get(
                canonical([entry.timestamp, entry.event.type, entry.event.payload]),
              ) ?? [])
                hits.add(god);
            }
        shared = shared === undefined ? hits : new Set([...shared].filter((god) => hits.has(god)));
      }
      candidates = [...(shared ?? [])].filter((god) => {
        if (
          god.file.owner !== item.file.owner ||
          god.file.metadata.actors.state !== "observed" ||
          item.file.metadata.actors.state !== "observed"
        )
          return false;
        const roster = god.file.metadata.actors.value;
        return (
          item.file.metadata.actors.value.length === views.length &&
          item.file.metadata.actors.value.every((actor) =>
            roster.some((candidate) => canonical(candidate) === canonical(actor)),
          ) &&
          views.every(
            (view) =>
              record(view) &&
              (view.locale === undefined ||
                (god.file.metadata.locale.state === "observed" &&
                  view.locale === god.file.metadata.locale.value)),
          )
        );
      });
      detail =
        "Each actor shares literal event timestamp, type and payload with exactly one god archive; actor id/role/camp and recorded locale agree. No filename or production projection supplies the match.";
    } else if (item.file.kind === "checkpoint" && record(item.value)) {
      const name = item.file.originPath.slice(item.file.originPath.lastIndexOf("/") + 1);
      const stem = name.endsWith(".checkpoint.txt")
        ? name.slice(0, -".checkpoint.txt".length)
        : name.endsWith(".json")
          ? name.slice(0, -".json".length)
          : "";
      const checkpoint = item.value;
      candidates = gods.filter((god) => {
        if (
          god.file.owner !== item.file.owner ||
          !god.file.originPath.endsWith("/" + stem + ".replay.json") ||
          !record(god.value) ||
          !record(checkpoint.snapshot) ||
          !Array.isArray(god.value.events) ||
          !record(god.value.result)
        )
          return false;
        const completeRoster = (member: LoadedFixture) =>
          record(member.value) &&
          Array.isArray(member.value.players) &&
          member.file.metadata.actors.state === "observed" &&
          member.file.metadata.actors.value.length > 0 &&
          member.file.metadata.actors.value.length === member.value.players.length &&
          new Set(member.file.metadata.actors.value.map((actor) => actor.playerId)).size ===
            member.value.players.length;
        if (!completeRoster(item) || !completeRoster(god)) return false;
        if (
          checkpoint.eventCount !== god.value.events.length ||
          canonical(
            item.file.metadata.actors.state === "observed" ? item.file.metadata.actors.value : [],
          ) !==
            canonical(
              god.file.metadata.actors.state === "observed" ? god.file.metadata.actors.value : [],
            )
        )
          return false;
        const outcome = god.value.result.decision ?? god.value.result;
        const ordinary = canonical(checkpoint.snapshot.result) === canonical(outcome);
        const last = god.value.events.at(-1);
        const failed =
          record(checkpoint.failure) &&
          checkpoint.failure.code === "cycle_failed" &&
          checkpoint.snapshot.result === null &&
          checkpoint.snapshot.gameOver === false &&
          checkpoint.complete === false &&
          god.value.result.reason === "runtime_error" &&
          god.value.result.winner === null &&
          record(last) &&
          checkpoint.snapshot.day === last.day &&
          checkpoint.snapshot.phase === last.phase;
        return ordinary || failed;
      });
      detail =
        "Basename only locates candidates; recorded eventCount, complete actor roster and literal terminal result agree, or the explicit cycle_failed/runtime_error nonterminal snapshot and last event day/phase agree. This compares archives and never predicts a rule outcome.";
    }
    // 只有唯一候选才关联；歧义或无匹配保持独立档案，不任意选首个候选。
    const anchor =
      item.file.kind === "god-replay" ? item : candidates.length === 1 ? candidates[0]! : item;
    item.file.suiteId = suiteIdFor(anchor.file.originPath);
    if (anchor !== item) groups.get(anchor)!.push(item);
    else if (!groups.has(item)) groups.set(item, [item]);
    memberships.set(item, {
      originPath: item.file.originPath,
      state: anchor !== item ? "literal-associated" : "standalone",
      evidence: [
        ref(
          item.file.originPath,
          "",
          anchor !== item
            ? detail
            : candidates.length > 1
              ? "Multiple archive associations require review; no match was selected."
              : item.file.kind === "checkpoint"
                ? "No complete literal actor/event/outcome archive association was established; this checkpoint remains standalone pending review."
                : ["player-view", "player-view-bundle"].includes(item.file.kind)
                  ? "No unique literal event/actor/locale archive association was established; this player archive remains standalone pending review."
                  : "Standalone identity anchor; no cross-file relationship was asserted.",
        ),
      ],
    });
  }
  const suites = [...groups.entries()].map(([anchor, members]): FixtureSuite => {
    const metadata = mergeMetadata(anchor, members);
    const unresolved = Object.entries(metadata).flatMap(([name, observation]) =>
      observation.state === "unknown" ? [name + ": " + observation.reason] : [],
    );
    if (
      anchor.file.kind === "player-view" ||
      anchor.file.kind === "player-view-bundle" ||
      anchor.file.kind === "unknown-json"
    )
      unresolved.push("Archive association is unresolved; this artifact remains standalone.");
    unresolved.push(
      "Grouping and exact byte preservation are inventory evidence; independent scenario/consumer acceptance has not been assigned.",
    );
    return {
      suiteId: suiteIdFor(anchor.file.originPath),
      anchorOriginPath: anchor.file.originPath,
      owner: anchor.file.owner,
      kind:
        anchor.file.kind === "god-replay"
          ? "recorded-archive"
          : anchor.file.kind === "adapter-script"
            ? "adapter-script"
            : "unassociated-json",
      files: members.map((member) => member.file.originPath).sort(),
      metadata,
      membership: members
        .map((member) => memberships.get(member)!)
        .sort((a, b) => a.originPath.localeCompare(b.originPath)),
      acceptance: {
        status: "pending-review",
        evidence: [
          {
            kind: "metadata-association",
            reference: anchor.file.originPath,
            detail:
              "Membership evidence identifies literal associations or explicit standalone status; this pure description does not verify caller-supplied byte hashes or infer passed test status.",
          },
        ],
        unresolved,
      },
    };
  });
  return {
    files: loaded.map((item) => item.file).sort((a, b) => a.originPath.localeCompare(b.originPath)),
    suites: suites.sort((a, b) => a.suiteId.localeCompare(b.suiteId)),
  };
}

/** 仅派生已登记的精确子集，重新校验其清单；不读磁盘或赋予验收状态。 */
export function deriveLocalFixtureManifest(
  document: FixtureManifest,
  manifestPath: string,
): FixtureManifest {
  const descriptor = document.derivedManifests.find((entry) => entry.path === manifestPath);
  if (!descriptor) fail("derived_manifest_unregistered");
  const suites = document.suites.filter((suite) => descriptor.suiteIds.includes(suite.suiteId));
  const origins = new Set(suites.flatMap((suite) => suite.files));
  const files = document.files.filter((file) => origins.has(file.originPath));
  const exactBytesFiles = files.filter(
    (file) => file.sha256 === file.currentSha256 && file.bytes === file.currentBytes,
  ).length;
  return parseFixtureManifest(
    JSON.stringify({
      ...document,
      files,
      suites,
      derivedManifests: [],
      sourceAssets: document.sourceAssets.filter(
        (asset) => asset.kind === "test-support" || origins.has(asset.originPath),
      ),
      coverage: {
        expectedFiles: files.length,
        exactBytesFiles,
        mechanicalSourceFiles: files.length - exactBytesFiles,
        originalBytes: files.reduce((sum, file) => sum + file.bytes, 0),
        currentBytes: files.reduce((sum, file) => sum + file.currentBytes, 0),
      },
    }),
  );
}

/** 描述脱离执行的源码程序，包括 RPC／动作字面和导入绑定；只规范化已准许的模块路径与语句前置空白／注释，不执行输入脚本。 */
export function sourceProgramContract(
  ts: typeof import("typescript"),
  text: string,
  filename: string,
  current: boolean,
  mappings: readonly { originPath: string; currentPath: string }[],
  relocations: readonly FixtureSourceModuleRelocation[] = [],
): { statements: string[]; moduleBindings: string[] } {
  const inverse = new Map(mappings.map((asset) => [asset.currentPath, asset.originPath]));
  const relocated = new Map(relocations.map((entry) => [entry.currentPath, entry]));
  // 具名导入迁移须精确匹配登记绑定，并且每项只使用一次；不能借路径映射吞掉漏接或新增导入。
  const observedRelocations = new Set<string>();
  const ast = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true);
  const changes: { start: number; end: number; replacement: string }[] = [];
  const imports: string[] = [];
  const visit = (node: import("typescript").Node) => {
    let literal: import("typescript").StringLiteralLike | undefined;
    if (
      (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) &&
      node.moduleSpecifier &&
      ts.isStringLiteralLike(node.moduleSpecifier)
    )
      literal = node.moduleSpecifier;
    else if (
      ts.isImportTypeNode(node) &&
      ts.isLiteralTypeNode(node.argument) &&
      ts.isStringLiteralLike(node.argument.literal)
    )
      literal = node.argument.literal;
    else if (
      ts.isCallExpression(node) &&
      node.expression.kind === ts.SyntaxKind.ImportKeyword &&
      node.arguments[0] &&
      ts.isStringLiteralLike(node.arguments[0])
    )
      literal = node.arguments[0];
    if (literal) {
      let identity = literal.text;
      if (identity.startsWith(".")) {
        identity = normalizeSourceModule(filename, identity);
        if (!identity.endsWith(".ts")) identity += ".ts";
        if (current) {
          const relocation = relocated.get(identity);
          if (relocation) {
            if (!ts.isImportDeclaration(node) || !node.importClause || node.importClause.name ||
              !node.importClause.namedBindings || !ts.isNamedImports(node.importClause.namedBindings))
              fail("source_module_relocation_requires_named_import");
            const names = node.importClause.namedBindings.elements.map((entry) =>
              (entry.propertyName ?? entry.name).text).sort();
            const expected = relocation.bindings.map((entry) => entry.name).sort();
            if (JSON.stringify(names) !== JSON.stringify(expected))
              fail("source_module_relocation_binding_drift");
            if (observedRelocations.has(identity)) fail("source_module_relocation_duplicate_import");
            observedRelocations.add(identity);
            identity = relocation.originPath;
          }
          identity = inverse.get(identity) ?? identity;
        }
      }
      changes.push({
        start: literal.getStart(ast),
        end: literal.getEnd(),
        replacement: JSON.stringify(identity),
      });
      imports.push(node.getText(ast).replace(literal.getText(ast), JSON.stringify(identity)));
    }
    ts.forEachChild(node, visit);
  };
  visit(ast);
  if (current && observedRelocations.size !== relocations.length)
    fail("source_module_relocation_unused");
  let normalized = text;
  for (const change of changes.sort((a, b) => b.start - a.start))
    normalized =
      normalized.slice(0, change.start) + change.replacement + normalized.slice(change.end);
  const normalizedAst = ts.createSourceFile(filename, normalized, ts.ScriptTarget.Latest, true);
  return {
    statements: normalizedAst.statements.map((node) => node.getText(normalizedAst)),
    moduleBindings: imports,
  };
}

/** 输出完整具名导出声明的规范语法，移除格式／注释，不执行源码。 */
export function sourceDeclarationContract(
  ts: typeof import("typescript"), text: string, filename: string, name: string,
): string {
  const ast = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true);
  const nodes = ast.statements.filter((node) => {
    if (ts.isFunctionDeclaration(node) || ts.isInterfaceDeclaration(node) ||
      ts.isTypeAliasDeclaration(node) || ts.isClassDeclaration(node) || ts.isEnumDeclaration(node))
      return node.name?.text === name;
    return false;
  });
  if (nodes.length !== 1) fail("source_module_declaration_identity");
  const declaration = nodes[0]!;
  const modifiers = ts.canHaveModifiers(declaration) ? ts.getModifiers(declaration) : undefined;
  if (!modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword) ||
    modifiers.some((modifier) => modifier.kind === ts.SyntaxKind.DefaultKeyword))
    fail("source_module_declaration_requires_named_export");
  return ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed })
    .printNode(ts.EmitHint.Unspecified, declaration, ast);
}

function normalizeSourceModule(filename: string, specifier: string): string {
  const parts = (filename.slice(0, filename.lastIndexOf("/") + 1) + specifier).split("/");
  const normalized: string[] = [];
  for (const part of parts) {
    if (part === "." || !part) continue;
    if (part === "..") normalized.pop();
    else normalized.push(part);
  }
  return normalized.join("/");
}

/** 对照实际档案的纯数据输入重算元数据与关联；两侧都不计算游戏规则预期。 */
export function assertLiteralFixtureMetadata(
  layout: FixtureManifest,
  actualInputs: Parameters<typeof describeFixtureCohorts>[0],
): void {
  const described = describeFixtureCohorts(actualInputs);
  const fileMetadata = (files: FixtureArtifact[]) =>
    files.map(({ originPath, kind, suiteId, metadata }) => ({
      originPath,
      kind,
      suiteId,
      metadata,
    }));
  const suiteMetadata = (suites: FixtureSuite[]) =>
    suites.map(({ suiteId, anchorOriginPath, owner, kind, files, metadata, membership }) => ({
      suiteId,
      anchorOriginPath,
      owner,
      kind,
      files,
      metadata,
      membership,
    }));
  if (
    canonical(fileMetadata(described.files)) !== canonical(fileMetadata(layout.files)) ||
    canonical(suiteMetadata(described.suites)) !== canonical(suiteMetadata(layout.suites))
  )
    fail("literal_archive_metadata_or_association_drift");
}

/** 只读取白名单公开 fixture 根，先核固定 Git 字节，再验证当前档案与登记描述。 */
export async function generateFixtureManifest(repository: string): Promise<FixtureManifest> {
  const fs = await import("node:fs/promises"),
    path = await import("node:path"),
    crypto = await import("node:crypto"),
    childProcess = await import("node:child_process");
  const requestedRoot = path.resolve(repository);
  const rootParts = requestedRoot
    .slice(path.parse(requestedRoot).root.length)
    .split(path.sep)
    .filter(Boolean);
  if (rootParts.some(privateSegment)) fail("private_repository_path_rejected");
  let rootComponent = path.parse(requestedRoot).root;
  for (const part of rootParts) {
    rootComponent = path.join(rootComponent, part);
    const info = await fs.lstat(rootComponent);
    if (info.isSymbolicLink()) fail("repository_symlink_rejected");
    if (!info.isDirectory()) fail("repository_directory_required");
  }
  const root = await fs.realpath(requestedRoot);
  if (root !== requestedRoot) fail("repository_resolution_changed");
  const digest = (bytes: Uint8Array | string) =>
    crypto.createHash("sha256").update(bytes).digest("hex");
  async function safeFile(relative: string) {
    if (
      relative !== inventoryPath &&
      relative !== fixtureManifestPath &&
      !publicFixturePath(relative) &&
      !publicSupportSourcePath(relative)
    )
      fail("private_path_rejected");
    const parts = relative.split("/");
    for (let index = 1; index <= parts.length; index++) {
      const candidate = path.join(root, ...parts.slice(0, index)),
        info = await fs.lstat(candidate);
      if (info.isSymbolicLink()) fail("symlink_rejected");
      if (
        (index < parts.length && !info.isDirectory()) ||
        (index === parts.length && !info.isFile())
      )
        fail("public_input_kind");
    }
    return fs.readFile(path.join(root, relative));
  }
  const inventoryBytes = await safeFile(inventoryPath),
    inventory: unknown = JSON.parse(inventoryBytes.toString("utf8"));
  if (!record(inventory) || inventory.commit !== baselineCommit || !Array.isArray(inventory.files))
    fail("frozen_inventory_identity");
  // 清单不仅要自洽，还须与冻结 Git 的完整路径、大小和 blob 字节逐项一致。
  const rows = inventory.files.map((row: unknown) => {
    if (
      !record(row) ||
      !publicFixturePath(row.path) ||
      !hash(row.sha256) ||
      !Number.isSafeInteger(row.bytes) ||
      Number(row.bytes) < 0
    )
      fail("frozen_inventory_row");
    return { originPath: row.path, sha256: row.sha256, bytes: Number(row.bytes) };
  });
  const git = childProcess.execFileSync(
    "git",
    ["ls-tree", "-r", "-z", baselineCommit, "--", ...fixtureRoots],
    { cwd: root, encoding: "utf8", maxBuffer: 4 * 1024 * 1024 },
  );
  const origin = git
    .split("\0")
    .filter(Boolean)
    .map((entry) => {
      const match = /^(\d+) blob ([a-f0-9]{40})\t(.+)$/.exec(entry);
      if (!match || match[1] === "120000" || !publicFixturePath(match[3])) fail("frozen_git_input");
      return { path: match[3]!, blob: match[2]! };
    });
  if (
    origin.length !== 907 ||
    rows.length !== origin.length ||
    new Set(rows.map((row) => row.originPath)).size !== rows.length ||
    rows.some((row) => !origin.some((entry) => entry.path === row.originPath))
  )
    fail("frozen_inventory_coverage");
  const blobs = childProcess.execFileSync("git", ["cat-file", "--batch"], {
    cwd: root,
    input: origin.map((entry) => entry.blob).join("\n") + "\n",
    maxBuffer: 128 * 1024 * 1024,
  });
  const originalContents = new Map<string, Uint8Array>();
  let offset = 0;
  for (const entry of origin) {
    const end = blobs.indexOf(10, offset),
      header = blobs.subarray(offset, end).toString("utf8"),
      match = /^([a-f0-9]{40}) blob (\d+)$/.exec(header);
    if (end < 0 || !match || match[1] !== entry.blob) fail("frozen_git_blob");
    const size = Number(match[2]),
      content = blobs.subarray(end + 1, end + 1 + size),
      row = rows.find((candidate) => candidate.originPath === entry.path)!;
    if (
      content.length !== size ||
      blobs[end + 1 + size] !== 10 ||
      size !== row.bytes ||
      digest(content) !== row.sha256
    )
      fail("frozen_inventory_blob_mismatch");
    originalContents.set(entry.path, content);
    offset = end + size + 2;
  }
  const layout = parseFixtureManifest((await safeFile(fixtureManifestPath)).toString("utf8"));
  if (
    layout.files.length !== rows.length ||
    rows.some(
      (row) =>
        !layout.files.some(
          (file) =>
            file.originPath === row.originPath &&
            file.sha256 === row.sha256 &&
            file.bytes === row.bytes,
        ),
    )
  )
    fail("layout_original_coverage");
  const { compiler } = await import("./architecture/contracts");
  const ts = compiler(root);
  function program(text: string, filename: string, current: boolean, relocations: FixtureSourceModuleRelocation[] = []) {
    const contract = sourceProgramContract(ts, text, filename, current, layout.sourceAssets, relocations);
    return {
      programSha256: digest(JSON.stringify(contract.statements)),
      moduleBindingsSha256: digest(JSON.stringify(contract.moduleBindings)),
    };
  }
  for (const asset of layout.sourceAssets) {
    const original =
      originalContents.get(asset.originPath) ??
      childProcess.execFileSync("git", ["show", `${asset.originCommit}:${asset.originPath}`], {
        cwd: root,
        maxBuffer: 4 * 1024 * 1024,
      });
    const current = await safeFile(asset.currentPath);
    if (
      digest(original) !== asset.originalSha256 ||
      original.length !== asset.originalBytes ||
      digest(current) !== asset.currentSha256 ||
      current.length !== asset.currentBytes
    )
      fail("source_asset_byte_identity");
    for (const relocation of asset.moduleRelocations ?? []) {
      const previous = childProcess.execFileSync("git", ["show", `${relocation.originCommit}:${relocation.originPath}`], {
        cwd: root, maxBuffer: 4 * 1024 * 1024,
      }).toString("utf8");
      const moved = (await safeFile(relocation.currentPath)).toString("utf8");
      for (const binding of relocation.bindings) {
        const before = digest(sourceDeclarationContract(ts, previous, relocation.originPath, binding.name));
        const after = digest(sourceDeclarationContract(ts, moved, relocation.currentPath, binding.name));
        if (before !== binding.declarationSha256 || after !== before)
          fail("source_module_relocation_declaration_drift");
      }
    }
    const before = program(Buffer.from(original).toString("utf8"), asset.originPath, false),
      after = program(current.toString("utf8"), asset.currentPath, true, asset.moduleRelocations);
    if (
      before.programSha256 !== after.programSha256 ||
      before.moduleBindingsSha256 !== after.moduleBindingsSha256 ||
      before.programSha256 !== asset.programSha256 ||
      before.moduleBindingsSha256 !== asset.moduleBindingsSha256
    )
      fail("source_asset_program_or_import_drift");
  }
  const currentPaths: string[] = [];
  async function scan(relative: string) {
    const info = await fs.lstat(path.join(root, relative));
    if (info.isSymbolicLink()) fail("symlink_rejected");
    if (info.isDirectory())
      for (const name of (await fs.readdir(path.join(root, relative))).sort())
        await scan(relative + "/" + name);
    else if (info.isFile() && publicFixturePath(relative)) currentPaths.push(relative);
    else fail("unexpected_fixture_kind");
  }
  for (const directory of fixtureRoots) {
    // 仅 lstat 完整路径仍可能穿过祖先链接；先逐段核公开目录，再允许递归枚举子项。
    const parts = directory.split("/");
    for (let index = 1; index <= parts.length; index++) {
      const info = await fs.lstat(path.join(root, ...parts.slice(0, index)));
      if (info.isSymbolicLink()) fail("symlink_rejected");
      if (!info.isDirectory()) fail("public_fixture_directory_required");
    }
    await scan(directory);
  }
  const expectedPaths = new Set([
    ...layout.files.map((file) => file.currentPath),
    ...layout.derivedManifests.map((entry) => entry.path),
  ]);
  if (
    currentPaths.length !== expectedPaths.size ||
    currentPaths.some((file) => !expectedPaths.has(file))
  )
    fail("current_fixture_coverage");
  const actualInputs = [];
  for (const file of layout.files) {
    const bytes = await safeFile(file.currentPath);
    if (digest(bytes) !== file.currentSha256 || bytes.length !== file.currentBytes)
      fail("current_fixture_byte_drift");
    if (
      file.kind !== "adapter-script" &&
      (digest(bytes) !== file.sha256 || bytes.length !== file.bytes)
    )
      fail("json_archive_byte_drift");
    actualInputs.push({
      originPath: file.originPath,
      sha256: file.sha256,
      bytes: file.bytes,
      script: file.kind === "adapter-script",
      value:
        file.kind === "adapter-script"
          ? undefined
          : (JSON.parse(bytes.toString("utf8")) as unknown),
    });
  }
  assertLiteralFixtureMetadata(layout, actualInputs);
  for (const derived of layout.derivedManifests) {
    const subset = deriveLocalFixtureManifest(layout, derived.path);
    const actual = parseFixtureManifest((await safeFile(derived.path)).toString("utf8"));
    if (canonical(subset) !== canonical(actual)) fail("derived_manifest_content_drift");
  }
  return layout;
}

if (import.meta.main) {
  const args = process.argv.slice(2);
  const check = args[0] === "--check";
  if (args.length > (check ? 2 : 1) || (!check && args[0]?.startsWith("--")))
    throw new Error("usage: bun tooling/refactor/fixture-manifest.ts [--check] [repository]");
  const document = await generateFixtureManifest(args[check ? 1 : 0] ?? process.cwd());
  process.stdout.write(
    JSON.stringify(
      check
        ? {
            schema: "awa-fixture-check-v1",
            success: true,
            artifacts: document.files.length,
            exactJsonArchives: document.files.filter((file) => file.kind !== "adapter-script")
              .length,
            mechanicalSourceFixtures: document.coverage.mechanicalSourceFiles,
            sourceProgramProofs: document.sourceAssets.length,
            suites: document.suites.length,
            derivedManifests: document.derivedManifests.length,
          }
        : document,
      null,
      check ? undefined : 2,
    ) + "\n",
  );
}
