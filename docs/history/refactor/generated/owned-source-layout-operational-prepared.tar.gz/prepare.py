#!/usr/bin/env python3
"""只读仓库并生成临时候选；不应用、不编译、不运行产品或门禁。"""
from pathlib import Path
import json, hashlib, subprocess, re, os
ROOT=Path('/home/hby/dev/AI-Werewolf-Arena')
OUT=Path('/tmp/awa-owned-layout-operational-adaptations')
sha=lambda b:hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
mapdoc=json.loads(Path('/tmp/awa-owned-layout-map.json').read_text())
routes={x['from']:x['to'] for x in mapdoc['mapping']}
smoke={'from':'backend/src/run-game-smoke.ts','to':'backend/src/app/cli/run-game-smoke.ts'}
if smoke['from'] not in routes: routes[smoke['from']]=smoke['to']
elif routes[smoke['from']]!=smoke['to']: raise ValueError('Root smoke route differs')
files={}
def begin(old):
 if old in files:return files[old]
 b=(ROOT/old).read_bytes(); t=b.decode()
 row={'oldPath':old,'targetPath':routes.get(old,old),'observedHead':head,'originalSha256':sha(b),'originalBytes':len(b),'edits':[],'_text':t}
 files[old]=row;return row
def edit(old,before,after,purpose,expected=1,already=False):
 row=begin(old); text=row['_text']; count=text.count(before)
 if count!=expected:raise ValueError((old,purpose,'anchor_count',count,expected))
 row['edits'].append({'before':before,'after':after,'count':expected,'purpose':purpose,'mayAlreadyBeAppliedByModuleRewrite':already})
 row['_text']=text.replace(before,after)
def change_full(old,before,after,purpose):edit(old,before,after,purpose)
# ACP 原观察点和扩展名选择保持。
edit('backend/src/ai/integrations/acp/acp_process_client.ts','`werewolf_mcp_server${extension}`','`werewolf-mcp-server${extension}`','同目录游戏 sidecar 物理文件名')
edit('backend/src/ai/audit/acp_audit_runner.ts','path.join(__dirname, `audit_mcp_server${extension}`)','path.join(__dirname, "../../adapters/acp", `audit-mcp-server${extension}`)','审计 runner 依原 .ts/.js 选择点定位适配器 sidecar')
# package values 只改真实入口，不删 key 或参数。
pkg='backend/package.json'; data=json.loads((ROOT/pkg).read_text())
for key,value in data['scripts'].items():
 for old,new in routes.items():
  if old.startswith('backend/src/'):
   a=old[len('backend/'):];b=new[len('backend/'):]
   if a in value:edit(pkg,'"'+key+'": '+json.dumps(value,ensure_ascii=False),'"'+key+'": '+json.dumps(value.replace(a,b),ensure_ascii=False),'保留 '+key+' 键／完整参数，仅迁物理入口')
# 有限三个构建 profile，保留 original 与 Domain 中间态。
p='tooling/refactor/trace-game.ts';text=(ROOT/p).read_text()
a=text.index('/** 只识别两种已声明布局');b=text.index('\nexport interface TraceScenario',a)
before=text[a:b]
after='''/** 完整职责目录只声明七个实际入口；原始与领域中间构建各保原路径，不让旧构建加载新树模块。 */
const ownedLayout: BuildLayout = {
  bootstrap: "backend/src/app/bootstrap.ts",
  core: "backend/src/domain/index.ts",
  recorder: "backend/src/recording/session/recorder.ts",
  recordingContext: "backend/src/recording/session/context.ts",
  reproductionContext: "backend/src/app/simulation/reproduction-context.ts",
  reproduction: "backend/src/recording/reproduction/format.ts",
  replay: "backend/src/app/simulation/replay-reproduction.ts",
};

/** 只识别三个完整声明；任一 profile 外的旧／新入口残留也拒绝，避免同构建混载两套运行对象。 */
async function selectBuildLayout(root: string): Promise<BuildLayout> {
  const exists = async (relative: string) => {
    try {
      const entry = await lstat(path.join(root, relative));
      if (!entry.isFile()) throw Error("differential_layout_input_invalid");
      return true;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
      throw error;
    }
  };
  // 只探测显式有限入口；不搜索任意替代目录，也不导入产品来判断布局。
  const profiles = [originalLayout, domainLayout, ownedLayout];
  const paths = [...new Set(profiles.flatMap((profile) => Object.values(profile)))];
  const presence = new Map<string, boolean>();
  for (const relative of paths) presence.set(relative, await exists(relative));
  const matches = profiles.filter((profile) => {
    const members = new Set(Object.values(profile));
    return paths.every((relative) => presence.get(relative) === members.has(relative));
  });
  if (matches.length !== 1) throw Error("differential_build_layout_ambiguous");
  return matches[0]!;
}'''
change_full(p,before,after,'保留 originalLayout/domainLayout 完整字面；增加 ownedLayout 有限互斥选择，显式新增 lstat 读点')
# 初身份五入口顺序／标题原字面与断言保持。
p='backend/tests/architecture/identity-import-initialization.test.ts';text=(ROOT/p).read_text()
headbefore=text[:text.index('import { expect')]
headnew='''/**
 * 负责用五种原始入口顺序核对初身份 setup 的冷初始化。入口标签和顺序保持，实际模块路径随职责目录迁移。
 * 每项独立解释器仍检查同三个公开构造器、退出码和成功字面；不启动对局，也不以导入成功替代玩法验收。
 */
'''
edit(p,headbefore,headnew,'触及的文件头明确五真实 import 次序和隔离边界')
edit(p,'const base = "./src/game/mechanisms/roles/";','''// 键保留原测试身份，值只描述当前职责入口；不把历史标签当作可加载物理目录。
const entryTargets: Record<string, string> = {
  "initial_identity/setup": "./src/features/initial-identity/setup.ts",
  "shapeshifter/setup": "./src/features/shapeshifter/setup.ts",
  "thief/setup": "./src/features/thief/setup.ts",
  catalog: "./src/rulesets/roles/catalog.ts",
  "../../engine/phase_manager": "./src/engine/phase-manager.ts",
};''','用精确映射保五原 entry 标签／顺序')
edit(p,'''const first =
      entry === "../../engine/phase_manager"
        ? "./src/game/engine/phase_manager.ts"
        : base + entry + ".ts";''','const first = entryTargets[entry]!;','逐项选择同一入口身份的新物理位置')
for a,b in [('initial_identity','initial-identity'),('thief','thief'),('shapeshifter','shapeshifter')]:
 edit(p,'"./src/game/mechanisms/roles/'+a+'/setup.ts"','"./src/features/'+b+'/setup.ts"','子进程模板中的真实 setup 路径')
edit('frontend/tests/architecture/stage-coverage.test.ts','"backend/src/game/mechanisms/script/event_render_registry.ts"','"backend/src/agents/presentation/event-render-registry.ts"','AST reader 的真实 renderer 注册表文件')
# 仅已知活跃 tests/ 的实际子进程字面；不是历史文本替换。
child_pairs=[('src/ai/integrations/acp/werewolf_mcp_server.ts','src/adapters/acp/werewolf-mcp-server.ts'),('src/ai/audit/audit_mcp_server.ts','src/adapters/acp/audit-mcp-server.ts')]
for path in sorted((ROOT/'backend/tests').rglob('*.ts')):
 rel=path.relative_to(ROOT).as_posix();text=path.read_text()
 for a,b in child_pairs:
  if a in text:edit(rel,a,b,'实际 ACP 子进程入口；保 wire ID／控制口／断言',text.count(a))
# 其他真实 CLI I/O 入口。
edit('backend/tests/unit/configuration/cli-config-directory.test.ts','backend/src/runtime/cli/config_directory.ts','backend/src/app/cli/config-directory.ts','生成 require 的配置根 helper 位置')
edit('backend/tests/integration/cli/provider-load-errors.test.ts','../../../src/runtime/cli/run_game.ts','../../../src/app/cli/run-game.ts','真实 CLI child')
edit('backend/tests/integration/cli/config-publication-failures.test.ts','../../../src/runtime/cli/check_config.ts','../../../src/app/cli/check-config.ts','真实 CLI child')
p='backend/tests/integration/cli/bilingual-commands.test.ts'
edit(p,'../../../src/runtime/cli/${file}','../../../src/app/cli/${file}','保 command helper／参数矩阵，只迁当前 CLI 根')
for a,b in [('check_config.ts','check-config.ts'),('run_game.ts','run-game.ts'),('migrate_configs.ts','migrate-configs.ts'),('replay_actions.ts','replay-actions.ts'),('../../replay/export_replay_bundle.ts','export-replay-bundle.ts'),('../../run-game-smoke.ts','run-game-smoke.ts')]:
 t=begin(p)['_text'];edit(p,'"'+a+'"','"'+b+'"','保原 bilingual case／oracle，当前入口 '+b,t.count('"'+a+'"'))
# Time public package key 退休；symbols/data 不动。
p='packages/game-contract/package.json';text=(ROOT/p).read_text()
for a,b in [('./facts/time-consort','./facts/time-wolf-consort'),('./src/facts/time-consort.ts','./src/facts/time-wolf-consort.ts'),('facts/time-consort','facts/time-wolf-consort'),('src/facts/time-consort.ts','src/facts/time-wolf-consort.ts')]:
 q='"'+a+'"';edit(p,q,'"'+b+'"','旧 Time package subpath 显式退休；不加兼容 key',text.count(q))
# 活跃模块 import/export 的包路径。只操作精确完整 literal，不改角色、seed、origin 或档案内容。
time_api='@ai-werewolf-arena/game-contract/facts/time-consort'
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
for p in tracked:
 if not p or not p.endswith(('.ts','.tsx','.mts','.cts','.js','.mjs','.cjs')) or not p.startswith(('backend/','frontend/','packages/','tooling/')):continue
 t=(ROOT/p).read_text()
 if time_api in t:
  # 此精确 package literal 的模块消费者清单仍由主 AST rewrite 终核；候选只做该完整字面。
  edit(p,time_api,time_api.replace('/time-consort','/time-wolf-consort'),'当前 Time package import；若主 AST 已迁则记录已应用',t.count(time_api),True)
p='packages/game-contract/src/index.ts';q='"./facts/time-consort"'
if q in (ROOT/p).read_text():edit(p,q,'"./facts/time-wolf-consort"','GC 根公开出口保持名字和顺序，迁 Time 物理叶',1,True)
# fixture metadata reader 的生产类型迁移支持：精确表，不扩大 test-support 资产接受面。
p='tooling/refactor/fixture-manifest.ts'
edit(p,'/** 已审查的 support 归属迁移所移动的精确导入声明；每个绑定保留独立声明摘要。 */','/** 已审查的精确导入归属迁移；support 保原绑定规则，显式生产白名单仅容许 type-only 接口／类型别名。 */','声明 type relocation 的窄边界')
anchor='function sourceAssetPath(value: unknown): value is string {'
addition='''// 只有这次实际迁移的公开类型叶可被 fixture 声明证明读取；不是 backend/src 通配白名单。
const productionTypeRelocations = [{
  originPath: "backend/src/ai/integrations/acp/acp_mcp_bridge.ts",
  currentPath: "backend/src/adapters/acp/acp-mcp-bridge.ts",
  bindings: ["AcpMcpServerConfig"],
}] as const;
function productionTypeRelocation(originPath: unknown, currentPath: unknown) {
  return productionTypeRelocations.find((entry) =>
    entry.originPath === originPath && entry.currentPath === currentPath);
}
function permittedSourceRelocation(originPath: unknown, currentPath: unknown): boolean {
  return (publicSupportSourcePath(originPath) && publicSupportSourcePath(currentPath)) ||
    productionTypeRelocation(originPath, currentPath) !== undefined;
}
'''
edit(p,anchor,addition+anchor,'类型迁移只准实际 MCP bridge 一组原／新路径；sourceAssetPath 仍原 fixture/support 域')
edit(p,'''!publicSupportSourcePath(relocation.originPath) ||
          !publicSupportSourcePath(relocation.currentPath) ||''','''!permittedSourceRelocation(relocation.originPath, relocation.currentPath) ||''','仅 moduleRelocation 接受显式生产类型路径，不扩大 asset 路径')
anchor='''          names.add(binding.name);
        }
      }
    }
    sourceOrigins.add(entry.originPath);'''
replacement='''          names.add(binding.name);
        }
        const typeRoute = productionTypeRelocation(relocation.originPath, relocation.currentPath);
        if (typeRoute && JSON.stringify([...names].sort()) !== JSON.stringify([...typeRoute.bindings].sort()))
          fail("source_module_relocation_type_binding_not_registered");
      }
    }
    sourceOrigins.add(entry.originPath);'''
edit(p,anchor,replacement,'生产类型 relocation 的具名绑定只能是显式原声明')
anchor='''            const names = node.importClause.namedBindings.elements.map((entry) =>'''
replacement='''            // 生产声明只供擦除的类型导入；值导入、namespace、动态加载不能借摘要登记进入此入口。
            if (productionTypeRelocation(relocation.originPath, relocation.currentPath) &&
              !node.importClause.isTypeOnly &&
              !node.importClause.namedBindings.elements.every((entry) => entry.isTypeOnly))
              fail("source_module_relocation_requires_type_only_import");
            const names = node.importClause.namedBindings.elements.map((entry) =>'''
edit(p,anchor,replacement,'当前 adapter 的实际生产声明 import 必须 type-only')
edit(p,'''  ts: typeof import("typescript"), text: string, filename: string, name: string,
): string {
  const ast = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true);''','''  ts: typeof import("typescript"), text: string, filename: string, name: string, typeOnly = false,
): string {
  const ast = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true);''','保原调用默认接受面，只给新生产 relocation 增 type-only 检查参数')
anchor='''  const declaration = nodes[0]!;
  const modifiers ='''
replacement='''  const declaration = nodes[0]!;
  if (typeOnly && !ts.isInterfaceDeclaration(declaration) && !ts.isTypeAliasDeclaration(declaration))
    fail("source_module_relocation_requires_type_declaration");
  const modifiers ='''
edit(p,anchor,replacement,'摘要覆盖完整 named interface/alias，不能将函数／类／enum 当擦除类型')
edit(p,'''  async function safeFile(relative: string) {
    if (''','''  // 只在 parse 清单完成后登记显式生产类型目标；仍逐层 lstat 拒绝符号链接与非普通文件。
  const registeredTypeInputs = new Set<string>();
  async function safeFile(relative: string) {
    if (''','增加已验证精确生产类型输入集合，不通配 backend 源码')
edit(p,'''      !publicFixturePath(relative) &&
      !publicSupportSourcePath(relative)
    )''','''      !publicFixturePath(relative) &&
      !publicSupportSourcePath(relative) &&
      !registeredTypeInputs.has(relative)
    )''','safeFile 仅额外接受清单中实际登记的显式类型叶')
anchor='''  const layout = parseFixtureManifest((await safeFile(fixtureManifestPath)).toString("utf8"));
  if ('''
replacement='''  const layout = parseFixtureManifest((await safeFile(fixtureManifestPath)).toString("utf8"));
  for (const asset of layout.sourceAssets)
    for (const relocation of asset.moduleRelocations ?? [])
      if (productionTypeRelocation(relocation.originPath, relocation.currentPath))
        registeredTypeInputs.add(relocation.currentPath);
  if ('''
edit(p,anchor,replacement,'parse 完成后才开放已登记类型目标，保其他 safeFile 拒绝面')
anchor='''    for (const relocation of asset.moduleRelocations ?? []) {
      const previous = childProcess.execFileSync'''
replacement='''    for (const relocation of asset.moduleRelocations ?? []) {
      const typeOnly = productionTypeRelocation(relocation.originPath, relocation.currentPath) !== undefined;
      // 新生产类型的旧侧也必须是固定 Git 普通源码，不能把 symlink blob 当声明文本。
      if (typeOnly) {
        const entry = childProcess.execFileSync("git", ["ls-tree", relocation.originCommit, "--", relocation.originPath], {
          cwd: root, encoding: "utf8", maxBuffer: 1024 * 1024,
        }).trim();
        const match = /^100644 blob [a-f0-9]{40}\\t(.+)$/.exec(entry);
        if (!match || match[1] !== relocation.originPath) fail("source_module_relocation_git_file_required");
      }
      const previous = childProcess.execFileSync'''
edit(p,anchor,replacement,'新生产类型原态按精确 commit/path 拒旧 symlink，保原 support 行为')
edit(p,'sourceDeclarationContract(ts, previous, relocation.originPath, binding.name)','sourceDeclarationContract(ts, previous, relocation.originPath, binding.name, typeOnly)','原声明完整类型摘要')
edit(p,'sourceDeclarationContract(ts, moved, relocation.currentPath, binding.name)','sourceDeclarationContract(ts, moved, relocation.currentPath, binding.name, typeOnly)','新声明同完整类型摘要')
# 完整候选和原始文本仅 TMP；应用器使用编辑片段，不能覆盖 Root 主 AST 迁移后的 import。
rows=[]
for old,row in files.items():
 text=row.pop('_text');row['candidateSha256']=sha(text);row['candidateBytes']=len(text.encode())
 target=OUT/'candidates'/row['targetPath'];target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
 original=OUT/'observed-source'/old;original.parent.mkdir(parents=True,exist_ok=True);original.write_bytes((ROOT/old).read_bytes())
 rows.append(row)
(OUT/'operations.json').write_text(json.dumps({'status':'TMP_ONLY_NOT_APPLIED_NOT_CHECKED','observedHead':head,'rootMapPath':'/tmp/awa-owned-layout-map.json','rootMapObservedSha256':sha(Path('/tmp/awa-owned-layout-map.json').read_bytes()),'rootMapObservedRoutes':len(mapdoc['mapping']),'requiredSmokeRoute':smoke,'files':rows},ensure_ascii=False,indent=2)+'\n')
(OUT/'routing-snapshot.json').write_text(json.dumps({'observedHead':head,'mapping':[{'from':a,'to':b}for a,b in routes.items()],'note':'Root主map尚671时仅在本TMP显式加已批准smoke路线；不回写Rootmap。'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'generationOnly':True,'files':len(rows),'exactEdits':sum(len(x['edits'])for x in rows),'routes':len(routes),'observedHead':head}))
