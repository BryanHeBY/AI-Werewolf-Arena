# smoke inventory 误查更正

我此前把 rg 发现结果与旧671映射未列 `backend/src/run-game-smoke.ts` 合并推断为“actual Git／工作树缺失”。该判断未做叶级 git ls-tree 校准，是本审阅者的 inventory 错误，不是产品缺口。

Root 对实际 `6025b64bca6d57c1d0965fdecf5328a8b897ef4c` 校准：

- `100644 blob 661fab85a1b7b1d53909ad8b5fbcb922b7ce0ba7`，普通文件361 bytes。
- 原两 import 是 `./runtime/run_mock_game` 与 `./runtime/cli/display`，原执行为 `void runCli(main)`。
- 第672路线是 `backend/src/run-game-smoke.ts → backend/src/app/cli/run-game-smoke.ts`，原业务不重造。
- backend package 的 smoke key 与完整 release:check 必须保留，仅值接新位置。
- bilingual child 原 smoke 行、参数和错误码 oracle 必须保留，仅相对位置接新入口。

本包保留这次错误判断的文字溯源，不把其伪记为测试红或已运行故障。此前 standalone path plan 提到可保 Time 旧 subpath alias 的建议也被 Root 当前明确退休政策取代；旧计划原文不篡，本次 package 候选不保旧 key。
