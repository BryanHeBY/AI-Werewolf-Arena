from pathlib import Path
import json,hashlib,subprocess
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-owned-layout-operational-adaptations');doc=json.loads((O/'operations.json').read_text())
p='tooling/refactor/fixture-source-relocations.test.ts';raw=subprocess.check_output(['git','show',doc['observedHead']+':'+p],cwd=R);text=raw.decode();edits=[]
def edit(a,b,why):
 global text
 if text.count(a)!=1:raise ValueError((why,text.count(a)))
 text=text.replace(a,b);edits.append({'before':a,'after':b,'count':1,'purpose':why,'mayAlreadyBeAppliedByModuleRewrite':False})
edit('import { expect, test } from "bun:test";','''import { expect, test } from "bun:test";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";''','新三声明只使用临时公开目录／本地Git对象库，不运行旧声明或fixture程序')
edit('''  parseFixtureManifest,
  sourceProgramContract,''','''  parseFixtureManifest,
  generateFixtureManifest,
  sourceProgramContract,''','实际校准新类型读取的mode和symlink拒绝，不造测试专用产品hook')
append=r'''

// 这三项是新生产类型 relocation 的独立输入；现有 support 迁移三声明不因目录迁移重跑。
const productionTypeRoute: FixtureSourceModuleRelocation = {
  originPath: "backend/src/ai/integrations/acp/acp_mcp_bridge.ts",
  currentPath: "backend/src/adapters/acp/acp-mcp-bridge.ts",
  originCommit: "a".repeat(40),
  bindings: [{ name: "AcpMcpServerConfig", declarationSha256: "1".repeat(64) }],
};

test("production fixture type relocation retains named type-only imports and full type declarations", () => {
  const file = "backend/tests/fixtures/acp/test-agent.ts";
  for (const clause of ["import type { AcpMcpServerConfig as Config }", "import { type AcpMcpServerConfig as Config }"]) {
    const before = `${clause} from "../../../src/ai/integrations/acp/acp_mcp_bridge"; const config: Config | undefined = undefined;`;
    const after = before.replace("../../../src/ai/integrations/acp/acp_mcp_bridge", "../../../src/adapters/acp/acp-mcp-bridge");
    expect(sourceProgramContract(ts, after, file, true, [], [productionTypeRoute]))
      .toEqual(sourceProgramContract(ts, before, file, false, []));
  }
  const first = "export interface AcpMcpServerConfig { args: string[]; env: Array<{ name: string; value: string }>; }";
  const alias = "export type AcpMcpServerConfig = { args: string[]; env: Array<{ name: string; value: string }>; };";
  expect(sourceDeclarationContract(ts, first, "first.ts", "AcpMcpServerConfig", true))
    .toBe("export interface AcpMcpServerConfig {\n    args: string[];\n    env: Array<{\n        name: string;\n        value: string;\n    }>;\n}");
  expect(sourceDeclarationContract(ts, alias, "alias.ts", "AcpMcpServerConfig", true))
    .toContain("export type AcpMcpServerConfig = {");
  expect(sourceDeclarationContract(ts, alias.replace("value: string", "value: number"), "changed.ts", "AcpMcpServerConfig", true))
    .not.toEqual(sourceDeclarationContract(ts, alias, "alias.ts", "AcpMcpServerConfig", true));
});

test("production fixture type relocation rejects value loading and undeclared production paths", () => {
  const file = "backend/tests/fixtures/acp/test-agent.ts";
  expect(() => sourceProgramContract(ts,
    'import { AcpMcpServerConfig } from "../../../src/adapters/acp/acp-mcp-bridge";',
    file, true, [], [productionTypeRoute])).toThrow("source_module_relocation_requires_type_only_import");
  expect(() => sourceProgramContract(ts,
    'import * as bridge from "../../../src/adapters/acp/acp-mcp-bridge";',
    file, true, [], [productionTypeRoute])).toThrow("source_module_relocation_requires_named_import");
  expect(() => sourceDeclarationContract(ts, "export class AcpMcpServerConfig {}", "class.ts", "AcpMcpServerConfig", true))
    .toThrow("source_module_relocation_requires_type_declaration");
  const mutations: Array<(route: FixtureSourceModuleRelocation) => void> = [
    (route) => { route.currentPath = "backend/src/adapters/acp/other.ts"; },
    (route) => { route.originPath = "backend/src/ai/integrations/acp/other.ts"; },
    (route) => { route.currentPath = "backend/src/adapters/acp/../acp/acp-mcp-bridge.ts"; },
    (route) => { route.currentPath = "backend/src/.codex/auth.ts"; },
    (route) => { route.bindings[0]!.name = "AcpMcpControlServer"; },
  ];
  const accepted = structuredClone(manifest) as FixtureManifest;
  accepted.sourceAssets[0]!.moduleRelocations = [structuredClone(productionTypeRoute)];
  expect(() => parseFixtureManifest(JSON.stringify(accepted))).not.toThrow();
  for (const mutate of mutations) {
    const next = structuredClone(accepted);
    mutate(next.sourceAssets[0]!.moduleRelocations![0]!);
    expect(() => parseFixtureManifest(JSON.stringify(next))).toThrow("fixture_manifest_invalid");
  }
});

test("production fixture type relocation refuses Git symlink mode and a current declaration symlink", async () => {
  // 临时 Git 只通过 alternates 读取当前仓库的公开固定对象；不 checkout、不复制配置凭据、不写原仓库。
  const repository = process.cwd();
  const temporary = await fs.mkdtemp(path.join(os.tmpdir(), "awa-fixture-type-relocation-"));
  try {
    execFileSync("git", ["clone", "--quiet", "--shared", "--no-checkout", repository, temporary], { maxBuffer: 4 * 1024 * 1024 });
    const document = structuredClone(manifest) as FixtureManifest;
    const typeRoute = document.sourceAssets[0]!.moduleRelocations?.find((entry) =>
      entry.currentPath === productionTypeRoute.currentPath);
    if (!typeRoute) throw Error("production_type_route_fixture_not_applied");
    const inputs = new Set([
      document.baseline.inventoryPath,
      "tooling/refactor/fixtures/manifest.json",
      "backend/package.json",
      ...document.sourceAssets.map((asset) => asset.currentPath),
      ...document.sourceAssets.flatMap((asset) => (asset.moduleRelocations ?? []).map((route) => route.currentPath)),
    ]);
    for (const relative of inputs) {
      await fs.mkdir(path.dirname(path.join(temporary, relative)), { recursive: true });
      await fs.copyFile(path.join(repository, relative), path.join(temporary, relative));
    }
    // compiler(root) 沿原工具入口定位已安装 TypeScript；此链接不是 safeFile 允许读取的公开输入。
    await fs.mkdir(path.join(temporary, "backend/node_modules"), { recursive: true });
    await fs.symlink(await fs.realpath(path.join(repository, "backend/node_modules/typescript")),
      path.join(temporary, "backend/node_modules/typescript"), "dir");
    const originCommit = typeRoute.originCommit;
    const previous = execFileSync("git", ["show", `${originCommit}:${typeRoute.originPath}`], { cwd: temporary });
    const blob = execFileSync("git", ["hash-object", "-w", "--stdin"], { cwd: temporary, input: previous, encoding: "utf8" }).trim();
    execFileSync("git", ["read-tree", originCommit], { cwd: temporary });
    execFileSync("git", ["update-index", "--add", "--cacheinfo", `120000,${blob},${typeRoute.originPath}`], { cwd: temporary });
    const tree = execFileSync("git", ["write-tree"], { cwd: temporary, encoding: "utf8" }).trim();
    typeRoute.originCommit = execFileSync("git", ["-c", "user.name=Fixture mode probe", "-c", "user.email=fixture@example.invalid",
      "commit-tree", tree, "-p", originCommit], { cwd: temporary, input: "synthetic public type mode\n", encoding: "utf8" }).trim();
    await fs.writeFile(path.join(temporary, "tooling/refactor/fixtures/manifest.json"), JSON.stringify(document));
    await expect(generateFixtureManifest(temporary)).rejects.toThrow("source_module_relocation_git_file_required");
    typeRoute.originCommit = originCommit;
    await fs.writeFile(path.join(temporary, "tooling/refactor/fixtures/manifest.json"), JSON.stringify(document));
    const current = path.join(temporary, typeRoute.currentPath);
    const target = path.join(temporary, "public-type-control.ts");
    await fs.rename(current, target);
    await fs.symlink(target, current, "file");
    await expect(generateFixtureManifest(temporary)).rejects.toThrow("symlink_rejected");
  } finally {
    await fs.rm(temporary, { recursive: true, force: true });
  }
});
'''
edits.append({'before':'','after':append,'count':1,'purpose':'仅新增三项生产类型relocation风险，不运行旧3声明','append':True,'mayAlreadyBeAppliedByModuleRewrite':False})
text+=append
row={'oldPath':p,'targetPath':p,'observedHead':doc['observedHead'],'originalSha256':hashlib.sha256(raw).hexdigest(),'originalBytes':len(raw),'candidateSha256':hashlib.sha256(text.encode()).hexdigest(),'candidateBytes':len(text.encode()),'edits':edits}
doc['files'].append(row);(O/'operations.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
q=O/'candidates'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(text);q=O/'observed-source'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
(O/'new-risk-plan.json').write_text(json.dumps({'status':'PREPARED_NOT_EXECUTED','path':p,'newDeclarations':3,'existingDeclarations':3,'filter':'production fixture type relocation','command':['bun','--no-env-file','test',p,'--test-name-pattern','production fixture type relocation'],'scope':'类型和工具I/O新接受边界；不运行fixture适配器/模型/对局；Gitclone和全部写入仅临时目录','needsAppliedMetadataFirst':True,'modeProbe':'临时Git普通声明同blob换120000mode，必须以mode错误拒；不修改真实Git','symlinkProbe':'仅已登记current类型目标替为临时symlink，必须safeFile原逐层lstat拒'},ensure_ascii=False,indent=2)+'\n')
print('prepared new3 declarations; not executed')
