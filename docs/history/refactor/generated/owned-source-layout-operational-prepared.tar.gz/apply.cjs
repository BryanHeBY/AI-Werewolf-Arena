#!/usr/bin/env node
/** 仅由 Root 在物理迁移之后显式应用有限片段；完整 candidates 用于审阅，绝不整文件覆盖已重接 import 的产品。 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const args = process.argv.slice(2);
const option = (key) => { const i = args.indexOf(key); return i < 0 ? undefined : args[i + 1]; };
const repository = path.resolve(option('--repository') || '.');
const packageRoot = __dirname;
const operations = JSON.parse(fs.readFileSync(path.join(packageRoot, 'operations.json'), 'utf8'));
const mechanicalPath = option('--mechanical-candidate');
const mapPath = option('--map');
if (!mechanicalPath || !mapPath) throw Error('explicit_mechanical_candidate_and_map_required');
const mechanical = JSON.parse(fs.readFileSync(mechanicalPath, 'utf8'));
const mapping = JSON.parse(fs.readFileSync(mapPath, 'utf8')).mapping;
const smoke = operations.requiredSmokeRoute;
if (!mapping.some((r) => r.from === smoke.from && r.to === smoke.to)) throw Error('approved_smoke_route_required');
const moved = new Map(mapping.map((r) => [r.from, r.to]));
const prepared = new Map(mechanical.changed.map((r) => [r.from, r]));
const digest = (b) => crypto.createHash('sha256').update(b).digest('hex');
function safe(relative) {
  if (path.isAbsolute(relative) || relative.includes('\\') || relative.split('/').some((s) =>
    !s || s === '.' || s === '..' || ['.git', '.codex', '.agents', '.aws', 'node_modules'].includes(s) || s.startsWith('.env')))
    throw Error('application_path_rejected:' + relative);
  for (let i = 1, parts = relative.split('/'); i <= parts.length; i++) {
    const entry = fs.lstatSync(path.join(repository, ...parts.slice(0, i)));
    if (entry.isSymbolicLink() || (i < parts.length ? !entry.isDirectory() : !entry.isFile()))
      throw Error('application_regular_file_required:' + relative);
  }
  return path.join(repository, relative);
}
const writes = [];
for (const row of operations.files) {
  const target = moved.get(row.oldPath) || row.oldPath;
  if (target !== row.targetPath) throw Error('mapping_changed_reprepare:' + row.oldPath);
  const file = safe(target), before = fs.readFileSync(file), main = prepared.get(row.oldPath);
  const expected = main ? main.afterSHA256 : row.originalSha256;
  if (digest(before) !== expected) throw Error('actual_stage_changed_reprepare:' + target);
  let text = before.toString('utf8');
  const steps = [];
  for (const edit of row.edits) {
    if (edit.append) {
      if (text.includes(edit.after)) throw Error('append_already_present:' + target);
      text += edit.after; steps.push({purpose: edit.purpose, appended: true}); continue;
    }
    const count = text.split(edit.before).length - 1;
    if (count !== edit.count) {
      if (count === 0 && edit.mayAlreadyBeAppliedByModuleRewrite && text.split(edit.after).length - 1 >= edit.count) {
        steps.push({purpose: edit.purpose, alreadyAppliedByMechanicalRewrite: true}); continue;
      }
      throw Error('exact_anchor_changed:' + target + ':' + edit.purpose + ':' + count);
    }
    text = text.split(edit.before).join(edit.after);
    steps.push({purpose: edit.purpose, occurrences: count});
  }
  writes.push({path: target, beforeSha256: digest(before), afterSha256: digest(text), beforeBytes: before.length,
    afterBytes: Buffer.byteLength(text), steps, text});
}
// 先准备全体计划，任何片段不匹配就整体不写；真正文件写入并非事务，I/O错误由Root保存实际前缀。
if (args.includes('--apply')) for (const row of writes) fs.writeFileSync(safe(row.path), row.text);
const receipt = {status: args.includes('--apply') ? 'APPLIED_NOT_CHECKED' : 'PLAN_ONLY_NOT_APPLIED',
  repository, observedBefore: operations.observedHead, mechanicalCandidateSha256: digest(fs.readFileSync(mechanicalPath)),
  mapSha256: digest(fs.readFileSync(mapPath)), files: writes.map(({text, ...row}) => row),
  limits: ['这里只核实际机械阶段SHA和精确替换位置，不声明类型、行为或门禁通过。',
    '不运行历史脚本、产品、模型、fixture适配器或全门禁。',
    '尚须独立运行 fixture-metadata.cjs 更新实际当前位置摘要；不以此工具刷新任何origin或归档内容。']};
const receiptPath = option('--receipt');
if (receiptPath) fs.writeFileSync(path.resolve(receiptPath), JSON.stringify(receipt, null, 2) + '\n');
process.stdout.write(JSON.stringify({status: receipt.status, files: writes.length, edits: writes.reduce((n,r)=>n+r.steps.length,0)}) + '\n');
