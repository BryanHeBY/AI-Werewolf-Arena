from pathlib import Path
import json,hashlib,subprocess
O=Path('/tmp/awa-owned-layout-operational-adaptations');R=Path('/home/hby/dev/AI-Werewolf-Arena');d=json.loads((O/'operations.json').read_text())
# 候选修改仅更新同一精确编辑，不触仓库。保留原路径原文按actual6025读。
def adjust(p,before,after,why):
 row=next(x for x in d['files']if x['oldPath']==p);q=O/'candidates'/row['targetPath'];t=q.read_text()
 if t.count(before)!=1:raise ValueError((why,t.count(before)))
 t=t.replace(before,after)
 # 将末修并入原同一准备片段，以使实际应用依次可审。
 for e in row['edits']:
  if before in e['after']:e['after']=e['after'].replace(before,after);break
 else:row['edits'].append({'before':before,'after':after,'count':1,'purpose':why,'mayAlreadyBeAppliedByModuleRewrite':False})
 row['candidateSha256']=hashlib.sha256(t.encode()).hexdigest();row['candidateBytes']=len(t.encode());q.write_text(t)
adjust('tooling/refactor/fixture-manifest.ts','''          !permittedSourceRelocation(relocation.originPath, relocation.currentPath) ||''','''          typeof relocation.originPath !== "string" ||
          typeof relocation.currentPath !== "string" ||
          !permittedSourceRelocation(relocation.originPath, relocation.currentPath) ||''','保parse运行检查与两个字段的TS窄化，不依赖双参数boolean进行类型推断')
# 原AI的少数根文件／app组合入口同样保原adapter-feature检查面。
p='tooling/refactor/architecture/dependency-check.ts'
adjust(p,'const browserSource = (file: string) =>',r'''// 只列由旧 AI 层迁出的真实执行／传输入口；旧 game 的观察、展示和 repair 端口不属于此集合。
const executionAgentSource = (file: string) =>
  /^backend\/src\/(?:agents\/(?:acp|llm|player|providers|runtime|reporting)|audit\/agents)\//.test(file) ||
  /^backend\/src\/agents\/(?:index|game-tool-protocol|visible-event-protocol)\.[cm]?ts$/.test(file) ||
  /^backend\/src\/app\/(?:agent-exports|audit-agent-exports|audit-agent-factory)\.[cm]?ts$/.test(file);
const browserSource = (file: string) =>'''.replace('\\\\','\\'),'原AI具体职责入口不因移动到app/rootagents而逃逸旧公开机制检查')
adjust(p,r'/^backend\/src\/(?:ai|adapters|agents\/(?:acp|llm|player|providers|runtime|reporting)|audit\/agents)\//.test(file.path)',
 r'(/^backend\/src\/(?:ai|adapters)\//.test(file.path) || executionAgentSource(file.path))','改用精确原AI职责入口集合，排除旧game端口')
# features和rulesets的原game ports允许，新增目录不能引入旧AI执行／传输。
p='backend/scripts/import_boundaries.cjs'
a='''  {
    layer: "recording",
    forbidden: ["app", "ai", "runtime", "game", "audit", "replay", "agents", "adapters"],
  },'''
b='''  {
    layer: "features",
    forbidden: [
      "app", "ai", "runtime", "server", "infra", "audit", "replay", "adapters",
      "agents/acp", "agents/llm", "agents/player", "agents/providers", "agents/runtime", "agents/reporting",
      "agents/index", "agents/game-tool-protocol", "agents/visible-event-protocol",
    ],
  },
  {
    layer: "rulesets",
    forbidden: [
      "app", "ai", "runtime", "server", "infra", "audit", "replay", "adapters",
      "agents/acp", "agents/llm", "agents/player", "agents/providers", "agents/runtime", "agents/reporting",
      "agents/index", "agents/game-tool-protocol", "agents/visible-event-protocol",
    ],
  },
  {
    layer: "recording",
    forbidden: ["app", "ai", "runtime", "game", "audit", "replay", "agents", "adapters"],
  },'''
adjust(p,a,b,'新增features/rulesets职责目录仍拒AI执行与传输；实际observation/presentation/repair/prompt原口不误封')
(O/'operations.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
# 固定 Git 类型声明原始字节证据；printer规范摘要由Root未来唯一metadata步骤产生，不伪称已跑AST。
p='backend/src/ai/integrations/acp/acp_mcp_bridge.ts';raw=subprocess.check_output(['git','show',d['observedHead']+':'+p],cwd=R);t=raw.decode()
a=t.index('export interface AcpMcpServerConfig {');depth=0;end=None
for i in range(t.index('{',a),len(t)):
 if t[i]=='{':depth+=1
 elif t[i]=='}':
  depth-=1
  if depth==0:end=i+1;break
full=t[a:end];entry=subprocess.check_output(['git','ls-tree',d['observedHead'],'--',p],cwd=R,text=True).strip()
(O/'production-type-origin.json').write_text(json.dumps({'status':'READ_ONLY_SOURCE_CAPTURE_NOT_PRINTER_PROOF','commit':d['observedHead'],'gitEntry':entry,'originPath':p,'currentPath':'backend/src/adapters/acp/acp-mcp-bridge.ts','importers':['backend/tests/fixtures/acp/audit-agent.ts','backend/tests/fixtures/acp/game-agent.ts'],'requiredMode':'100644','wholeSourceSha256':hashlib.sha256(raw).hexdigest(),'wholeSourceBytes':len(raw),'wholeSourceText':t,'name':'AcpMcpServerConfig','kind':'InterfaceDeclaration','completeRawDeclaration':full,'completeRawDeclarationSha256':hashlib.sha256(full.encode()).hexdigest(),'canonicalDeclarationSha256':'Root执行fixture-metadata.cjs后按sourceDeclarationContract完整printer产出，当前未执行不造值'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'preparedFiles':len(d['files']),'preparedEdits':sum(len(r['edits'])for r in d['files']),'noApplyOrChecks':True}))
