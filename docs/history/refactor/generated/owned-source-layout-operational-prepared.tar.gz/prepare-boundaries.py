from pathlib import Path
import json,re,hashlib,posixpath,subprocess
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-owned-layout-operational-adaptations')
doc=json.loads((O/'operations.json').read_text()); mp={r['from']:r['to']for r in json.loads(Path('/tmp/awa-owned-layout-map.json').read_text())['mapping']}
# 同一 edits/完整候选体系；只准备，不加载／执行检查器。
def add(p,a,b,why):
 row=next((x for x in doc['files']if x['oldPath']==p),None)
 if row is None:
  raw=(R/p).read_bytes();row={'oldPath':p,'targetPath':mp.get(p,p),'observedHead':doc['observedHead'],'originalSha256':hashlib.sha256(raw).hexdigest(),'originalBytes':len(raw),'edits':[]};doc['files'].append(row)
  t=raw.decode();q=O/'observed-source'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 else:t=(O/'candidates'/row['targetPath']).read_text()
 n=t.count(a)
 if n!=1:raise ValueError((p,why,n))
 t=t.replace(a,b);row['edits'].append({'before':a,'after':b,'count':1,'purpose':why,'mayAlreadyBeAppliedByModuleRewrite':False})
 row['candidateSha256']=hashlib.sha256(t.encode()).hexdigest();row['candidateBytes']=len(t.encode());q=O/'candidates'/row['targetPath'];q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
p='backend/scripts/import_boundaries.cjs'
a='''  { layer: "recording", forbidden: ["app", "ai", "runtime", "game", "audit", "replay"] },'''
b='''  // 以下承接新物理 owner；旧 synthetic 表项原样保留，迁目录不能让 AI 执行／传输获得反向依赖许可。
  {
    layer: "engine",
    forbidden: [
      "app", "ai", "runtime", "server", "infra", "audit", "replay", "adapters",
      "agents/acp", "agents/llm", "agents/player", "agents/providers", "agents/runtime", "agents/reporting",
      "agents/index", "agents/game-tool-protocol", "agents/visible-event-protocol",
    ],
  },
  {
    layer: "rulesets/presets",
    forbidden: [
      "app", "ai", "engine", "runtime", "server", "infra", "recording", "audit", "replay", "adapters",
      "agents/acp", "agents/llm", "agents/player", "agents/providers", "agents/runtime", "agents/reporting",
      "agents/index", "agents/game-tool-protocol", "agents/visible-event-protocol",
    ],
  },
  {
    layer: "recording",
    forbidden: ["app", "ai", "runtime", "game", "audit", "replay", "agents", "adapters"],
  },'''
add(p,a,b,'新 owner 按原职责承接禁边；agents observation/presentation/tool-repair 是旧 game port，不冒 AI 决策层')
a='''  const forbidden = boundary.forbidden.find((layer) => within(target, layer));'''
b='''  // Session recorder 的原 FileStore 是单一持久化端口；不扩大为整个 adapters 或网络／AI 许可。
  if (source === "recording/session/recorder.ts" && target === "adapters/filesystem/session-file-store")
    return null;
  const forbidden = boundary.forbidden.find((layer) => within(target, layer));'''
add(p,a,b,'保原唯一磁盘依赖的精确 source/target，不授整个适配器目录')
p='tooling/refactor/architecture/dependency-check.ts'
add(p,'/^backend\\/src\\/(?:ai|adapters)\\//.test(file.path)',
'''/^backend\\/src\\/(?:ai|adapters|agents\\/(?:acp|llm|player|providers|runtime|reporting)|audit\\/agents)\\//.test(file.path)''',
'实际从旧AI移出的执行／传输作者仍消费机制公开port；不误将旧game observation当AI')
add(p,'/^backend\\/src\\/(?:game\\/engine|engine)\\//.test(file.path)',
'''/^backend\\/src\\/(?:game\\/engine|engine(?!\\/actions\\/))\\//.test(file.path)''',
'engine/actions 由同一原gateway规则负责，避免同一源重复报 engine+gateway')
add(p,'/^backend\\/src\\/game\\/gateway\\//.test(file.path)',
'''/^backend\\/src\\/(?:game\\/gateway|engine\\/actions)\\//.test(file.path)''',
'新engine/actions承接原gateway精确权限边界')
add(p,'/^backend\\/src\\/(?:game|features|engine|ai|adapters|app|runtime|recording|verification|audit|rulesets)\\//.test(',
'''/^backend\\/src\\/(?:game|features|engine|ai|agents|adapters|app|runtime|recording|verification|audit|rulesets)\\//.test(''',
'领域不能反导迁后的agents；原其余集合不变')
add(p,'/^backend\\/src\\/(?:game|features|engine|ai|adapters|app|runtime)\\//.test(target)',
'''/^backend\\/src\\/(?:game|features|engine|ai|agents|adapters|app|runtime|rulesets)\\//.test(target)''',
'verifier不能借新agents/rulesets落点导生产规则；实际已有edge由Root真实gate裁定不放豁免')
(O/'operations.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
# 读取 Root 已备物理候选形成纯 lexical edge 定位，不运行 TS checker／架构门禁。
c=json.loads(Path('/tmp/awa-owned-layout-candidate.json').read_text()); texts={x['to']:x['after']for x in c['changed']}
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')
for p in tracked:
 if p.startswith('backend/src/') and p.endswith('.ts') and mp.get(p,p) not in texts:texts[mp.get(p,p)]=(R/p).read_text()
rows=[]
pat=re.compile(r'(?:(?:from\s*|import\s*\(\s*|require\s*\(\s*|import\s+))[\'\"]([^\'\"]+)[\'\"]')
for f,t in texts.items():
 if not f.startswith('backend/src/'):continue
 for m in pat.finditer(t):
  spec=m.group(1)
  if not spec.startswith('.'):continue
  a=posixpath.normpath(posixpath.join(posixpath.dirname(f),spec));cs=[a,a+'.ts',a+'/index.ts']
  target=next((x for x in cs if x in texts),None)
  if not target:continue
  if ((f.startswith(('backend/src/engine/','backend/src/features/','backend/src/rulesets/','backend/src/recording/')) and target.startswith(('backend/src/agents/','backend/src/adapters/','backend/src/app/'))) or
      (f.startswith('backend/src/recording/verification/') and target.startswith(('backend/src/features/','backend/src/rulesets/','backend/src/engine/')))):
   rows.append({'source':f,'line':t.count('\n',0,m.start())+1,'specifier':spec,'target':target})
(O/'mapped-edge-locations.json').write_text(json.dumps({'scope':'仅Root候选的相对字面词法定位，不代替AST完整消费/门禁结果；type/value未作推断','source':'/tmp/awa-owned-layout-candidate.json','rows':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'preparationOnly':True,'files':len(doc['files']),'edits':sum(len(x['edits'])for x in doc['files']),'locatedEdges':len(rows)}))
