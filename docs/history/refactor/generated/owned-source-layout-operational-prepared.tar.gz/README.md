# 职责目录：非 module 输入适配候选

状态：**仅 TMP 候选，未应用、未执行校验／测试／类型／产品**。仓库业务程序不由本目录的准备工作写入。

## 来源与交接

- 固定观察前态：`6025b64bca6d57c1d0965fdecf5328a8b897ef4c`。
- 主物理映射：`/tmp/awa-owned-layout-map.json`，672 routes；主 module 候选 `/tmp/awa-owned-layout-candidate.json` 的 1475 programs／6317 specifier edits／12 data moves 由 Root 负责。
- `operations.json` 是每文件的**顺序精确片段**，包含旧／新物理位置、完整前态 SHA、候选 SHA 和目的。`observed-source/` 保存捕获原文，`candidates/` 是供人工阅读的完整非 module 候选。
- 完整候选中的普通 import 是捕获时原值。**不可把 candidates 整文件覆盖主 AST 重接后的文件。** `apply.cjs` 仅在 Root 主 module 阶段 SHA 匹配后按片段应用，保留主阶段的新 import。
- 只含精确 Time package literal 的操作若已被主 AST 重接会单独记为已应用；不以宽泛 replace 或任意当前 SHA 兼容其他漂移。
- `routing-snapshot.json`、`before.json`、`production-type-origin.json` 和 `nonmodule-consumer-classification.json` 描述准备来源，不是已通过收据。

## 完整适配清单

| 真实消费者／所有者 | 候选变化 | 保留边界 |
| --- | --- | --- |
| 游戏 ACP client | 同目录 `werewolf-mcp-server${extension}` | 原 `.ts/.js` 分支、lookup 时点和 sidecar 生命周期 |
| 审计 ACP runner | `audit/agents` 相对定位 `../../adapters/acp/audit-mcp-server${extension}` | 原 extension 捕获、bridge callback、control 和 receiver |
| backend package | 11 个实际 script value 的路径 | smoke key、release:check 全链、参数与其余脚本不删改 |
| Trace | original／Domain 原字面不动，新增七入口 owned profile；有限全集互斥选择 | 原基线布局身份、固定时钟早于生产加载、调用顺序不改；新增 lstat 观察明确是布局校验差异 |
| 初身份冷导入测试 | 原五标签／顺序映射到五实际新入口；模板中三 setup 路径迁移 | 原五测试身份、三个 constructor、exit／成功字面与 cwd 不变 |
| 前端 stage AST reader | 新 `agents/presentation/event-render-registry.ts` | 仍读 `REPLAY_STAGE_HANDLERS`，不改变覆盖预期 |
| 实际 ACP child tests | 游戏／审计 sidecar 精确字符串接新文件 | 协议、locale、RPC action／断言原文 |
| 其他 CLI child tests | config-directory、run/check 与 bilingual 矩阵新 kebab 文件 | 包括真实 smoke 的原矩阵行及错误 oracle |
| Time GC API | `facts/time-wolf-consort` canonical key／typeVersions／根 export／活跃精确 import | **旧 subpath key 有意退休**；不加兼容 alias，未知外部 consumer 不保证；Role、TimeConsort symbols、模型字段／事件／RNG 不变 |
| main fixture manifest | 仅两个 adapter 类型依赖登记、3 adapter current 字节元数据、8 Time payload currentPath、4 derived path | origin、原 SHA／bytes、suite、metadata、acceptance、archive payload 原字节不动 |
| derived manifests | ACP 一份＋Time 四份按现有派生函数重建 current 描述 | 其余251份不重格式化，不重建归档 |
| fixture 工具新窄接受面 | 唯一实际 MCP bridge old/new 路径＋`AcpMcpServerConfig`；只 type-only named import／完整 interface 或 alias | support 原面、sourceAsset 根、值导入拒绝、namespace 拒绝、未登记生产 path 拒绝；当前逐层 lstat、旧 Git mode100644 |
| checker | 新 engine/features/rulesets、AI 执行路径、gateway、domain/verifier 对应覆盖 | 旧 synthetic／旧目录规则保；旧 game 的 observation/presentation/tool-repair/prompt 不是 AI 决策，不能粗禁后假豁免 |
| Session recorder | 精确 `recording/session/recorder.ts → adapters/filesystem/session-file-store` | 不授权整个 adapters、网络或 AI |

## 安全／准入的实际新增差异

`fixture-manifest.ts` 原先只登记 support relocation。本候选新增**一组实际生产类型路径**，不是把 backend/src 加进 safeFile：

1. 清单 parser 只接受这组精确 old/current 与唯一 name。原 support 两端仍按原路径策略。
2. 当前源码必须实际 type-only named import，逐 binding 原名相等；值 import、namespace、动态加载不能借登记获准。
3. 完整 named declaration 必须是 interface／type alias；完整 printer 摘要须与固定 Git 旧声明相同，不只比较成员名。
4. 当前生产叶只有清单 parse 后加入精确集合；仍逐路径段拒绝符号链接／非普通文件。旧侧新增真实 Git mode100644 核验。
5. 原 sourceAsset 的 `programSha256`／`moduleBindingsSha256` 不更新为新值。Root 元数据脚本必须以路径逆映射重得**原摘要**，不符就失败。
6. 仅 audit/game 两个类型导入需要新 descriptor，ownership adapter 只按实际字节记录，不能为了计数伪造修改。

`production-type-origin.json` 保完整旧文件、Git entry、完整原 interface 文本与 raw SHA。**raw 声明 SHA 不是 printer SHA**；规范摘要只由 Root 后续唯一 `fixture-metadata.cjs` 实际计算、前后比较并登记，此刻未运行不造值。

## 新风险声明与执行次序

`tooling/refactor/fixture-source-relocations.test.ts` 原三声明全文保留；候选仅新增三声明，唯一新 filter 为 `production fixture type relocation`。

- 两种 type-only named import；interface／alias 完整字段正例及字段变动。
- value／namespace／class／未登记 old/new／穿越／private／额外 binding 拒绝。
- 真实 `generateFixtureManifest`：临时 `git clone --shared --no-checkout` 读取公开固定对象；同一公开声明 blob 改旧 Git mode120000 必须拒，再独立把当前声明换临时 symlink 必须拒。只复制公开 inventory、main 与少量 source assets／declarations。TypeScript 工具库在临时 backend/node_modules 单独链接供原 compiler 定位；该工具链链接不进入 safeFile 的公开输入白名单。所有写入仅临时 clone，finally 删除；不 checkout 全树、不复制配置凭据、不执行 adapter 或模型。

Root 审核并授权后才执行；本目录尚未执行以下命令：

```sh
bun --no-env-file /tmp/awa-owned-layout-operational-adaptations/apply.cjs --repository /home/hby/dev/AI-Werewolf-Arena --mechanical-candidate /tmp/awa-owned-layout-candidate.json --map /tmp/awa-owned-layout-map.json --apply --receipt /tmp/awa-owned-layout-operational-adaptations/applied-receipt.json
bun --no-env-file /tmp/awa-owned-layout-operational-adaptations/fixture-metadata.cjs --repository /home/hby/dev/AI-Werewolf-Arena --before-commit 6025b64bca6d57c1d0965fdecf5328a8b897ef4c --map /tmp/awa-owned-layout-map.json --apply --receipt /tmp/awa-owned-layout-operational-adaptations/fixture-metadata-receipt.json
bun --no-env-file test tooling/refactor/fixture-source-relocations.test.ts --test-name-pattern 'production fixture type relocation'
```

应用器先完整准备所有片段后再写，但 I/O 写入本身不是事务；失败可能留下已写前缀，必须按真实收据记录。它不自动执行 metadata updater／测试／检查。

## 67 条具体既有端口边

`mapped-edge-locations.json` 从 Root 机械候选纯词法定位，**不是 AST 完整图或 gate 结果**：features→tool-repair23／presentation15／observation14；rulesets→observation5／tool-repair4／presentation2／prompt1；engine→observation2；recording→filesystem1。这些是实际已有 owner 迁址，保持原完整模块依赖，不为改名造 wrapper。

checker 候选给 AI 执行／传输的目录和三个根协议／三个 app 组合入口保原禁面；verifier 增 agents／rulesets 实际新目录识别。任何后续真实静态 finding 都需 Root 据具体 owner 裁定，本候选不宣称当前 gate 已绿，也不借 debt／map 自动豁免 feature private edge。

## 明确保留的路径字面

- runtime/providers.json、runtime/agents.json 是用户配置 API，不是 runtime 源码位置。
- Trace originalLayout、Domain 中间 profile、inventory 历史六根及原合成测试路径是历史／synthetic，不改成当前身份。
- `wolf-tool-admission` 那条旧 `validation_rules` resolver 是**退休路径拒绝 oracle**，有意保旧不存在路径。
- Time 前端 e2e 的 `frontend/tests/fixtures/time-consort-...` 传入 `frontendFixtureURL` 的是 origin lookup key；不改。只 currentPath 迁新目录。
- Time seed、临时目录前缀、transport label、suite ID、事件、模型字段、ruleCardRef 与历史生成文件原字节不改。
- C43 旧交付文档／origin 物理迁移是另组候选，本包不改历史知识字节。

## 已更正的审阅错误

见 `reviewer-inventory-correction.md`。旧 TMP 曾把 rg 发现和671 map未列 smoke 推断成文件缺失，这是审阅 inventory 错误。真实6025 Git 叶为普通361字节，Root已将原入口纳第672路线。没有产品缺口，没有删 key／release／oracle 的授权。

### 仍须由真实结构检查裁定的既有 checkpoint 依赖

`recording-existing-boundary-edges.json` 另列16条 recording/reproduction/checkpoint→features 位置：authority-snapshots3、identity-setups4、player-snapshots5、private-state-codec4。它们原为 recording→game 依赖；候选把旧禁止面承接到 engine/features/rulesets，**没有因物理改名把这些边自动判合法或清掉旧债**。若 Root 后续结构 gate 报到这些真实边，须据具体记录端口／所有者处理；本批不另造 facade，也不以 FileStore 的特定持久化例外覆盖它们。

`prepare*.py` 与 `finalize-candidates.py` 是这次 TMP 生成过程的可读记录，生成时读取固定旧位置；物理迁移之后不应重新跑它们覆盖已审候选。Root 的实际应用入口只有 `apply.cjs` 和 `fixture-metadata.cjs`。所有后续阶段需要保存真实 raw、首失败和 source SHA，不能把本包准备态写成已通过。
