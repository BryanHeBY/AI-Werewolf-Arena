import { recordNightAbilityUse } from "../night-abilities/abilities";
import { installNativeAbility } from "../night-abilities/ability-changes";
import { freshPairSeerState, readPairSeerState } from "./state";
import { assertWritable, plainJson, write } from "./owned-state-data";
export function installPairStateSlot(role) {
    role.privateState.pairSeer =
        installNativeAbility(role, "pair_check", PAIR_STATE_SLOT_CONTRACT.create());
}
export function commitPairStateSlot(slot, next, day) {
    assertWritable(slot.pairAbility, slot.pairAbility);
    write(slot.pairState, next);
    slot.pairJson = PAIR_STATE_SLOT_CONTRACT.checkpoint.encode(next);
    recordNightAbilityUse(slot.pairAbility, day, true);
    slot.pairAbilityJson = plainJson(slot.pairAbility);
}
function pairAliasesCurrent(slot, own) {
    return (own(slot.seer.privateState, "pairSeer") === slot.pairState &&
        own(slot.seer.privateState, "abilities") === slot.abilities &&
        plainJson(slot.pairAbility) === slot.pairAbilityJson &&
        slot.pairAbility.source === slot.pairSource &&
        own(slot.abilities, slot.pairAbility.id) === slot.pairAbility &&
        slot.pairAbility.state === slot.pairState);
}
function pairDataCurrent(slot) {
    return JSON.stringify(readPairSeerState(slot.pairState)) === slot.pairJson;
}
export const PAIR_STATE_SLOT_CONTRACT = Object.freeze({
    create: freshPairSeerState,
    schema: readPairSeerState,
    allowedWrites: Object.freeze({ appendCheck: commitPairStateSlot }),
    checkpoint: Object.freeze({
        encode: (state) => JSON.stringify(state),
        decode: (readJson) => JSON.parse(readJson()),
    }),
    invalidations: Object.freeze({
        aliasesCurrent: pairAliasesCurrent,
        dataCurrent: pairDataCurrent,
    }),
});
