import { createDaytimeInterruptionComposition } from "../../rulesets/daytime-interruption-composition";
import { COMPONENT } from "../../domain/components/names";
import { ActionWindow, Phase, KnightDuelWindow as DuelWindow, } from "../../domain/model";
import { electSheriffIfNeeded } from "../../features/sheriff/election";
import { buildSpeakerOrder, chooseSpeakerDirection } from "../../features/sheriff/speaking-order";
import { findSheriffId } from "../../features/sheriff/badge";
import { GameActionRequestFactory } from "../actions/action-request-factory";
import { isSelfDestructWindowEnabled } from "../../rulesets/self-destruct-window";
export class DayPipeline {
    world;
    roleRegistry;
    toolGateway;
    events;
    interruptions;
    constructor(dependencies) {
        this.world = dependencies.world;
        this.roleRegistry = dependencies.roleRegistry;
        this.toolGateway = dependencies.toolGateway;
        this.events = dependencies.events;
        this.interruptions = createDaytimeInterruptionComposition({
            world: () => this.world,
            roleRegistry: () => this.roleRegistry,
            toolGateway: () => this.toolGateway,
            events: () => this.events,
        });
    }
    async execute(config, actionProvider, options) {
        this.interruptions.assertEntry();
        const speeches = [];
        const requests = new GameActionRequestFactory(this.world, this.events, options.day);
        const isCurrent = options.isCurrent ?? (() => true);
        if (!isCurrent())
            return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        if (options.day === 1 &&
            config.enableSheriff &&
            findSheriffId(this.world) === null &&
            config.hooks.onPreElection &&
            isSelfDestructWindowEnabled(config, ActionWindow.OnPreElection)) {
            const exploded = await this.interruptions.selfDestruct.execute(requests, actionProvider, ActionWindow.OnPreElection, Phase.Day, isCurrent, (id) => options.commitSelfDestruct?.(id, ActionWindow.OnPreElection) ?? Promise.resolve());
            if (exploded !== null)
                return {
                    summary: { speeches, selfDestructBy: exploded.actorId },
                    interrupted: true,
                    selfDestruct: exploded,
                };
            if (!isCurrent())
                return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        }
        await electSheriffIfNeeded({
            get requestFactory() { return GameActionRequestFactory; },
            world: this.world,
            events: this.events,
            toolGateway: this.toolGateway,
            actionProvider,
            day: options.day,
            enableSheriff: config.enableSheriff,
            config,
            isCurrent,
        });
        if (!isCurrent())
            return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        if (await options.afterSheriffElection?.()) {
            return {
                summary: { speeches, selfDestructBy: null },
                interrupted: false,
            };
        }
        if (config.hooks.onDaybreak && isSelfDestructWindowEnabled(config, ActionWindow.OnDaybreak)) {
            const exploded = await this.interruptions.selfDestruct.execute(requests, actionProvider, ActionWindow.OnDaybreak, Phase.Day, isCurrent, (id) => options.commitSelfDestruct?.(id, ActionWindow.OnDaybreak) ?? Promise.resolve());
            if (exploded !== null) {
                return {
                    summary: {
                        speeches,
                        selfDestructBy: exploded.actorId,
                    },
                    interrupted: true,
                    selfDestruct: exploded,
                };
            }
        }
        if (!isCurrent())
            return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        const openingDuel = await this.interruptions.duel.execute(config, requests, actionProvider, DuelWindow.BeforeSpeeches, isCurrent, options.commitKnightDuel);
        if (openingDuel.endsDay)
            return {
                summary: { speeches, selfDestructBy: null },
                interrupted: true,
                ...(openingDuel.selection ? { duel: openingDuel.selection } : {}),
            };
        if (!isCurrent())
            return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        const speakerDirection = await chooseSpeakerDirection({
            get requestFactory() { return GameActionRequestFactory; },
            world: this.world,
            events: this.events,
            toolGateway: this.toolGateway,
            actionProvider,
            day: options.day,
            enableSheriff: config.enableSheriff,
        });
        const speakers = buildSpeakerOrder(this.world, this.world.getAliveEntityIds(), findSheriffId(this.world), speakerDirection);
        for (const actorId of speakers) {
            if (!isCurrent())
                return { summary: { speeches, selfDestructBy: null }, interrupted: false };
            if (!this.isAlive(actorId)) {
                continue;
            }
            const debate = await this.interruptions.debate.execute(config, requests, actionProvider, actorId, options.day, isCurrent);
            if (!isCurrent())
                return { summary: { speeches, selfDestructBy: null }, interrupted: false };
            if (!debate.skipSpeech && this.isAlive(actorId)) {
                const req = requests.create({
                    phase: Phase.Day,
                    actorId,
                    allowedTools: ["speak"],
                    stage: "day_speech",
                    requiresAction: true,
                    summary: { key: "request.summary.day_speech" },
                    context: {},
                });
                const action = await actionProvider.getAction(req);
                if (!isCurrent())
                    return { summary: { speeches, selfDestructBy: null }, interrupted: false };
                if (action?.name === "speak") {
                    const result = this.toolGateway.validateAndSanitize(this.world, actorId, action, {
                        phase: Phase.Day,
                    });
                    if (result.ok && result.sanitizedCall) {
                        speeches.push({ actorId, text: result.sanitizedCall.args.text });
                        this.events.push({
                            timestamp: Date.now(),
                            type: "day_speech",
                            payload: {
                                actorId,
                                text: result.sanitizedCall.args.text,
                            },
                        });
                    }
                }
            }
            if (config.hooks.onPerSpeechGap &&
                isSelfDestructWindowEnabled(config, ActionWindow.OnPerSpeechGap)) {
                const exploded = await this.interruptions.selfDestruct.execute(requests, actionProvider, ActionWindow.OnPerSpeechGap, Phase.Day, isCurrent, (id) => options.commitSelfDestruct?.(id, ActionWindow.OnPerSpeechGap) ?? Promise.resolve());
                if (exploded !== null) {
                    return {
                        summary: {
                            speeches,
                            selfDestructBy: exploded.actorId,
                        },
                        interrupted: true,
                        selfDestruct: exploded,
                    };
                }
            }
            const gapDuel = await this.interruptions.duel.execute(config, requests, actionProvider, DuelWindow.BetweenSpeeches, isCurrent, options.commitKnightDuel);
            if (gapDuel.endsDay)
                return {
                    summary: { speeches, selfDestructBy: null },
                    interrupted: true,
                    ...(gapDuel.selection ? { duel: gapDuel.selection } : {}),
                };
        }
        const closingDuel = await this.interruptions.duel.execute(config, requests, actionProvider, DuelWindow.AfterSpeeches, isCurrent, options.commitKnightDuel);
        if (closingDuel.endsDay)
            return {
                summary: { speeches, selfDestructBy: null },
                interrupted: true,
                ...(closingDuel.selection ? { duel: closingDuel.selection } : {}),
            };
        return {
            summary: {
                speeches,
                selfDestructBy: null,
            },
            interrupted: false,
        };
    }
    isAlive(entityId) {
        const alive = this.world.getComponent(entityId, COMPONENT.Alive);
        return alive?.alive === true;
    }
}
