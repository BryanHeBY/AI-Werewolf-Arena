import { text } from "@ai-werewolf-arena/game-text";
import { registerToolSpecs } from "../../rulesets/tool-spec-registration";
import { COMMON_TOOL_SPECS } from "./common-tool-specs";
import { getDefaultRoleCatalog } from "../../rulesets/roles/role-catalog-assembly";
import { SHERIFF_TOOL_SPECS } from "../../features/sheriff/tool-ports";
function buildDefaultSpecs(roleProfileRegistry) {
    const specs = [...COMMON_TOOL_SPECS, ...SHERIFF_TOOL_SPECS];
    for (const { runtime: profile } of roleProfileRegistry.allRuntime()) {
        if (profile.toolSpecs) {
            specs.push(...profile.toolSpecs);
        }
    }
    return specs;
}
function buildDefaultStageDirectives(roleProfileRegistry) {
    const directives = [];
    for (const { runtime: profile } of roleProfileRegistry.allRuntime()) {
        if (profile.stageDirectives) {
            directives.push(...profile.stageDirectives);
        }
    }
    return directives;
}
export class ToolSpecRegistry {
    specByName = new Map();
    stageDirectives;
    constructor(specs, stageDirectives, roleProfileRegistry = getDefaultRoleCatalog()) {
        const effectiveSpecs = specs ?? buildDefaultSpecs(roleProfileRegistry);
        const effectiveDirectives = stageDirectives ?? buildDefaultStageDirectives(roleProfileRegistry);
        registerToolSpecs(this.specByName, effectiveSpecs);
        this.stageDirectives = [...effectiveDirectives];
    }
    get(name) {
        return this.specByName.get(name);
    }
    getArgHint(name) {
        return this.specByName.get(name)?.argHint ?? null;
    }
    getUserPromptHint(name, locale = "zh-CN") {
        const spec = this.specByName.get(name);
        return (spec?.userPromptHint ??
            (spec?.userPromptHintKey ? text(locale, spec.userPromptHintKey) : null));
    }
    getStageDirective(allowedTools, locale = "zh-CN") {
        const matched = this.stageDirectives.find((rule) => rule.match(allowedTools));
        if (!matched)
            return null;
        return matched.messageKey && matched.text === text("zh-CN", matched.messageKey)
            ? text(locale, matched.messageKey)
            : matched.text;
    }
    getApplicableUserPromptHints(allowedTools, locale = "zh-CN") {
        return allowedTools
            .map((name) => this.getUserPromptHint(name, locale))
            .filter((item) => Boolean(item));
    }
}
let defaultRegistry = null;
export function getDefaultToolSpecRegistry() {
    if (!defaultRegistry) {
        defaultRegistry = new ToolSpecRegistry();
    }
    return defaultRegistry;
}
