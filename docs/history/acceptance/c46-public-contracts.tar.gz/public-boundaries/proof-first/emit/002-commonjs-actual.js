"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolSpecRegistry = void 0;
exports.getDefaultToolSpecRegistry = getDefaultToolSpecRegistry;
const game_text_1 = require("@ai-werewolf-arena/game-text");
const tool_spec_registration_1 = require("../../rulesets/tool-spec-registration");
const common_tool_specs_1 = require("./common-tool-specs");
const role_catalog_assembly_1 = require("../../rulesets/roles/role-catalog-assembly");
const tool_ports_1 = require("../../features/sheriff/tool-ports");
function buildDefaultSpecs(roleProfileRegistry) {
    const specs = [...common_tool_specs_1.COMMON_TOOL_SPECS, ...tool_ports_1.SHERIFF_TOOL_SPECS];
    for (const { runtime: profile } of roleProfileRegistry.allRuntime()) {
        if (profile.toolSpecs) {
            specs.push(...profile.toolSpecs);
        }
    }
    return specs;
}
function buildDefaultStageDirectives(roleProfileRegistry) {
    const directives = [];
    for (const { runtime: profile } of roleProfileRegistry.allRuntime()) {
        if (profile.stageDirectives) {
            directives.push(...profile.stageDirectives);
        }
    }
    return directives;
}
class ToolSpecRegistry {
    specByName = new Map();
    stageDirectives;
    constructor(specs, stageDirectives, roleProfileRegistry = (0, role_catalog_assembly_1.getDefaultRoleCatalog)()) {
        const effectiveSpecs = specs ?? buildDefaultSpecs(roleProfileRegistry);
        const effectiveDirectives = stageDirectives ?? buildDefaultStageDirectives(roleProfileRegistry);
        (0, tool_spec_registration_1.registerToolSpecs)(this.specByName, effectiveSpecs);
        this.stageDirectives = [...effectiveDirectives];
    }
    get(name) {
        return this.specByName.get(name);
    }
    getArgHint(name) {
        return this.specByName.get(name)?.argHint ?? null;
    }
    getUserPromptHint(name, locale = "zh-CN") {
        const spec = this.specByName.get(name);
        return (spec?.userPromptHint ??
            (spec?.userPromptHintKey ? (0, game_text_1.text)(locale, spec.userPromptHintKey) : null));
    }
    getStageDirective(allowedTools, locale = "zh-CN") {
        const matched = this.stageDirectives.find((rule) => rule.match(allowedTools));
        if (!matched)
            return null;
        return matched.messageKey && matched.text === (0, game_text_1.text)("zh-CN", matched.messageKey)
            ? (0, game_text_1.text)(locale, matched.messageKey)
            : matched.text;
    }
    getApplicableUserPromptHints(allowedTools, locale = "zh-CN") {
        return allowedTools
            .map((name) => this.getUserPromptHint(name, locale))
            .filter((item) => Boolean(item));
    }
}
exports.ToolSpecRegistry = ToolSpecRegistry;
let defaultRegistry = null;
function getDefaultToolSpecRegistry() {
    if (!defaultRegistry) {
        defaultRegistry = new ToolSpecRegistry();
    }
    return defaultRegistry;
}
