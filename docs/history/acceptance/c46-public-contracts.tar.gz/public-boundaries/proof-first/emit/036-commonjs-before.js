"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HUNTER_TOOL_SPECS = void 0;
var death_shot_1 = require("../death-actions/death-shot");
Object.defineProperty(exports, "HUNTER_TOOL_SPECS", { enumerable: true, get: function () { return death_shot_1.DEATH_SHOT_TOOL_SPECS; } });
