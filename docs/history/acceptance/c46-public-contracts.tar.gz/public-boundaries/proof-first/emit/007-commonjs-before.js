"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.transferOrDestroySheriffBadge = exports.GameActionRequestFactory = exports.PhaseManager = exports.EventRegistry = void 0;
var event_registry_1 = require("./events/event-registry");
Object.defineProperty(exports, "EventRegistry", { enumerable: true, get: function () { return event_registry_1.EventRegistry; } });
var phase_manager_1 = require("./phase-manager");
Object.defineProperty(exports, "PhaseManager", { enumerable: true, get: function () { return phase_manager_1.PhaseManager; } });
var action_request_factory_1 = require("./actions/action-request-factory");
Object.defineProperty(exports, "GameActionRequestFactory", { enumerable: true, get: function () { return action_request_factory_1.GameActionRequestFactory; } });
var badge_1 = require("../features/sheriff/badge");
Object.defineProperty(exports, "transferOrDestroySheriffBadge", { enumerable: true, get: function () { return badge_1.transferOrDestroySheriffBadge; } });
__exportStar(require("./hooks/on-daybreak"), exports);
__exportStar(require("./hooks/on-per-speech-gap"), exports);
__exportStar(require("./hooks/on-pre-election"), exports);
__exportStar(require("./hooks/on-pre-vote"), exports);
__exportStar(require("./phases/day-pipeline"), exports);
__exportStar(require("./phases/night-pipeline"), exports);
__exportStar(require("./phases/voting-pipeline"), exports);
