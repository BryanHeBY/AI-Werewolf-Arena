"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DREAMER_NIGHT_STAGE = void 0;
const ports_1 = require("./ports");
const paid_effect_ports_1 = require("../radiant-eclipse/paid-effect-ports");
const alive_1 = require("../../domain/components/alive");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const abilities_1 = require("../night-abilities/abilities");
const ability_scope_1 = require("../night-abilities/ability-scope");
const night_frame_1 = require("./night-frame");
const night_links_1 = require("./night-links");
exports.DREAMER_NIGHT_STAGE = {
    id: "dreamer_action",
    priority: 150,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const { actorId, ability } of ctx.nightActors.actors("dream", day)) {
            if (!ctx.isCurrent())
                return;
            const scope = (0, ability_scope_1.captureNightAbilityScope)(ctx.world, actorId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day);
            if (!scope?.isEligible())
                continue;
            const actorLife = scope.life.life, actorVersion = scope.life.version, state = ability.state;
            const targets = new Map(ctx.world
                .getAliveEntityIds()
                .filter((id) => id !== actorId)
                .map((id) => {
                const life = ctx.world.getComponent(id, names_1.COMPONENT.Alive);
                return [id, { life, version: (0, alive_1.aliveLifeVersion)(life) }];
            }));
            if (targets.size === 0)
                continue;
            let applied = false;
            const current = () => scope.isEligible();
            for (let attempt = 1; attempt <= 3; attempt++) {
                if (!current()) {
                    if ((0, paid_effect_ports_1.isRadiantEclipseBoard)(ctx.world))
                        throw new Error("radiant_eclipse_dream_scope_stale");
                    break;
                }
                const request = ctx.makeRequest(actorId, ["dream"], {
                    stage: "dreamer",
                    ability_id: ability.id,
                    ...(attempt === 1 ? {} : { retry_attempt: attempt - 1, retry_max: 2 }),
                });
                if (!current()) {
                    if ((0, paid_effect_ports_1.isRadiantEclipseBoard)(ctx.world))
                        throw new Error("radiant_eclipse_dream_scope_stale");
                    break;
                }
                const action = await ctx.actionProvider.getAction(request);
                if (!current()) {
                    if ((0, paid_effect_ports_1.isRadiantEclipseBoard)(ctx.world))
                        throw new Error("radiant_eclipse_dream_scope_stale");
                    break;
                }
                if (action?.name !== "dream") {
                    if ((0, paid_effect_ports_1.isRadiantEclipseBoard)(ctx.world))
                        throw new Error("radiant_eclipse_dream_action_missing");
                    continue;
                }
                const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                    phase: model_1.Phase.Night,
                    day,
                    abilityId: ability.id,
                });
                if (!current()) {
                    if ((0, paid_effect_ports_1.isRadiantEclipseBoard)(ctx.world))
                        throw new Error("radiant_eclipse_dream_scope_stale");
                    break;
                }
                if (!validated.ok || validated.sanitizedCall?.name !== "dream") {
                    if ((0, paid_effect_ports_1.isRadiantEclipseBoard)(ctx.world))
                        throw new Error("radiant_eclipse_dream_action_invalid");
                    continue;
                }
                const targetId = validated.sanitizedCall.args.target_id, target = targets.get(targetId);
                if (!target ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Alive) !== target.life ||
                    !target.life.alive ||
                    target.version === undefined ||
                    (0, alive_1.aliveLifeVersion)(target.life) !== target.version)
                    continue;
                const consecutive = state.lastDay === day - 1 && state.lastTarget === targetId;
                ports_1.DREAMER_STATE_SLOT.allowedWrites.recordDreamSelection(state, targetId, day);
                (0, abilities_1.recordNightAbilityUse)(ability, day, true);
                (0, night_frame_1.markDreamNightCommitted)(ctx.world, day);
                applied = true;
                (0, night_links_1.dreamNightLinksForAppend)(ctx.state).push({
                    actorId,
                    targetId,
                    day,
                    isCurrent: (0, paid_effect_ports_1.captureRadiantPaidEffect)(ctx.world, day, actorId, ability, targetId),
                    consecutive,
                    protectionPolicy: state.protectionPolicy,
                    actorLife,
                    actorVersion,
                    targetLife: target.life,
                    targetVersion: target.version,
                    ...(ability.source.kind === "native" ? {} : { abilityId: ability.id }),
                });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "dream_applied",
                    payload: {
                        actorId,
                        targetId,
                        day,
                        consecutive,
                        ...(ability.source.kind === "native" ? {} : { abilityId: ability.id }),
                    },
                });
                break;
            }
            if (!applied &&
                current() &&
                [...targets].some(([id, target]) => ctx.world.getComponent(id, names_1.COMPONENT.Alive) === target.life &&
                    target.life.alive &&
                    target.version !== undefined &&
                    (0, alive_1.aliveLifeVersion)(target.life) === target.version))
                throw new Error("dream_required_action_missing");
        }
    },
};
