"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setGuardState = exports.GUARD_STATE_SLOT = exports.recordRecipientGuardTarget = exports.recordGuardTarget = exports.getGuardState = void 0;
exports.guardTargetRepeated = guardTargetRepeated;
var state_slot_1 = require("./state-slot");
Object.defineProperty(exports, "getGuardState", { enumerable: true, get: function () { return state_slot_1.getGuardState; } });
Object.defineProperty(exports, "recordGuardTarget", { enumerable: true, get: function () { return state_slot_1.recordGuardTarget; } });
Object.defineProperty(exports, "recordRecipientGuardTarget", { enumerable: true, get: function () { return state_slot_1.recordRecipientGuardTarget; } });
function guardTargetRepeated(ability, day, targetId) {
    return (ability.state.lastTarget === targetId &&
        (ability.state.repeatPolicy !== "netease_consecutive_nights_v1" ||
            ability.lastUsedDay === day - 1));
}
var state_slot_2 = require("./state-slot");
Object.defineProperty(exports, "GUARD_STATE_SLOT", { enumerable: true, get: function () { return state_slot_2.GUARD_STATE_SLOT; } });
var state_slot_3 = require("./state-slot");
Object.defineProperty(exports, "setGuardState", { enumerable: true, get: function () { return state_slot_3.setGuardState; } });
