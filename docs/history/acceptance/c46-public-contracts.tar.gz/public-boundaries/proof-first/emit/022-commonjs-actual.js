"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeDemonWitchTurn = executeDemonWitchTurn;
exports.sealDeliveredDemonWitchSources = sealDeliveredDemonWitchSources;
exports.freezeDeliveredDemonNightSources = freezeDeliveredDemonNightSources;
const domain_1 = require("../../domain");
const status_marks_1 = require("../../domain/components/status-marks");
const night_effects_1 = require("../../domain/night-effects");
const recorder_1 = require("../../recording/session/recorder");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const authority_1 = require("./authority");
const native_potion_requests_1 = require("./native-potion-requests");
const native_poison_1 = require("./native-poison");
const poison_contribution_1 = require("./poison-contribution");
const heal_contribution_1 = require("./heal-contribution");
const deliveredHeals = new WeakMap();
const nativeAddMark = status_marks_1.StatusMarksComponent.prototype.add;
const delivered = new WeakMap();
const sealedSources = new WeakMap();
const sealedNights = new WeakMap();
async function executeDemonWitchTurn(input) {
    const { world, gateway, events, provider, day, wolfTarget } = input, frame = (0, authority_1.openDemonWitchTurnFrame)(world);
    if (!frame || frame.day !== day)
        throw new Error("demon_hunter_native_witch_unavailable");
    const ability = frame.ability, scope = Object.freeze({});
    let closed = false;
    if (!world.entityIds().every((id) => (0, native_potion_requests_1.demonWitchMarksSafe)(world, id)))
        throw new Error("demon_hunter_native_marks_invalid");
    const request = new input.construction.requestFactory(world, events, day).create({
        phase: domain_1.Phase.Night,
        actorId: frame.witchId,
        allowedTools: ["use_potion"],
        stage: "witch",
        requiresAction: true,
        summary: { key: "request.summary.night_action" },
        context: {
            ability_id: "native:potion",
            allow_fallback: false,
            action_failure_policy: "error",
            ...(ability.state.heal > 0 ? { wolf_target: wolfTarget } : {}),
        },
    });
    (0, native_potion_requests_1.bindDemonWitchRequest)(world, request, scope, () => !closed && frame.isCurrent(), frame.targetCurrent);
    const authorized = () => (0, native_potion_requests_1.demonWitchRequestCurrent)(world, request);
    try {
        if (!authorized())
            throw new Error("demon_hunter_native_witch_revoked");
        const raw = await provider.getAction(request);
        if (!authorized())
            throw new Error("demon_hunter_native_witch_revoked");
        const call = (0, native_potion_requests_1.readDemonPotionTool)(raw);
        if (!call || !(0, native_potion_requests_1.demonWitchRequestTargetCurrent)(world, request, call.args.target_id))
            throw new Error("demon_hunter_native_witch_invalid");
        const candidateMarks = world.getComponent(call.args.target_id, domain_1.COMPONENT.StatusMarks);
        if (candidateMarks &&
            (!(0, status_marks_1.statusMarkSnapshot)(candidateMarks, domain_1.StatusMark.PoisonMark) ||
                Object.getPrototypeOf(candidateMarks) !== status_marks_1.StatusMarksComponent.prototype ||
                Object.getOwnPropertyDescriptor(candidateMarks, "has")))
            throw new Error("demon_hunter_native_marks_invalid");
        const checked = gateway.validateAndSanitize(world, frame.witchId, call, {
            phase: domain_1.Phase.Night,
            day,
            abilityId: "native:potion",
            deferOperation: true,
        });
        if (!checked.ok ||
            !checked.sanitizedCall ||
            !authorized() ||
            !(0, native_potion_requests_1.demonWitchRequestTargetCurrent)(world, request, call.args.target_id))
            throw new Error("demon_hunter_native_witch_invalid");
        const targetId = call.args.target_id, potion = call.args.potion_type;
        const source = (0, night_effects_1.captureNightLife)(world, frame.witchId), target = (0, night_effects_1.captureNightLife)(world, targetId);
        if (!source || !target)
            throw new Error("demon_hunter_native_witch_revoked");
        Object.freeze(source);
        Object.freeze(target);
        let poison = null;
        const native = potion === domain_1.PotionType.Poison && targetId === frame.demonId
            ? (0, native_poison_1.captureDemonNativePoison)(world, frame.witchId, ability, targetId)
            : null;
        if (potion === domain_1.PotionType.Poison && targetId === frame.demonId && !native)
            throw new Error("demon_hunter_native_poison_unavailable");
        let marks = world.getComponent(targetId, domain_1.COMPONENT.StatusMarks);
        if (potion !== domain_1.PotionType.None && !marks) {
            marks = new status_marks_1.StatusMarksComponent();
            world.addComponent(targetId, domain_1.COMPONENT.StatusMarks, marks);
        }
        const contribution = potion === domain_1.PotionType.Poison && marks
            ? (0, poison_contribution_1.openNativePoisonContribution)(world, targetId, marks)
            : null;
        const healContribution = potion === domain_1.PotionType.Heal && marks
            ? (0, heal_contribution_1.openNativeHealContribution)(world, targetId, marks)
            : null;
        (0, inventory_ports_1.recordNightAbilityUse)(ability, day, potion !== domain_1.PotionType.None);
        if (potion !== domain_1.PotionType.None) {
            nativeAddMark.call(marks, potion === domain_1.PotionType.Heal ? domain_1.StatusMark.HealMark : domain_1.StatusMark.PoisonMark);
            ability.state[potion]--;
            ability.state[potion === domain_1.PotionType.Heal ? "healUsedThisNight" : "poisonUsedThisNight"] =
                true;
        }
        if (!frame.commit(potion))
            throw new Error("demon_hunter_native_witch_commit_failed");
        if (contribution)
            (0, poison_contribution_1.commitNativePoisonContribution)(contribution);
        if (healContribution) {
            (0, heal_contribution_1.commitNativeHealContribution)(healContribution);
            const heals = deliveredHeals.get(world) ?? new Map();
            if (heals.has(day))
                throw new Error("demon_hunter_native_witch_delivery_reentry");
            heals.set(day, Object.freeze({
                claim: Object.freeze({
                    source,
                    target,
                    isCurrent: () => frame.sourceCurrent() && frame.targetCurrent(targetId),
                }),
                lateUnknown: () => (0, heal_contribution_1.lateUnknownHealContribution)(healContribution),
                sealContribution: () => (0, heal_contribution_1.sealNativeHealContribution)(healContribution),
            }));
            deliveredHeals.set(world, heals);
        }
        if (native && contribution) {
            const proof = (0, native_poison_1.commitDemonNativePoison)(native);
            if (!proof)
                throw new Error("demon_hunter_native_poison_commit_failed");
            poison = Object.freeze({
                proof,
                claim: Object.freeze((0, night_effects_1.originalPoisonIntent)({
                    source,
                    target,
                    isCurrent: () => frame.sourceCurrent() && frame.targetCurrent(targetId),
                }, {
                    family: "demon-witch",
                    day,
                    stage: "witch",
                    actorLife: source,
                    requestedTargetId: targetId,
                    abilityId: "native:potion",
                })),
                lateUnknown: () => (0, poison_contribution_1.lateUnknownPoisonContribution)(contribution),
                sealContribution: () => (0, poison_contribution_1.sealNativePoisonContribution)(contribution),
            });
        }
        else if (potion === domain_1.PotionType.Poison) {
            poison = Object.freeze({
                proof: null,
                claim: Object.freeze((0, night_effects_1.originalPoisonIntent)({
                    source,
                    target,
                    isCurrent: () => frame.sourceCurrent() && frame.targetCurrent(targetId),
                }, {
                    family: "demon-witch",
                    day,
                    stage: "witch",
                    actorLife: source,
                    requestedTargetId: targetId,
                    abilityId: "native:potion",
                })),
                lateUnknown: () => (0, poison_contribution_1.lateUnknownPoisonContribution)(contribution),
                sealContribution: () => (0, poison_contribution_1.sealNativePoisonContribution)(contribution),
            });
        }
        const nights = delivered.get(world) ?? new Map();
        if (nights.has(day))
            throw new Error("demon_hunter_native_witch_delivery_reentry");
        nights.set(day, poison);
        delivered.set(world, nights);
        (0, domain_1.settleRequestDelivery)(scope, true);
        (0, recorder_1.safeRecordLogicOp)({
            scope: "gateway",
            op: "validate_tool_call",
            actorId: frame.witchId,
            phase: domain_1.Phase.Night,
            status: "ok",
            input: { tool: call.name, args: call.args },
        });
        events.push({
            timestamp: Date.now(),
            type: potion === domain_1.PotionType.None ? "witch_potion_skipped" : "witch_potion_used",
            payload: {
                actorId: frame.witchId,
                targetId,
                potionType: potion,
            },
        });
        return Object.freeze({ poison, used: potion !== domain_1.PotionType.None });
    }
    finally {
        closed = true;
        (0, domain_1.settleRequestDelivery)(scope, false);
    }
}
function sealDeliveredDemonWitchSources(world, day) {
    if ((0, authority_1.demonHunterFreezeDay)(world) !== day ||
        ((0, authority_1.demonWitchRequiredThisNight)(world) && !delivered.get(world)?.has(day)))
        throw new Error("demon_hunter_native_sources_missing");
    const seen = sealedNights.get(world) ?? new Set();
    if (seen.has(day))
        throw new Error("demon_hunter_native_sources_already_sealed");
    const poison = delivered.get(world)?.get(day) ?? null;
    const contributions = poison?.sealContribution() ?? null;
    const heal = deliveredHeals.get(world)?.get(day) ?? null, healContributions = heal?.sealContribution() ?? null;
    const token = Object.freeze({});
    sealedSources.set(token, {
        world,
        day,
        poison,
        contributions,
        heal,
        healContributions,
        frozen: false,
    });
    seen.add(day);
    sealedNights.set(world, seen);
    return token;
}
function freezeDeliveredDemonNightSources(world, token, faultId = null) {
    const sealed = sealedSources.get(token), day = (0, authority_1.demonHunterFreezeDay)(world);
    if (!sealed || sealed.world !== world || sealed.day !== day || sealed.frozen)
        throw new Error("demon_hunter_native_sources_invalid");
    const poison = sealed.poison, contributions = sealed.contributions;
    const originalSourceCurrent = poison?.claim.isCurrent?.() === true;
    const lateUnknown = poison?.lateUnknown() ?? false;
    const healCurrent = sealed.heal?.claim.isCurrent?.() === true, lateHeal = sealed.heal?.lateUnknown() ?? false;
    const result = (0, native_poison_1.freezeDemonNightSources)(world, poison?.proof ? [poison.proof] : [], faultId);
    sealed.frozen = true;
    const immunity = !!poison?.proof &&
        contributions?.native === true &&
        originalSourceCurrent &&
        result.poisonImmunities.length === 1;
    return Object.freeze({
        hunt: result.hunt,
        healOverrides: Object.freeze(sealed.heal && sealed.healContributions
            ? [
                Object.freeze({
                    targetId: sealed.heal.claim.target.id,
                    heal: sealed.healContributions.unknown ||
                        lateHeal ||
                        (sealed.healContributions.native && healCurrent),
                }),
            ]
            : []),
        poisonImmunities: Object.freeze(immunity ? [...result.poisonImmunities] : []),
        poisonOverrides: Object.freeze(poison && contributions
            ? [
                Object.freeze({
                    targetId: poison.claim.target.id,
                    poison: contributions.unknown ||
                        lateUnknown ||
                        (contributions.native && originalSourceCurrent && !immunity),
                }),
            ]
            : []),
    });
}
