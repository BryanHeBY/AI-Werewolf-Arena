"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SHELTER_STATE_SLOT = void 0;
const abilities_1 = require("../night-abilities/abilities");
const abilities_2 = require("../night-abilities/abilities");
const shelter_state_1 = require("./shelter-state");
function installShelterState(role, state) {
    return (0, abilities_2.commitPreparedNativeAbility)(role, "shelter", exports.SHELTER_STATE_SLOT.prepare(state));
}
function recordShelterSelection(ability, next) {
    Object.assign(ability.state, next);
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.policy]);
}
exports.SHELTER_STATE_SLOT = Object.freeze({
    create: shelter_state_1.createShelterState,
    prepare: (abilities_1.copyAbilityData),
    schema: shelter_state_1.readShelterState,
    select: shelter_state_1.selectShelter,
    project: shelter_state_1.projectShelterState,
    install: installShelterState,
    allowedWrites: Object.freeze({ recordShelterSelection }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
