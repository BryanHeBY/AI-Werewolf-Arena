"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRoleInspection = exports.ROLE_INSPECTION_TOOL = void 0;
exports.roleInspectionTargets = roleInspectionTargets;
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const model_1 = require("../../domain/model");
const validation_contracts_1 = require("../../engine/actions/validation-contracts");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const role_inspection_policy_1 = require("@ai-werewolf-arena/game-contract/role-inspection-policy");
function roleInspectionTargets(world, actorId, state) {
    const repeat = (0, role_inspection_policy_1.inspectionRepeats)(state);
    return world
        .getAliveEntityIds()
        .filter((id) => id !== actorId && (repeat || !state.history.some((report) => report.targetId === id)));
}
exports.ROLE_INSPECTION_TOOL = {
    name: "inspect_role",
    parameters: {
        type: "object",
        properties: { target_id: { type: "number" } },
        required: ["target_id"],
        additionalProperties: false,
    },
    argHint: 'inspect_role args: {"target_id":number}',
    userPromptHintKey: "action.inspect_role.hint",
};
const validateRoleInspection = ({ world, actorId, role, day, phase, abilityId, toolCall, }) => {
    const ability = (0, inventory_ports_1.activeNightAbility)(role, "role_check", day ?? 1, abilityId);
    if (!ability)
        return { code: game_contract_1.RuleError.RoleInspectUnavailable };
    if (phase !== model_1.Phase.Night)
        return { code: game_contract_1.RuleError.AbilityPhase };
    if (toolCall.name !== "inspect_role")
        return { code: game_contract_1.RuleError.ToolMismatch };
    if (toolCall.args.target_id === actorId || !(0, validation_contracts_1.isAliveTarget)(world, toolCall.args.target_id))
        return { code: game_contract_1.RuleError.RoleInspectTarget };
    if (!(0, role_inspection_policy_1.inspectionRepeats)(ability.state) &&
        ability.state.history.some((report) => report.targetId === toolCall.args.target_id))
        return { code: game_contract_1.RuleError.RoleInspectRepeat };
    return null;
};
exports.validateRoleInspection = validateRoleInspection;
