import { roleInspectionPolicy } from "@ai-werewolf-arena/game-contract/role-inspection-policy";
import { RuleError } from "@ai-werewolf-arena/game-contract";
import { Camp, Phase, Role } from "../../domain/model";
import { COMPONENT } from "../../domain/components/names";
import { activeNightAbility } from "../night-abilities/abilities";
export function pureWhiteInspectionTargets(world, actorId, policy) {
    return world
        .getAliveEntityIds()
        .filter((id) => {
        if (id === actorId)
            return false;
        if (policy === "pure_white")
            return true;
        const role = world.getComponent(id, COMPONENT.Role);
        return !role || world.getComponent(id, COMPONENT.Camp)?.camp !== Camp.Wolf;
    });
}
export const PURE_WHITE_INSPECTION_TOOL = {
    name: "inspect_night_identity",
    parameters: {
        type: "object",
        properties: {
            target_id: { type: ["integer", "null"], minimum: 1 },
            abstain: { type: "boolean" },
        },
        required: ["target_id", "abstain"],
        additionalProperties: false,
    },
    argHint: 'inspect_night_identity args: {"target_id":number|null,"abstain":boolean}',
    userPromptHintKey: "action.inspect_night_identity.hint",
};
export const validatePureWhiteInspection = ({ world, actorId, role, day, phase, abilityId, toolCall, }) => {
    const ability = activeNightAbility(role, "role_check", day ?? 1, abilityId);
    if (!ability)
        return { code: RuleError.RoleInspectUnavailable };
    const policy = roleInspectionPolicy(ability.state);
    if (policy !== "pure_white" && policy !== "wolf_witch")
        return { code: RuleError.RoleInspectUnavailable };
    const expected = policy === "pure_white" ? Role.PureWhiteGirl : Role.WolfWitch;
    if (role.role !== expected ||
        ability.source.kind !== "native" ||
        ability.source.role !== expected)
        return { code: RuleError.RoleInspectUnavailable };
    if (phase !== Phase.Night)
        return { code: RuleError.AbilityPhase };
    if (toolCall.name !== "inspect_night_identity")
        return { code: RuleError.ToolMismatch };
    const { target_id, abstain } = toolCall.args;
    if (abstain === true && target_id === null)
        return null;
    if (abstain !== false ||
        target_id === null ||
        !Number.isSafeInteger(target_id) ||
        !pureWhiteInspectionTargets(world, actorId, policy).includes(target_id))
        return { code: RuleError.RoleInspectTarget };
    return null;
};
