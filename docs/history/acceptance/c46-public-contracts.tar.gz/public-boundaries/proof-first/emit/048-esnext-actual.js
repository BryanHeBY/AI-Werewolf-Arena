import { COMPONENT } from "../../domain/components/names";
import { aliveLifeVersion, aliveLifeDescriptor, } from "../../domain/components/alive";
import { Camp } from "../../domain/identity";
import { captureNightLife, livingNightLife, } from "../../domain/night-effects";
import { getNightmareShadowState, NIGHTMARE_SHADOW_STATE_SLOT } from "./state-slot";
import { nightmareFearTargets } from "./targets";
function authority(ability) {
    const state = ability.state;
    return JSON.stringify([
        ability.id,
        ability.kind,
        ability.activation,
        ability.source,
        ability.sourceDisclosed,
        ability.startsOnDay,
        ability.expiresAfterDay,
        ability.maxUses,
        ability.disabled,
        ability.deathExpired,
        state.targetPolicy,
        state.actionPolicy,
        state.selfHealRule,
        state.knifeVisibility,
        state.potionPolicy,
        state.repeatPolicy,
        state.policy,
        state.inspectionPolicy,
        state.protectionPolicy,
    ]);
}
function captureRole(world, id) {
    const role = world.getComponent(id, COMPONENT.Role);
    if (!role)
        throw new Error("nightmare_roster_missing");
    const kind = role.role, camp = world.getComponent(id, COMPONENT.Camp)?.camp, privateState = role.privateState;
    const life = world.getComponent(id, COMPONENT.Alive);
    const descriptor = life && aliveLifeDescriptor(life);
    const version = life && aliveLifeVersion(life);
    if (!life || !descriptor || version === undefined)
        throw new Error("nightmare_roster_life_missing");
    const lifeCurrent = () => {
        const current = Object.getOwnPropertyDescriptor(life, "alive");
        return (world.getComponent(id, COMPONENT.Alive) === life &&
            current?.get === descriptor.get &&
            current?.set === descriptor.set &&
            (aliveLifeVersion(life) === version ||
                (aliveLifeVersion(life) === version + 1 && !life.alive)));
    };
    const refs = Object.entries(privateState);
    const slots = Object.entries(privateState.abilities ?? {});
    const abilities = Object.values((privateState.abilities ?? {})).map((ability) => ({
        ability,
        state: ability.state,
        source: ability.source,
        identity: authority(ability),
    }));
    return {
        id,
        role,
        current: () => lifeCurrent() &&
            world.getComponent(id, COMPONENT.Role) === role &&
            role.role === kind &&
            world.getComponent(id, COMPONENT.Camp)?.camp === camp &&
            role.privateState === privateState &&
            refs.every(([key, value]) => privateState[key] === value) &&
            Object.keys(privateState.abilities ?? {}).length ===
                slots.length &&
            slots.every(([key, value]) => privateState.abilities?.[key] === value) &&
            abilities.every((a) => a.ability.state === a.state &&
                a.ability.source === a.source &&
                authority(a.ability) === a.identity),
    };
}
const boards = new WeakMap();
export function installNightmareBoard(world) {
    if (boards.has(world))
        throw new Error("nightmare_board_reinstall");
    const roster = world.entityIds().map((id) => captureRole(world, id));
    const actors = roster.filter((row) => getNightmareShadowState(row.role, () => world.getComponent(row.id, COMPONENT.Camp)));
    if (actors.length !== 1)
        throw new Error("nightmare_actor_count");
    const state = getNightmareShadowState(actors[0].role, () => world.getComponent(actors[0].id, COMPONENT.Camp));
    boards.set(world, {
        actorId: actors[0].id,
        state,
        expectedState: NIGHTMARE_SHADOW_STATE_SLOT.checkpoint.identity(state),
        roster,
        night: null,
    });
}
export function isNightmareBoard(world) {
    return boards.has(world);
}
export function assertNightmareRosterCurrent(world) {
    const board = boards.get(world);
    if (!board)
        return;
    if (world.entityIds().length !== board.roster.length ||
        board.roster.some((row) => !row.current()) ||
        getNightmareShadowState(world.getComponent(board.actorId, COMPONENT.Role), () => world.getComponent(board.actorId, COMPONENT.Camp)) !== board.state ||
        NIGHTMARE_SHADOW_STATE_SLOT.checkpoint.identity(board.state) !== board.expectedState)
        throw new Error("nightmare_roster_revoked");
}
export function beginNightmareNight(world, day) {
    const board = boards.get(world);
    if (!board)
        return null;
    assertNightmareRosterCurrent(world);
    if (!Number.isSafeInteger(day) ||
        day !== (board.night?.day ?? 0) + 1 ||
        (board.night?.required && !board.night.committed))
        throw new Error("nightmare_night_reentry");
    board.night = {
        day,
        required: world.getAliveEntityIds().includes(board.actorId),
        committed: false,
        target: null,
        wolfBlocked: false,
    };
    return world.getAliveEntityIds().includes(board.actorId) ? board.actorId : null;
}
export function nightmarePackReady(world) {
    assertNightmareRosterCurrent(world);
    return boards.get(world)?.state.packReady ?? true;
}
export function commitNightmareFear(world, actorId, day, targetId) {
    assertNightmareRosterCurrent(world);
    const board = boards.get(world), night = board?.night;
    if (!board ||
        !night ||
        board.actorId !== actorId ||
        night.day !== day ||
        night.committed ||
        !world.getAliveEntityIds().includes(actorId))
        throw new Error("nightmare_fear_scope_invalid");
    const candidates = nightmareFearTargets(world, actorId, day);
    if (targetId === null
        ? board.state.fearActionPolicy === "required_when_legal" && candidates.length > 0
        : !candidates.includes(targetId))
        throw new Error("nightmare_fear_target_invalid");
    const target = targetId === null ? null : captureNightLife(world, targetId);
    if (targetId !== null && !target)
        throw new Error("nightmare_fear_target_invalid");
    const wolfBlocked = targetId !== null && !!world.getComponent(targetId, COMPONENT.Role) &&
        world.getComponent(targetId, COMPONENT.Camp)?.camp === Camp.Wolf;
    NIGHTMARE_SHADOW_STATE_SLOT.allowedWrites.recordFear(() => board.state, day, targetId);
    board.expectedState = NIGHTMARE_SHADOW_STATE_SLOT.checkpoint.identity(board.state);
    night.committed = true;
    night.target = target;
    night.wolfBlocked = wolfBlocked;
}
export function nightmareFearBlocks(world, id, day, allowFirstDeath = false) {
    assertNightmareRosterCurrent(world);
    const night = boards.get(world)?.night, target = night?.target;
    if (!night || night.day !== day || !target || target.id !== id)
        return false;
    if (livingNightLife(world, target))
        return true;
    if (!allowFirstDeath)
        throw new Error("nightmare_target_life_revoked");
    return (world.getComponent(id, COMPONENT.Alive) === target.life &&
        !target.life.alive &&
        aliveLifeVersion(target.life) === target.version + 1);
}
export function nightmareKnifeBlocked(world, day) {
    assertNightmareRosterCurrent(world);
    const night = boards.get(world)?.night;
    return !!night && (day === undefined || night.day === day) && night.wolfBlocked;
}
export function nightmareFearPending(world, actorId, day) {
    assertNightmareRosterCurrent(world);
    const board = boards.get(world), night = board?.night;
    return (!!board &&
        !!night &&
        board.actorId === actorId &&
        night.day === day &&
        night.required &&
        !night.committed &&
        world.getAliveEntityIds().includes(actorId));
}
