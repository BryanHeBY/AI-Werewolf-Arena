"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WOLF_WITCH_INSPECTION_STAGE = exports.PURE_WHITE_INSPECTION_STAGE = void 0;
const role_inspection_policy_1 = require("@ai-werewolf-arena/game-contract/role-inspection-policy");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const deaths_1 = require("../../domain/deaths");
const night_effects_1 = require("../../domain/night-effects");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const scope_ports_1 = require("../night-abilities/scope-ports");
const inspection_1 = require("../../engine/inspection");
const ports_1 = require("../role-inspection/ports");
const night_commit_ports_1 = require("../role-inspection/night-commit-ports");
const rules_1 = require("./rules");
async function execute(ctx, policy) {
    const day = ctx.currentDay();
    const expectedRole = policy === "pure_white" ? model_1.Role.PureWhiteGirl : model_1.Role.WolfWitch;
    for (const { actorId, ability } of ctx.nightActors.actors("role_check", day)) {
        if (!ctx.isCurrent())
            return;
        if ((0, role_inspection_policy_1.roleInspectionPolicy)(ability.state) !== policy)
            continue;
        if (ability.source.kind !== "native" || ability.source.role !== expectedRole)
            continue;
        const scope = (0, scope_ports_1.captureNightAbilityScope)(ctx.world, actorId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day);
        if (!scope || scope.role.role !== expectedRole)
            continue;
        const current = () => scope.isEligible() && (0, role_inspection_policy_1.roleInspectionPolicy)(ability.state) === policy;
        const close = (reason) => {
            if (!current())
                return;
            (0, inventory_ports_1.recordNightAbilityUse)(ability, day, false);
            ctx.events.push({
                timestamp: Date.now(),
                type: "role_inspection_skipped",
                payload: { actorId, day, reason },
            });
            (0, night_commit_ports_1.recordRoleInspectionNightCommit)(ctx.world, day, ctx.isCurrent);
        };
        const targets = new Map((0, rules_1.pureWhiteInspectionTargets)(ctx.world, actorId, policy).map((id) => {
            const life = (0, night_effects_1.captureNightLife)(ctx.world, id);
            const role = ctx.world.getComponent(id, names_1.COMPONENT.Role);
            return [id, { life, role, identity: role?.role, camp: role == null ? undefined : ctx.world.getComponent(id, names_1.COMPONENT.Camp)?.camp }];
        }));
        if (!current())
            continue;
        if (!targets.size) {
            close("no_targets");
            continue;
        }
        const request = ctx.makeRequest(actorId, ["inspect_night_identity"], {
            stage: policy === "pure_white" ? "pure_white_girl" : "wolf_witch",
            requiresAction: true,
            ability_id: ability.id,
            action_failure_policy: "error",
            allow_fallback: false,
        });
        const action = await ctx.actionProvider.getAction(request);
        if (!current())
            continue;
        if (action?.name !== "inspect_night_identity")
            throw new Error("pure_white_inspection_action_missing");
        const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: model_1.Phase.Night,
            day,
            abilityId: ability.id,
        });
        if (!current())
            continue;
        if (!validated.ok || validated.sanitizedCall?.name !== "inspect_night_identity")
            throw new Error("pure_white_inspection_action_invalid");
        const args = validated.sanitizedCall.args;
        if (args.abstain && args.target_id === null) {
            close("passed");
            continue;
        }
        const targetId = args.target_id;
        if (targetId === null)
            throw new Error("pure_white_inspection_target_invalid");
        const target = targets.get(targetId);
        const targetCurrent = () => !!target?.life &&
            !!target.role &&
            (0, night_effects_1.livingNightLife)(ctx.world, target.life) &&
            ctx.world.getComponent(targetId, names_1.COMPONENT.Role) === target.role &&
            target.role.role === target.identity &&
            ctx.world.getComponent(targetId, names_1.COMPONENT.Camp)?.camp === target.camp &&
            (0, rules_1.pureWhiteInspectionTargets)(ctx.world, actorId, policy).includes(targetId);
        if (!targetCurrent())
            throw new Error("pure_white_inspection_target_stale");
        const result = (0, inspection_1.resolveInspection)(ctx.world, targetId, "role", ctx.roleCatalog);
        if (!current())
            continue;
        if (!result || !targetCurrent())
            throw new Error("pure_white_inspection_target_stale");
        ports_1.ROLE_INSPECTION_STATE_SLOT.allowedWrites.appendAbility(ability, targetId, day, result);
        (0, inventory_ports_1.recordNightAbilityUse)(ability, day, true);
        ctx.events.push({
            timestamp: Date.now(),
            type: "role_inspected",
            payload: { actorId, targetId, day, result: { ...result } },
        });
        (0, night_commit_ports_1.recordRoleInspectionNightCommit)(ctx.world, day, ctx.isCurrent);
        if (day >= 2 &&
            (policy === "pure_white"
                ? target.camp === model_1.Camp.Wolf
                : target.identity === model_1.Role.PureWhiteGirl)) {
            (ctx.state.inspectionAttacks ??= []).push({
                actorId,
                target: target.life,
                cause: policy === "pure_white" ? deaths_1.DeathCause.PureWhiteInspection : deaths_1.DeathCause.WolfWitchInspection,
                isCurrent: () => scope.isOwnerCurrent() &&
                    !ability.disabled &&
                    !ability.deathExpired &&
                    targetCurrent() &&
                    (0, role_inspection_policy_1.roleInspectionPolicy)(ability.state) === policy,
            });
        }
    }
}
exports.PURE_WHITE_INSPECTION_STAGE = {
    id: "pure_white_inspection",
    priority: 610,
    execute: (ctx) => execute(ctx, "pure_white"),
};
exports.WOLF_WITCH_INSPECTION_STAGE = {
    id: "wolf_witch_inspection",
    priority: 620,
    execute: (ctx) => execute(ctx, "wolf_witch"),
};
