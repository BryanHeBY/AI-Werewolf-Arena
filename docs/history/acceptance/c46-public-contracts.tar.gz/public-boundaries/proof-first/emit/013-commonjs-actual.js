"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.awakenedDeathHook = void 0;
const model_1 = require("../../domain/model");
const settlement_ports_1 = require("../death-actions/settlement-ports");
const state_1 = require("./state");
const native_resource_ports_1 = require("../death-actions/native-resource-ports");
const awakenedDeathHook = (world, ids, sources, choose, events, context) => {
    const readGun = (0, native_resource_ports_1.createAwakenedGunReader)({ get getAwakenedState() { return state_1.getAwakenedState; } });
    return (0, settlement_ports_1.resolveNativeDeathShots)(world, ids, sources, choose, events, {
        role: model_1.Role.AwakenedHiddenWolf,
        state: readGun,
        permits: model_1.permitsDeathShot,
        shotEvent: (actorId, targetId) => ({
            timestamp: Date.now(),
            type: "player_shot",
            payload: { actorId, targetId },
        }),
    }, context);
};
exports.awakenedDeathHook = awakenedDeathHook;
