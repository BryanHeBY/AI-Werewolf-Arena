import { copyAbilityData, findNightAbility } from "../night-abilities/inventory-ports";
import { commitPreparedNativeAbility } from "../night-abilities/inventory-ports";
export function setDreamerState(roleComp, state) {
    return commitPreparedNativeAbility(roleComp, "dream", DREAMER_STATE_SLOT.create(state));
}
export function getDreamerState(roleComp, abilityId) {
    return findNightAbility(roleComp, "dream", abilityId)?.state;
}
export function recordDreamSelection(state, targetId, day) {
    state.lastTarget = targetId;
    state.lastDay = day;
    state.history.push({ day, targetId });
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.protectionPolicy]);
}
export const DREAMER_STATE_SLOT = Object.freeze({
    create: (copyAbilityData),
    schema: (copyAbilityData),
    install: setDreamerState,
    get: getDreamerState,
    allowedWrites: Object.freeze({ recordDreamSelection }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
