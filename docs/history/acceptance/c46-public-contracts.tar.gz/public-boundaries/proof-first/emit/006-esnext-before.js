import { getDefaultRoleCatalog } from "../../rulesets/roles/role-catalog-assembly";
import { giftGunDeathHook } from "../../features/death-actions/gift-gun-death-hook";
import { resolveWildChildDeathWave } from "../../features/wild-child/ports";
export function createCommittedDeathWaveContributions() {
    return [resolveWildChildDeathWave];
}
function buildDefaultVotedOutHooks() {
    return getDefaultRoleCatalog()
        .allRuntime()
        .map(({ runtime }) => runtime.votedOutHook)
        .filter((hook) => Boolean(hook));
}
function buildDefaultDeathHooks() {
    return getDefaultRoleCatalog()
        .allRuntime()
        .map(({ runtime }) => runtime.deathHook)
        .filter((hook) => Boolean(hook))
        .concat(giftGunDeathHook);
}
export class HookRegistry {
    votedOutHooks;
    deathHooks;
    constructor(votedOutHooks = buildDefaultVotedOutHooks(), deathHooks = buildDefaultDeathHooks()) {
        this.votedOutHooks = votedOutHooks;
        this.deathHooks = deathHooks;
    }
    onVotedOut(world, targetId, events) {
        for (const hook of this.votedOutHooks) {
            const result = hook(world, targetId, events);
            if (result) {
                return result;
            }
        }
        return null;
    }
    async onDeath(world, deadIds, deathSources, chooseDeathShot, events, commitAdditionalDeaths, context) {
        const aggregated = {
            extraDeaths: [],
            extraDeathSources: {},
        };
        for (const hook of this.deathHooks) {
            if (context?.isCurrent && !context.isCurrent())
                break;
            const result = await hook(world, deadIds, deathSources, chooseDeathShot, events, context);
            commitAdditionalDeaths?.(result);
            aggregated.extraDeaths.push(...result.extraDeaths);
            if (result.nightEffectTargets?.length)
                (aggregated.nightEffectTargets ??= []).push(...result.nightEffectTargets);
            if (result.pendingShots?.length)
                (aggregated.pendingShots ??= []).push(...result.pendingShots);
            if (result.deathWaveContributions?.length)
                (aggregated.deathWaveContributions ??= []).push(...result.deathWaveContributions);
            for (const [id, marks] of Object.entries(result.extraDeathSources)) {
                aggregated.extraDeathSources[Number(id)] = [
                    ...new Set([...(aggregated.extraDeathSources[Number(id)] ?? []), ...marks]),
                ];
            }
        }
        return aggregated;
    }
}
let defaultRegistry = null;
export function getDefaultHookRegistry() {
    if (!defaultRegistry) {
        defaultRegistry = new HookRegistry();
    }
    return defaultRegistry;
}
