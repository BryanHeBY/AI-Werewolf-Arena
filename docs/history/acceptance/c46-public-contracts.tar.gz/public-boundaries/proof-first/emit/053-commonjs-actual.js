"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ECLIPSE_MAID_ROLE_PROFILE = exports.RADIANT_COUNT_ROLE_PROFILE = void 0;
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const zod_1 = require("zod");
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const identity_1 = require("../../domain/identity");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const native_installation_ports_1 = require("../night-abilities/native-installation-ports");
const inventory_ports_2 = require("../night-abilities/inventory-ports");
const ability_ports_1 = require("../wolf/ability-ports");
const night_stages_1 = require("./night-stages");
const eclipse_state_slot_1 = require("./eclipse-state-slot");
const shelter_state_1 = require("./shelter-state");
const night_frame_1 = require("./night-frame");
const parameters = zod_1.z.strictObject({
    policy: zod_1.z.literal(eclipse_state_slot_1.RADIANT_ECLIPSE_POLICY).default(eclipse_state_slot_1.RADIANT_ECLIPSE_POLICY),
});
const configuration = {
    schema: parameters,
    defaults: parameters.parse({}),
    apply: (config, value) => ({ ...config, radiantEclipse: parameters.parse(value) }),
    serialize: (config) => parameters.parse(config.radiantEclipse ?? {}),
};
const common = {
    metadata: {
        maxCount: 1,
        supportedBoardRoles: [
            identity_1.Role.Wolf,
            identity_1.Role.EclipseMaid,
            identity_1.Role.Villager,
            identity_1.Role.RadiantCount,
            identity_1.Role.Seer,
            identity_1.Role.Witch,
            identity_1.Role.Dreamer,
        ],
        supportedWinConditions: [identity_1.WinCondition.SlaughterSide],
    },
    runtime: {
        canSelfDestruct: false,
        configuration,
    },
};
const targetParameters = {
    type: "object",
    properties: { target_id: { type: ["integer", "null"], minimum: 1 } },
    required: ["target_id"],
    additionalProperties: false,
};
exports.RADIANT_COUNT_ROLE_PROFILE = {
    metadata: {
        ...common.metadata,
        role: identity_1.Role.RadiantCount,
        camp: identity_1.Camp.Good,
        goodSide: "god",
        label: (0, game_text_1.roleName)("radiant_count"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.radiant_count.brief"),
    },
    runtime: {
        ...common.runtime,
        init: (role) => {
            (0, native_installation_ports_1.installNativeAbility)(role, "shelter", (0, shelter_state_1.createShelterState)());
            (0, inventory_ports_2.setNightAbilityStartDay)((0, inventory_ports_1.activeNightAbility)(role, "shelter", 1), 2);
        },
        nightStages: [night_stages_1.RADIANT_SHELTER_STAGE],
        toolSpecs: [
            {
                name: "cast_shelter",
                parameters: targetParameters,
                argHint: 'cast_shelter args: {"target_id":number|null}',
                userPromptHintKey: "action.cast_shelter.hint",
            },
        ],
        stageDirectives: [
            {
                match: (tools) => tools.length === 1 && tools[0] === "cast_shelter",
                messageKey: "action.cast_shelter.directive",
                text: (0, game_text_1.text)("zh-CN", "action.cast_shelter.directive"),
            },
        ],
        validationRules: {
            cast_shelter: ({ world, actorId, role, day, phase, abilityId, toolCall }) => {
                if (phase !== identity_1.Phase.Night ||
                    day === undefined ||
                    !(0, night_frame_1.isRadiantEclipseBoard)(world) ||
                    toolCall.name !== "cast_shelter")
                    return { code: game_contract_1.RuleError.RadiantShelterUnavailable };
                const a = (0, inventory_ports_1.activeNightAbility)(role, "shelter", day, abilityId);
                if (!a)
                    return { code: game_contract_1.RuleError.RadiantShelterUnavailable };
                try {
                    if (!(0, night_frame_1.captureRadiantTurn)(world, actorId, a, day)())
                        return { code: game_contract_1.RuleError.RadiantShelterUnavailable };
                }
                catch {
                    return { code: game_contract_1.RuleError.RadiantShelterUnavailable };
                }
                return toolCall.args.target_id === null ||
                    (0, night_frame_1.shelterTargets)(world, day, actorId, a.id).includes(toolCall.args.target_id)
                    ? null
                    : { code: game_contract_1.RuleError.RadiantShelterTarget };
            },
        },
        baselineAction: (_role, request) => request.allowedTools.includes("cast_shelter")
            ? { name: "cast_shelter", args: { target_id: null } }
            : null,
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("radiant_count"),
};
exports.ECLIPSE_MAID_ROLE_PROFILE = {
    metadata: {
        ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.metadata,
        ...common.metadata,
        role: identity_1.Role.EclipseMaid,
        camp: identity_1.Camp.Wolf,
        label: (0, game_text_1.roleName)("eclipse_maid"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.eclipse_maid.brief"),
    },
    runtime: {
        ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime,
        ...common.runtime,
        init: (role) => {
            (0, eclipse_state_slot_1.initializeEclipseState)(role);
            (0, inventory_ports_1.initializeNightAbilityInventory)(role);
        },
        wolfTeam: (_role, world) => ({
            recognizedByPack: false,
            recognizes: "none",
            canChat: false,
            canVoteForKill: !!world && (0, night_frame_1.eclipseKnifeEligible)(world),
        }),
        knownTeammates: (_role, world) => (0, night_frame_1.eclipseKnownWolves)(world),
        possibleNightAbilities: ["shelter", "dream", "potion", "seer_check"],
        nightStages: [...(ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.nightStages ?? []), night_stages_1.ECLIPSE_SWALLOW_STAGE],
        toolSpecs: [
            ...(ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.toolSpecs ?? []),
            {
                name: "swallow_skill",
                parameters: targetParameters,
                argHint: 'swallow_skill args: {"target_id":number|null}',
                userPromptHintKey: "action.swallow_skill.hint",
            },
        ],
        stageDirectives: [
            ...(ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.stageDirectives ?? []),
            {
                match: (tools) => tools.length === 1 && tools[0] === "swallow_skill",
                messageKey: "action.swallow_skill.directive",
                text: (0, game_text_1.text)("zh-CN", "action.swallow_skill.directive"),
            },
        ],
        validationRules: {
            ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.validationRules,
            swallow_skill: ({ world, actorId, day, phase, toolCall }) => {
                if (phase !== identity_1.Phase.Night ||
                    day === undefined ||
                    !(0, night_frame_1.isRadiantEclipseBoard)(world) ||
                    toolCall.name !== "swallow_skill")
                    return { code: game_contract_1.RuleError.EclipseSwallowUnavailable };
                if (!(0, night_frame_1.eclipseChoiceEligible)(world, day, actorId))
                    return { code: game_contract_1.RuleError.EclipseSwallowUnavailable };
                return toolCall.args.target_id === null ||
                    (0, night_frame_1.eclipseSwallowTargets)(world, day).includes(toolCall.args.target_id)
                    ? null
                    : { code: game_contract_1.RuleError.EclipseSwallowTarget };
            },
        },
        baselineAction: (role, request, ...rest) => request.allowedTools.includes("swallow_skill")
            ? { name: "swallow_skill", args: { target_id: null } }
            : (ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.baselineAction?.(role, request, ...rest) ?? null),
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("eclipse_maid"),
};
