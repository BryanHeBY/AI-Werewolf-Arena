import { scholarMentorPackBlocked } from "../scholar-mentor/wolf-team-ports";
import { animalPackKnifeBlocked } from "../animal-dream/wolf-team-ports";
import { nightmareKnifeBlocked } from "../nightmare/wolf-team-ports";
import { weddingMember, ghostBrideReady, weddingSetup } from "../ghost-bride/wedding-ports";
import { initialIdentitySetupReady } from "../initial-identity/deal-ports";
import { COMPONENT } from "../../domain/components/names";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { Camp, } from "../../domain/model";
const NO_ACCESS = Object.freeze({
    recognizedByPack: false,
    recognizes: "none",
    canChat: false,
    canVoteForKill: false,
});
export function wolfTeamPermissions(role, catalog, currentCamp, world) {
    if (world && !initialIdentitySetupReady(world))
        return NO_ACCESS;
    if (!role || currentCamp()?.camp !== Camp.Wolf)
        return NO_ACCESS;
    if (world && weddingSetup(world) && (!ghostBrideReady(world) || weddingMember(world, role)))
        return NO_ACCESS;
    const permissions = catalog.runtime(role.role)?.wolfTeam;
    const result = typeof permissions === "function" ? permissions(role, world, currentCamp) : (permissions ?? NO_ACCESS);
    const current = world &&
        (nightmareKnifeBlocked(world) ||
            scholarMentorPackBlocked(world) ||
            animalPackKnifeBlocked(world))
        ? { ...result, canVoteForKill: false }
        : result;
    if (current === NO_ACCESS)
        return current;
    return isRoleExecutionRetired(role)
        ? { ...current, canChat: false, canVoteForKill: false }
        : current;
}
export function knownWolfTeammates(world, actorId, catalog) {
    const viewer = wolfTeamPermissions(world.getComponent(actorId, COMPONENT.Role), catalog, () => world.getComponent(actorId, COMPONENT.Camp), world);
    if (viewer === NO_ACCESS)
        return [];
    const role = world.getComponent(actorId, COMPONENT.Role);
    const snapshot = role && world.getComponent(actorId, COMPONENT.Camp)?.camp === Camp.Wolf && catalog.runtime(role.role)?.knownTeammates;
    if (snapshot)
        return [...new Set(snapshot(role, world))]
            .filter((id) => id !== actorId && world.getComponent(id, COMPONENT.Role) && world.getComponent(id, COMPONENT.Camp)?.camp === Camp.Wolf)
            .sort((a, b) => a - b);
    if (viewer.recognizes === "none")
        return [];
    return world
        .entityIds()
        .filter((id) => {
        if (id === actorId)
            return false;
        const target = world.getComponent(id, COMPONENT.Role);
        if (!target || world.getComponent(id, COMPONENT.Camp)?.camp !== Camp.Wolf)
            return false;
        if (viewer.recognizes === "all")
            return true;
        if (viewer.recognizes === "pack")
            return wolfTeamPermissions(target, catalog, () => world.getComponent(id, COMPONENT.Camp), world).recognizedByPack;
        return viewer.recognizes.includes(target.role);
    })
        .sort((a, b) => a - b);
}
export function wolfChatParticipants(world, catalog) {
    return world
        .getAliveEntityIds()
        .filter((id) => wolfTeamPermissions(world.getComponent(id, COMPONENT.Role), catalog, () => world.getComponent(id, COMPONENT.Camp), world).canChat)
        .sort((a, b) => a - b);
}
export function wolfKnifeHolders(world, catalog) {
    return world
        .getAliveEntityIds()
        .filter((id) => wolfTeamPermissions(world.getComponent(id, COMPONENT.Role), catalog, () => world.getComponent(id, COMPONENT.Camp), world).canVoteForKill)
        .sort((a, b) => a - b);
}
export function wolfTeamEvent(world, catalog, event) {
    const recipients = wolfChatParticipants(world, catalog);
    if (event.type === "wolf_kill_vote_cast")
        recipients.push(...wolfKnifeHolders(world, catalog));
    return {
        ...event,
        audience: Object.freeze([...new Set(recipients)].sort((a, b) => a - b)),
    };
}
