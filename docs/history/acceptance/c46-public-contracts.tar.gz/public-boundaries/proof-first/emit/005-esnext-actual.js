import { refreshWolfKnifeInheritanceAtCheckpoint } from "../rulesets/wolf-knife-inheritance-plan";
import { AnimalDeathWavePreparation } from "../features/animal-dream/ports";
import { planDeathWave, openDeathWave, deathExecutionContext, deathWaveOriginalLives, deathWavePoisonMetadata, preflightDeathWaveData, DeathCommitReceipt, } from "./death-wave";
import { DeathCommitter } from "./death-committer";
import { FRAGRANT_PAIR_POLICY } from "@ai-werewolf-arena/game-contract/facts/fragrant-pair-seer";
import { FragrantDeathWavePublication, isFragrantPairBoard, commitFragrantDeathWave, publishFragrantDeathWave, cancelFragrantDeathWave, fragrantAuthoritySnapshot, } from "../features/fragrant-pair-seer/ports";
import { collectDeathShot } from "../rulesets/death-shot-selection";
import { prepareInitialDeathRelations } from "../rulesets/initial-death-relations";
import { WeddingDeathWavePublication } from "../features/ghost-bride/ports";
import { prepareAdditionalDeathRelations } from "../rulesets/additional-death-relations";
import { livingNightLife } from "../domain/night-effects";
import { COMPONENT } from "../domain/components/names";
import { Phase, Role, DeathCause, } from "../domain/model";
import { getDefaultLastWordsMechanism } from "../features/last-words/grant-ports";
import { LastWordsWindow } from "../features/last-words/window-ports";
import { resolveSheriffBadge } from "../features/sheriff/choice-ports";
import { GameActionRequestFactory } from "./actions/action-request-factory";
import { finishDeathGuns, } from "../features/death-actions/gift-gun-ports";
export class DeathResolution {
    world;
    events;
    toolGateway;
    eventRegistry;
    state;
    config;
    weddingDeathWave = (() => {
        const resolution = this;
        return new WeddingDeathWavePublication({
            get world() {
                return resolution.world;
            },
            get events() {
                return resolution.events;
            },
            get day() {
                return resolution.state.day;
            },
            get phase() {
                return resolution.state.phase;
            },
        });
    })();
    lastWordsMechanism = getDefaultLastWordsMechanism();
    lastWordsWindow = (() => {
        const resolution = this;
        return new LastWordsWindow({
            get requestFactory() { return GameActionRequestFactory; },
            get world() { return resolution.world; },
            get events() { return resolution.events; },
            get state() { return resolution.state; },
            get toolGateway() { return resolution.toolGateway; },
            get lastWordsMechanism() { return resolution.lastWordsMechanism; },
        });
    })();
    deathCommitter = (() => {
        const resolution = this;
        return new DeathCommitter({
            get world() {
                return resolution.world;
            },
            get events() {
                return resolution.events;
            },
            get state() {
                return resolution.state;
            },
        });
    })();
    fragrantDeathWave = (() => {
        const resolution = this;
        return new FragrantDeathWavePublication({
            actorId: () => resolution.world.getEntityIdsByRole(Role.FragrantPhantom)[0],
            get phase() {
                return resolution.state.phase;
            },
            get day() {
                return resolution.state.day;
            },
            get events() {
                return resolution.events;
            },
            publish(receipt, event) {
                publishFragrantDeathWave(resolution.world, receipt, event);
            },
        });
    })();
    constructor(world, events, toolGateway, eventRegistry, state, config) {
        this.world = world;
        this.events = events;
        this.toolGateway = toolGateway;
        this.eventRegistry = eventRegistry;
        this.state = state;
        this.config = config;
    }
    async resolve(deadIds, sources, actionProvider, phase, lastWordsPhase, deathPhases = {}, nightEffects) {
        const resolutionPhase = this.state.phase;
        const resolutionDay = this.state.day;
        const lastWordsPolicy = this.config?.lastWords?.policy ?? "awa_initial_wave_v1";
        const revealPolicy = this.config?.disclosure?.deathRevealPolicy ?? "awa_hidden_v1";
        const ownsFragrant = isFragrantPairBoard(this.world);
        const isCurrent = () => this.state.phase === resolutionPhase &&
            this.state.day === resolutionDay &&
            !this.state.gameOver &&
            (nightEffects?.isCurrent?.() ?? true) &&
            (!ownsFragrant || !!fragrantAuthoritySnapshot(this.world));
        const revealCurrent = () => revealPolicy === "netease_2017_open_v1" &&
            this.config?.disclosure?.deathRevealPolicy === revealPolicy;
        const lastWordsCurrent = () => isCurrent() && (this.config?.lastWords?.policy ?? "awa_initial_wave_v1") === lastWordsPolicy;
        const resolution = this;
        const animalDeathWave = AnimalDeathWavePreparation.fromRuntime({
            get world() {
                return resolution.world;
            },
            get events() {
                return resolution.events;
            },
        }, resolutionDay, nightEffects, isCurrent);
        const ownsAnimal = animalDeathWave.enabled;
        const preparedSources = structuredClone(sources);
        preflightDeathWaveData(deadIds, preparedSources, deathPhases);
        deadIds = animalDeathWave.prepare(deadIds, preparedSources, phase);
        const seen = new Set(deadIds.filter((id) => {
            return (this.world.getComponent(id, COMPONENT.Alive) !== undefined &&
                !this.deathCommitter.isSettledLife(id));
        }));
        let pending = [...seen];
        const allSources = preparedSources;
        const nativeHunterShotTargets = new Set();
        const initialPhases = structuredClone(deathPhases);
        const nightOrigin = new Set(nightEffects?.nightOriginIds ?? []);
        if (!isCurrent())
            return;
        const { fragrantInitial, originPhases } = prepareInitialDeathRelations({
            wedding: () => this.weddingDeathWave,
            world: () => this.world,
            events: () => this.events,
            phase: () => phase,
            resolutionDay: () => resolutionDay,
            ownsFragrant: () => ownsFragrant,
            dreams: () => nightEffects?.dreams,
        }, pending, allSources, seen, nightOrigin, initialPhases);
        const initialUnit = openDeathWave("initial", resolutionDay, resolutionPhase, deathExecutionContext(nightEffects));
        let pendingUnits = [initialUnit];
        let previousCommits = [];
        let firstBatch = true;
        let fragrantInitialCommitted = false;
        const gunsToExpire = [];
        try {
            if (pending.length === 0 && nightEffects?.onInitialWaveCommitted && isCurrent()) {
                const receipt = new DeathCommitReceipt(planDeathWave([], {}, "initial", originPhases, deathWaveOriginalLives(nightEffects), deathWavePoisonMetadata(nightEffects), pendingUnits), Object.freeze([]));
                const event = nightEffects.onInitialWaveCommitted([], {}, receipt);
                receipt.recordPublication(event, []);
            }
            while (pending.length > 0) {
                if (!isCurrent())
                    return;
                const deathPhase = firstBatch ? phase : this.state.phase;
                const receipt = this.deathCommitter.markPlayersDead(pending, true, gunsToExpire, revealPolicy === "netease_2017_open_v1", allSources, nightEffects?.animalUnit ?? isCurrent, planDeathWave(pending, allSources, firstBatch ? "initial" : "revisit", originPhases, deathWaveOriginalLives(nightEffects), deathWavePoisonMetadata(nightEffects), pendingUnits, previousCommits));
                if (firstBatch && fragrantInitial) {
                    commitFragrantDeathWave(this.world, fragrantInitial);
                    fragrantInitialCommitted = true;
                }
                if (ownsFragrant && firstBatch)
                    this.fragrantDeathWave.recordCommittedWave(firstBatch ? fragrantInitial : null, pending, allSources, originPhases, firstBatch);
                if (firstBatch && nightEffects?.onInitialWaveCommitted) {
                    const event = nightEffects.onInitialWaveCommitted(pending, allSources, receipt);
                    receipt.recordPublication(event, pending);
                    this.fragrantDeathWave.publishVisibleWave(fragrantInitial, event);
                }
                if (ownsAnimal && firstBatch)
                    animalDeathWave.recordInitialWave(pending, allSources, deathPhase);
                if (firstBatch &&
                    fragrantInitial?.addedTargetId !== null &&
                    fragrantInitial?.addedTargetId !== undefined) {
                    const event = {
                        timestamp: Date.now(),
                        type: "additional_deaths",
                        payload: { deaths: [fragrantInitial.addedTargetId] },
                    };
                    this.events.push(event);
                    receipt.recordPublication(event, [fragrantInitial.addedTargetId]);
                    this.fragrantDeathWave.publishVisibleWave(fragrantInitial, event);
                }
                this.eventRegistry.onCommittedDeathWave(this.world, pending, allSources, resolutionDay, deathPhase, this.events);
                nightEffects?.dreams?.recordDeaths(pending, this.events);
                if ((firstBatch || lastWordsPolicy === "netease_2017_day_and_first_night_v1") &&
                    lastWordsCurrent()) {
                    const wordsPhases = firstBatch
                        ? initialPhases
                        : Object.fromEntries(pending.map((id) => [id, nightOrigin.has(id) ? Phase.Night : deathPhase]));
                    const wordsContext = ownsFragrant
                        ? { policy: FRAGRANT_PAIR_POLICY, initialWave: firstBatch }
                        : undefined;
                    this.lastWordsMechanism.recordLastWordsGranted(this.world, pending, phase, lastWordsPhase, this.state.day, this.events, allSources, wordsPhases, lastWordsPolicy, wordsContext);
                    await this.lastWordsWindow.collect(pending, lastWordsPhase, phase, allSources, actionProvider, wordsPhases, lastWordsCurrent, lastWordsPolicy, wordsContext);
                }
                if (!isCurrent())
                    return;
                for (const deadId of pending) {
                    const causes = allSources[deadId] ?? [];
                    const actualDeathPhase = firstBatch ? (initialPhases[deadId] ?? deathPhase) : deathPhase;
                    const reason = causes.includes(DeathCause.SelfDestruct)
                        ? "self_destruct"
                        : causes.includes(DeathCause.Exile)
                            ? "voted_out"
                            : `${actualDeathPhase}_death`;
                    await resolveSheriffBadge(this.world, deadId, reason, this.events, this.toolGateway, actionProvider, resolutionPhase, resolutionDay, isCurrent, {
                        get requestFactory() { return GameActionRequestFactory; },
                    });
                    if (!isCurrent())
                        return;
                }
                const next = new Set();
                const nextCommits = [];
                const nextUnits = [];
                for (const deadId of pending) {
                    if (!isCurrent())
                        return;
                    const sourcePhase = originPhases.get(deadId) ?? (nightOrigin.has(deadId) ? Phase.Night : deathPhase);
                    const actions = {
                        phase: resolutionPhase,
                        day: resolutionDay,
                        permits: [],
                        isCurrent,
                    };
                    try {
                        await this.eventRegistry.onDeath(this.world, [deadId], allSources, (actorId, abilityId) => collectDeathShot({
                            get world() { return resolution.world; },
                            get events() { return resolution.events; },
                            get toolGateway() { return resolution.toolGateway; },
                            get state() { return resolution.state; },
                            get config() { return resolution.config; },
                        }, actorId, firstBatch ? (initialPhases[actorId] ?? deathPhase) : deathPhase, sourcePhase, allSources, actionProvider, actions, abilityId, nightOrigin.has(actorId) && !(firstBatch && initialPhases[actorId] === Phase.Day)), this.events, (result) => {
                            if (!isCurrent())
                                return;
                            const proposed = [...result.extraDeaths], proposedSources = structuredClone(result.extraDeathSources), nightTargets = [...(result.nightEffectTargets ?? [])];
                            preflightDeathWaveData(proposed, proposedSources);
                            preflightDeathWaveData(nightTargets, {});
                            const additionalUnit = openDeathWave("additional", resolutionDay, resolutionPhase, deathExecutionContext(nightEffects));
                            const shots = new Map((result.pendingShots ?? []).map((shot) => [shot.targetScope.id, shot]));
                            for (const [id, shot] of shots) {
                                if (livingNightLife(this.world, shot.targetScope) && (shot.isCurrent?.() ?? true))
                                    continue;
                                proposedSources[id] = (proposedSources[id] ?? []).filter((cause) => cause !== DeathCause.Shot);
                                if (!proposedSources[id].length) {
                                    const index = proposed.indexOf(id);
                                    if (index >= 0)
                                        proposed.splice(index, 1);
                                }
                                if (!proposedSources[id].length)
                                    for (let i = nightTargets.length - 1; i >= 0; i--)
                                        if (nightTargets[i] === id)
                                            nightTargets.splice(i, 1);
                                shots.delete(id);
                            }
                            const linked = new Set(), publicLinked = [];
                            let newlyMarked = false;
                            const marked = [];
                            const additionalReceipts = [];
                            const resolution = this;
                            const preparedContributions = (result.deathWaveContributions ?? []).map((contribution) => contribution.prepare({
                                get world() {
                                    return resolution.world;
                                },
                                get events() {
                                    return resolution.events;
                                },
                                blocksNightLinkedDeath: (target) => nightEffects?.dreams?.blocksNightCharm(this.world, target(), seen),
                            }, proposed, proposedSources, nightTargets, allSources, nativeHunterShotTargets, seen));
                            const contributedCauses = new Map();
                            const publicContributionTargets = new Set();
                            for (const contribution of preparedContributions)
                                for (const linkedDeath of contribution.linkedDeaths) {
                                    contributedCauses.set(linkedDeath.targetId, [
                                        ...new Set([
                                            ...(contributedCauses.get(linkedDeath.targetId) ?? []),
                                            ...linkedDeath.addedCauses,
                                        ]),
                                    ]);
                                    if (linkedDeath.publicAdditionalDeath)
                                        publicContributionTargets.add(linkedDeath.targetId);
                                }
                            const additionalRelations = prepareAdditionalDeathRelations({
                                world: () => this.world,
                                events: () => this.events,
                                wedding: () => this.weddingDeathWave,
                                dreams: () => nightEffects?.dreams,
                                isSettledLife: (id) => this.deathCommitter.isSettledLife(id),
                                phase: () => this.state.phase,
                            }, { proposed, proposedSources, nightTargets, allSources, next, seen, nightOrigin, linked, ownsFragrant, resolutionDay, sourcePhase });
                            const { fragrantGun } = additionalRelations;
                            let fragrantGunCommitted = false;
                            try {
                                for (const id of proposed) {
                                    if (next.has(id)) {
                                        allSources[id] = [
                                            ...new Set([...(allSources[id] ?? []), ...(proposedSources[id] ?? [])]),
                                        ];
                                        continue;
                                    }
                                    if (seen.has(id) || this.deathCommitter.isSettledLife(id)) {
                                        if ((proposedSources[id] ?? []).includes(DeathCause.Lovers))
                                            allSources[id] = [
                                                ...new Set([...(allSources[id] ?? []), DeathCause.Lovers]),
                                            ];
                                        if (linked.has(id))
                                            allSources[id] = [
                                                ...new Set([...(allSources[id] ?? []), DeathCause.Dream]),
                                            ];
                                        if (contributedCauses.has(id))
                                            allSources[id] = [
                                                ...new Set([...(allSources[id] ?? []), ...contributedCauses.get(id)]),
                                            ];
                                        continue;
                                    }
                                    if (!this.world.getComponent(id, COMPONENT.Alive))
                                        continue;
                                    if (ownsAnimal &&
                                        !animalDeathWave.prepare([id], proposedSources, sourcePhase).includes(id))
                                        continue;
                                    let shot = shots.get(id);
                                    if (shot &&
                                        (!livingNightLife(this.world, shot.targetScope) ||
                                            (!fragrantGun && shot.isCurrent?.() === false))) {
                                        proposedSources[id] = (proposedSources[id] ?? []).filter((cause) => cause !== DeathCause.Shot);
                                        shots.delete(id);
                                        shot = undefined;
                                        if (!proposedSources[id].length)
                                            continue;
                                    }
                                    seen.add(id);
                                    allSources[id] = [...new Set(proposedSources[id] ?? [])];
                                    originPhases.set(id, additionalRelations.originPhase());
                                    const commitIds = [id];
                                    const receipt = this.deathCommitter.markPlayersDead(commitIds, false, gunsToExpire, revealCurrent(), allSources, nightEffects?.animalUnit ?? isCurrent, planDeathWave(commitIds, allSources, "additional", originPhases, shot ? new Map([[id, shot.targetScope]]) : undefined, [], [additionalUnit]));
                                    additionalReceipts.push(receipt);
                                    nextCommits.push(receipt);
                                    if (ownsAnimal)
                                        animalDeathWave.recordAdditionalDeath(id, allSources, sourcePhase);
                                    newlyMarked = true;
                                    marked.push(id);
                                    if (shot) {
                                        if (shot.event.type === "hunter_shot")
                                            nativeHunterShotTargets.add(id);
                                        this.events.push(shot.event);
                                        receipt.recordPublication(shot.event, [id]);
                                    }
                                    if (publicContributionTargets.has(id) ||
                                        (linked.has(id) && !result.extraDeaths.includes(id)) ||
                                        (!shot && !(proposedSources[id] ?? []).includes(DeathCause.Shot)))
                                        publicLinked.push(id);
                                    next.add(id);
                                }
                                if (newlyMarked) {
                                    nextUnits.push(additionalUnit);
                                    if (fragrantGun) {
                                        commitFragrantDeathWave(this.world, fragrantGun);
                                        fragrantGunCommitted = true;
                                    }
                                    if (ownsFragrant)
                                        this.fragrantDeathWave.recordCommittedWave(fragrantGun, marked, allSources, originPhases, false);
                                    refreshWolfKnifeInheritanceAtCheckpoint({
                                        world: () => this.world,
                                        events: () => this.events,
                                        day: () => this.state.day,
                                    });
                                }
                                if (publicLinked.length) {
                                    const event = {
                                        timestamp: Date.now(),
                                        type: "additional_deaths",
                                        payload: { deaths: publicLinked },
                                    };
                                    this.events.push(event);
                                    for (const receipt of additionalReceipts)
                                        receipt.recordPublication(event, publicLinked.filter((id) => receipt.committed(id) !== undefined));
                                    this.fragrantDeathWave.publishVisibleWave(fragrantGun, event);
                                }
                                for (const contribution of preparedContributions)
                                    contribution.publishAfterDeaths();
                                nightEffects?.dreams?.recordDeaths([...next, ...linked], this.events);
                                for (const permit of actions.permits.splice(0))
                                    permit.close();
                            }
                            finally {
                                if (fragrantGun && !fragrantGunCommitted)
                                    cancelFragrantDeathWave(this.world, fragrantGun);
                            }
                        }, Object.freeze({
                            day: resolutionDay,
                            nativeHunterShotTargets,
                            deferShotCommit: true,
                            deathOriginPhase: sourcePhase,
                            nightEffect: nightOrigin.has(deadId),
                            blocksNightShot: (targetId) => (nightEffects?.blocksPassiveNightShot?.(targetId) ?? false) ||
                                (nightEffects?.dreams?.blocksNightShot(this.world, targetId) ?? false),
                            blocksNightCharm: (targetId) => nightEffects?.dreams?.blocksNightCharm(this.world, targetId, seen) ?? false,
                            eligibleDead: seen,
                            isCurrent,
                        }));
                    }
                    finally {
                        for (const permit of actions.permits)
                            permit.close();
                    }
                }
                pending = [...next];
                pendingUnits = nextUnits;
                previousCommits = nextCommits;
                firstBatch = false;
            }
        }
        finally {
            if (fragrantInitial && !fragrantInitialCommitted)
                cancelFragrantDeathWave(this.world, fragrantInitial);
            finishDeathGuns(gunsToExpire, this.events);
        }
    }
}
