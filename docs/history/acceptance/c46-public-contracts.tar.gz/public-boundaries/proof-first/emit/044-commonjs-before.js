"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MIRROR_GIRL_ROLE_PROFILE = exports.freshMirrorInspectionState = void 0;
const role_inspection_policy_1 = require("@ai-werewolf-arena/game-contract/role-inspection-policy");
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const contribution_ports_1 = require("../role-inspection/contribution-ports");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const ports_1 = require("../role-inspection/ports");
const abilities_1 = require("../night-abilities/abilities");
const helpers_1 = require("../../agents/tool-repair/helpers");
const contribution_ports_2 = require("../role-inspection/contribution-ports");
const contribution_ports_3 = require("../role-inspection/contribution-ports");
const native_inspection_1 = require("./native-inspection");
var native_inspection_2 = require("./native-inspection");
Object.defineProperty(exports, "freshMirrorInspectionState", { enumerable: true, get: function () { return native_inspection_2.freshMirrorInspectionState; } });
exports.MIRROR_GIRL_ROLE_PROFILE = {
    metadata: {
        role: model_1.Role.MirrorGirl,
        camp: model_1.Camp.Good,
        goodSide: "god",
        maxCount: 1,
        label: (0, game_text_1.roleName)("mirror_girl"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.mirror_girl.brief"),
        supportedBoardRoles: [
            model_1.Role.CursedFox,
            model_1.Role.MirrorGirl,
            model_1.Role.AwakenedHiddenWolf,
            model_1.Role.Wolf,
            model_1.Role.WolfKing,
            model_1.Role.HiddenWolf,
            model_1.Role.Gargoyle,
            model_1.Role.Psychic,
            model_1.Role.Seer,
            model_1.Role.Witch,
            model_1.Role.Guard,
            model_1.Role.Hunter,
            model_1.Role.Idiot,
            model_1.Role.Villager,
        ],
    },
    runtime: {
        init: (role, ctx) => {
            const native = (0, native_inspection_1.nativeMirror)(role);
            if (native?.kind === "role_check" && (0, role_inspection_policy_1.roleInspectionPolicy)(native.state) !== "mirror")
                throw new Error("mirror_native_policy_invalid");
            if (!native && !(0, abilities_1.retiredNightAbilityIds)(role).some((id) => id.startsWith("native:role_check")))
                (0, ports_1.setRoleInspectionState)(role, {
                    ...(0, native_inspection_1.freshMirrorInspectionState)(),
                    ...(ctx.boardConfig?.mirrorGirl?.inspectionPolicy &&
                        ctx.boardConfig.mirrorGirl.inspectionPolicy !== "awa_unique_optional_v1"
                        ? { inspectionPolicy: ctx.boardConfig.mirrorGirl.inspectionPolicy }
                        : {}),
                });
        },
        configuration: (0, contribution_ports_1.inspectionConfiguration)("mirrorGirl", "awa_unique_optional_v1"),
        toolSpecs: [contribution_ports_3.ROLE_INSPECTION_TOOL],
        validationRules: { inspect_role: contribution_ports_3.validateRoleInspection },
        nightStages: [contribution_ports_2.MIRROR_INSPECTION_STAGE],
        possibleNightAbilities: ["role_check"],
        llmRepair: {
            coerce: {
                inspect_role: (args) => {
                    const target = (0, helpers_1.numberOrNull)(args.target_id);
                    return target === null ? null : { target_id: target };
                },
            },
        },
        baselineAction: (role, request, _pick, _byCamp, _locale, world) => {
            if (!world || !request.allowedTools.includes("inspect_role"))
                return null;
            const ability = (0, abilities_1.findNightAbility)(role, "role_check", request.context.ability_id), target = ability
                ? (0, contribution_ports_3.roleInspectionTargets)(world, request.actorId, ability.state)[0]
                : undefined;
            return target === undefined ? null : { name: "inspect_role", args: { target_id: target } };
        },
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("mirror_girl"),
};
