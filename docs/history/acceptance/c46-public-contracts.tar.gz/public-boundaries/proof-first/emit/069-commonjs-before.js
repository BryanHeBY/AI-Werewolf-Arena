"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWolfKingState = void 0;
var native_death_gun_resources_1 = require("../death-actions/native-death-gun-resources");
Object.defineProperty(exports, "getWolfKingState", { enumerable: true, get: function () { return native_death_gun_resources_1.getWolfKingState; } });
