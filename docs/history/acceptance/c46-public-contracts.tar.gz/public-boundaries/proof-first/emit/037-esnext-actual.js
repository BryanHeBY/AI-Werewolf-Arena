import { Role, permitsDeathShot } from "../../domain/model";
import { resolveNativeDeathShots } from "../death-actions/settlement-ports";
import { getMechanicalState } from "./state";
import { createMechanicalGunReader } from "../death-actions/native-resource-ports";
export const mechanicalDeathHook = (world, ids, sources, choose, events, context) => {
    const readGun = createMechanicalGunReader({ get getMechanicalState() { return getMechanicalState; } });
    return resolveNativeDeathShots(world, ids, sources, choose, events, {
        role: Role.MechanicalWolf,
        state: readGun,
        permits: permitsDeathShot,
        shotEvent: (actorId, targetId) => ({
            timestamp: Date.now(),
            type: "mechanical_shot",
            payload: { actorId, targetId },
        }),
    }, context);
};
