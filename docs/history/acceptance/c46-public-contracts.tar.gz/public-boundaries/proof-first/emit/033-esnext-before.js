import { Role, permitsHunterShot } from "../../domain/model";
import { getHunterState } from "../death-actions/native-death-gun-resources";
import { openDemonHunterStockFrame } from "../demon-hunter/native-gun-ports";
import { resolveNativeDeathShots } from "../death-actions/native-death-shot-settlement";
export const hunterDeathHook = (world, ids, sources, choose, events, context) => resolveNativeDeathShots(world, ids, sources, choose, events, {
    role: Role.Hunter,
    state: getHunterState,
    get openHunterStock() { return openDemonHunterStockFrame; },
    permits: (sources) => permitsHunterShot(sources),
    policy: (state) => state.deathActionPolicy ?? "awa_qualified_sources_v1",
    poisonEvent: (hunterId) => ({
        timestamp: Date.now(),
        type: "hunter_silent_due_to_poison",
        payload: { hunterId },
    }),
    shotEvent: (hunterId, targetId) => ({
        timestamp: Date.now(),
        type: "hunter_shot",
        payload: { hunterId, targetId },
    }),
}, context);
