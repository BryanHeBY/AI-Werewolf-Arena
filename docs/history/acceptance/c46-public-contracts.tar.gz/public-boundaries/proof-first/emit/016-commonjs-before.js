"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AWAKENED_HIDDEN_WOLF_ROLE_PROFILE = void 0;
const names_1 = require("../../domain/components/names");
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const zod_1 = require("zod");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const ability_ports_1 = require("../wolf/ability-ports");
const death_shot_1 = require("../death-actions/death-shot");
const contribution_ports_1 = require("../role-inspection/contribution-ports");
const abilities_1 = require("../night-abilities/abilities");
const helpers_1 = require("../../agents/tool-repair/helpers");
const inheritance_1 = require("./inheritance");
const death_hook_1 = require("./death-hook");
const night_stages_1 = require("./night-stages");
const tool_specs_1 = require("./tool-specs");
const rules_1 = require("./rules");
const state_1 = require("./state");
exports.AWAKENED_HIDDEN_WOLF_ROLE_PROFILE = {
    metadata: {
        ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.metadata,
        role: model_1.Role.AwakenedHiddenWolf,
        camp: model_1.Camp.Wolf,
        maxCount: 1,
        supportedBoardRoles: [
            model_1.Role.AwakenedHiddenWolf,
            model_1.Role.Wolf,
            model_1.Role.MirrorGirl,
            model_1.Role.Witch,
            model_1.Role.Hunter,
            model_1.Role.Guard,
            model_1.Role.Villager,
        ],
        label: (0, game_text_1.roleName)("awakened_hidden_wolf"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.awakened_hidden_wolf.brief"),
    },
    runtime: {
        ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime,
        canSelfDestruct: false,
        init: (role) => {
            if (!(0, state_1.getAwakenedState)(role))
                (0, state_1.setAwakenedState)(role, (0, state_1.freshAwakenedState)());
        },
        wolfTeam: (role, world, currentCamp) => ({
            recognizedByPack: false,
            recognizes: "none",
            canChat: false,
            canVoteForKill: (0, inheritance_1.canAwakenedKnife)(role, world, currentCamp),
        }),
        inspectionLabels: (role) => ({
            camp: model_1.Camp.Wolf,
            role: (0, state_1.getAwakenedState)(role)?.learned?.role ?? model_1.Role.AwakenedHiddenWolf,
        }),
        configuration: {
            schema: zod_1.z.strictObject({}),
            defaults: {},
            apply: (config) => config,
            serialize: () => ({}),
        },
        possibleNightAbilities: ["role_check"],
        toolSpecs: [
            ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.toolSpecs.filter((spec) => spec.name === "kill_vote"),
            ...tool_specs_1.AWAKENED_TOOL_SPECS,
            contribution_ports_1.ROLE_INSPECTION_TOOL,
            ...death_shot_1.DEATH_SHOT_TOOL_SPECS,
        ],
        nightStages: [...night_stages_1.AWAKENED_NIGHT_STAGES, ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.nightStages],
        validationRules: {
            ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.validationRules,
            ...rules_1.AWAKENED_VALIDATION_RULES,
            inspect_role: contribution_ports_1.validateRoleInspection,
            shoot: (ctx) => {
                const learned = (0, state_1.getAwakenedState)(ctx.role)?.learned, gun = learned?.skill;
                return (0, death_shot_1.validateDeathShot)(ctx, ctx.role.role === model_1.Role.AwakenedHiddenWolf &&
                    ctx.world.getComponent(ctx.actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Wolf &&
                    learned?.role === model_1.Role.Hunter &&
                    learned.activationNight != null &&
                    gun?.kind === "hunter" &&
                    gun.armed &&
                    gun.canShoot);
            },
        },
        deathHook: death_hook_1.awakenedDeathHook,
        llmRepair: {
            coerce: {
                ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.llmRepair?.coerce,
                ...death_shot_1.DEATH_SHOT_REPAIR.coerce,
                ...Object.fromEntries([...rules_1.AWAKENED_TOOL_NAMES, "inspect_role"].map((name) => [
                    name,
                    (args) => {
                        if (args.target_id === null && ["awakened_guard", "awakened_attack"].includes(name))
                            return { target_id: null };
                        const target = (0, helpers_1.numberOrNull)(args.target_id);
                        return target === null ? null : { target_id: target };
                    },
                ])),
            },
        },
        baselineAction: (role, request, pick, byCamp, locale, world, currentCamp) => {
            if (request.allowedTools.includes("awakened_mimic")) {
                const target = pick();
                return target === null ? null : { name: "awakened_mimic", args: { target_id: target } };
            }
            if (request.allowedTools.includes("awakened_poison")) {
                const target = byCamp("good");
                return target === null ? null : { name: "awakened_poison", args: { target_id: target } };
            }
            if (request.allowedTools.includes("awakened_guard"))
                return { name: "awakened_guard", args: { target_id: null } };
            if (request.allowedTools.includes("awakened_attack"))
                return { name: "awakened_attack", args: { target_id: byCamp("good") } };
            if (request.allowedTools.includes("inspect_role")) {
                const ability = (0, abilities_1.findNightAbility)(role, "role_check", request.context.ability_id), target = world && ability
                    ? (0, contribution_ports_1.roleInspectionTargets)(world, request.actorId, ability.state)[0]
                    : undefined;
                return target === undefined ? null : { name: "inspect_role", args: { target_id: target } };
            }
            if (request.allowedTools.includes("shoot"))
                return { name: "shoot", args: { target_id: byCamp("good") } };
            return ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.baselineAction(role, request, pick, byCamp, locale, world, currentCamp);
        },
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("awakened_hidden_wolf"),
};
