"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.installNativeAbility = installNativeAbility;
const model_1 = require("../../domain/model");
const abilities_1 = require("./abilities");
const ports_1 = require("../dreamer/ports");
const shelter_slot_ports_1 = require("../radiant-eclipse/shelter-slot-ports");
const ports_2 = require("../seer/ports");
const ports_3 = require("../guard/ports");
const ports_4 = require("../witch/ports");
const ports_5 = require("../role-inspection/ports");
function installNativeAbility(role, kind, state, mayCommit) {
    if (kind === "pair_check" && role.role !== model_1.Role.AwakenedSeer)
        throw Error("ability_pair_native_role_invalid");
    const ownedState = (kind === "pair_check"
        ? (0, abilities_1.copyAbilityData)((0, abilities_1.projectPairState)(state))
        : kind === "role_check"
            ? ports_5.ROLE_INSPECTION_STATE_SLOT.create(state)
            : kind === "seer_check"
                ? ports_2.SEER_STATE_SLOT.create(state)
                : kind === "guard"
                    ? ports_3.GUARD_STATE_SLOT.create(state)
                    : kind === "potion"
                        ? ports_4.WITCH_STATE_SLOT.create(state)
                        : kind === "dream"
                            ? ports_1.DREAMER_STATE_SLOT.create(state)
                            : kind === "shelter"
                                ? shelter_slot_ports_1.SHELTER_STATE_SLOT.prepare(state)
                                : (0, abilities_1.copyAbilityData)(state));
    return mayCommit
        ? (0, abilities_1.commitPreparedNativeAbility)(role, kind, ownedState, mayCommit)
        : (0, abilities_1.commitPreparedNativeAbility)(role, kind, ownedState);
}
