"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MECHANICAL_WOLF_ROLE_PROFILE = void 0;
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const zod_1 = require("zod");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const ability_ports_1 = require("../wolf/ability-ports");
const death_shot_1 = require("../death-actions/death-shot");
const helpers_1 = require("../../agents/tool-repair/helpers");
const inheritance_1 = require("./inheritance");
const death_hook_1 = require("./death-hook");
const night_stages_1 = require("./night-stages");
const tool_specs_1 = require("./tool-specs");
const rules_1 = require("./rules");
const state_1 = require("./state");
exports.MECHANICAL_WOLF_ROLE_PROFILE = {
    metadata: {
        ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.metadata,
        role: model_1.Role.MechanicalWolf,
        camp: model_1.Camp.Wolf,
        maxCount: 1,
        supportedBoardRoles: [
            model_1.Role.Wolf,
            model_1.Role.Psychic,
            model_1.Role.Witch,
            model_1.Role.Hunter,
            model_1.Role.Guard,
            model_1.Role.Villager,
            model_1.Role.MechanicalWolf,
        ],
        label: (0, game_text_1.roleName)("mechanical_wolf"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.mechanical_wolf.brief"),
    },
    runtime: {
        ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime,
        canSelfDestruct: false,
        init: (role) => {
            if (!(0, state_1.getMechanicalState)(role))
                (0, state_1.setMechanicalState)(role, (0, state_1.freshMechanicalState)());
        },
        wolfTeam: (role, world, currentCamp) => ({
            recognizedByPack: false,
            recognizes: "none",
            canChat: false,
            canVoteForKill: (0, inheritance_1.canMechanicalKnife)(role, world, currentCamp),
        }),
        inspectionLabels: (role) => ({
            camp: model_1.Camp.Wolf,
            role: (0, state_1.getMechanicalState)(role)?.learned?.role ?? model_1.Role.MechanicalWolf,
        }),
        configuration: {
            schema: zod_1.z.strictObject({}),
            defaults: {},
            apply: (config) => config,
            serialize: () => ({}),
        },
        toolSpecs: [
            ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.toolSpecs.filter((spec) => spec.name === "kill_vote"),
            ...tool_specs_1.MECHANICAL_TOOL_SPECS,
            ...death_shot_1.DEATH_SHOT_TOOL_SPECS,
        ],
        nightStages: [...night_stages_1.MECHANICAL_NIGHT_STAGES, ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.nightStages],
        validationRules: {
            ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.validationRules,
            ...rules_1.MECHANICAL_VALIDATION_RULES,
            shoot: (ctx) => {
                const skill = (0, state_1.getMechanicalState)(ctx.role)?.learned?.skill;
                return (0, death_shot_1.validateDeathShot)(ctx, ctx.role.role === model_1.Role.MechanicalWolf &&
                    skill?.kind === "hunter" &&
                    skill.armed &&
                    skill.canShoot);
            },
        },
        deathHook: death_hook_1.mechanicalDeathHook,
        llmRepair: {
            coerce: {
                ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.llmRepair?.coerce,
                ...death_shot_1.DEATH_SHOT_REPAIR.coerce,
                ...Object.fromEntries([
                    "mimic_role",
                    "mechanical_inspect",
                    "mechanical_poison",
                    "mechanical_guard",
                    "mechanical_attack",
                ].map((name) => [
                    name,
                    (args) => {
                        if (args.target_id === null &&
                            ["mechanical_guard", "mechanical_attack"].includes(name))
                            return { target_id: null };
                        const target = (0, helpers_1.numberOrNull)(args.target_id);
                        return target === null ? null : { target_id: target };
                    },
                ])),
            },
        },
        baselineAction: (role, request, pick, byCamp, locale, world, currentCamp) => {
            if (request.allowedTools.includes("mechanical_mode")) {
                const state = (0, state_1.getMechanicalState)(role);
                return {
                    name: "mechanical_mode",
                    args: {
                        mode: state?.hasInheritedKnife &&
                            state.firstKnifeNight !== null &&
                            state.firstKnifeNight <= request.context.day
                            ? "kill"
                            : "skill",
                    },
                };
            }
            if (request.allowedTools.includes("mimic_role")) {
                const target = pick();
                return target === null ? null : { name: "mimic_role", args: { target_id: target } };
            }
            if (request.allowedTools.includes("mechanical_inspect")) {
                const target = pick();
                return target === null ? null : { name: "mechanical_inspect", args: { target_id: target } };
            }
            if (request.allowedTools.includes("mechanical_poison")) {
                const target = byCamp("good");
                return target === null ? null : { name: "mechanical_poison", args: { target_id: target } };
            }
            if (request.allowedTools.includes("mechanical_guard"))
                return { name: "mechanical_guard", args: { target_id: pick() } };
            if (request.allowedTools.includes("mechanical_attack"))
                return { name: "mechanical_attack", args: { target_id: byCamp("good") } };
            if (request.allowedTools.includes("shoot"))
                return { name: "shoot", args: { target_id: byCamp("good") } };
            return ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.baselineAction(role, request, pick, byCamp, locale, world, currentCamp);
        },
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("mechanical_wolf"),
};
