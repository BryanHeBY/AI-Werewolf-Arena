export { getHunterState, setHunterState } from "../death-actions/native-death-gun-resources";
