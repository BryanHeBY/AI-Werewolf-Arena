"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SEER_STATE_SLOT = void 0;
exports.setSeerState = setSeerState;
exports.getSeerState = getSeerState;
exports.recordSeerInspection = recordSeerInspection;
exports.recordRecipientSeerInspection = recordRecipientSeerInspection;
const abilities_1 = require("../night-abilities/abilities");
const abilities_2 = require("../night-abilities/abilities");
function setSeerState(roleComp, state) {
    return (0, abilities_2.commitPreparedNativeAbility)(roleComp, "seer_check", exports.SEER_STATE_SLOT.create(state));
}
function getSeerState(roleComp, abilityId) {
    return (0, abilities_1.findNightAbility)(roleComp, "seer_check", abilityId)?.state;
}
function recordSeerInspection(state, targetId, isWerewolf, inspection) {
    state.lastTarget = targetId;
    state.lastIsWerewolf = isWerewolf;
    state.lastResult = { ...inspection };
    state.history.push({ targetId, isWerewolf, result: { ...inspection } });
}
function recordRecipientSeerInspection(ability, target, isWerewolf, result) {
    ability.state.lastTarget = target.id;
    ability.state.lastIsWerewolf = isWerewolf;
    ability.state.lastResult = { ...result };
    ability.state.history.push({
        targetId: target.id,
        isWerewolf,
        result: { ...result },
    });
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.targetPolicy, ability.state.actionPolicy]);
}
exports.SEER_STATE_SLOT = Object.freeze({
    create: (abilities_1.copyAbilityData),
    schema: (abilities_1.copyAbilityData),
    install: setSeerState,
    get: getSeerState,
    allowedWrites: Object.freeze({
        recordSeerInspection,
        recordRecipientSeerInspection,
    }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
