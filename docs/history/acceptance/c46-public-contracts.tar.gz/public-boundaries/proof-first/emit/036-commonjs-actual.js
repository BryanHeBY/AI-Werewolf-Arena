"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HUNTER_TOOL_SPECS = void 0;
var tool_ports_1 = require("../death-actions/tool-ports");
Object.defineProperty(exports, "HUNTER_TOOL_SPECS", { enumerable: true, get: function () { return tool_ports_1.DEATH_SHOT_TOOL_SPECS; } });
