"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.captureAwakenedOwner = captureAwakenedOwner;
exports.bindAwakenedSkill = bindAwakenedSkill;
exports.captureAwakenedMirrorScope = captureAwakenedMirrorScope;
exports.beginAwakenedNight = beginAwakenedNight;
exports.currentAwakenedNight = currentAwakenedNight;
exports.recordAwakenedNightCommit = recordAwakenedNightCommit;
exports.hasAwakenedNightCommit = hasAwakenedNightCommit;
const alive_1 = require("../../domain/components/alive");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const night_effects_1 = require("../../domain/night-effects");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const state_1 = require("./state");
const abilities_1 = require("../night-abilities/abilities");
function captureAwakenedOwner(world, actorId, phaseCurrent) {
    const role = world.getComponent(actorId, names_1.COMPONENT.Role), state = (0, state_1.getAwakenedState)(role), life = (0, night_effects_1.captureNightLife)(world, actorId);
    if (!phaseCurrent() ||
        !role ||
        role.role !== model_1.Role.AwakenedHiddenWolf ||
        world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Wolf ||
        !state ||
        !life)
        return null;
    const privateState = role.privateState;
    return {
        world,
        actorId,
        role,
        state,
        life,
        canAct: () => !(0, role_execution_authority_1.isRoleExecutionRetired)(role),
        isCurrent: (allowFirstDeath = false) => {
            const original = world.getComponent(actorId, names_1.COMPONENT.Alive) === life.life &&
                (0, alive_1.aliveLifeVersion)(life.life) ===
                    life.version + (allowFirstDeath && !life.life.alive ? 1 : 0);
            return (phaseCurrent() &&
                world.getComponent(actorId, names_1.COMPONENT.Role) === role &&
                role.role === model_1.Role.AwakenedHiddenWolf &&
                world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Wolf &&
                role.privateState === privateState &&
                (0, state_1.getAwakenedState)(role) === state &&
                original &&
                (allowFirstDeath || life.life.alive));
        },
    };
}
function bindAwakenedSkill(owner, day) {
    const learned = owner.state.learned, skill = (0, state_1.awakenedSkillForNight)(owner.state, day);
    if (!owner.isCurrent() ||
        !learned ||
        !skill ||
        learned.activationNight === null ||
        learned.activeFromNight === null)
        return null;
    const { targetId, role, day: learnedDay, activationNight, activeFromNight } = learned, kind = skill.kind;
    return {
        skill,
        isCurrent: (allowFirstDeath = false) => owner.isCurrent(allowFirstDeath) &&
            owner.state.learned === learned &&
            learned.skill === skill &&
            skill.kind === kind &&
            learned.targetId === targetId &&
            learned.role === role &&
            learned.day === learnedDay &&
            learned.activationNight === activationNight &&
            learned.activeFromNight === activeFromNight,
    };
}
function captureAwakenedMirrorScope(world, actorId, ability, day, phaseCurrent) {
    const owner = captureAwakenedOwner(world, actorId, phaseCurrent), learned = owner?.state.learned, skill = learned?.skill;
    if (!owner ||
        currentAwakenedNight(world, owner.role) !== day ||
        !learned ||
        learned.role !== model_1.Role.MirrorGirl ||
        learned.activationNight === null ||
        learned.activeFromNight === null ||
        day < learned.activeFromNight ||
        skill?.kind !== "inspection" ||
        skill.abilityId !== ability.id)
        return null;
    const { targetId, role, day: learnedDay, activationNight, activeFromNight } = learned, abilityId = skill.abilityId;
    return () => owner.isCurrent() &&
        currentAwakenedNight(world, owner.role) === day &&
        owner.state.learned === learned &&
        learned.skill === skill &&
        skill.kind === "inspection" &&
        skill.abilityId === abilityId &&
        learned.targetId === targetId &&
        learned.role === role &&
        learned.day === learnedDay &&
        learned.activationNight === activationNight &&
        learned.activeFromNight === activeFromNight &&
        (0, abilities_1.findNightAbility)(owner.role, "role_check", abilityId) === ability;
}
const nights = new WeakMap();
const committed = new WeakMap();
function beginAwakenedNight(world, day, owners) {
    if (hasAwakenedNightCommit(world, day))
        throw new Error("awakened_night_reentry_after_commit");
    if (nights.get(world)?.day === day)
        throw new Error("awakened_night_reentry_after_commit");
    if ((nights.get(world)?.day ?? day) > day)
        throw new Error("awakened_night_clock_regressed");
    const currentOwners = owners.filter((owner) => owner.world === world && owner.isCurrent() && owner.canAct());
    nights.set(world, { day, owners: new Map(currentOwners.map((owner) => [owner.role, owner])) });
    if (currentOwners.length)
        recordAwakenedNightCommit(world, day);
}
function currentAwakenedNight(world, role) {
    const night = nights.get(world), owner = night?.owners.get(role);
    return night && owner?.isCurrent() && (0, night_effects_1.livingNightLife)(world, owner.life) ? night.day : null;
}
function recordAwakenedNightCommit(world, day) {
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
function hasAwakenedNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
