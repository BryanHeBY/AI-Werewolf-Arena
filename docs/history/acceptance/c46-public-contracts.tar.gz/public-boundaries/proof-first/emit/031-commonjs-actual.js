"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GUARD_ROLE_PROFILE = void 0;
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const guard_tool_admission_1 = require("../../rulesets/guard-tool-admission");
const zod_1 = require("zod");
const board_1 = require("../../domain/board");
const ports_1 = require("./ports");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const ports_2 = require("./ports");
const helpers_1 = require("../../agents/tool-repair/helpers");
const night_stages_1 = require("./night-stages");
const tool_specs_1 = require("./tool-specs");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const history_ports_1 = require("../night-abilities/history-ports");
const parameters = zod_1.z.strictObject({
    repeatPolicy: zod_1.z.enum(board_1.GUARD_REPEAT_POLICIES).default("awa_last_action_v1"),
});
exports.GUARD_ROLE_PROFILE = {
    metadata: {
        role: model_1.Role.Guard,
        camp: model_1.Camp.Good,
        label: (0, game_text_1.roleName)("guard"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.guard.brief"),
        goodSide: "god",
    },
    runtime: {
        configuration: {
            schema: parameters,
            defaults: { repeatPolicy: "awa_last_action_v1" },
            apply: (config, value) => ({ ...config, guard: parameters.parse(value) }),
            serialize: (config) => parameters.parse(config.guard ?? {}),
        },
        init: (roleComp, ctx) => {
            (0, ports_2.setGuardState)(roleComp, {
                lastTarget: null,
                ...(ctx.boardConfig?.guard?.repeatPolicy === "netease_consecutive_nights_v1"
                    ? { repeatPolicy: ctx.boardConfig.guard.repeatPolicy }
                    : {}),
            });
        },
        toolSpecs: tool_specs_1.GUARD_TOOL_SPECS,
        validationRules: guard_tool_admission_1.GUARD_VALIDATION_RULES,
        nightStages: night_stages_1.GUARD_NIGHT_STAGES,
        llmRepair: {
            coerce: {
                guard: (args) => {
                    const abstain = Boolean(args.abstain);
                    if (abstain)
                        return { target_id: null, abstain: true };
                    const target = (0, helpers_1.numberOrNull)(args.target_id);
                    return target === null ? null : { target_id: target, abstain: false };
                },
            },
        },
        baselineAction: (roleComp, request, pickAliveNotSelf, _byCamp, _locale, world) => {
            if (!request.allowedTools.includes("guard")) {
                return null;
            }
            const ability = (0, inventory_ports_1.activeNightAbility)(roleComp, "guard", request.context.day, request.context.ability_id);
            const target = world && ability
                ? (world
                    .getAliveEntityIds()
                    .find((id) => id !== request.actorId &&
                    !(0, ports_1.guardTargetRepeated)(ability, request.context.day, id) &&
                    (0, history_ports_1.luckyTargetAllowed)(world, request.actorId, ability, request.context.day, "guard", id)) ?? null)
                : pickAliveNotSelf();
            if (target !== null &&
                ability &&
                !(0, ports_1.guardTargetRepeated)(ability, request.context.day, target)) {
                return { name: "guard", args: { target_id: target, abstain: false } };
            }
            return { name: "guard", args: { target_id: null, abstain: true } };
        },
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("guard"),
};
