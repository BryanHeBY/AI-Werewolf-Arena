import { COMPONENT } from "../domain";
import { getDefaultRoleCatalog } from "../rulesets/roles/role-catalog-assembly";
import { debateVoteBlocked } from "../features/debater/vote-ports";
export function canVoteExile(world, id, day, catalog) {
    return canVote(world, id, catalog) && !debateVoteBlocked(world, id, day);
}
export function canBeExiled(world, id, catalog = getDefaultRoleCatalog()) {
    const role = world.getComponent(id, COMPONENT.Role);
    return (world.getComponent(id, COMPONENT.Alive)?.alive === true &&
        role !== undefined &&
        catalog.participation(role).canBeExiled);
}
export function canVote(world, id, catalog = getDefaultRoleCatalog()) {
    const role = world.getComponent(id, COMPONENT.Role);
    return (world.getComponent(id, COMPONENT.Alive)?.alive === true &&
        role !== undefined &&
        catalog.participation(role).canVote &&
        world.getComponent(id, COMPONENT.VotingRight)?.canVote === true);
}
export function canBeSheriff(world, id, catalog = getDefaultRoleCatalog()) {
    const role = world.getComponent(id, COMPONENT.Role);
    return (canVote(world, id, catalog) && role !== undefined && catalog.participation(role).canBeSheriff);
}
