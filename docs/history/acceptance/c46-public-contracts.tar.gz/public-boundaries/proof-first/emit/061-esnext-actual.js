import { nativeRolePresentation } from "../../rulesets/roles/presentation-contribution";
import { SEER_VALIDATION_RULES } from "../../rulesets/seer-tool-admission";
import { z } from "zod";
import { SEER_TARGET_POLICIES, SEER_ACTION_POLICIES, DEFAULT_SEER_ACTION_POLICY, } from "../../domain/board";
import { seerTargetAllowed } from "./ports";
import { roleName, text } from "@ai-werewolf-arena/game-text";
import { Camp, Role } from "../../domain/model";
import { setSeerState } from "./ports";
import { numberOrNull } from "../../agents/tool-repair/helpers";
import { SEER_NIGHT_STAGES } from "./night-stages";
import { SEER_TOOL_SPECS } from "./tool-specs";
import { activeNightAbility } from "../night-abilities/inventory-ports";
import { luckyTargetAllowed } from "../night-abilities/history-ports";
const parameters = z.strictObject({
    targetPolicy: z.enum(SEER_TARGET_POLICIES).default("awa_alive_v1"),
    actionPolicy: z.enum(SEER_ACTION_POLICIES).default(DEFAULT_SEER_ACTION_POLICY),
});
export const SEER_ROLE_PROFILE = {
    metadata: {
        role: Role.Seer,
        camp: Camp.Good,
        label: roleName("seer"),
        skillBrief: text("zh-CN", "role.seer.brief"),
        goodSide: "god",
    },
    runtime: {
        configuration: {
            schema: parameters,
            defaults: { targetPolicy: "awa_alive_v1", actionPolicy: DEFAULT_SEER_ACTION_POLICY },
            apply: (config, value) => ({ ...config, seer: parameters.parse(value) }),
            serialize: (config) => parameters.parse(config.seer ?? {}),
        },
        init: (roleComp, ctx) => {
            setSeerState(roleComp, {
                lastTarget: null,
                lastIsWerewolf: null,
                lastResult: null,
                history: [],
                ...(ctx.boardConfig?.seer?.targetPolicy === "awa_fresh_others_v1"
                    ? { targetPolicy: ctx.boardConfig.seer.targetPolicy }
                    : {}),
                ...(ctx.boardConfig?.seer?.actionPolicy === "awa_optional_v1"
                    ? { actionPolicy: ctx.boardConfig.seer.actionPolicy }
                    : {}),
            });
        },
        toolSpecs: SEER_TOOL_SPECS,
        validationRules: SEER_VALIDATION_RULES,
        nightStages: SEER_NIGHT_STAGES,
        llmRepair: {
            coerce: {
                check_identity: (args) => {
                    const target = numberOrNull(args.target_id);
                    return target === null ? null : { target_id: target };
                },
            },
        },
        baselineAction: (roleComp, request, pickAliveNotSelf, _byCamp, _locale, world) => {
            if (!request.allowedTools.includes("check_identity")) {
                return null;
            }
            const ability = activeNightAbility(roleComp, "seer_check", request.context.day, request.context.ability_id);
            const target = world && ability
                ? (world
                    .getAliveEntityIds()
                    .find((id) => id !== request.actorId &&
                    seerTargetAllowed(ability.state, request.actorId, id) &&
                    luckyTargetAllowed(world, request.actorId, ability, request.context.day, "check", id)) ?? null)
                : pickAliveNotSelf();
            return target !== null ? { name: "check_identity", args: { target_id: target } } : null;
        },
    },
    presentation: nativeRolePresentation("seer"),
};
