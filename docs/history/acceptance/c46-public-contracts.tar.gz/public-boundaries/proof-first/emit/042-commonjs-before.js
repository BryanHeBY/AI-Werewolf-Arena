"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.freshMerchantState = void 0;
exports.getMerchantState = getMerchantState;
exports.setMerchantState = setMerchantState;
exports.projectMerchantState = projectMerchantState;
exports.canMerchantTrade = canMerchantTrade;
exports.closeMerchantTrade = closeMerchantTrade;
exports.recordMerchantTrade = recordMerchantTrade;
const abilities_1 = require("../night-abilities/abilities");
const freshMerchantState = () => ({
    remaining: 1,
    closedDay: null,
    choice: null,
});
exports.freshMerchantState = freshMerchantState;
function getMerchantState(role) {
    return role
        ?.privateState.miracle_merchant;
}
function setMerchantState(role, state) {
    role.privateState.miracle_merchant =
        (0, abilities_1.copyAbilityData)(state);
}
function projectMerchantState(state) {
    return {
        remaining: state.remaining,
        closedDay: state.closedDay,
        choice: state.choice
            ? { day: state.choice.day, targetId: state.choice.targetId, skill: state.choice.skill }
            : null,
    };
}
function canMerchantTrade(state, day) {
    return state.remaining > 0 && day >= 1 && (state.closedDay === null || state.closedDay < day);
}
function closeMerchantTrade(state, day) {
    state.closedDay = day;
}
function recordMerchantTrade(state, day, targetId, skill) {
    state.remaining = 0;
    state.closedDay = day;
    state.choice = {
        day,
        targetId,
        skill: skill,
    };
}
