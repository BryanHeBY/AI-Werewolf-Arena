"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HookRegistry = void 0;
exports.createCommittedDeathWaveContributions = createCommittedDeathWaveContributions;
exports.getDefaultHookRegistry = getDefaultHookRegistry;
const role_catalog_assembly_1 = require("../../rulesets/roles/role-catalog-assembly");
const gift_gun_death_hook_1 = require("../../features/death-actions/gift-gun-death-hook");
const ports_1 = require("../../features/wild-child/ports");
function createCommittedDeathWaveContributions() {
    return [ports_1.resolveWildChildDeathWave];
}
function buildDefaultVotedOutHooks() {
    return (0, role_catalog_assembly_1.getDefaultRoleCatalog)()
        .allRuntime()
        .map(({ runtime }) => runtime.votedOutHook)
        .filter((hook) => Boolean(hook));
}
function buildDefaultDeathHooks() {
    return (0, role_catalog_assembly_1.getDefaultRoleCatalog)()
        .allRuntime()
        .map(({ runtime }) => runtime.deathHook)
        .filter((hook) => Boolean(hook))
        .concat(gift_gun_death_hook_1.giftGunDeathHook);
}
class HookRegistry {
    votedOutHooks;
    deathHooks;
    constructor(votedOutHooks = buildDefaultVotedOutHooks(), deathHooks = buildDefaultDeathHooks()) {
        this.votedOutHooks = votedOutHooks;
        this.deathHooks = deathHooks;
    }
    onVotedOut(world, targetId, events) {
        for (const hook of this.votedOutHooks) {
            const result = hook(world, targetId, events);
            if (result) {
                return result;
            }
        }
        return null;
    }
    async onDeath(world, deadIds, deathSources, chooseDeathShot, events, commitAdditionalDeaths, context) {
        const aggregated = {
            extraDeaths: [],
            extraDeathSources: {},
        };
        for (const hook of this.deathHooks) {
            if (context?.isCurrent && !context.isCurrent())
                break;
            const result = await hook(world, deadIds, deathSources, chooseDeathShot, events, context);
            commitAdditionalDeaths?.(result);
            aggregated.extraDeaths.push(...result.extraDeaths);
            if (result.nightEffectTargets?.length)
                (aggregated.nightEffectTargets ??= []).push(...result.nightEffectTargets);
            if (result.pendingShots?.length)
                (aggregated.pendingShots ??= []).push(...result.pendingShots);
            if (result.deathWaveContributions?.length)
                (aggregated.deathWaveContributions ??= []).push(...result.deathWaveContributions);
            for (const [id, marks] of Object.entries(result.extraDeathSources)) {
                aggregated.extraDeathSources[Number(id)] = [
                    ...new Set([...(aggregated.extraDeathSources[Number(id)] ?? []), ...marks]),
                ];
            }
        }
        return aggregated;
    }
}
exports.HookRegistry = HookRegistry;
let defaultRegistry = null;
function getDefaultHookRegistry() {
    if (!defaultRegistry) {
        defaultRegistry = new HookRegistry();
    }
    return defaultRegistry;
}
