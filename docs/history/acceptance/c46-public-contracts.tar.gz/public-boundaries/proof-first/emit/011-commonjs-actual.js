"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DayPipeline = void 0;
const daytime_interruption_composition_1 = require("../../rulesets/daytime-interruption-composition");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const election_ports_1 = require("../../features/sheriff/election-ports");
const speaking_order_ports_1 = require("../../features/sheriff/speaking-order-ports");
const badge_ports_1 = require("../../features/sheriff/badge-ports");
const action_request_factory_1 = require("../actions/action-request-factory");
const self_destruct_window_1 = require("../../rulesets/self-destruct-window");
class DayPipeline {
    world;
    roleRegistry;
    toolGateway;
    events;
    interruptions;
    constructor(dependencies) {
        this.world = dependencies.world;
        this.roleRegistry = dependencies.roleRegistry;
        this.toolGateway = dependencies.toolGateway;
        this.events = dependencies.events;
        this.interruptions = (0, daytime_interruption_composition_1.createDaytimeInterruptionComposition)({
            world: () => this.world,
            roleRegistry: () => this.roleRegistry,
            toolGateway: () => this.toolGateway,
            events: () => this.events,
        });
    }
    async execute(config, actionProvider, options) {
        this.interruptions.assertEntry();
        const speeches = [];
        const requests = new action_request_factory_1.GameActionRequestFactory(this.world, this.events, options.day);
        const isCurrent = options.isCurrent ?? (() => true);
        if (!isCurrent())
            return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        if (options.day === 1 &&
            config.enableSheriff &&
            (0, badge_ports_1.findSheriffId)(this.world) === null &&
            config.hooks.onPreElection &&
            (0, self_destruct_window_1.isSelfDestructWindowEnabled)(config, model_1.ActionWindow.OnPreElection)) {
            const exploded = await this.interruptions.selfDestruct.execute(requests, actionProvider, model_1.ActionWindow.OnPreElection, model_1.Phase.Day, isCurrent, (id) => options.commitSelfDestruct?.(id, model_1.ActionWindow.OnPreElection) ?? Promise.resolve());
            if (exploded !== null)
                return {
                    summary: { speeches, selfDestructBy: exploded.actorId },
                    interrupted: true,
                    selfDestruct: exploded,
                };
            if (!isCurrent())
                return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        }
        await (0, election_ports_1.electSheriffIfNeeded)({
            get requestFactory() { return action_request_factory_1.GameActionRequestFactory; },
            world: this.world,
            events: this.events,
            toolGateway: this.toolGateway,
            actionProvider,
            day: options.day,
            enableSheriff: config.enableSheriff,
            config,
            isCurrent,
        });
        if (!isCurrent())
            return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        if (await options.afterSheriffElection?.()) {
            return {
                summary: { speeches, selfDestructBy: null },
                interrupted: false,
            };
        }
        if (config.hooks.onDaybreak && (0, self_destruct_window_1.isSelfDestructWindowEnabled)(config, model_1.ActionWindow.OnDaybreak)) {
            const exploded = await this.interruptions.selfDestruct.execute(requests, actionProvider, model_1.ActionWindow.OnDaybreak, model_1.Phase.Day, isCurrent, (id) => options.commitSelfDestruct?.(id, model_1.ActionWindow.OnDaybreak) ?? Promise.resolve());
            if (exploded !== null) {
                return {
                    summary: {
                        speeches,
                        selfDestructBy: exploded.actorId,
                    },
                    interrupted: true,
                    selfDestruct: exploded,
                };
            }
        }
        if (!isCurrent())
            return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        const openingDuel = await this.interruptions.duel.execute(config, requests, actionProvider, model_1.KnightDuelWindow.BeforeSpeeches, isCurrent, options.commitKnightDuel);
        if (openingDuel.endsDay)
            return {
                summary: { speeches, selfDestructBy: null },
                interrupted: true,
                ...(openingDuel.selection ? { duel: openingDuel.selection } : {}),
            };
        if (!isCurrent())
            return { summary: { speeches, selfDestructBy: null }, interrupted: false };
        const speakerDirection = await (0, speaking_order_ports_1.chooseSpeakerDirection)({
            get requestFactory() { return action_request_factory_1.GameActionRequestFactory; },
            world: this.world,
            events: this.events,
            toolGateway: this.toolGateway,
            actionProvider,
            day: options.day,
            enableSheriff: config.enableSheriff,
        });
        const speakers = (0, speaking_order_ports_1.buildSpeakerOrder)(this.world, this.world.getAliveEntityIds(), (0, badge_ports_1.findSheriffId)(this.world), speakerDirection);
        for (const actorId of speakers) {
            if (!isCurrent())
                return { summary: { speeches, selfDestructBy: null }, interrupted: false };
            if (!this.isAlive(actorId)) {
                continue;
            }
            const debate = await this.interruptions.debate.execute(config, requests, actionProvider, actorId, options.day, isCurrent);
            if (!isCurrent())
                return { summary: { speeches, selfDestructBy: null }, interrupted: false };
            if (!debate.skipSpeech && this.isAlive(actorId)) {
                const req = requests.create({
                    phase: model_1.Phase.Day,
                    actorId,
                    allowedTools: ["speak"],
                    stage: "day_speech",
                    requiresAction: true,
                    summary: { key: "request.summary.day_speech" },
                    context: {},
                });
                const action = await actionProvider.getAction(req);
                if (!isCurrent())
                    return { summary: { speeches, selfDestructBy: null }, interrupted: false };
                if (action?.name === "speak") {
                    const result = this.toolGateway.validateAndSanitize(this.world, actorId, action, {
                        phase: model_1.Phase.Day,
                    });
                    if (result.ok && result.sanitizedCall) {
                        speeches.push({ actorId, text: result.sanitizedCall.args.text });
                        this.events.push({
                            timestamp: Date.now(),
                            type: "day_speech",
                            payload: {
                                actorId,
                                text: result.sanitizedCall.args.text,
                            },
                        });
                    }
                }
            }
            if (config.hooks.onPerSpeechGap &&
                (0, self_destruct_window_1.isSelfDestructWindowEnabled)(config, model_1.ActionWindow.OnPerSpeechGap)) {
                const exploded = await this.interruptions.selfDestruct.execute(requests, actionProvider, model_1.ActionWindow.OnPerSpeechGap, model_1.Phase.Day, isCurrent, (id) => options.commitSelfDestruct?.(id, model_1.ActionWindow.OnPerSpeechGap) ?? Promise.resolve());
                if (exploded !== null) {
                    return {
                        summary: {
                            speeches,
                            selfDestructBy: exploded.actorId,
                        },
                        interrupted: true,
                        selfDestruct: exploded,
                    };
                }
            }
            const gapDuel = await this.interruptions.duel.execute(config, requests, actionProvider, model_1.KnightDuelWindow.BetweenSpeeches, isCurrent, options.commitKnightDuel);
            if (gapDuel.endsDay)
                return {
                    summary: { speeches, selfDestructBy: null },
                    interrupted: true,
                    ...(gapDuel.selection ? { duel: gapDuel.selection } : {}),
                };
        }
        const closingDuel = await this.interruptions.duel.execute(config, requests, actionProvider, model_1.KnightDuelWindow.AfterSpeeches, isCurrent, options.commitKnightDuel);
        if (closingDuel.endsDay)
            return {
                summary: { speeches, selfDestructBy: null },
                interrupted: true,
                ...(closingDuel.selection ? { duel: closingDuel.selection } : {}),
            };
        return {
            summary: {
                speeches,
                selfDestructBy: null,
            },
            interrupted: false,
        };
    }
    isAlive(entityId) {
        const alive = this.world.getComponent(entityId, names_1.COMPONENT.Alive);
        return alive?.alive === true;
    }
}
exports.DayPipeline = DayPipeline;
