import { roleInspectionPolicy } from "@ai-werewolf-arena/game-contract/role-inspection-policy";
import { aliveLifeVersion } from "../../domain/components/alive";
import { COMPONENT } from "../../domain/components/names";
import { Role } from "../../domain/model";
import { findNightAbility } from "../night-abilities/inventory-ports";
import { getGargoyleState } from "../gargoyle/ports";
import { ROLE_INSPECTION_STATE_SLOT } from "./state-slot";
const nights = new WeakMap();
const committed = new WeakMap();
export function hasRoleInspectionNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
export function beginRoleInspectionNight(world, day) {
    if (nights.get(world)?.day !== day)
        nights.set(world, { day, completed: new Map() });
}
export function recordRoleInspectionNightCommit(world, day, isCurrent) {
    if (!isCurrent())
        return;
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
export function recordRoleInspectionCompletion(world, actorId, day, ability, isCurrent) {
    if (!isCurrent())
        return;
    recordRoleInspectionNightCommit(world, day, isCurrent);
    const role = world.getComponent(actorId, COMPONENT.Role), state = role && getGargoyleState(role), life = world.getComponent(actorId, COMPONENT.Alive), version = life && aliveLifeVersion(life);
    if (roleInspectionPolicy(ability.state) !== "gargoyle" ||
        role?.role !== Role.Gargoyle ||
        !state ||
        !life?.alive ||
        version === undefined ||
        ability.source.kind !== "native" ||
        ability.source.role !== Role.Gargoyle)
        return;
    beginRoleInspectionNight(world, day);
    nights.get(world).completed.set(role, {
        actorId,
        role,
        privateState: role.privateState,
        state,
        ability,
        abilityId: ability.id,
        activation: ability.activation,
        inspection: ability.state,
        inspectionPolicy: ability.state.inspectionPolicy,
        life,
        version,
        isCurrent,
    });
}
export function completedGargoyleInspection(world, role) {
    const scope = nights.get(world)?.completed.get(role);
    if (!scope ||
        !scope.isCurrent() ||
        role.privateState !== scope.privateState ||
        getGargoyleState(role) !== scope.state ||
        role.role !== Role.Gargoyle ||
        scope.ability.id !== scope.abilityId ||
        scope.ability.activation !== scope.activation ||
        findNightAbility(role, "role_check", scope.abilityId) !== scope.ability ||
        scope.ability.source.kind !== "native" ||
        scope.ability.source.role !== Role.Gargoyle ||
        scope.ability.disabled ||
        ROLE_INSPECTION_STATE_SLOT.invalidations.payloadChanged(scope))
        return false;
    return (world.getComponent(scope.actorId, COMPONENT.Role) === role &&
        world.getComponent(scope.actorId, COMPONENT.Alive) === scope.life &&
        scope.life.alive &&
        aliveLifeVersion(scope.life) === scope.version);
}
