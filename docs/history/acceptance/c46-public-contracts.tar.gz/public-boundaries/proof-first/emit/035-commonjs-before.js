"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HUNTER_ROLE_PROFILE = void 0;
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const death_action_policy_1 = require("../death-actions/death-action-policy");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const native_death_gun_resources_1 = require("../death-actions/native-death-gun-resources");
const death_hook_1 = require("./death-hook");
const tool_specs_1 = require("./tool-specs");
const death_shot_1 = require("../death-actions/death-shot");
exports.HUNTER_ROLE_PROFILE = {
    metadata: {
        role: model_1.Role.Hunter,
        camp: model_1.Camp.Good,
        label: (0, game_text_1.roleName)("hunter"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.hunter.brief"),
        goodSide: "god",
    },
    runtime: {
        configuration: (0, death_action_policy_1.deathActionConfiguration)("hunter"),
        init: (roleComp, ctx) => {
            (0, native_death_gun_resources_1.setHunterState)(roleComp, (0, native_death_gun_resources_1.createHunterState)(ctx));
        },
        toolSpecs: tool_specs_1.HUNTER_TOOL_SPECS,
        validationRules: {
            shoot: (ctx) => (0, death_shot_1.validateDeathShot)(ctx, ctx.role.role === model_1.Role.Hunter && (0, native_death_gun_resources_1.getHunterState)(ctx.role)?.canShoot === true),
        },
        llmRepair: death_shot_1.DEATH_SHOT_REPAIR,
        deathHook: death_hook_1.hunterDeathHook,
        baselineAction: (_roleComp, request, pickAliveNotSelf) => {
            if (!request.allowedTools.includes("shoot")) {
                return null;
            }
            const target = pickAliveNotSelf();
            return { name: "shoot", args: { target_id: target } };
        },
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("hunter"),
};
