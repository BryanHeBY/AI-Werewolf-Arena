export { DEATH_SHOT_TOOL_SPECS as HUNTER_TOOL_SPECS } from "../death-actions/death-shot";
