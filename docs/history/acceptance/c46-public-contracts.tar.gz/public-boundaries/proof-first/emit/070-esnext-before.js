import { nativeRolePresentation } from "../../rulesets/roles/presentation-contribution";
import { deathActionConfiguration } from "../death-actions/death-action-policy";
import { roleName, text } from "@ai-werewolf-arena/game-text";
import { Role, permitsDeathShot } from "../../domain/model";
import { getWolfKingState, setWolfKingState, createWolfKingState } from "../death-actions/native-death-gun-resources";
import { DEATH_SHOT_TOOL_SPECS, DEATH_SHOT_REPAIR, validateDeathShot, } from "../death-actions/death-shot";
import { resolveNativeDeathShots } from "../death-actions/native-death-shot-settlement";
import { ORDINARY_WOLF_CONTRIBUTIONS } from "../wolf/ability-ports";
export const WOLF_KING_ROLE_PROFILE = {
    metadata: {
        ...ORDINARY_WOLF_CONTRIBUTIONS.metadata,
        role: Role.WolfKing,
        label: roleName("wolf_king"),
        skillBrief: text("zh-CN", "role.wolf_king.brief"),
    },
    runtime: {
        ...ORDINARY_WOLF_CONTRIBUTIONS.runtime,
        configuration: deathActionConfiguration("wolfKing"),
        init: (role, ctx) => {
            setWolfKingState(role, createWolfKingState(ctx));
        },
        toolSpecs: [...ORDINARY_WOLF_CONTRIBUTIONS.runtime.toolSpecs, ...DEATH_SHOT_TOOL_SPECS],
        validationRules: {
            ...ORDINARY_WOLF_CONTRIBUTIONS.runtime.validationRules,
            shoot: (ctx) => validateDeathShot(ctx, ctx.role.role === Role.WolfKing && getWolfKingState(ctx.role)?.canShoot === true),
        },
        llmRepair: {
            coerce: { ...ORDINARY_WOLF_CONTRIBUTIONS.runtime.llmRepair?.coerce, ...DEATH_SHOT_REPAIR.coerce },
        },
        deathHook: (world, ids, sources, choose, events, context) => resolveNativeDeathShots(world, ids, sources, choose, events, {
            role: Role.WolfKing,
            state: getWolfKingState,
            permits: (sources) => permitsDeathShot(sources),
            policy: (state) => state.deathActionPolicy ?? "awa_qualified_sources_v1",
            shotEvent: (actorId, targetId) => ({
                timestamp: Date.now(),
                type: "wolf_king_shot",
                payload: { actorId, targetId },
            }),
        }, context),
        baselineAction: (role, request, pickAliveNotSelf, pickAliveByCamp, locale, _world, currentCamp) => request.allowedTools.includes("shoot")
            ? { name: "shoot", args: { target_id: pickAliveByCamp("good") ?? pickAliveNotSelf() } }
            : ORDINARY_WOLF_CONTRIBUTIONS.runtime.baselineAction(role, request, pickAliveNotSelf, pickAliveByCamp, locale, undefined, currentCamp),
    },
    presentation: nativeRolePresentation("wolf_king"),
};
