"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wolfTeamPermissions = wolfTeamPermissions;
exports.knownWolfTeammates = knownWolfTeammates;
exports.wolfChatParticipants = wolfChatParticipants;
exports.wolfKnifeHolders = wolfKnifeHolders;
exports.wolfTeamEvent = wolfTeamEvent;
const night_frame_1 = require("../scholar-mentor/night-frame");
const authority_1 = require("../animal-dream/authority");
const night_frame_2 = require("../nightmare/night-frame");
const authority_2 = require("../ghost-bride/authority");
const deal_1 = require("../initial-identity/deal");
const names_1 = require("../../domain/components/names");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const model_1 = require("../../domain/model");
const NO_ACCESS = Object.freeze({
    recognizedByPack: false,
    recognizes: "none",
    canChat: false,
    canVoteForKill: false,
});
function wolfTeamPermissions(role, catalog, currentCamp, world) {
    if (world && !(0, deal_1.initialIdentitySetupReady)(world))
        return NO_ACCESS;
    if (!role || currentCamp()?.camp !== model_1.Camp.Wolf)
        return NO_ACCESS;
    if (world && (0, authority_2.weddingSetup)(world) && (!(0, authority_2.ghostBrideReady)(world) || (0, authority_2.weddingMember)(world, role)))
        return NO_ACCESS;
    const permissions = catalog.runtime(role.role)?.wolfTeam;
    const result = typeof permissions === "function" ? permissions(role, world, currentCamp) : (permissions ?? NO_ACCESS);
    const current = world &&
        ((0, night_frame_2.nightmareKnifeBlocked)(world) ||
            (0, night_frame_1.scholarMentorPackBlocked)(world) ||
            (0, authority_1.animalPackKnifeBlocked)(world))
        ? { ...result, canVoteForKill: false }
        : result;
    if (current === NO_ACCESS)
        return current;
    return (0, role_execution_authority_1.isRoleExecutionRetired)(role)
        ? { ...current, canChat: false, canVoteForKill: false }
        : current;
}
function knownWolfTeammates(world, actorId, catalog) {
    const viewer = wolfTeamPermissions(world.getComponent(actorId, names_1.COMPONENT.Role), catalog, () => world.getComponent(actorId, names_1.COMPONENT.Camp), world);
    if (viewer === NO_ACCESS)
        return [];
    const role = world.getComponent(actorId, names_1.COMPONENT.Role);
    const snapshot = role && world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Wolf && catalog.runtime(role.role)?.knownTeammates;
    if (snapshot)
        return [...new Set(snapshot(role, world))]
            .filter((id) => id !== actorId && world.getComponent(id, names_1.COMPONENT.Role) && world.getComponent(id, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Wolf)
            .sort((a, b) => a - b);
    if (viewer.recognizes === "none")
        return [];
    return world
        .entityIds()
        .filter((id) => {
        if (id === actorId)
            return false;
        const target = world.getComponent(id, names_1.COMPONENT.Role);
        if (!target || world.getComponent(id, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Wolf)
            return false;
        if (viewer.recognizes === "all")
            return true;
        if (viewer.recognizes === "pack")
            return wolfTeamPermissions(target, catalog, () => world.getComponent(id, names_1.COMPONENT.Camp), world).recognizedByPack;
        return viewer.recognizes.includes(target.role);
    })
        .sort((a, b) => a - b);
}
function wolfChatParticipants(world, catalog) {
    return world
        .getAliveEntityIds()
        .filter((id) => wolfTeamPermissions(world.getComponent(id, names_1.COMPONENT.Role), catalog, () => world.getComponent(id, names_1.COMPONENT.Camp), world).canChat)
        .sort((a, b) => a - b);
}
function wolfKnifeHolders(world, catalog) {
    return world
        .getAliveEntityIds()
        .filter((id) => wolfTeamPermissions(world.getComponent(id, names_1.COMPONENT.Role), catalog, () => world.getComponent(id, names_1.COMPONENT.Camp), world).canVoteForKill)
        .sort((a, b) => a - b);
}
function wolfTeamEvent(world, catalog, event) {
    const recipients = wolfChatParticipants(world, catalog);
    if (event.type === "wolf_kill_vote_cast")
        recipients.push(...wolfKnifeHolders(world, catalog));
    return {
        ...event,
        audience: Object.freeze([...new Set(recipients)].sort((a, b) => a - b)),
    };
}
