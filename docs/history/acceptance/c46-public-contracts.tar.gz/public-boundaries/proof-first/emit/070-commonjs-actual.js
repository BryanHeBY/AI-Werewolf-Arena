"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WOLF_KING_ROLE_PROFILE = void 0;
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const policy_ports_1 = require("../death-actions/policy-ports");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const native_resource_ports_1 = require("../death-actions/native-resource-ports");
const tool_ports_1 = require("../death-actions/tool-ports");
const settlement_ports_1 = require("../death-actions/settlement-ports");
const ability_ports_1 = require("../wolf/ability-ports");
exports.WOLF_KING_ROLE_PROFILE = {
    metadata: {
        ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.metadata,
        role: model_1.Role.WolfKing,
        label: (0, game_text_1.roleName)("wolf_king"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.wolf_king.brief"),
    },
    runtime: {
        ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime,
        configuration: (0, policy_ports_1.deathActionConfiguration)("wolfKing"),
        init: (role, ctx) => {
            (0, native_resource_ports_1.setWolfKingState)(role, (0, native_resource_ports_1.createWolfKingState)(ctx));
        },
        toolSpecs: [...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.toolSpecs, ...tool_ports_1.DEATH_SHOT_TOOL_SPECS],
        validationRules: {
            ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.validationRules,
            shoot: (ctx) => (0, tool_ports_1.validateDeathShot)(ctx, ctx.role.role === model_1.Role.WolfKing && (0, native_resource_ports_1.getWolfKingState)(ctx.role)?.canShoot === true),
        },
        llmRepair: {
            coerce: { ...ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.llmRepair?.coerce, ...tool_ports_1.DEATH_SHOT_REPAIR.coerce },
        },
        deathHook: (world, ids, sources, choose, events, context) => (0, settlement_ports_1.resolveNativeDeathShots)(world, ids, sources, choose, events, {
            role: model_1.Role.WolfKing,
            state: native_resource_ports_1.getWolfKingState,
            permits: (sources) => (0, model_1.permitsDeathShot)(sources),
            policy: (state) => state.deathActionPolicy ?? "awa_qualified_sources_v1",
            shotEvent: (actorId, targetId) => ({
                timestamp: Date.now(),
                type: "wolf_king_shot",
                payload: { actorId, targetId },
            }),
        }, context),
        baselineAction: (role, request, pickAliveNotSelf, pickAliveByCamp, locale, _world, currentCamp) => request.allowedTools.includes("shoot")
            ? { name: "shoot", args: { target_id: pickAliveByCamp("good") ?? pickAliveNotSelf() } }
            : ability_ports_1.ORDINARY_WOLF_CONTRIBUTIONS.runtime.baselineAction(role, request, pickAliveNotSelf, pickAliveByCamp, locale, undefined, currentCamp),
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("wolf_king"),
};
