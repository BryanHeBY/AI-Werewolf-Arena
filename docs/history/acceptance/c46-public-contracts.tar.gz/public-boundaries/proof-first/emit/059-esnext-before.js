import { copyAbilityData, findNightAbility } from "../night-abilities/abilities";
import { roleInspectionPolicy } from "@ai-werewolf-arena/game-contract/role-inspection-policy";
import { commitPreparedNativeAbility } from "../night-abilities/abilities";
export function setRoleInspectionState(role, state) {
    return commitPreparedNativeAbility(role, "role_check", ROLE_INSPECTION_STATE_SLOT.create(state));
}
export function getRoleInspectionState(role, abilityId) {
    return findNightAbility(role, "role_check", abilityId)?.state;
}
export function recordRoleInspection(state, targetId, day, result) {
    state.lastTarget = targetId;
    state.lastDay = day;
    state.history.push({ day, targetId, result: { ...result } });
}
export function recordAbilityRoleInspection(ability, targetId, day, result) {
    ability.state.lastTarget = targetId;
    ability.state.lastDay = day;
    ability.state.history.push({ day, targetId, result: { ...result } });
}
function createRoleInspectionState(state) {
    const ownedState = copyAbilityData(state);
    roleInspectionPolicy(ownedState);
    return ownedState;
}
function encodeRoleInspectionPolicy(ability) {
    return JSON.stringify([ability.state.policy, ability.state.inspectionPolicy]);
}
function capturedInspectionPayloadChanged(scope) {
    return (scope.ability.state !== scope.inspection ||
        scope.inspection.inspectionPolicy !== scope.inspectionPolicy ||
        roleInspectionPolicy(scope.inspection) !== "gargoyle");
}
export const ROLE_INSPECTION_STATE_SLOT = Object.freeze({
    create: createRoleInspectionState,
    schema: roleInspectionPolicy,
    install: setRoleInspectionState,
    get: getRoleInspectionState,
    allowedWrites: Object.freeze({
        appendState: recordRoleInspection,
        appendAbility: recordAbilityRoleInspection,
    }),
    checkpoint: Object.freeze({ policyIdentity: encodeRoleInspectionPolicy }),
    invalidations: Object.freeze({ payloadChanged: capturedInspectionPayloadChanged }),
});
