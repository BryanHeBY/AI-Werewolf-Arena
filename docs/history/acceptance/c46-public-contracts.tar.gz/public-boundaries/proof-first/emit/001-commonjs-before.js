"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMMON_VALIDATION_RULES = void 0;
const wall_notes_1 = require("@ai-werewolf-arena/game-contract/facts/wall-notes");
const authority_1 = require("../../features/wall-notes/authority");
const relation_1 = require("../../features/cupid/relation");
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const authority_2 = require("../../features/debater/authority");
const original_participant_1 = require("../../domain/original-participant");
const domain_1 = require("../../domain");
const participation_1 = require("../participation");
exports.COMMON_VALIDATION_RULES = {
    write_note: ({ world, actorId, day, phase, toolCall, wallScope, wallId, itemInstanceId }) => {
        if (day !== 1 ||
            phase !== domain_1.Phase.Voting ||
            !(0, authority_1.authorizedWallAuthor)(world, actorId, wallId, itemInstanceId, wallScope))
            return { code: game_contract_1.RuleError.WallNoteUnavailable };
        return (0, wall_notes_1.readWallTool)(toolCall) ? null : { code: game_contract_1.RuleError.WallNoteText };
    },
    debate_vote: ({ world, actorId, day, phase, toolCall, debateId }) => {
        const a = (0, authority_2.debateAuthority)(world, debateId), actor = a?.participants.get(actorId);
        if (toolCall.name !== "debate_vote")
            return { code: game_contract_1.RuleError.ToolMismatch };
        if (!a ||
            !actor ||
            a.stage !== "ballot" ||
            a.day !== day ||
            phase !== domain_1.Phase.Day ||
            !(0, original_participant_1.sameOriginalParticipant)(world, actor))
            return { code: game_contract_1.RuleError.DebateUnavailable };
        if (toolCall.args.support !== true &&
            toolCall.args.support !== false &&
            toolCall.args.support !== null)
            return { code: game_contract_1.RuleError.DebateBallot };
        return null;
    },
    report_bug: ({ toolCall }) => {
        if (toolCall.name !== "report_bug") {
            return { code: game_contract_1.RuleError.ToolMismatch };
        }
        const { category, severity, message } = toolCall.args;
        const categorySet = new Set(["flow", "rule", "state", "logging", "other"]);
        const severitySet = new Set(["low", "medium", "high", "critical"]);
        if (!categorySet.has(String(category))) {
            return { code: game_contract_1.RuleError.ReportCategory };
        }
        if (!severitySet.has(String(severity))) {
            return { code: game_contract_1.RuleError.ReportSeverity };
        }
        if (typeof message !== "string" || message.trim().length === 0) {
            return { code: game_contract_1.RuleError.ReportMessageEmpty };
        }
        if (message.length > 300) {
            return { code: game_contract_1.RuleError.ReportMessageLong };
        }
        return null;
    },
    speak: () => null,
    vote: ({ world, actorId, day, toolCall, roleCatalog, exileCandidates }) => {
        if (toolCall.name !== "vote") {
            return { code: game_contract_1.RuleError.ToolMismatch };
        }
        if (exileCandidates?.includes(actorId))
            return { code: game_contract_1.RuleError.PkVoteEligibility };
        if (!toolCall.args.abstain &&
            exileCandidates &&
            !exileCandidates.includes(toolCall.args.target_id))
            return { code: game_contract_1.RuleError.PkVoteTarget };
        if (!(0, participation_1.canVoteExile)(world, actorId, day, roleCatalog)) {
            return { code: game_contract_1.RuleError.VoteRight };
        }
        if (toolCall.args.abstain) {
            return null;
        }
        if (toolCall.args.target_id === null) {
            return { code: game_contract_1.RuleError.VoteTarget };
        }
        if ((0, relation_1.prohibitsLoversVote)(world, actorId, toolCall.args.target_id))
            return { code: game_contract_1.RuleError.LoversVote };
        if (!(0, participation_1.canBeExiled)(world, toolCall.args.target_id, roleCatalog)) {
            return { code: game_contract_1.RuleError.VoteTarget };
        }
        return null;
    },
};
