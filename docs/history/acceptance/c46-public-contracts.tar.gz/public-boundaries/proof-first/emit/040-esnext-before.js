import { hasRecipientNightCommit, recordRecipientNightCommit, recipientAbilityStage, } from "../night-abilities/recipient-ability-stage";
export const hasLuckyNightCommit = (world, day) => hasRecipientNightCommit(world, day, "lucky");
export const recordLuckyNightCommit = (world, day) => recordRecipientNightCommit(world, day, "lucky");
export const LUCKY_ABILITY_STAGE = recipientAbilityStage("lucky", 700);
