"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWolfKingState = void 0;
var native_resource_ports_1 = require("../death-actions/native-resource-ports");
Object.defineProperty(exports, "getWolfKingState", { enumerable: true, get: function () { return native_resource_ports_1.getWolfKingState; } });
