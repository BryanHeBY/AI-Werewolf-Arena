"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DREAMER_ROLE_PROFILE = void 0;
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const zod_1 = require("zod");
const board_1 = require("../../domain/board");
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const abilities_1 = require("../night-abilities/abilities");
const ports_1 = require("./ports");
const validation_contracts_1 = require("../../engine/actions/validation-contracts");
const helpers_1 = require("../../agents/tool-repair/helpers");
const night_stages_1 = require("./night-stages");
const parameters = zod_1.z.strictObject({
    protectionPolicy: zod_1.z.enum(board_1.DREAM_PROTECTION_POLICIES).default("awa_night_damage_v1"),
});
exports.DREAMER_ROLE_PROFILE = {
    metadata: {
        role: model_1.Role.Dreamer,
        camp: model_1.Camp.Good,
        goodSide: "god",
        label: (0, game_text_1.roleName)("dreamer"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.dreamer.brief"),
    },
    runtime: {
        init: (role, ctx) => {
            (0, ports_1.setDreamerState)(role, {
                lastTarget: null,
                lastDay: null,
                history: [],
                ...(ctx.boardConfig?.dreamer?.protectionPolicy &&
                    ctx.boardConfig.dreamer.protectionPolicy !== "awa_night_damage_v1"
                    ? { protectionPolicy: ctx.boardConfig.dreamer.protectionPolicy }
                    : {}),
            });
        },
        configuration: {
            schema: parameters,
            defaults: { protectionPolicy: "awa_night_damage_v1" },
            apply: (config, value) => ({ ...config, dreamer: parameters.parse(value) }),
            serialize: (config) => parameters.parse(config.dreamer ?? {}),
        },
        nightStages: [night_stages_1.DREAMER_NIGHT_STAGE],
        toolSpecs: [
            {
                name: "dream",
                parameters: {
                    type: "object",
                    properties: { target_id: { type: "number" } },
                    required: ["target_id"],
                    additionalProperties: false,
                },
                argHint: 'dream args: {"target_id":number}',
                userPromptHintKey: "action.dream.hint",
            },
        ],
        validationRules: {
            dream: ({ world, actorId, role, toolCall, phase, day, abilityId }) => {
                if (!(0, abilities_1.activeNightAbility)(role, "dream", day ?? 1, abilityId))
                    return { code: game_contract_1.RuleError.DreamUnavailable };
                if (phase !== model_1.Phase.Night)
                    return { code: game_contract_1.RuleError.AbilityPhase };
                if (toolCall.name !== "dream" ||
                    toolCall.args.target_id === actorId ||
                    !(0, validation_contracts_1.isAliveTarget)(world, toolCall.args.target_id))
                    return { code: game_contract_1.RuleError.DreamTarget };
                return null;
            },
        },
        stageDirectives: [
            {
                match: (tools) => tools.length === 1 && tools[0] === "dream",
                messageKey: "action.dream.directive",
                text: (0, game_text_1.text)("zh-CN", "action.dream.directive"),
            },
        ],
        llmRepair: {
            coerce: {
                dream: (args) => {
                    const target = (0, helpers_1.numberOrNull)(args.target_id);
                    return target === null ? null : { target_id: target };
                },
            },
        },
        baselineAction: (_role, request, pick) => {
            if (!request.allowedTools.includes("dream"))
                return null;
            const target = pick();
            return target === null ? null : { name: "dream", args: { target_id: target } };
        },
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("dreamer"),
};
