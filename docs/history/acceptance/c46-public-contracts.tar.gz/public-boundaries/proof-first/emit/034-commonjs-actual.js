"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setHunterState = exports.getHunterState = void 0;
var native_resource_ports_1 = require("../death-actions/native-resource-ports");
Object.defineProperty(exports, "getHunterState", { enumerable: true, get: function () { return native_resource_ports_1.getHunterState; } });
Object.defineProperty(exports, "setHunterState", { enumerable: true, get: function () { return native_resource_ports_1.setHunterState; } });
