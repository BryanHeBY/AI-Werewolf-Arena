import { readPairSeerState } from "../fragrant-pair-seer/pair-data-ports";
import { nativePotionSecondTurn } from "../witch/potion-policy-ports";
import { Role } from "../../domain/model";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { COMPONENT } from "../../domain/components/names";
import { roleOf, emit } from "./night-ability-change-runtime";
import { types as utilTypes } from "node:util";
export { projectRoleInspectionState, projectSeerState, projectWitchState } from "../../agents/observation/player-state";
export const ROLE_INSPECTION_POLICY_ROLES = {
    gargoyle: Role.Gargoyle,
    psychic: Role.Psychic,
    mirror: Role.MirrorGirl,
    pure_white: Role.PureWhiteGirl,
    wolf_witch: Role.WolfWitch,
};
export function projectPairState(value) {
    const state = readPairSeerState(value);
    if (!state)
        throw Error("fragrant_pair_state_invalid");
    return state;
}
export function copyAbilityData(value) {
    const result = structuredClone(value), ancestors = new WeakSet();
    const visit = (item) => {
        if (item === null || typeof item === "string" || typeof item === "boolean")
            return;
        if (typeof item === "number" && Number.isFinite(item))
            return;
        if (typeof item !== "object" || !item || ancestors.has(item))
            throw new Error("ability_state_not_json");
        ancestors.add(item);
        if (Array.isArray(item)) {
            for (let index = 0; index < item.length; index++) {
                if (!Object.hasOwn(item, index))
                    throw new Error("ability_state_not_json");
                visit(item[index]);
            }
        }
        else {
            const prototype = Object.getPrototypeOf(item);
            if (prototype !== Object.prototype && prototype !== null)
                throw new Error("ability_state_not_json");
            for (const [key, entry] of Object.entries(item)) {
                if (entry === undefined)
                    delete item[key];
                else
                    visit(entry);
            }
        }
        ancestors.delete(item);
    };
    visit(result);
    return result;
}
export function allNightAbilities(role) {
    const stored = role
        ?.privateState.abilities;
    return stored
        ? Object.values(stored).sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
        : [];
}
export function nightAbilityDisabled(ability) {
    const blocker = Object.getOwnPropertyDescriptor(ability, "nightSuppression");
    return ability.disabled || (!!blocker && (!("value" in blocker) || blocker.value !== undefined));
}
export function abilityStatus(ability, day) {
    if (nightAbilityDisabled(ability) || ability.deathExpired)
        return "disabled";
    if (day < ability.startsOnDay)
        return "pending";
    if (ability.expiresAfterDay !== undefined && day > ability.expiresAfterDay)
        return "expired";
    if (ability.maxUses !== null && ability.uses >= ability.maxUses)
        return "spent";
    if (ability.lastUsedDay === day &&
        !(ability.kind === "potion" && nativePotionSecondTurn(ability, day)))
        return "used_this_night";
    if (ability.kind === "potion" &&
        ability.source.kind === "native" &&
        ability.source.role === Role.Witch &&
        ability.state.potionPolicy === "awa_both_native_experimental_v1" &&
        ability.state.potionTurnClosedDay === day)
        return "used_this_night";
    return "active";
}
export function findNightAbility(role, kind, id) {
    const candidates = allNightAbilities(role).filter((ability) => ability.kind === kind);
    if (id !== undefined)
        return candidates.find((ability) => ability.id === id);
    return (candidates.find((ability) => ability.source.kind === "native") ??
        (candidates.length === 1 ? candidates[0] : undefined));
}
export function activeNightAbility(role, kind, day, id) {
    const ability = findNightAbility(role, kind, id);
    return ability && abilityStatus(ability, day) === "active" && role && !isRoleExecutionRetired(role)
        ? ability
        : undefined;
}
export function retiredNightAbilityIds(role) {
    return (role.privateState.retiredAbilityIds ??
        []);
}
export function commitPreparedNativeAbility(role, kind, ownedState, mayCommit) {
    const stored = (role.privateState.abilities ??=
        {});
    const retired = (role.privateState
        .retiredAbilityIds ?? []);
    const baseId = `native:${kind}`;
    let id = baseId, revision = 1;
    while (retired.includes(id))
        id = `${baseId}:${++revision}`;
    const existing = stored[id];
    if (existing) {
        if (existing.kind !== kind ||
            existing.source.kind !== "native" ||
            existing.source.role !== role.role)
            throw new Error("ability_native_binding_conflict");
        if (mayCommit && !mayCommit())
            return null;
        existing.state = ownedState;
    }
    else {
        const installed = {
            id,
            kind,
            state: ownedState,
            source: { kind: "native", role: role.role },
            sourceDisclosed: true,
            startsOnDay: 1,
            maxUses: null,
            uses: 0,
            lastUsedDay: null,
            disabled: false,
        };
        if (mayCommit && !mayCommit())
            return null;
        stored[id] = installed;
    }
    return ownedState;
}
export function setNightAbilityEnabled(world, actorId, id, enabled, events) {
    const ability = allNightAbilities(roleOf(world, actorId)).find((ability) => ability.id === id);
    if (!ability)
        throw new Error("ability_instance_missing");
    if (enabled && ability.deathExpired)
        throw new Error("ability_lucky_expired_on_death");
    if (ability.disabled === !enabled)
        return;
    ability.disabled = !enabled;
    emit(events, actorId, ability, enabled ? "enabled" : "disabled");
}
export function retireBorrowedNightAbility(readBorrowed) {
    Object.defineProperty(readBorrowed(), "disabled", {
        value: true,
        writable: true,
        enumerable: true,
        configurable: true,
    });
}
export function expireLuckyAbilitiesOnDeath(world, actorId, events) {
    for (const ability of allNightAbilities(world.getComponent(actorId, COMPONENT.Role))) {
        if ((ability.activation !== "lucky" && ability.activation !== "black_market") ||
            ability.deathExpired)
            continue;
        ability.deathExpired = true;
        ability.disabled = true;
        emit(events, actorId, ability, "disabled");
    }
}
export function setNightAbilityStartDay(ability, day) {
    ability.startsOnDay = day;
}
export function recordNightAbilityUse(ability, day, consumed) {
    if (abilityStatus(ability, day) !== "active")
        throw new Error("ability_not_active");
    ability.lastUsedDay = day;
    if (consumed)
        ability.uses++;
}
export function initializeNightAbilityInventory(role) {
    role.privateState.abilities = {};
}
export function commitGrantedNightAbility(role, actorId, ability, events, sourceRole) {
    if (isRoleExecutionRetired(role) || isRoleExecutionRetired(sourceRole))
        throw new Error("ability_actor_execution_retired");
    const stored = (role.privateState.abilities ??=
        {});
    if (isRoleExecutionRetired(role) || isRoleExecutionRetired(sourceRole))
        throw new Error("ability_actor_execution_retired");
    stored[ability.id] = ability;
    emit(events, actorId, ability, "granted");
    return ability;
}
function transferPrivateState(role) {
    if (utilTypes.isProxy(role))
        throw new Error("ability_transfer_inventory_invalid");
    const descriptor = Object.getOwnPropertyDescriptor(role, "privateState");
    const value = descriptor && "value" in descriptor ? descriptor.value : undefined;
    if (!value || typeof value !== "object" || utilTypes.isProxy(value))
        throw new Error("ability_transfer_inventory_invalid");
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null)
        throw new Error("ability_transfer_inventory_invalid");
    return value;
}
function transferInventory(privateState) {
    const descriptor = Object.getOwnPropertyDescriptor(privateState, "abilities");
    if (!descriptor) {
        if ("abilities" in privateState)
            throw new Error("ability_transfer_inventory_invalid");
        return undefined;
    }
    if (!("value" in descriptor))
        throw new Error("ability_transfer_inventory_invalid");
    const value = descriptor.value;
    if (value === undefined || value === null)
        return undefined;
    if (typeof value !== "object" || utilTypes.isProxy(value))
        throw new Error("ability_transfer_inventory_invalid");
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null)
        throw new Error("ability_transfer_inventory_invalid");
    for (const key of Reflect.ownKeys(value)) {
        if (!("value" in Object.getOwnPropertyDescriptor(value, key)))
            throw new Error("ability_transfer_inventory_invalid");
    }
    return value;
}
export function commitTransferredNightAbility(world, source, originalPrivateState, target, fromId, toId, id, ability, received, events) {
    if (source === target)
        throw new Error("ability_transfer_inventory_alias");
    if (roleOf(world, fromId) !== source || roleOf(world, toId) !== target)
        throw new Error("ability_transfer_owner_revoked");
    const sourcePrivate = transferPrivateState(source), targetPrivate = transferPrivateState(target);
    if (sourcePrivate !== originalPrivateState)
        throw new Error("ability_transfer_owner_revoked");
    if (sourcePrivate === targetPrivate)
        throw new Error("ability_transfer_inventory_alias");
    const sourceStored = transferInventory(sourcePrivate), targetStored = transferInventory(targetPrivate);
    if (sourceStored === targetStored && sourceStored !== undefined)
        throw new Error("ability_transfer_inventory_alias");
    if (utilTypes.isProxy(ability))
        throw new Error("ability_transfer_inventory_invalid");
    const sourceEntry = sourceStored && Object.getOwnPropertyDescriptor(sourceStored, id), sourceId = Object.getOwnPropertyDescriptor(ability, "id");
    if (!sourceStored || !sourceEntry || !("value" in sourceEntry) || sourceEntry.value !== ability ||
        !sourceId || !("value" in sourceId) || sourceId.value !== id ||
        Reflect.ownKeys(sourceStored).filter((key) => Object.getOwnPropertyDescriptor(sourceStored, key).value === ability).length !== 1)
        throw new Error("ability_transfer_source_slot_invalid");
    if (targetStored && Reflect.ownKeys(targetStored).some((key) => Object.getOwnPropertyDescriptor(targetStored, key).value === ability))
        throw new Error("ability_transfer_inventory_alias");
    if (isRoleExecutionRetired(source) || isRoleExecutionRetired(target))
        throw new Error("ability_transfer_owner_revoked");
    delete sourceStored[id];
    (sourcePrivate.retiredAbilityIds ??= []).push(id);
    if (isRoleExecutionRetired(source) || isRoleExecutionRetired(target))
        throw new Error("ability_transfer_owner_revoked");
    const stored = targetStored ?? (targetPrivate.abilities = {});
    if (isRoleExecutionRetired(source) || isRoleExecutionRetired(target))
        throw new Error("ability_transfer_owner_revoked");
    stored[received.id] = received;
    emit(events, toId, received, "granted");
    emit(events, fromId, ability, "transferred_out");
}
