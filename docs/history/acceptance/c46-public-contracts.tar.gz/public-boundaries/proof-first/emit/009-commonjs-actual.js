"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.canVoteExile = canVoteExile;
exports.canBeExiled = canBeExiled;
exports.canVote = canVote;
exports.canBeSheriff = canBeSheriff;
const domain_1 = require("../domain");
const role_catalog_assembly_1 = require("../rulesets/roles/role-catalog-assembly");
const vote_ports_1 = require("../features/debater/vote-ports");
function canVoteExile(world, id, day, catalog) {
    return canVote(world, id, catalog) && !(0, vote_ports_1.debateVoteBlocked)(world, id, day);
}
function canBeExiled(world, id, catalog = (0, role_catalog_assembly_1.getDefaultRoleCatalog)()) {
    const role = world.getComponent(id, domain_1.COMPONENT.Role);
    return (world.getComponent(id, domain_1.COMPONENT.Alive)?.alive === true &&
        role !== undefined &&
        catalog.participation(role).canBeExiled);
}
function canVote(world, id, catalog = (0, role_catalog_assembly_1.getDefaultRoleCatalog)()) {
    const role = world.getComponent(id, domain_1.COMPONENT.Role);
    return (world.getComponent(id, domain_1.COMPONENT.Alive)?.alive === true &&
        role !== undefined &&
        catalog.participation(role).canVote &&
        world.getComponent(id, domain_1.COMPONENT.VotingRight)?.canVote === true);
}
function canBeSheriff(world, id, catalog = (0, role_catalog_assembly_1.getDefaultRoleCatalog)()) {
    const role = world.getComponent(id, domain_1.COMPONENT.Role);
    return (canVote(world, id, catalog) && role !== undefined && catalog.participation(role).canBeSheriff);
}
