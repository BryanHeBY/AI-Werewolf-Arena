import { copyAbilityData } from "../night-abilities/inventory-ports";
export const freshBlackMarketState = () => ({
    remaining: 1,
    closedDay: null,
    choice: null,
});
export function getBlackMarketState(role) {
    return role?.privateState.black_market_merchant;
}
export function setBlackMarketState(role, state) {
    role.privateState.black_market_merchant =
        copyAbilityData(state);
}
export function projectBlackMarketState(state) {
    return {
        remaining: state.remaining,
        closedDay: state.closedDay,
        choice: state.choice
            ? { day: state.choice.day, targetId: state.choice.targetId, skill: state.choice.skill }
            : null,
    };
}
export function canBlackMarketTrade(state, day) {
    return state.remaining === 1 && day >= 1 && (state.closedDay === null || state.closedDay < day);
}
export function closeBlackMarketTrade(state, day) {
    state.closedDay = day;
}
export function recordBlackMarketTrade(state, day, targetId, skill) {
    state.remaining = 0;
    state.closedDay = day;
    state.choice = { day, targetId, skill };
}
