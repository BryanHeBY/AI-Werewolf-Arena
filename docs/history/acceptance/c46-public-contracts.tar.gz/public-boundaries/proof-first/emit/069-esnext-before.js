export { getWolfKingState } from "../death-actions/native-death-gun-resources";
