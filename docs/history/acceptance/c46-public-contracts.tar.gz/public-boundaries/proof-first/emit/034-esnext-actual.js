export { getHunterState, setHunterState } from "../death-actions/native-resource-ports";
