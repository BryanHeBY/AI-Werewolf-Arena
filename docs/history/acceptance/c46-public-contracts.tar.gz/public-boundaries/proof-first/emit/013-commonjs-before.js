"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.awakenedDeathHook = void 0;
const model_1 = require("../../domain/model");
const native_death_shot_settlement_1 = require("../death-actions/native-death-shot-settlement");
const state_1 = require("./state");
const native_death_gun_resources_1 = require("../death-actions/native-death-gun-resources");
const awakenedDeathHook = (world, ids, sources, choose, events, context) => {
    const readGun = (0, native_death_gun_resources_1.createAwakenedGunReader)({ get getAwakenedState() { return state_1.getAwakenedState; } });
    return (0, native_death_shot_settlement_1.resolveNativeDeathShots)(world, ids, sources, choose, events, {
        role: model_1.Role.AwakenedHiddenWolf,
        state: readGun,
        permits: model_1.permitsDeathShot,
        shotEvent: (actorId, targetId) => ({
            timestamp: Date.now(),
            type: "player_shot",
            payload: { actorId, targetId },
        }),
    }, context);
};
exports.awakenedDeathHook = awakenedDeathHook;
