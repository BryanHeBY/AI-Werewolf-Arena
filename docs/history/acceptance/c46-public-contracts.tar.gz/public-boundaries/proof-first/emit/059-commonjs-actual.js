"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROLE_INSPECTION_STATE_SLOT = void 0;
exports.setRoleInspectionState = setRoleInspectionState;
exports.getRoleInspectionState = getRoleInspectionState;
exports.recordRoleInspection = recordRoleInspection;
exports.recordAbilityRoleInspection = recordAbilityRoleInspection;
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const role_inspection_policy_1 = require("@ai-werewolf-arena/game-contract/role-inspection-policy");
const inventory_ports_2 = require("../night-abilities/inventory-ports");
function setRoleInspectionState(role, state) {
    return (0, inventory_ports_2.commitPreparedNativeAbility)(role, "role_check", exports.ROLE_INSPECTION_STATE_SLOT.create(state));
}
function getRoleInspectionState(role, abilityId) {
    return (0, inventory_ports_1.findNightAbility)(role, "role_check", abilityId)?.state;
}
function recordRoleInspection(state, targetId, day, result) {
    state.lastTarget = targetId;
    state.lastDay = day;
    state.history.push({ day, targetId, result: { ...result } });
}
function recordAbilityRoleInspection(ability, targetId, day, result) {
    ability.state.lastTarget = targetId;
    ability.state.lastDay = day;
    ability.state.history.push({ day, targetId, result: { ...result } });
}
function createRoleInspectionState(state) {
    const ownedState = (0, inventory_ports_1.copyAbilityData)(state);
    (0, role_inspection_policy_1.roleInspectionPolicy)(ownedState);
    return ownedState;
}
function encodeRoleInspectionPolicy(ability) {
    return JSON.stringify([ability.state.policy, ability.state.inspectionPolicy]);
}
function capturedInspectionPayloadChanged(scope) {
    return (scope.ability.state !== scope.inspection ||
        scope.inspection.inspectionPolicy !== scope.inspectionPolicy ||
        (0, role_inspection_policy_1.roleInspectionPolicy)(scope.inspection) !== "gargoyle");
}
exports.ROLE_INSPECTION_STATE_SLOT = Object.freeze({
    create: createRoleInspectionState,
    schema: role_inspection_policy_1.roleInspectionPolicy,
    install: setRoleInspectionState,
    get: getRoleInspectionState,
    allowedWrites: Object.freeze({
        appendState: recordRoleInspection,
        appendAbility: recordAbilityRoleInspection,
    }),
    checkpoint: Object.freeze({ policyIdentity: encodeRoleInspectionPolicy }),
    invalidations: Object.freeze({ payloadChanged: capturedInspectionPayloadChanged }),
});
