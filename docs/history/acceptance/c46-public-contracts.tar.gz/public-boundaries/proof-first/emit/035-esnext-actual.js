import { nativeRolePresentation } from "../../rulesets/roles/presentation-contribution";
import { deathActionConfiguration } from "../death-actions/policy-ports";
import { roleName, text } from "@ai-werewolf-arena/game-text";
import { Camp, Role } from "../../domain/model";
import { getHunterState, setHunterState, createHunterState } from "../death-actions/native-resource-ports";
import { hunterDeathHook } from "./death-hook";
import { HUNTER_TOOL_SPECS } from "./tool-specs";
import { DEATH_SHOT_REPAIR, validateDeathShot } from "../death-actions/tool-ports";
export const HUNTER_ROLE_PROFILE = {
    metadata: {
        role: Role.Hunter,
        camp: Camp.Good,
        label: roleName("hunter"),
        skillBrief: text("zh-CN", "role.hunter.brief"),
        goodSide: "god",
    },
    runtime: {
        configuration: deathActionConfiguration("hunter"),
        init: (roleComp, ctx) => {
            setHunterState(roleComp, createHunterState(ctx));
        },
        toolSpecs: HUNTER_TOOL_SPECS,
        validationRules: {
            shoot: (ctx) => validateDeathShot(ctx, ctx.role.role === Role.Hunter && getHunterState(ctx.role)?.canShoot === true),
        },
        llmRepair: DEATH_SHOT_REPAIR,
        deathHook: hunterDeathHook,
        baselineAction: (_roleComp, request, pickAliveNotSelf) => {
            if (!request.allowedTools.includes("shoot")) {
                return null;
            }
            const target = pickAliveNotSelf();
            return { name: "shoot", args: { target_id: target } };
        },
    },
    presentation: nativeRolePresentation("hunter"),
};
