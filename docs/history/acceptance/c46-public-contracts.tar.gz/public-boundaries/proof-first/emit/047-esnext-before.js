import { captureRadiantTurn } from "../radiant-eclipse/night-frame";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { COMPONENT } from "../../domain/components/names";
import { captureNightLife, livingNightLife } from "../../domain/night-effects";
import { activeNightAbility } from "./abilities";
import { aliveLifeVersion } from "../../domain/components/alive";
import { DREAMER_STATE_SLOT } from "../dreamer/ports";
import { SHELTER_STATE_SLOT } from "../radiant-eclipse/shelter-state-slot";
import { SEER_STATE_SLOT } from "../seer/ports";
import { GUARD_STATE_SLOT } from "../guard/ports";
import { WITCH_STATE_SLOT } from "../witch/ports";
import { ROLE_INSPECTION_STATE_SLOT } from "../role-inspection/ports";
function policyIdentity(ability) {
    switch (ability.kind) {
        case "pair_check":
            return JSON.stringify([ability.state.policy]);
        case "shelter":
            return SHELTER_STATE_SLOT.invalidations.policyIdentity(ability);
        case "seer_check":
            return SEER_STATE_SLOT.invalidations.policyIdentity(ability);
        case "potion":
            return WITCH_STATE_SLOT.invalidations.policyIdentity(ability);
        case "guard":
            return GUARD_STATE_SLOT.invalidations.policyIdentity(ability);
        case "role_check":
            return ROLE_INSPECTION_STATE_SLOT.checkpoint.policyIdentity(ability);
        case "dream":
            return DREAMER_STATE_SLOT.invalidations.policyIdentity(ability);
    }
}
export function captureNightAbilityScope(world, actorId, ability, day, phaseCurrent) {
    const role = world.getComponent(actorId, COMPONENT.Role), life = captureNightLife(world, actorId);
    if (!role || !life)
        return null;
    const radiantCurrent = captureRadiantTurn(world, actorId, ability, day);
    const roleKind = role.role, camp = world.getComponent(actorId, COMPONENT.Camp)?.camp, privateState = role.privateState;
    const state = ability.state, kind = ability.kind, activation = ability.activation, id = ability.id;
    const source = ability.source, sourceKind = source.kind, sourceOwner = source.kind === "native" ? source.role : source.actorId, sourceId = source.kind === "copy" || source.kind === "transfer" ? source.abilityId : undefined;
    const policy = policyIdentity(ability);
    const starts = ability.startsOnDay, expires = ability.expiresAfterDay, maxUses = ability.maxUses, disclosed = ability.sourceDisclosed;
    const ownerCurrent = (allowFirstDeath = false) => phaseCurrent() &&
        world.getComponent(actorId, COMPONENT.Role) === role &&
        role.role === roleKind &&
        world.getComponent(actorId, COMPONENT.Camp)?.camp === camp &&
        role.privateState === privateState &&
        (livingNightLife(world, life) ||
            (allowFirstDeath &&
                world.getComponent(actorId, COMPONENT.Alive) === life.life &&
                !life.life.alive &&
                aliveLifeVersion(life.life) === life.version + 1)) &&
        ability.id === id &&
        ability.kind === kind &&
        ability.activation === activation &&
        ability.state === state &&
        policyIdentity(ability) === policy &&
        role.privateState.abilities?.[id] === ability &&
        ability.source === source &&
        source.kind === sourceKind &&
        (source.kind === "native" ? source.role : source.actorId) === sourceOwner &&
        (source.kind === "copy" || source.kind === "transfer" ? source.abilityId : undefined) ===
            sourceId &&
        ability.startsOnDay === starts &&
        ability.expiresAfterDay === expires &&
        ability.maxUses === maxUses &&
        ability.sourceDisclosed === disclosed;
    return {
        role,
        life,
        state,
        isOwnerCurrent: ownerCurrent,
        isEligible: () => radiantCurrent() &&
            ownerCurrent() &&
            !isRoleExecutionRetired(role) &&
            activeNightAbility(role, kind, day, id) === ability,
    };
}
