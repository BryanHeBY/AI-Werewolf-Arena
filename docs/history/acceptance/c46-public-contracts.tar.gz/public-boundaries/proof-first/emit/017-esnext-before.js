import { copyAbilityData } from "../night-abilities/abilities";
import { createLearnedNativeGun, armAwakenedNativeGun } from "../death-actions/native-death-gun-resources";
const validDay = (day) => Number.isSafeInteger(day) && day >= 1 && day < Number.MAX_SAFE_INTEGER;
const validTarget = (id) => Number.isSafeInteger(id) && id >= 1;
export function freshAwakenedState() {
    return {
        learned: null,
        mimicClosedDay: null,
        skillClosedDay: null,
        hasInheritedKnife: false,
        firstKnifeNight: null,
    };
}
export function getAwakenedState(role) {
    return role?.privateState.awakened_hidden_wolf;
}
export function setAwakenedState(role, state) {
    const owned = copyAbilityData(state);
    role.privateState.awakened_hidden_wolf = owned;
    return owned;
}
export function awakenedLearning(targetId, role, day) {
    if (!validDay(day) || !validTarget(targetId))
        throw new Error("awakened_learning_input_invalid");
    let skill;
    switch (role) {
        case "villager":
            skill = { kind: "villager" };
            break;
        case "mirror_girl":
            skill = { kind: "inspection", abilityId: null };
            break;
        case "witch":
            skill = { kind: "poison", remaining: 1 };
            break;
        case "guard":
            skill = { kind: "guard", lastTarget: null, lastGuardDay: null };
            break;
        case "hunter":
            skill = createLearnedNativeGun();
            break;
        case "wolf":
            skill = { kind: "wolf", extraKnife: "available" };
            break;
        default:
            throw new Error("awakened_learning_role_not_supported");
    }
    return { targetId, role, day, activationNight: null, activeFromNight: null, skill };
}
export function canAwakenedMimic(state, day) {
    return (validDay(day) &&
        state.learned === null &&
        (state.mimicClosedDay === null || state.mimicClosedDay < day));
}
export function closeAwakenedMimic(state, day, mayCommit) {
    if (!canAwakenedMimic(state, day))
        return false;
    if (mayCommit && !mayCommit())
        return false;
    state.mimicClosedDay = day;
    return true;
}
export function learnAwakenedRole(state, targetId, role, day, mayCommit) {
    if (!canAwakenedMimic(state, day))
        return false;
    const learned = awakenedLearning(targetId, role, day);
    if (mayCommit && !mayCommit())
        return false;
    state.learned = learned;
    state.mimicClosedDay = day;
    return true;
}
export function activateAwakenedLearning(state, night, mirrorAbilityId, mayCommit) {
    const learned = state.learned;
    if (!learned || !validDay(night) || night < learned.day || learned.activationNight !== null)
        return false;
    if (learned.skill.kind === "inspection" &&
        (typeof mirrorAbilityId !== "string" || !mirrorAbilityId.length))
        return false;
    if (learned.skill.kind !== "inspection" && mirrorAbilityId !== undefined)
        return false;
    let committed = false;
    const firstWrite = () => {
        if (committed)
            return true;
        if (mayCommit && !mayCommit())
            return false;
        committed = true;
        return true;
    };
    if (learned.skill.kind === "inspection") {
        const skill = learned.skill;
        if (!firstWrite())
            return "retired";
        skill.abilityId = mirrorAbilityId;
    }
    if (mayCommit) {
        if (!armAwakenedNativeGun(learned, firstWrite))
            return "retired";
    }
    else
        armAwakenedNativeGun(learned);
    if (!firstWrite())
        return "retired";
    learned.activationNight = night;
    learned.activeFromNight = night + 1;
    return true;
}
export function awakenedSkillForNight(state, night) {
    const learned = state.learned;
    if (!validDay(night) ||
        !learned ||
        learned.activationNight === null ||
        learned.activeFromNight === null ||
        night < learned.activeFromNight ||
        (state.skillClosedDay !== null && state.skillClosedDay >= night))
        return undefined;
    if (learned.skill.kind === "poison" && learned.skill.remaining === 0)
        return undefined;
    if (learned.skill.kind === "wolf" && learned.skill.extraKnife === "spent")
        return undefined;
    return learned.skill.kind === "poison" ||
        learned.skill.kind === "guard" ||
        learned.skill.kind === "wolf"
        ? learned.skill
        : undefined;
}
export function closeAwakenedSkill(state, night, mayCommit) {
    if (!awakenedSkillForNight(state, night))
        return false;
    if (mayCommit && !mayCommit())
        return false;
    state.skillClosedDay = night;
    return true;
}
export function recordAwakenedInheritance(state, day) {
    if (!validDay(day) || state.hasInheritedKnife)
        return false;
    state.hasInheritedKnife = true;
    state.firstKnifeNight = Math.max(2, day + 1);
    return true;
}
export function awakenedKnifeReady(state, night) {
    return (validDay(night) &&
        state.hasInheritedKnife &&
        state.firstKnifeNight !== null &&
        night >= state.firstKnifeNight);
}
export function canAwakenedExtraKnife(state, night) {
    const skill = awakenedSkillForNight(state, night);
    return (awakenedKnifeReady(state, night) && skill?.kind === "wolf" && skill.extraKnife === "available");
}
export function chooseAwakenedAttack(state, targetId, night, mayCommit) {
    if (!canAwakenedExtraKnife(state, night) || (targetId !== null && !validTarget(targetId)))
        return false;
    const skill = state.learned.skill;
    if (skill.kind !== "wolf")
        return false;
    if (mayCommit && !mayCommit())
        return false;
    if (targetId !== null)
        skill.extraKnife = "spent";
    state.skillClosedDay = night;
    return true;
}
export function chooseAwakenedGuard(state, targetId, night, mayCommit) {
    const skill = awakenedSkillForNight(state, night);
    if (skill?.kind !== "guard" ||
        (targetId !== null && !validTarget(targetId)) ||
        (targetId !== null && skill.lastTarget === targetId && skill.lastGuardDay === night - 1))
        return false;
    if (mayCommit && !mayCommit())
        return false;
    skill.lastTarget = targetId;
    skill.lastGuardDay = night;
    state.skillClosedDay = night;
    return true;
}
export function skipAwakenedSkill(state, night, mayCommit) {
    const skill = awakenedSkillForNight(state, night);
    if (!skill)
        return false;
    if (skill.kind === "guard")
        return chooseAwakenedGuard(state, null, night, mayCommit);
    if (skill.kind === "wolf")
        return chooseAwakenedAttack(state, null, night, mayCommit);
    return closeAwakenedSkill(state, night, mayCommit);
}
export function useAwakenedPoison(state, night, mayCommit) {
    const skill = awakenedSkillForNight(state, night);
    if (skill?.kind !== "poison" || skill.remaining !== 1)
        return false;
    if (mayCommit && !mayCommit())
        return false;
    skill.remaining = 0;
    state.skillClosedDay = night;
    return true;
}
export function projectAwakenedState(state) {
    const learned = state.learned;
    let skill;
    if (learned)
        switch (learned.skill.kind) {
            case "villager":
                skill = { kind: "villager" };
                break;
            case "inspection":
                skill = { kind: "inspection", abilityId: learned.skill.abilityId };
                break;
            case "poison":
                skill = { kind: "poison", remaining: learned.skill.remaining };
                break;
            case "guard":
                skill = {
                    kind: "guard",
                    lastTarget: learned.skill.lastTarget,
                    lastGuardDay: learned.skill.lastGuardDay,
                };
                break;
            case "hunter":
                skill = { kind: "hunter", armed: learned.skill.armed, canShoot: learned.skill.canShoot };
                break;
            case "wolf":
                skill = { kind: "wolf", extraKnife: learned.skill.extraKnife };
                break;
        }
    return {
        learned: learned && skill
            ? {
                targetId: learned.targetId,
                role: learned.role,
                day: learned.day,
                activationNight: learned.activationNight,
                activeFromNight: learned.activeFromNight,
                skill,
            }
            : null,
        mimicClosedDay: state.mimicClosedDay,
        skillClosedDay: state.skillClosedDay,
        hasInheritedKnife: state.hasInheritedKnife,
        firstKnifeNight: state.firstKnifeNight,
    };
}
