import { RuleError } from "@ai-werewolf-arena/game-contract";
import { COMMON_VALIDATION_RULES } from "./common-validation-rules";
import { getDefaultRoleCatalog } from "../../rulesets/roles/role-catalog-assembly";
import { SHERIFF_VALIDATION_RULES } from "../../features/sheriff/validation-rules";
import { validateGiftGun } from "../../features/death-actions/death-abilities";
function buildDefaultRules(roleProfileRegistry) {
    const rules = {
        ...COMMON_VALIDATION_RULES,
        ...SHERIFF_VALIDATION_RULES,
    };
    for (const { runtime: profile } of roleProfileRegistry.allRuntime()) {
        if (profile.validationRules) {
            Object.assign(rules, profile.validationRules);
        }
    }
    return rules;
}
export class ToolValidationRuleRegistry {
    roleProfileRegistry;
    rules;
    useProfileRules;
    constructor(rules, roleProfileRegistry = getDefaultRoleCatalog()) {
        this.roleProfileRegistry = roleProfileRegistry;
        this.rules = { ...(rules ?? buildDefaultRules(roleProfileRegistry)) };
        this.useProfileRules = rules === undefined;
    }
    validate(ctx) {
        if (this.useProfileRules && ctx.toolCall.name === "shoot" && ctx.abilityId !== undefined)
            return validateGiftGun({ ...ctx, roleCatalog: this.roleProfileRegistry });
        const rule = (this.useProfileRules
            ? this.roleProfileRegistry.runtime(ctx.role.role)?.validationRules?.[ctx.toolCall.name]
            : undefined) ?? this.rules[ctx.toolCall.name];
        if (!rule) {
            return { code: RuleError.UnknownTool };
        }
        const result = rule({ ...ctx, roleCatalog: this.roleProfileRegistry });
        return !result
            ? null
            : typeof result === "string"
                ? { code: RuleError.CustomRuleError, message: result }
                : result;
    }
}
let defaultRegistry = null;
export function getDefaultToolValidationRuleRegistry() {
    if (!defaultRegistry) {
        defaultRegistry = new ToolValidationRuleRegistry();
    }
    return defaultRegistry;
}
