import { Role } from "@ai-werewolf-arena/game-contract";
import { allNightAbilities } from "../night-abilities/inventory-ports";
export const freshMirrorInspectionState = () => ({
    policy: "mirror",
    lastTarget: null,
    lastDay: null,
    history: [],
});
export const nativeMirror = (role) => allNightAbilities(role).find((ability) => ability.kind === "role_check" &&
    ability.source.kind === "native" &&
    ability.source.role === Role.MirrorGirl);
