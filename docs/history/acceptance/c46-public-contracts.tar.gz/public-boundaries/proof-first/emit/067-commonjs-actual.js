"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativePotionsCanCombine = nativePotionsCanCombine;
exports.witchKnifeVisible = witchKnifeVisible;
exports.nativePotionSecondTurn = nativePotionSecondTurn;
const model_1 = require("../../domain/model");
function nativePotionsCanCombine(ability) {
    return (ability.source.kind === "native" &&
        ability.state.potionPolicy === "awa_both_native_experimental_v1");
}
function witchKnifeVisible(ability) {
    const policy = ability.source.kind === "native" && ability.source.role === model_1.Role.Witch
        ? ability.state.knifeVisibility
        : undefined;
    if (policy === "awa_always_v1")
        return true;
    return (ability.state.heal > 0 &&
        !ability.state.healUsedThisNight &&
        (nativePotionsCanCombine(ability) || !ability.state.poisonUsedThisNight));
}
function nativePotionSecondTurn(ability, day) {
    return (nativePotionsCanCombine(ability) &&
        ability.state.potionTurnClosedDay !== day &&
        ((ability.state.healUsedThisNight &&
            !ability.state.poisonUsedThisNight &&
            ability.state.poison > 0) ||
            (ability.state.poisonUsedThisNight &&
                !ability.state.healUsedThisNight &&
                ability.state.heal > 0)));
}
