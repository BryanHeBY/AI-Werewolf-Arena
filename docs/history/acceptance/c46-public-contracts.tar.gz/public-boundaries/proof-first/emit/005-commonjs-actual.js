"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeathResolution = void 0;
const wolf_knife_inheritance_plan_1 = require("../rulesets/wolf-knife-inheritance-plan");
const ports_1 = require("../features/animal-dream/ports");
const death_wave_1 = require("./death-wave");
const death_committer_1 = require("./death-committer");
const fragrant_pair_seer_1 = require("@ai-werewolf-arena/game-contract/facts/fragrant-pair-seer");
const ports_2 = require("../features/fragrant-pair-seer/ports");
const death_shot_selection_1 = require("../rulesets/death-shot-selection");
const initial_death_relations_1 = require("../rulesets/initial-death-relations");
const ports_3 = require("../features/ghost-bride/ports");
const additional_death_relations_1 = require("../rulesets/additional-death-relations");
const night_effects_1 = require("../domain/night-effects");
const names_1 = require("../domain/components/names");
const model_1 = require("../domain/model");
const grant_ports_1 = require("../features/last-words/grant-ports");
const window_ports_1 = require("../features/last-words/window-ports");
const choice_ports_1 = require("../features/sheriff/choice-ports");
const action_request_factory_1 = require("./actions/action-request-factory");
const gift_gun_ports_1 = require("../features/death-actions/gift-gun-ports");
class DeathResolution {
    world;
    events;
    toolGateway;
    eventRegistry;
    state;
    config;
    weddingDeathWave = (() => {
        const resolution = this;
        return new ports_3.WeddingDeathWavePublication({
            get world() {
                return resolution.world;
            },
            get events() {
                return resolution.events;
            },
            get day() {
                return resolution.state.day;
            },
            get phase() {
                return resolution.state.phase;
            },
        });
    })();
    lastWordsMechanism = (0, grant_ports_1.getDefaultLastWordsMechanism)();
    lastWordsWindow = (() => {
        const resolution = this;
        return new window_ports_1.LastWordsWindow({
            get requestFactory() { return action_request_factory_1.GameActionRequestFactory; },
            get world() { return resolution.world; },
            get events() { return resolution.events; },
            get state() { return resolution.state; },
            get toolGateway() { return resolution.toolGateway; },
            get lastWordsMechanism() { return resolution.lastWordsMechanism; },
        });
    })();
    deathCommitter = (() => {
        const resolution = this;
        return new death_committer_1.DeathCommitter({
            get world() {
                return resolution.world;
            },
            get events() {
                return resolution.events;
            },
            get state() {
                return resolution.state;
            },
        });
    })();
    fragrantDeathWave = (() => {
        const resolution = this;
        return new ports_2.FragrantDeathWavePublication({
            actorId: () => resolution.world.getEntityIdsByRole(model_1.Role.FragrantPhantom)[0],
            get phase() {
                return resolution.state.phase;
            },
            get day() {
                return resolution.state.day;
            },
            get events() {
                return resolution.events;
            },
            publish(receipt, event) {
                (0, ports_2.publishFragrantDeathWave)(resolution.world, receipt, event);
            },
        });
    })();
    constructor(world, events, toolGateway, eventRegistry, state, config) {
        this.world = world;
        this.events = events;
        this.toolGateway = toolGateway;
        this.eventRegistry = eventRegistry;
        this.state = state;
        this.config = config;
    }
    async resolve(deadIds, sources, actionProvider, phase, lastWordsPhase, deathPhases = {}, nightEffects) {
        const resolutionPhase = this.state.phase;
        const resolutionDay = this.state.day;
        const lastWordsPolicy = this.config?.lastWords?.policy ?? "awa_initial_wave_v1";
        const revealPolicy = this.config?.disclosure?.deathRevealPolicy ?? "awa_hidden_v1";
        const ownsFragrant = (0, ports_2.isFragrantPairBoard)(this.world);
        const isCurrent = () => this.state.phase === resolutionPhase &&
            this.state.day === resolutionDay &&
            !this.state.gameOver &&
            (nightEffects?.isCurrent?.() ?? true) &&
            (!ownsFragrant || !!(0, ports_2.fragrantAuthoritySnapshot)(this.world));
        const revealCurrent = () => revealPolicy === "netease_2017_open_v1" &&
            this.config?.disclosure?.deathRevealPolicy === revealPolicy;
        const lastWordsCurrent = () => isCurrent() && (this.config?.lastWords?.policy ?? "awa_initial_wave_v1") === lastWordsPolicy;
        const resolution = this;
        const animalDeathWave = ports_1.AnimalDeathWavePreparation.fromRuntime({
            get world() {
                return resolution.world;
            },
            get events() {
                return resolution.events;
            },
        }, resolutionDay, nightEffects, isCurrent);
        const ownsAnimal = animalDeathWave.enabled;
        const preparedSources = structuredClone(sources);
        (0, death_wave_1.preflightDeathWaveData)(deadIds, preparedSources, deathPhases);
        deadIds = animalDeathWave.prepare(deadIds, preparedSources, phase);
        const seen = new Set(deadIds.filter((id) => {
            return (this.world.getComponent(id, names_1.COMPONENT.Alive) !== undefined &&
                !this.deathCommitter.isSettledLife(id));
        }));
        let pending = [...seen];
        const allSources = preparedSources;
        const nativeHunterShotTargets = new Set();
        const initialPhases = structuredClone(deathPhases);
        const nightOrigin = new Set(nightEffects?.nightOriginIds ?? []);
        if (!isCurrent())
            return;
        const { fragrantInitial, originPhases } = (0, initial_death_relations_1.prepareInitialDeathRelations)({
            wedding: () => this.weddingDeathWave,
            world: () => this.world,
            events: () => this.events,
            phase: () => phase,
            resolutionDay: () => resolutionDay,
            ownsFragrant: () => ownsFragrant,
            dreams: () => nightEffects?.dreams,
        }, pending, allSources, seen, nightOrigin, initialPhases);
        const initialUnit = (0, death_wave_1.openDeathWave)("initial", resolutionDay, resolutionPhase, (0, death_wave_1.deathExecutionContext)(nightEffects));
        let pendingUnits = [initialUnit];
        let previousCommits = [];
        let firstBatch = true;
        let fragrantInitialCommitted = false;
        const gunsToExpire = [];
        try {
            if (pending.length === 0 && nightEffects?.onInitialWaveCommitted && isCurrent()) {
                const receipt = new death_wave_1.DeathCommitReceipt((0, death_wave_1.planDeathWave)([], {}, "initial", originPhases, (0, death_wave_1.deathWaveOriginalLives)(nightEffects), (0, death_wave_1.deathWavePoisonMetadata)(nightEffects), pendingUnits), Object.freeze([]));
                const event = nightEffects.onInitialWaveCommitted([], {}, receipt);
                receipt.recordPublication(event, []);
            }
            while (pending.length > 0) {
                if (!isCurrent())
                    return;
                const deathPhase = firstBatch ? phase : this.state.phase;
                const receipt = this.deathCommitter.markPlayersDead(pending, true, gunsToExpire, revealPolicy === "netease_2017_open_v1", allSources, nightEffects?.animalUnit ?? isCurrent, (0, death_wave_1.planDeathWave)(pending, allSources, firstBatch ? "initial" : "revisit", originPhases, (0, death_wave_1.deathWaveOriginalLives)(nightEffects), (0, death_wave_1.deathWavePoisonMetadata)(nightEffects), pendingUnits, previousCommits));
                if (firstBatch && fragrantInitial) {
                    (0, ports_2.commitFragrantDeathWave)(this.world, fragrantInitial);
                    fragrantInitialCommitted = true;
                }
                if (ownsFragrant && firstBatch)
                    this.fragrantDeathWave.recordCommittedWave(firstBatch ? fragrantInitial : null, pending, allSources, originPhases, firstBatch);
                if (firstBatch && nightEffects?.onInitialWaveCommitted) {
                    const event = nightEffects.onInitialWaveCommitted(pending, allSources, receipt);
                    receipt.recordPublication(event, pending);
                    this.fragrantDeathWave.publishVisibleWave(fragrantInitial, event);
                }
                if (ownsAnimal && firstBatch)
                    animalDeathWave.recordInitialWave(pending, allSources, deathPhase);
                if (firstBatch &&
                    fragrantInitial?.addedTargetId !== null &&
                    fragrantInitial?.addedTargetId !== undefined) {
                    const event = {
                        timestamp: Date.now(),
                        type: "additional_deaths",
                        payload: { deaths: [fragrantInitial.addedTargetId] },
                    };
                    this.events.push(event);
                    receipt.recordPublication(event, [fragrantInitial.addedTargetId]);
                    this.fragrantDeathWave.publishVisibleWave(fragrantInitial, event);
                }
                this.eventRegistry.onCommittedDeathWave(this.world, pending, allSources, resolutionDay, deathPhase, this.events);
                nightEffects?.dreams?.recordDeaths(pending, this.events);
                if ((firstBatch || lastWordsPolicy === "netease_2017_day_and_first_night_v1") &&
                    lastWordsCurrent()) {
                    const wordsPhases = firstBatch
                        ? initialPhases
                        : Object.fromEntries(pending.map((id) => [id, nightOrigin.has(id) ? model_1.Phase.Night : deathPhase]));
                    const wordsContext = ownsFragrant
                        ? { policy: fragrant_pair_seer_1.FRAGRANT_PAIR_POLICY, initialWave: firstBatch }
                        : undefined;
                    this.lastWordsMechanism.recordLastWordsGranted(this.world, pending, phase, lastWordsPhase, this.state.day, this.events, allSources, wordsPhases, lastWordsPolicy, wordsContext);
                    await this.lastWordsWindow.collect(pending, lastWordsPhase, phase, allSources, actionProvider, wordsPhases, lastWordsCurrent, lastWordsPolicy, wordsContext);
                }
                if (!isCurrent())
                    return;
                for (const deadId of pending) {
                    const causes = allSources[deadId] ?? [];
                    const actualDeathPhase = firstBatch ? (initialPhases[deadId] ?? deathPhase) : deathPhase;
                    const reason = causes.includes(model_1.DeathCause.SelfDestruct)
                        ? "self_destruct"
                        : causes.includes(model_1.DeathCause.Exile)
                            ? "voted_out"
                            : `${actualDeathPhase}_death`;
                    await (0, choice_ports_1.resolveSheriffBadge)(this.world, deadId, reason, this.events, this.toolGateway, actionProvider, resolutionPhase, resolutionDay, isCurrent, {
                        get requestFactory() { return action_request_factory_1.GameActionRequestFactory; },
                    });
                    if (!isCurrent())
                        return;
                }
                const next = new Set();
                const nextCommits = [];
                const nextUnits = [];
                for (const deadId of pending) {
                    if (!isCurrent())
                        return;
                    const sourcePhase = originPhases.get(deadId) ?? (nightOrigin.has(deadId) ? model_1.Phase.Night : deathPhase);
                    const actions = {
                        phase: resolutionPhase,
                        day: resolutionDay,
                        permits: [],
                        isCurrent,
                    };
                    try {
                        await this.eventRegistry.onDeath(this.world, [deadId], allSources, (actorId, abilityId) => (0, death_shot_selection_1.collectDeathShot)({
                            get world() { return resolution.world; },
                            get events() { return resolution.events; },
                            get toolGateway() { return resolution.toolGateway; },
                            get state() { return resolution.state; },
                            get config() { return resolution.config; },
                        }, actorId, firstBatch ? (initialPhases[actorId] ?? deathPhase) : deathPhase, sourcePhase, allSources, actionProvider, actions, abilityId, nightOrigin.has(actorId) && !(firstBatch && initialPhases[actorId] === model_1.Phase.Day)), this.events, (result) => {
                            if (!isCurrent())
                                return;
                            const proposed = [...result.extraDeaths], proposedSources = structuredClone(result.extraDeathSources), nightTargets = [...(result.nightEffectTargets ?? [])];
                            (0, death_wave_1.preflightDeathWaveData)(proposed, proposedSources);
                            (0, death_wave_1.preflightDeathWaveData)(nightTargets, {});
                            const additionalUnit = (0, death_wave_1.openDeathWave)("additional", resolutionDay, resolutionPhase, (0, death_wave_1.deathExecutionContext)(nightEffects));
                            const shots = new Map((result.pendingShots ?? []).map((shot) => [shot.targetScope.id, shot]));
                            for (const [id, shot] of shots) {
                                if ((0, night_effects_1.livingNightLife)(this.world, shot.targetScope) && (shot.isCurrent?.() ?? true))
                                    continue;
                                proposedSources[id] = (proposedSources[id] ?? []).filter((cause) => cause !== model_1.DeathCause.Shot);
                                if (!proposedSources[id].length) {
                                    const index = proposed.indexOf(id);
                                    if (index >= 0)
                                        proposed.splice(index, 1);
                                }
                                if (!proposedSources[id].length)
                                    for (let i = nightTargets.length - 1; i >= 0; i--)
                                        if (nightTargets[i] === id)
                                            nightTargets.splice(i, 1);
                                shots.delete(id);
                            }
                            const linked = new Set(), publicLinked = [];
                            let newlyMarked = false;
                            const marked = [];
                            const additionalReceipts = [];
                            const resolution = this;
                            const preparedContributions = (result.deathWaveContributions ?? []).map((contribution) => contribution.prepare({
                                get world() {
                                    return resolution.world;
                                },
                                get events() {
                                    return resolution.events;
                                },
                                blocksNightLinkedDeath: (target) => nightEffects?.dreams?.blocksNightCharm(this.world, target(), seen),
                            }, proposed, proposedSources, nightTargets, allSources, nativeHunterShotTargets, seen));
                            const contributedCauses = new Map();
                            const publicContributionTargets = new Set();
                            for (const contribution of preparedContributions)
                                for (const linkedDeath of contribution.linkedDeaths) {
                                    contributedCauses.set(linkedDeath.targetId, [
                                        ...new Set([
                                            ...(contributedCauses.get(linkedDeath.targetId) ?? []),
                                            ...linkedDeath.addedCauses,
                                        ]),
                                    ]);
                                    if (linkedDeath.publicAdditionalDeath)
                                        publicContributionTargets.add(linkedDeath.targetId);
                                }
                            const additionalRelations = (0, additional_death_relations_1.prepareAdditionalDeathRelations)({
                                world: () => this.world,
                                events: () => this.events,
                                wedding: () => this.weddingDeathWave,
                                dreams: () => nightEffects?.dreams,
                                isSettledLife: (id) => this.deathCommitter.isSettledLife(id),
                                phase: () => this.state.phase,
                            }, { proposed, proposedSources, nightTargets, allSources, next, seen, nightOrigin, linked, ownsFragrant, resolutionDay, sourcePhase });
                            const { fragrantGun } = additionalRelations;
                            let fragrantGunCommitted = false;
                            try {
                                for (const id of proposed) {
                                    if (next.has(id)) {
                                        allSources[id] = [
                                            ...new Set([...(allSources[id] ?? []), ...(proposedSources[id] ?? [])]),
                                        ];
                                        continue;
                                    }
                                    if (seen.has(id) || this.deathCommitter.isSettledLife(id)) {
                                        if ((proposedSources[id] ?? []).includes(model_1.DeathCause.Lovers))
                                            allSources[id] = [
                                                ...new Set([...(allSources[id] ?? []), model_1.DeathCause.Lovers]),
                                            ];
                                        if (linked.has(id))
                                            allSources[id] = [
                                                ...new Set([...(allSources[id] ?? []), model_1.DeathCause.Dream]),
                                            ];
                                        if (contributedCauses.has(id))
                                            allSources[id] = [
                                                ...new Set([...(allSources[id] ?? []), ...contributedCauses.get(id)]),
                                            ];
                                        continue;
                                    }
                                    if (!this.world.getComponent(id, names_1.COMPONENT.Alive))
                                        continue;
                                    if (ownsAnimal &&
                                        !animalDeathWave.prepare([id], proposedSources, sourcePhase).includes(id))
                                        continue;
                                    let shot = shots.get(id);
                                    if (shot &&
                                        (!(0, night_effects_1.livingNightLife)(this.world, shot.targetScope) ||
                                            (!fragrantGun && shot.isCurrent?.() === false))) {
                                        proposedSources[id] = (proposedSources[id] ?? []).filter((cause) => cause !== model_1.DeathCause.Shot);
                                        shots.delete(id);
                                        shot = undefined;
                                        if (!proposedSources[id].length)
                                            continue;
                                    }
                                    seen.add(id);
                                    allSources[id] = [...new Set(proposedSources[id] ?? [])];
                                    originPhases.set(id, additionalRelations.originPhase());
                                    const commitIds = [id];
                                    const receipt = this.deathCommitter.markPlayersDead(commitIds, false, gunsToExpire, revealCurrent(), allSources, nightEffects?.animalUnit ?? isCurrent, (0, death_wave_1.planDeathWave)(commitIds, allSources, "additional", originPhases, shot ? new Map([[id, shot.targetScope]]) : undefined, [], [additionalUnit]));
                                    additionalReceipts.push(receipt);
                                    nextCommits.push(receipt);
                                    if (ownsAnimal)
                                        animalDeathWave.recordAdditionalDeath(id, allSources, sourcePhase);
                                    newlyMarked = true;
                                    marked.push(id);
                                    if (shot) {
                                        if (shot.event.type === "hunter_shot")
                                            nativeHunterShotTargets.add(id);
                                        this.events.push(shot.event);
                                        receipt.recordPublication(shot.event, [id]);
                                    }
                                    if (publicContributionTargets.has(id) ||
                                        (linked.has(id) && !result.extraDeaths.includes(id)) ||
                                        (!shot && !(proposedSources[id] ?? []).includes(model_1.DeathCause.Shot)))
                                        publicLinked.push(id);
                                    next.add(id);
                                }
                                if (newlyMarked) {
                                    nextUnits.push(additionalUnit);
                                    if (fragrantGun) {
                                        (0, ports_2.commitFragrantDeathWave)(this.world, fragrantGun);
                                        fragrantGunCommitted = true;
                                    }
                                    if (ownsFragrant)
                                        this.fragrantDeathWave.recordCommittedWave(fragrantGun, marked, allSources, originPhases, false);
                                    (0, wolf_knife_inheritance_plan_1.refreshWolfKnifeInheritanceAtCheckpoint)({
                                        world: () => this.world,
                                        events: () => this.events,
                                        day: () => this.state.day,
                                    });
                                }
                                if (publicLinked.length) {
                                    const event = {
                                        timestamp: Date.now(),
                                        type: "additional_deaths",
                                        payload: { deaths: publicLinked },
                                    };
                                    this.events.push(event);
                                    for (const receipt of additionalReceipts)
                                        receipt.recordPublication(event, publicLinked.filter((id) => receipt.committed(id) !== undefined));
                                    this.fragrantDeathWave.publishVisibleWave(fragrantGun, event);
                                }
                                for (const contribution of preparedContributions)
                                    contribution.publishAfterDeaths();
                                nightEffects?.dreams?.recordDeaths([...next, ...linked], this.events);
                                for (const permit of actions.permits.splice(0))
                                    permit.close();
                            }
                            finally {
                                if (fragrantGun && !fragrantGunCommitted)
                                    (0, ports_2.cancelFragrantDeathWave)(this.world, fragrantGun);
                            }
                        }, Object.freeze({
                            day: resolutionDay,
                            nativeHunterShotTargets,
                            deferShotCommit: true,
                            deathOriginPhase: sourcePhase,
                            nightEffect: nightOrigin.has(deadId),
                            blocksNightShot: (targetId) => (nightEffects?.blocksPassiveNightShot?.(targetId) ?? false) ||
                                (nightEffects?.dreams?.blocksNightShot(this.world, targetId) ?? false),
                            blocksNightCharm: (targetId) => nightEffects?.dreams?.blocksNightCharm(this.world, targetId, seen) ?? false,
                            eligibleDead: seen,
                            isCurrent,
                        }));
                    }
                    finally {
                        for (const permit of actions.permits)
                            permit.close();
                    }
                }
                pending = [...next];
                pendingUnits = nextUnits;
                previousCommits = nextCommits;
                firstBatch = false;
            }
        }
        finally {
            if (fragrantInitial && !fragrantInitialCommitted)
                (0, ports_2.cancelFragrantDeathWave)(this.world, fragrantInitial);
            (0, gift_gun_ports_1.finishDeathGuns)(gunsToExpire, this.events);
        }
    }
}
exports.DeathResolution = DeathResolution;
