import { closeBlackMarketTrade, recordBlackMarketTrade } from "./state";
import { COMPONENT } from "../../domain/components/names";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { Camp, Role, Phase, WitchSelfHealRule } from "../../domain/model";
import { aliveLifeVersion } from "../../domain/components/alive";
import { captureNightLife, livingNightLife } from "../../domain/night-effects";
import { grantNightAbility } from "../night-abilities/grant-ports";
import { grantDeathGun } from "../death-actions/gift-gun-ports";
import { recipientAbilityStage } from "../night-abilities/recipient-stage-ports";
import { canBlackMarketTrade, getBlackMarketState } from "./state";
const committed = new WeakMap();
export function hasBlackMarketNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
function recordCommit(world, day) {
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
export const BLACK_MARKET_RECIPIENT_STAGE = recipientAbilityStage("black_market", 140);
export const BLACK_MARKET_TRADE_STAGE = {
    id: "black_market_merchant",
    priority: 130,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const actorId of ctx.getAliveByRole(Role.BlackMarketMerchant)) {
            const role = ctx.world.getComponent(actorId, COMPONENT.Role), state = getBlackMarketState(role), life = captureNightLife(ctx.world, actorId);
            if (!state || !life || ctx.world.getComponent(actorId, COMPONENT.Camp)?.camp !== Camp.Good)
                continue;
            const privateState = role.privateState;
            const ownerCurrent = (paid = false) => ctx.isCurrent() &&
                ctx.currentDay() === day &&
                ctx.world.getComponent(actorId, COMPONENT.Role) === role &&
                role.role === Role.BlackMarketMerchant &&
                ctx.world.getComponent(actorId, COMPONENT.Camp)?.camp === Camp.Good &&
                role.privateState === privateState &&
                getBlackMarketState(role) === state &&
                (livingNightLife(ctx.world, life) ||
                    (paid &&
                        ctx.world.getComponent(actorId, COMPONENT.Alive) === life.life &&
                        !life.life.alive &&
                        aliveLifeVersion(life.life) === life.version + 1));
            const current = () => ownerCurrent() && canBlackMarketTrade(state, day) && !isRoleExecutionRetired(role);
            if (!current())
                continue;
            const skip = () => {
                const closeTrade = closeBlackMarketTrade;
                if (isRoleExecutionRetired(role))
                    return;
                closeTrade(state, day);
                recordCommit(ctx.world, day);
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "black_market_trade_skipped",
                    payload: { actorId, day },
                });
            };
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current())
                    break;
                const targets = new Map(ctx.world
                    .getAliveEntityIds()
                    .filter((id) => id !== actorId)
                    .map((id) => {
                    const targetRole = ctx.world.getComponent(id, COMPONENT.Role);
                    return [
                        id,
                        {
                            life: captureNightLife(ctx.world, id),
                            role: targetRole,
                            kind: targetRole.role,
                            camp: ctx.world.getComponent(id, COMPONENT.Camp)?.camp,
                            privateState: targetRole.privateState,
                        },
                    ];
                }));
                if (isRoleExecutionRetired(role))
                    break;
                let action = null;
                if (targets.size) {
                    const provider = ctx.actionProvider, getAction = provider.getAction, makeRequest = ctx.makeRequest, requestArgs = [actorId, ["black_market_trade"], {
                            stage: "black_market_merchant",
                            requiresAction: false,
                            action_failure_policy: "error",
                            allow_fallback: false,
                            ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                        }], invoke = Reflect.apply.bind(Reflect);
                    if (isRoleExecutionRetired(role))
                        break;
                    const request = invoke(makeRequest, ctx, requestArgs), actionArgs = [request];
                    if (isRoleExecutionRetired(role))
                        break;
                    action = await invoke(getAction, provider, actionArgs);
                }
                if (!current())
                    break;
                if (action === null) {
                    skip();
                    completed = true;
                    break;
                }
                if (action.name !== "black_market_trade")
                    continue;
                const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                    phase: Phase.Night,
                    day,
                });
                if (!current() || !validated.ok || validated.sanitizedCall?.name !== "black_market_trade")
                    continue;
                const { target_id: targetId, skill } = validated.sanitizedCall.args, target = targets.get(targetId);
                if (!target ||
                    !livingNightLife(ctx.world, target.life) ||
                    ctx.world.getComponent(targetId, COMPONENT.Role) !== target.role ||
                    target.role.role !== target.kind ||
                    ctx.world.getComponent(targetId, COMPONENT.Camp)?.camp !== target.camp ||
                    target.role.privateState !== target.privateState)
                    continue;
                if (target.camp !== Camp.Good && target.camp !== Camp.Wolf)
                    throw new Error("black_market_target_camp_unsupported");
                const failed = target.camp === Camp.Wolf;
                if (isRoleExecutionRetired(role))
                    break;
                if (!failed) {
                    if (skill === "gun") {
                        const grant = grantDeathGun, grantArgs = [ctx.world, actorId, targetId, day, ctx.events], grantWorld = grantArgs[0], grantActor = grantArgs[1], grantTarget = grantArgs[2], grantDay = grantArgs[3], grantEvents = grantArgs[4];
                        if (isRoleExecutionRetired(role))
                            break;
                        grant(grantWorld, grantActor, grantTarget, grantDay, grantEvents);
                    }
                    else {
                        const base = {
                            id: "gift:black-market",
                            activation: "black_market",
                            source: { kind: "gift", actorId },
                            sourceDisclosed: false,
                            startsOnDay: day + 1,
                            maxUses: 1,
                        };
                        if (skill === "check") {
                            const grant = grantNightAbility, grantArgs = [
                                ctx.world,
                                targetId,
                                {
                                    ...base,
                                    kind: "seer_check",
                                    state: { lastTarget: null, lastIsWerewolf: null, lastResult: null, history: [] },
                                },
                                ctx.events,
                            ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                            if (isRoleExecutionRetired(role))
                                break;
                            grant(grantWorld, grantTarget, grantInput, grantEvents);
                        }
                        else {
                            const grant = grantNightAbility, grantArgs = [
                                ctx.world,
                                targetId,
                                {
                                    ...base,
                                    kind: "potion",
                                    state: {
                                        heal: 0,
                                        poison: 1,
                                        selfHealRule: WitchSelfHealRule.Disabled,
                                        canSelfHeal: false,
                                        healUsedThisNight: false,
                                        poisonUsedThisNight: false,
                                    },
                                },
                                ctx.events,
                            ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                            if (isRoleExecutionRetired(role))
                                break;
                            grant(grantWorld, grantTarget, grantInput, grantEvents);
                        }
                    }
                }
                const recordTrade = recordBlackMarketTrade;
                if (failed && isRoleExecutionRetired(role))
                    break;
                recordTrade(state, day, targetId, skill);
                recordCommit(ctx.world, day);
                const choice = state.choice;
                if (failed)
                    (ctx.state.blackMarketBacklashes ??= []).push({
                        target: life,
                        isCurrent: () => ownerCurrent(true) &&
                            state.choice === choice &&
                            choice.day === day &&
                            choice.targetId === targetId &&
                            choice.skill === skill,
                    });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "black_market_trade_committed",
                    payload: { actorId, day, targetId, skill },
                });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "black_market_trade_resolved",
                    payload: { actorId, day, targetId, skill, outcome: failed ? "backlash" : "granted" },
                });
                completed = true;
                break;
            }
            if (!completed && current()) {
                if (ctx.world.getAliveEntityIds().some((id) => id !== actorId))
                    throw new Error("black_market_valid_action_missing");
                skip();
            }
        }
    },
};
