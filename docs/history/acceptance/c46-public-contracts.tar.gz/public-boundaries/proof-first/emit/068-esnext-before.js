import { WitchSelfHealRule } from "@ai-werewolf-arena/game-contract";
import { copyAbilityData, findNightAbility } from "../night-abilities/abilities";
import { commitPreparedNativeAbility } from "../night-abilities/abilities";
export function setWitchState(roleComp, state) {
    return commitPreparedNativeAbility(roleComp, "potion", WITCH_STATE_SLOT.create(state));
}
export function getWitchState(roleComp, abilityId) {
    return findNightAbility(roleComp, "potion", abilityId)?.state;
}
export function resetWitchNightState(state, currentDay) {
    state.healUsedThisNight = false;
    state.poisonUsedThisNight = false;
    state.canSelfHeal =
        state.selfHealRule === WitchSelfHealRule.Always ||
            (state.selfHealRule === WitchSelfHealRule.FirstNightOnly && currentDay() === 1);
}
export function refreshWitchSelfHeal(ability, day) {
    const state = ability.state;
    state.canSelfHeal =
        ability.state.selfHealRule === WitchSelfHealRule.Always ||
            (ability.state.selfHealRule === WitchSelfHealRule.FirstNightOnly && day === 1);
}
export function closeWitchPotionTurn(ability, day) {
    ability.state.potionTurnClosedDay = day;
}
export function consumeWitchHeal(state) {
    state.heal -= 1;
    state.healUsedThisNight = true;
}
export function consumeWitchPoison(state) {
    state.poison -= 1;
    state.poisonUsedThisNight = true;
}
export function consumeRecipientPoison(ability) {
    ability.state.poison--;
    ability.state.poisonUsedThisNight = true;
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.selfHealRule,
        ability.state.knifeVisibility,
        ability.state.potionPolicy]);
}
export const WITCH_STATE_SLOT = Object.freeze({
    create: (copyAbilityData),
    schema: (copyAbilityData),
    install: setWitchState,
    get: getWitchState,
    allowedWrites: Object.freeze({
        resetWitchNightState,
        refreshWitchSelfHeal,
        closeWitchPotionTurn,
        consumeWitchHeal,
        consumeWitchPoison,
        consumeRecipientPoison,
    }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
