import { copyAbilityData, findNightAbility } from "../night-abilities/abilities";
import { commitPreparedNativeAbility } from "../night-abilities/abilities";
export function setGuardState(roleComp, state) {
    return commitPreparedNativeAbility(roleComp, "guard", GUARD_STATE_SLOT.create(state));
}
export function getGuardState(roleComp, abilityId) {
    return findNightAbility(roleComp, "guard", abilityId)?.state;
}
export function recordGuardTarget(state, targetId) {
    state.lastTarget = targetId;
}
export function recordRecipientGuardTarget(ability, target) {
    const state = ability.state;
    state.lastTarget = target.id;
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.repeatPolicy]);
}
export const GUARD_STATE_SLOT = Object.freeze({
    create: (copyAbilityData),
    schema: (copyAbilityData),
    install: setGuardState,
    get: getGuardState,
    allowedWrites: Object.freeze({
        recordGuardTarget,
        recordRecipientGuardTarget,
    }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
