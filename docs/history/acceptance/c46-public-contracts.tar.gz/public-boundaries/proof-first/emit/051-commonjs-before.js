"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasRadiantNight = exports.isRadiantEclipseBoard = void 0;
exports.installRadiantEclipseBoard = installRadiantEclipseBoard;
exports.assertRadiantRosterCurrent = assertRadiantRosterCurrent;
exports.beginRadiantNight = beginRadiantNight;
exports.eclipseKnownWolves = eclipseKnownWolves;
exports.eclipseKnifeEligible = eclipseKnifeEligible;
exports.eclipseSwallowTargets = eclipseSwallowTargets;
exports.eclipseChoiceEligible = eclipseChoiceEligible;
exports.openEclipseChoice = openEclipseChoice;
exports.commitEclipseChoice = commitEclipseChoice;
exports.shelterTargets = shelterTargets;
exports.captureRadiantTurn = captureRadiantTurn;
exports.captureRadiantPaidEffect = captureRadiantPaidEffect;
exports.commitRadiantShelter = commitRadiantShelter;
exports.sealRadiantNightEffects = sealRadiantNightEffects;
exports.closeRadiantNight = closeRadiantNight;
const node_util_1 = require("node:util");
const names_1 = require("../../domain/components/names");
const identity_1 = require("../../domain/identity");
const alive_1 = require("../../domain/components/alive");
const night_effects_1 = require("../../domain/night-effects");
const abilities_1 = require("../night-abilities/abilities");
const abilities_2 = require("../night-abilities/abilities");
const night_ability_grants_1 = require("../night-abilities/night-ability-grants");
const suppression_1 = require("./suppression");
const borrowed_state_1 = require("./borrowed-state");
const eclipse_state_slot_1 = require("./eclipse-state-slot");
const shelter_state_1 = require("./shelter-state");
const invalid = Symbol("invalid_radiant_binding");
function own(value, key) {
    if (!value || typeof value !== "object" || node_util_1.types.isProxy(value))
        return invalid;
    const d = Object.getOwnPropertyDescriptor(value, key);
    return d && "value" in d ? d.value : d ? invalid : undefined;
}
function factoryLife(life) {
    if (node_util_1.types.isProxy(life))
        return false;
    const a = (0, alive_1.aliveLifeDescriptor)(life), b = Object.getOwnPropertyDescriptor(life, "alive");
    return (!!a &&
        !!b &&
        a.get === b.get &&
        a.set === b.set &&
        a.enumerable === b.enumerable &&
        a.configurable === b.configurable);
}
const boards = new WeakMap();
const nativeKeys = [
    "id",
    "kind",
    "activation",
    "startsOnDay",
    "expiresAfterDay",
    "maxUses",
    "sourceDisclosed",
];
const policyKeys = [
    "policy",
    "targetPolicy",
    "actionPolicy",
    "selfHealRule",
    "knifeVisibility",
    "potionPolicy",
    "protectionPolicy",
];
const identityKeys = ["id", "seat", "name", "sessionId"];
function original(world, id) {
    const role = world.getComponent(id, names_1.COMPONENT.Role);
    const life = world.getComponent(id, names_1.COMPONENT.Alive);
    const identity = world.getComponent(id, names_1.COMPONENT.Identity);
    if (!role || !life || !factoryLife(life) || !life.alive || (0, alive_1.aliveLifeVersion)(life) === undefined)
        throw new Error("radiant_original_invalid");
    const native = (0, abilities_1.allNightAbilities)(role).filter((a) => a.source.kind === "native");
    if (native.length > 1 || (0, abilities_1.allNightAbilities)(role).length !== native.length)
        throw new Error("radiant_original_abilities_invalid");
    return {
        id,
        role,
        kind: role.role,
        camp: world.getComponent(id, names_1.COMPONENT.Camp)?.camp,
        privateState: role.privateState,
        identity,
        identityValues: identityKeys.map((k) => own(identity, k)),
        life,
        version: (0, alive_1.aliveLifeVersion)(life),
        campComponent: world.getComponent(id, names_1.COMPONENT.Camp),
        victory: world.getComponent(id, names_1.COMPONENT.Victory),
        container: own(role.privateState, "abilities"),
        native: native[0],
        nativeId: native[0]?.id,
        nativeKind: native[0]?.kind,
        nativeState: native[0]?.state,
        nativeSource: native[0]?.source,
        nativeMetadata: nativeKeys.map((key) => own(native[0], key)),
        nativePolicy: policyKeys.map((key) => own(native[0]?.state, key)),
    };
}
function current(world, p, allowDeath = true) {
    if (world.getComponent(p.id, names_1.COMPONENT.Role) !== p.role ||
        own(p.role, "role") !== p.kind ||
        own(p.campComponent, "camp") !== p.camp ||
        own(p.role, "privateState") !== p.privateState ||
        world.getComponent(p.id, names_1.COMPONENT.Identity) !== p.identity ||
        !identityKeys.every((k, i) => own(p.identity, k) === p.identityValues[i]) ||
        world.getComponent(p.id, names_1.COMPONENT.Camp) !== p.campComponent ||
        own(p.campComponent, "camp") !== p.camp ||
        world.getComponent(p.id, names_1.COMPONENT.Victory) !== p.victory ||
        world.getComponent(p.id, names_1.COMPONENT.Alive) !== p.life ||
        !factoryLife(p.life) ||
        own(p.privateState, "abilities") !== p.container)
        return false;
    const v = (0, alive_1.aliveLifeVersion)(p.life);
    return p.life.alive ? v === p.version : allowDeath && v === p.version + 1;
}
function requireBoard(world) {
    const b = boards.get(world);
    if (!b)
        throw new Error("radiant_board_missing");
    if (world.entityIds().length !== b.players.size ||
        [...b.players.values()].some((p) => !current(world, p)))
        throw new Error("radiant_roster_revoked");
    for (const p of b.players.values()) {
        originalAbility(p);
        const allowed = b.allowed.get(p.id);
        const container = own(p.privateState, "abilities");
        const keys = container === undefined ? [] : Reflect.ownKeys(container);
        if (keys.length !== allowed.size ||
            keys.some((key) => typeof key !== "string" || !allowed.has(key) || own(container, key) !== allowed.get(key)))
            throw new Error("radiant_ability_membership_revoked");
    }
    b.eclipseState.assertCurrent(() => own(b.players.get(b.maidId).privateState, "eclipse"));
    return b;
}
function requireNight(world, day) {
    const b = requireBoard(world), n = b.night;
    if (!n || n.day !== day || n.closed)
        throw new Error("radiant_night_unavailable");
    return { b, n };
}
function originalAbility(p) {
    const a = p.native;
    if (!a)
        return undefined;
    if (own(p.container, p.nativeId) !== a ||
        own(a, "id") !== p.nativeId ||
        own(a, "kind") !== p.nativeKind ||
        own(a, "state") !== p.nativeState ||
        own(a, "source") !== p.nativeSource ||
        own(p.nativeSource, "kind") !== "native" ||
        own(p.nativeSource, "role") !== p.kind ||
        own(a, "activation") !== undefined ||
        !nativeKeys.every((key, i) => own(a, key) === p.nativeMetadata[i]) ||
        !policyKeys.every((key, i) => own(p.nativeState, key) === p.nativePolicy[i]))
        throw new Error("radiant_original_ability_revoked");
    return a;
}
function stateGuard(a) {
    const state = own(a, "state"), source = own(a, "source");
    if (!state ||
        !source ||
        node_util_1.types.isProxy(state) ||
        node_util_1.types.isProxy(source) ||
        typeof state !== "object" ||
        typeof source !== "object")
        throw new Error("radiant_ability_state_invalid");
    const fields = [
        "id",
        "kind",
        "activation",
        "startsOnDay",
        "expiresAfterDay",
        "maxUses",
        "uses",
        "lastUsedDay",
        "disabled",
        "deathExpired",
        "sourceDisclosed",
    ];
    const values = fields.map((k) => own(a, k));
    const sourceKeys = ["kind", "role", "actorId", "abilityId"], sourceValues = sourceKeys.map((k) => own(source, k));
    const keys = Reflect.ownKeys(state), valuesState = keys.map((k) => own(state, k));
    if (values.includes(invalid) || sourceValues.includes(invalid) || valuesState.includes(invalid))
        throw new Error("radiant_ability_state_invalid");
    const arrays = valuesState.filter(Array.isArray).map((array) => {
        if (node_util_1.types.isProxy(array))
            throw new Error("radiant_ability_state_invalid");
        return { array, length: own(array, "length") };
    });
    return () => own(a, "state") === state &&
        own(a, "source") === source &&
        fields.every((k, i) => own(a, k) === values[i]) &&
        sourceKeys.every((k, i) => own(source, k) === sourceValues[i]) &&
        Reflect.ownKeys(state).length === keys.length &&
        keys.every((k, i) => own(state, k) === valuesState[i]) &&
        arrays.every(({ array, length }) => own(array, "length") === length);
}
function installRadiantEclipseBoard(world) {
    if (boards.has(world))
        throw new Error("radiant_board_already_installed");
    const players = new Map(world.entityIds().map((id) => [id, original(world, id)]));
    const maid = [...players.values()].filter((p) => p.kind === identity_1.Role.EclipseMaid), count = [...players.values()].filter((p) => p.kind === identity_1.Role.RadiantCount);
    if (players.size !== 12 || maid.length !== 1 || count.length !== 1)
        throw new Error("radiant_roster_invalid");
    const state = own(maid[0].privateState, "eclipse"), parsed = (0, eclipse_state_slot_1.readEclipseState)(state);
    if (!parsed || parsed.history.length !== 0)
        throw new Error("eclipse_initial_state_invalid");
    boards.set(world, {
        players,
        maidId: maid[0].id,
        countId: count[0].id,
        knownWolves: Object.freeze([...players.values()].filter((p) => p.kind === identity_1.Role.Wolf).map((p) => p.id)),
        eclipseState: new eclipse_state_slot_1.EclipseStateBinding(state, parsed),
        night: null,
        allowed: new Map([...players.values()].map((p) => [
            p.id,
            new Map((0, abilities_1.allNightAbilities)(p.role).map((a) => [a.id, a])),
        ])),
    });
}
const isRadiantEclipseBoard = (world) => boards.has(world);
exports.isRadiantEclipseBoard = isRadiantEclipseBoard;
const hasRadiantNight = (world, day) => boards.get(world)?.night?.day === day;
exports.hasRadiantNight = hasRadiantNight;
function assertRadiantRosterCurrent(world) {
    if (boards.has(world))
        requireBoard(world);
}
function beginRadiantNight(world, day) {
    const b = requireBoard(world);
    if (!Number.isSafeInteger(day) || day < 1 || (b.night && (day <= b.night.day || !b.night.closed)))
        throw new Error("radiant_night_reentry");
    const living = new Set([...b.players.values()].filter((p) => p.life.alive).map((p) => p.id));
    b.night = {
        day,
        closed: false,
        status: "open",
        living,
        knife: living.has(b.maidId) && b.knownWolves.every((id) => !living.has(id)),
        swallowOpened: false,
        swallowed: false,
        targetId: null,
        lease: undefined,
        shelters: [],
        sourceChecks: new Map(),
    };
}
function eclipseKnownWolves(world) {
    return boards.has(world) ? requireBoard(world).knownWolves : [];
}
function eclipseKnifeEligible(world) {
    const b = boards.get(world);
    return (!!b &&
        !!b.night &&
        !b.night.closed &&
        b.night.knife &&
        current(world, b.players.get(b.maidId), false));
}
function eclipseSwallowTargets(world, day) {
    const { b, n } = requireNight(world, day);
    if (day < 2 || !n.living.has(b.maidId) || n.swallowed)
        return [];
    const last = b.eclipseState.lastChoice();
    return [...b.players.values()]
        .filter((p) => p.camp === identity_1.Camp.Good && p.life.alive && (last?.day !== day - 1 || last.targetId !== p.id))
        .map((p) => p.id);
}
function eclipseChoiceEligible(world, day, actorId) {
    try {
        const { b, n } = requireNight(world, day);
        return (day >= 2 &&
            actorId === b.maidId &&
            current(world, b.players.get(actorId), false) &&
            n.swallowOpened &&
            !n.swallowed);
    }
    catch {
        return false;
    }
}
function openEclipseChoice(world, day) {
    const { b, n } = requireNight(world, day);
    if (n.swallowOpened || day < 2)
        throw new Error("eclipse_choice_reentry");
    n.swallowOpened = true;
    for (const id of eclipseSwallowTargets(world, day)) {
        const p = b.players.get(id), a = originalAbility(p);
        if (a)
            n.sourceChecks.set(id, stateGuard(a));
    }
}
function commitEclipseChoice(world, day, targetId, events) {
    const { b, n } = requireNight(world, day);
    if (!n.swallowOpened || n.swallowed)
        throw new Error("eclipse_choice_unavailable");
    const maid = b.players.get(b.maidId);
    if (!current(world, maid, false) ||
        (targetId !== null && !eclipseSwallowTargets(world, day).includes(targetId)))
        throw new Error("eclipse_choice_target");
    const target = targetId === null ? undefined : b.players.get(targetId);
    const a = target && originalAbility(target);
    if (target &&
        (!current(world, target, false) ||
            (a && (!n.sourceChecks.get(target.id)?.() || (0, abilities_1.abilityStatus)(a, day) !== "active"))))
        throw new Error("eclipse_choice_source_revoked");
    const roleId = target?.kind ?? null;
    const next = b.eclipseState.next(day, targetId, () => eclipseSwallowTargets(world, day), roleId);
    let suppression, borrowed;
    if (a && target) {
        const kind = a.kind;
        if (!["seer_check", "potion", "dream", "shelter"].includes(kind))
            throw new Error("eclipse_borrow_kind_invalid");
        const state = (0, borrowed_state_1.snapshotBorrowedState)(kind, a.state, day);
        suppression = (0, suppression_1.openEclipseSuppression)(world, target.id, a, day);
        try {
            borrowed = (0, night_ability_grants_1.grantNightAbility)(world, b.maidId, {
                id: `copy:eclipse:night:${day}`,
                kind,
                state,
                source: { kind: "copy", actorId: target.id, abilityId: a.id },
                sourceDisclosed: true,
                startsOnDay: day,
                expiresAfterDay: day,
                maxUses: null,
            }, events);
        }
        catch (error) {
            suppression.close();
            throw error;
        }
    }
    if (borrowed)
        b.allowed.get(b.maidId).set(borrowed.id, borrowed);
    b.eclipseState.install(next);
    n.swallowed = true;
    n.targetId = targetId;
    n.lease = target
        ? { target, native: a, borrowed, borrowedId: borrowed?.id ?? null, suppression }
        : undefined;
    events.push({
        timestamp: Date.now(),
        type: "eclipse_swallowed",
        payload: { actorId: b.maidId, day, targetId, roleId, abilityId: borrowed?.id ?? null },
        audience: Object.freeze([b.maidId]),
    });
    if (target)
        events.push({
            timestamp: Date.now(),
            type: "eclipse_native_suppressed",
            payload: { playerId: target.id, day },
            audience: Object.freeze([target.id]),
        });
}
function shelterTargets(world, day, actorId, abilityId) {
    const { b, n } = requireNight(world, day), p = b.players.get(actorId);
    if (day < 2 || !p || !p.life.alive)
        return [];
    const a = (0, abilities_1.allNightAbilities)(p.role).find((a) => a.id === abilityId && a.kind === "shelter");
    if (!a || a.kind !== "shelter" || (0, abilities_1.abilityStatus)(a, day) !== "active")
        return [];
    const s = (0, shelter_state_1.readShelterState)(a.state);
    if (!s)
        throw new Error("radiant_shelter_state_invalid");
    if (actorId === b.countId && a !== p.native)
        return [];
    if (actorId !== b.countId && (actorId !== b.maidId || n.lease?.borrowed !== a))
        return [];
    return [...b.players.values()]
        .filter((p) => p.life.alive && p.id !== actorId && !(s.lastDay === day - 1 && s.lastTarget === p.id))
        .map((p) => p.id);
}
function captureRadiantTurn(world, actorId, ability, day) {
    if (!boards.has(world))
        return () => true;
    const { b, n } = requireNight(world, day), p = b.players.get(actorId);
    if (!p || !current(world, p, false) || own(p.container, ability.id) !== ability)
        throw new Error("radiant_turn_owner_invalid");
    if (ability !== p.native && n.lease?.borrowed !== ability)
        throw new Error("radiant_turn_instance_invalid");
    const capturedId = ability.id;
    const guard = stateGuard(ability), source = n.lease?.borrowed === ability ? n.lease : undefined;
    return () => !n.closed &&
        b.night === n &&
        current(world, p, false) &&
        own(p.container, capturedId) === ability &&
        guard() &&
        (!source ||
            (current(world, source.target, false) &&
                source.suppression?.isCurrent() === true &&
                n.sourceChecks.get(source.target.id)?.() === true));
}
function captureRadiantPaidEffect(world, day, actorId, ability, targetId) {
    if (!boards.has(world))
        return undefined;
    const { b, n } = requireNight(world, day), actor = b.players.get(actorId), target = b.players.get(targetId);
    const id = own(ability, "id"), kind = own(ability, "kind"), state = own(ability, "state"), source = own(ability, "source");
    const sourceKeys = ["kind", "role", "actorId", "abilityId"], sourceValues = sourceKeys.map((key) => own(source, key));
    return () => b.night === n &&
        n.status !== "aborted" &&
        current(world, actor) &&
        current(world, target) &&
        own(actor.container, id) === ability &&
        own(ability, "id") === id &&
        own(ability, "kind") === kind &&
        own(ability, "state") === state &&
        own(ability, "source") === source &&
        sourceKeys.every((key, i) => own(source, key) === sourceValues[i]);
}
function commitRadiantShelter(world, day, actorId, ability, targetId, events) {
    const { b, n } = requireNight(world, day), p = b.players.get(actorId);
    if (!p)
        throw new Error("radiant_shelter_actor_invalid");
    if (targetId !== null) {
        const target = (0, night_effects_1.captureNightLife)(world, targetId);
        if (!target)
            throw new Error("radiant_shelter_target_revoked");
        const id = ability.id;
        const owner = captureRadiantPaidEffect(world, day, actorId, ability, targetId);
        n.shelters.push({ actorId, abilityId: id, target, owner });
    }
    events.push({
        timestamp: Date.now(),
        type: "radiant_shelter_chosen",
        payload: { actorId, day, targetId, abilityId: ability.id },
        audience: Object.freeze([actorId]),
    });
}
function sealRadiantNightEffects(world, day) {
    const { b, n } = requireNight(world, day);
    const shelters = Object.freeze(n.shelters.map((s) => Object.freeze({ target: Object.freeze({ ...s.target }), isCurrent: s.owner })));
    const target = n.lease?.target;
    const triggered = target &&
        (target.id === b.countId || n.shelters.some((s) => s.target.id === target.id && s.owner()));
    const maid = b.players.get(b.maidId);
    const maidLife = triggered ? (0, night_effects_1.captureNightLife)(world, b.maidId) : null;
    const backlashes = maidLife
        ? [
            {
                target: Object.freeze(maidLife),
                isCurrent: () => b.night === n && n.status !== "aborted" && current(world, maid),
            },
        ]
        : [];
    if (triggered && !maidLife)
        throw new Error("radiant_backlash_owner_revoked");
    return Object.freeze({
        shelters,
        backlashes: Object.freeze(backlashes.map((claim) => Object.freeze(claim))),
    });
}
function closeRadiantNight(world, day, status, events) {
    const b = boards.get(world), n = b?.night;
    if (!b || !n || n.day !== day || n.closed)
        return;
    n.closed = true;
    n.status = status;
    const l = n.lease;
    const restored = l?.suppression?.close() ?? l?.native === undefined;
    const maid = b.players.get(b.maidId);
    if (l?.borrowed &&
        world.getComponent(b.maidId, names_1.COMPONENT.Role) === maid.role &&
        own(maid.role, "privateState") === maid.privateState &&
        own(maid.privateState, "abilities") === maid.container &&
        world.getComponent(b.maidId, names_1.COMPONENT.Alive) === maid.life &&
        factoryLife(maid.life) &&
        (maid.life.alive
            ? (0, alive_1.aliveLifeVersion)(maid.life) === maid.version
            : (0, alive_1.aliveLifeVersion)(maid.life) === maid.version + 1) &&
        own(maid.container, l.borrowedId) === l.borrowed)
        (0, abilities_2.retireBorrowedNightAbility)(() => l.borrowed);
    events.push({
        timestamp: Date.now(),
        type: "eclipse_lease_closed",
        payload: {
            actorId: b.maidId,
            day,
            targetId: n.targetId,
            abilityId: l?.borrowedId ?? null,
            status,
        },
        audience: Object.freeze([]),
    });
    if (status === "committed" &&
        restored &&
        l?.target &&
        current(world, l.target) &&
        l.target.life.alive)
        events.push({
            timestamp: Date.now(),
            type: "eclipse_native_restored",
            payload: { playerId: l.target.id, day },
            audience: Object.freeze([l.target.id]),
        });
}
