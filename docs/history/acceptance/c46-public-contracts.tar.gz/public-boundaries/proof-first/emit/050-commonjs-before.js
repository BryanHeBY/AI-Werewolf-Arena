"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validatePureWhiteInspection = exports.PURE_WHITE_INSPECTION_TOOL = void 0;
exports.pureWhiteInspectionTargets = pureWhiteInspectionTargets;
const role_inspection_policy_1 = require("@ai-werewolf-arena/game-contract/role-inspection-policy");
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const model_1 = require("../../domain/model");
const names_1 = require("../../domain/components/names");
const abilities_1 = require("../night-abilities/abilities");
function pureWhiteInspectionTargets(world, actorId, policy) {
    return world
        .getAliveEntityIds()
        .filter((id) => {
        if (id === actorId)
            return false;
        if (policy === "pure_white")
            return true;
        const role = world.getComponent(id, names_1.COMPONENT.Role);
        return !role || world.getComponent(id, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Wolf;
    });
}
exports.PURE_WHITE_INSPECTION_TOOL = {
    name: "inspect_night_identity",
    parameters: {
        type: "object",
        properties: {
            target_id: { type: ["integer", "null"], minimum: 1 },
            abstain: { type: "boolean" },
        },
        required: ["target_id", "abstain"],
        additionalProperties: false,
    },
    argHint: 'inspect_night_identity args: {"target_id":number|null,"abstain":boolean}',
    userPromptHintKey: "action.inspect_night_identity.hint",
};
const validatePureWhiteInspection = ({ world, actorId, role, day, phase, abilityId, toolCall, }) => {
    const ability = (0, abilities_1.activeNightAbility)(role, "role_check", day ?? 1, abilityId);
    if (!ability)
        return { code: game_contract_1.RuleError.RoleInspectUnavailable };
    const policy = (0, role_inspection_policy_1.roleInspectionPolicy)(ability.state);
    if (policy !== "pure_white" && policy !== "wolf_witch")
        return { code: game_contract_1.RuleError.RoleInspectUnavailable };
    const expected = policy === "pure_white" ? model_1.Role.PureWhiteGirl : model_1.Role.WolfWitch;
    if (role.role !== expected ||
        ability.source.kind !== "native" ||
        ability.source.role !== expected)
        return { code: game_contract_1.RuleError.RoleInspectUnavailable };
    if (phase !== model_1.Phase.Night)
        return { code: game_contract_1.RuleError.AbilityPhase };
    if (toolCall.name !== "inspect_night_identity")
        return { code: game_contract_1.RuleError.ToolMismatch };
    const { target_id, abstain } = toolCall.args;
    if (abstain === true && target_id === null)
        return null;
    if (abstain !== false ||
        target_id === null ||
        !Number.isSafeInteger(target_id) ||
        !pureWhiteInspectionTargets(world, actorId, policy).includes(target_id))
        return { code: game_contract_1.RuleError.RoleInspectTarget };
    return null;
};
exports.validatePureWhiteInspection = validatePureWhiteInspection;
