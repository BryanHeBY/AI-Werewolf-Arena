import { COMPONENT, Phase, PotionType, StatusMark, settleRequestDelivery, } from "../../domain";
import { StatusMarksComponent, statusMarkSnapshot, } from "../../domain/components/status-marks";
import { captureNightLife, originalPoisonIntent, } from "../../domain/night-effects";
import { safeRecordLogicOp } from "../../recording/session/recorder";
import { recordNightAbilityUse } from "../night-abilities/abilities";
import { openDemonWitchTurnFrame, demonHunterFreezeDay, demonWitchRequiredThisNight, } from "./authority";
import { bindDemonWitchRequest, demonWitchRequestCurrent, readDemonPotionTool, demonWitchRequestTargetCurrent, demonWitchMarksSafe, } from "./native-potion-requests";
import { captureDemonNativePoison, commitDemonNativePoison, freezeDemonNightSources, } from "./native-poison";
import { openNativePoisonContribution, commitNativePoisonContribution, sealNativePoisonContribution, lateUnknownPoisonContribution, } from "./poison-contribution";
import { openNativeHealContribution, commitNativeHealContribution, sealNativeHealContribution, lateUnknownHealContribution, } from "./heal-contribution";
const deliveredHeals = new WeakMap();
const nativeAddMark = StatusMarksComponent.prototype.add;
const delivered = new WeakMap();
const sealedSources = new WeakMap();
const sealedNights = new WeakMap();
export async function executeDemonWitchTurn(input) {
    const { world, gateway, events, provider, day, wolfTarget } = input, frame = openDemonWitchTurnFrame(world);
    if (!frame || frame.day !== day)
        throw new Error("demon_hunter_native_witch_unavailable");
    const ability = frame.ability, scope = Object.freeze({});
    let closed = false;
    if (!world.entityIds().every((id) => demonWitchMarksSafe(world, id)))
        throw new Error("demon_hunter_native_marks_invalid");
    const request = new input.construction.requestFactory(world, events, day).create({
        phase: Phase.Night,
        actorId: frame.witchId,
        allowedTools: ["use_potion"],
        stage: "witch",
        requiresAction: true,
        summary: { key: "request.summary.night_action" },
        context: {
            ability_id: "native:potion",
            allow_fallback: false,
            action_failure_policy: "error",
            ...(ability.state.heal > 0 ? { wolf_target: wolfTarget } : {}),
        },
    });
    bindDemonWitchRequest(world, request, scope, () => !closed && frame.isCurrent(), frame.targetCurrent);
    const authorized = () => demonWitchRequestCurrent(world, request);
    try {
        if (!authorized())
            throw new Error("demon_hunter_native_witch_revoked");
        const raw = await provider.getAction(request);
        if (!authorized())
            throw new Error("demon_hunter_native_witch_revoked");
        const call = readDemonPotionTool(raw);
        if (!call || !demonWitchRequestTargetCurrent(world, request, call.args.target_id))
            throw new Error("demon_hunter_native_witch_invalid");
        const candidateMarks = world.getComponent(call.args.target_id, COMPONENT.StatusMarks);
        if (candidateMarks &&
            (!statusMarkSnapshot(candidateMarks, StatusMark.PoisonMark) ||
                Object.getPrototypeOf(candidateMarks) !== StatusMarksComponent.prototype ||
                Object.getOwnPropertyDescriptor(candidateMarks, "has")))
            throw new Error("demon_hunter_native_marks_invalid");
        const checked = gateway.validateAndSanitize(world, frame.witchId, call, {
            phase: Phase.Night,
            day,
            abilityId: "native:potion",
            deferOperation: true,
        });
        if (!checked.ok ||
            !checked.sanitizedCall ||
            !authorized() ||
            !demonWitchRequestTargetCurrent(world, request, call.args.target_id))
            throw new Error("demon_hunter_native_witch_invalid");
        const targetId = call.args.target_id, potion = call.args.potion_type;
        const source = captureNightLife(world, frame.witchId), target = captureNightLife(world, targetId);
        if (!source || !target)
            throw new Error("demon_hunter_native_witch_revoked");
        Object.freeze(source);
        Object.freeze(target);
        let poison = null;
        const native = potion === PotionType.Poison && targetId === frame.demonId
            ? captureDemonNativePoison(world, frame.witchId, ability, targetId)
            : null;
        if (potion === PotionType.Poison && targetId === frame.demonId && !native)
            throw new Error("demon_hunter_native_poison_unavailable");
        let marks = world.getComponent(targetId, COMPONENT.StatusMarks);
        if (potion !== PotionType.None && !marks) {
            marks = new StatusMarksComponent();
            world.addComponent(targetId, COMPONENT.StatusMarks, marks);
        }
        const contribution = potion === PotionType.Poison && marks
            ? openNativePoisonContribution(world, targetId, marks)
            : null;
        const healContribution = potion === PotionType.Heal && marks
            ? openNativeHealContribution(world, targetId, marks)
            : null;
        recordNightAbilityUse(ability, day, potion !== PotionType.None);
        if (potion !== PotionType.None) {
            nativeAddMark.call(marks, potion === PotionType.Heal ? StatusMark.HealMark : StatusMark.PoisonMark);
            ability.state[potion]--;
            ability.state[potion === PotionType.Heal ? "healUsedThisNight" : "poisonUsedThisNight"] =
                true;
        }
        if (!frame.commit(potion))
            throw new Error("demon_hunter_native_witch_commit_failed");
        if (contribution)
            commitNativePoisonContribution(contribution);
        if (healContribution) {
            commitNativeHealContribution(healContribution);
            const heals = deliveredHeals.get(world) ?? new Map();
            if (heals.has(day))
                throw new Error("demon_hunter_native_witch_delivery_reentry");
            heals.set(day, Object.freeze({
                claim: Object.freeze({
                    source,
                    target,
                    isCurrent: () => frame.sourceCurrent() && frame.targetCurrent(targetId),
                }),
                lateUnknown: () => lateUnknownHealContribution(healContribution),
                sealContribution: () => sealNativeHealContribution(healContribution),
            }));
            deliveredHeals.set(world, heals);
        }
        if (native && contribution) {
            const proof = commitDemonNativePoison(native);
            if (!proof)
                throw new Error("demon_hunter_native_poison_commit_failed");
            poison = Object.freeze({
                proof,
                claim: Object.freeze(originalPoisonIntent({
                    source,
                    target,
                    isCurrent: () => frame.sourceCurrent() && frame.targetCurrent(targetId),
                }, {
                    family: "demon-witch",
                    day,
                    stage: "witch",
                    actorLife: source,
                    requestedTargetId: targetId,
                    abilityId: "native:potion",
                })),
                lateUnknown: () => lateUnknownPoisonContribution(contribution),
                sealContribution: () => sealNativePoisonContribution(contribution),
            });
        }
        else if (potion === PotionType.Poison) {
            poison = Object.freeze({
                proof: null,
                claim: Object.freeze(originalPoisonIntent({
                    source,
                    target,
                    isCurrent: () => frame.sourceCurrent() && frame.targetCurrent(targetId),
                }, {
                    family: "demon-witch",
                    day,
                    stage: "witch",
                    actorLife: source,
                    requestedTargetId: targetId,
                    abilityId: "native:potion",
                })),
                lateUnknown: () => lateUnknownPoisonContribution(contribution),
                sealContribution: () => sealNativePoisonContribution(contribution),
            });
        }
        const nights = delivered.get(world) ?? new Map();
        if (nights.has(day))
            throw new Error("demon_hunter_native_witch_delivery_reentry");
        nights.set(day, poison);
        delivered.set(world, nights);
        settleRequestDelivery(scope, true);
        safeRecordLogicOp({
            scope: "gateway",
            op: "validate_tool_call",
            actorId: frame.witchId,
            phase: Phase.Night,
            status: "ok",
            input: { tool: call.name, args: call.args },
        });
        events.push({
            timestamp: Date.now(),
            type: potion === PotionType.None ? "witch_potion_skipped" : "witch_potion_used",
            payload: {
                actorId: frame.witchId,
                targetId,
                potionType: potion,
            },
        });
        return Object.freeze({ poison, used: potion !== PotionType.None });
    }
    finally {
        closed = true;
        settleRequestDelivery(scope, false);
    }
}
export function sealDeliveredDemonWitchSources(world, day) {
    if (demonHunterFreezeDay(world) !== day ||
        (demonWitchRequiredThisNight(world) && !delivered.get(world)?.has(day)))
        throw new Error("demon_hunter_native_sources_missing");
    const seen = sealedNights.get(world) ?? new Set();
    if (seen.has(day))
        throw new Error("demon_hunter_native_sources_already_sealed");
    const poison = delivered.get(world)?.get(day) ?? null;
    const contributions = poison?.sealContribution() ?? null;
    const heal = deliveredHeals.get(world)?.get(day) ?? null, healContributions = heal?.sealContribution() ?? null;
    const token = Object.freeze({});
    sealedSources.set(token, {
        world,
        day,
        poison,
        contributions,
        heal,
        healContributions,
        frozen: false,
    });
    seen.add(day);
    sealedNights.set(world, seen);
    return token;
}
export function freezeDeliveredDemonNightSources(world, token, faultId = null) {
    const sealed = sealedSources.get(token), day = demonHunterFreezeDay(world);
    if (!sealed || sealed.world !== world || sealed.day !== day || sealed.frozen)
        throw new Error("demon_hunter_native_sources_invalid");
    const poison = sealed.poison, contributions = sealed.contributions;
    const originalSourceCurrent = poison?.claim.isCurrent?.() === true;
    const lateUnknown = poison?.lateUnknown() ?? false;
    const healCurrent = sealed.heal?.claim.isCurrent?.() === true, lateHeal = sealed.heal?.lateUnknown() ?? false;
    const result = freezeDemonNightSources(world, poison?.proof ? [poison.proof] : [], faultId);
    sealed.frozen = true;
    const immunity = !!poison?.proof &&
        contributions?.native === true &&
        originalSourceCurrent &&
        result.poisonImmunities.length === 1;
    return Object.freeze({
        hunt: result.hunt,
        healOverrides: Object.freeze(sealed.heal && sealed.healContributions
            ? [
                Object.freeze({
                    targetId: sealed.heal.claim.target.id,
                    heal: sealed.healContributions.unknown ||
                        lateHeal ||
                        (sealed.healContributions.native && healCurrent),
                }),
            ]
            : []),
        poisonImmunities: Object.freeze(immunity ? [...result.poisonImmunities] : []),
        poisonOverrides: Object.freeze(poison && contributions
            ? [
                Object.freeze({
                    targetId: poison.claim.target.id,
                    poison: contributions.unknown ||
                        lateUnknown ||
                        (contributions.native && originalSourceCurrent && !immunity),
                }),
            ]
            : []),
    });
}
