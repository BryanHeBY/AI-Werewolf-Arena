"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PAIR_STATE_SLOT_CONTRACT = void 0;
exports.installPairStateSlot = installPairStateSlot;
exports.commitPairStateSlot = commitPairStateSlot;
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const native_installation_ports_1 = require("../night-abilities/native-installation-ports");
const state_1 = require("./state");
const owned_state_data_1 = require("./owned-state-data");
function installPairStateSlot(role) {
    role.privateState.pairSeer =
        (0, native_installation_ports_1.installNativeAbility)(role, "pair_check", exports.PAIR_STATE_SLOT_CONTRACT.create());
}
function commitPairStateSlot(slot, next, day) {
    (0, owned_state_data_1.assertWritable)(slot.pairAbility, slot.pairAbility);
    (0, owned_state_data_1.write)(slot.pairState, next);
    slot.pairJson = exports.PAIR_STATE_SLOT_CONTRACT.checkpoint.encode(next);
    (0, inventory_ports_1.recordNightAbilityUse)(slot.pairAbility, day, true);
    slot.pairAbilityJson = (0, owned_state_data_1.plainJson)(slot.pairAbility);
}
function pairAliasesCurrent(slot, own) {
    return (own(slot.seer.privateState, "pairSeer") === slot.pairState &&
        own(slot.seer.privateState, "abilities") === slot.abilities &&
        (0, owned_state_data_1.plainJson)(slot.pairAbility) === slot.pairAbilityJson &&
        slot.pairAbility.source === slot.pairSource &&
        own(slot.abilities, slot.pairAbility.id) === slot.pairAbility &&
        slot.pairAbility.state === slot.pairState);
}
function pairDataCurrent(slot) {
    return JSON.stringify((0, state_1.readPairSeerState)(slot.pairState)) === slot.pairJson;
}
exports.PAIR_STATE_SLOT_CONTRACT = Object.freeze({
    create: state_1.freshPairSeerState,
    schema: state_1.readPairSeerState,
    allowedWrites: Object.freeze({ appendCheck: commitPairStateSlot }),
    checkpoint: Object.freeze({
        encode: (state) => JSON.stringify(state),
        decode: (readJson) => JSON.parse(readJson()),
    }),
    invalidations: Object.freeze({
        aliasesCurrent: pairAliasesCurrent,
        dataCurrent: pairDataCurrent,
    }),
});
