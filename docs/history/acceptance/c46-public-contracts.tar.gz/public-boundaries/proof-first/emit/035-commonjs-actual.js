"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HUNTER_ROLE_PROFILE = void 0;
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const policy_ports_1 = require("../death-actions/policy-ports");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const native_resource_ports_1 = require("../death-actions/native-resource-ports");
const death_hook_1 = require("./death-hook");
const tool_specs_1 = require("./tool-specs");
const tool_ports_1 = require("../death-actions/tool-ports");
exports.HUNTER_ROLE_PROFILE = {
    metadata: {
        role: model_1.Role.Hunter,
        camp: model_1.Camp.Good,
        label: (0, game_text_1.roleName)("hunter"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.hunter.brief"),
        goodSide: "god",
    },
    runtime: {
        configuration: (0, policy_ports_1.deathActionConfiguration)("hunter"),
        init: (roleComp, ctx) => {
            (0, native_resource_ports_1.setHunterState)(roleComp, (0, native_resource_ports_1.createHunterState)(ctx));
        },
        toolSpecs: tool_specs_1.HUNTER_TOOL_SPECS,
        validationRules: {
            shoot: (ctx) => (0, tool_ports_1.validateDeathShot)(ctx, ctx.role.role === model_1.Role.Hunter && (0, native_resource_ports_1.getHunterState)(ctx.role)?.canShoot === true),
        },
        llmRepair: tool_ports_1.DEATH_SHOT_REPAIR,
        deathHook: death_hook_1.hunterDeathHook,
        baselineAction: (_roleComp, request, pickAliveNotSelf) => {
            if (!request.allowedTools.includes("shoot")) {
                return null;
            }
            const target = pickAliveNotSelf();
            return { name: "shoot", args: { target_id: target } };
        },
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("hunter"),
};
