export { getWolfKingState } from "../death-actions/native-resource-ports";
