import { copyAbilityData } from "../night-abilities/abilities";
export const freshMerchantState = () => ({
    remaining: 1,
    closedDay: null,
    choice: null,
});
export function getMerchantState(role) {
    return role
        ?.privateState.miracle_merchant;
}
export function setMerchantState(role, state) {
    role.privateState.miracle_merchant =
        copyAbilityData(state);
}
export function projectMerchantState(state) {
    return {
        remaining: state.remaining,
        closedDay: state.closedDay,
        choice: state.choice
            ? { day: state.choice.day, targetId: state.choice.targetId, skill: state.choice.skill }
            : null,
    };
}
export function canMerchantTrade(state, day) {
    return state.remaining > 0 && day >= 1 && (state.closedDay === null || state.closedDay < day);
}
export function closeMerchantTrade(state, day) {
    state.closedDay = day;
}
export function recordMerchantTrade(state, day, targetId, skill) {
    state.remaining = 0;
    state.closedDay = day;
    state.choice = {
        day,
        targetId,
        skill: skill,
    };
}
