import { RuleError } from "@ai-werewolf-arena/game-contract";
import { Phase } from "../../domain/model";
import { isAliveTarget } from "../../engine/actions/validation-contracts";
import { activeNightAbility } from "../night-abilities/abilities";
import { inspectionRepeats } from "@ai-werewolf-arena/game-contract/role-inspection-policy";
export function roleInspectionTargets(world, actorId, state) {
    const repeat = inspectionRepeats(state);
    return world
        .getAliveEntityIds()
        .filter((id) => id !== actorId && (repeat || !state.history.some((report) => report.targetId === id)));
}
export const ROLE_INSPECTION_TOOL = {
    name: "inspect_role",
    parameters: {
        type: "object",
        properties: { target_id: { type: "number" } },
        required: ["target_id"],
        additionalProperties: false,
    },
    argHint: 'inspect_role args: {"target_id":number}',
    userPromptHintKey: "action.inspect_role.hint",
};
export const validateRoleInspection = ({ world, actorId, role, day, phase, abilityId, toolCall, }) => {
    const ability = activeNightAbility(role, "role_check", day ?? 1, abilityId);
    if (!ability)
        return { code: RuleError.RoleInspectUnavailable };
    if (phase !== Phase.Night)
        return { code: RuleError.AbilityPhase };
    if (toolCall.name !== "inspect_role")
        return { code: RuleError.ToolMismatch };
    if (toolCall.args.target_id === actorId || !isAliveTarget(world, toolCall.args.target_id))
        return { code: RuleError.RoleInspectTarget };
    if (!inspectionRepeats(ability.state) &&
        ability.state.history.some((report) => report.targetId === toolCall.args.target_id))
        return { code: RuleError.RoleInspectRepeat };
    return null;
};
