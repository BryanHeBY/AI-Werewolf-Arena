"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SEER_ROLE_PROFILE = void 0;
const presentation_contribution_1 = require("../../rulesets/roles/presentation-contribution");
const seer_tool_admission_1 = require("../../rulesets/seer-tool-admission");
const zod_1 = require("zod");
const board_1 = require("../../domain/board");
const ports_1 = require("./ports");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const model_1 = require("../../domain/model");
const ports_2 = require("./ports");
const helpers_1 = require("../../agents/tool-repair/helpers");
const night_stages_1 = require("./night-stages");
const tool_specs_1 = require("./tool-specs");
const abilities_1 = require("../night-abilities/abilities");
const night_action_history_1 = require("../night-abilities/night-action-history");
const parameters = zod_1.z.strictObject({
    targetPolicy: zod_1.z.enum(board_1.SEER_TARGET_POLICIES).default("awa_alive_v1"),
    actionPolicy: zod_1.z.enum(board_1.SEER_ACTION_POLICIES).default(board_1.DEFAULT_SEER_ACTION_POLICY),
});
exports.SEER_ROLE_PROFILE = {
    metadata: {
        role: model_1.Role.Seer,
        camp: model_1.Camp.Good,
        label: (0, game_text_1.roleName)("seer"),
        skillBrief: (0, game_text_1.text)("zh-CN", "role.seer.brief"),
        goodSide: "god",
    },
    runtime: {
        configuration: {
            schema: parameters,
            defaults: { targetPolicy: "awa_alive_v1", actionPolicy: board_1.DEFAULT_SEER_ACTION_POLICY },
            apply: (config, value) => ({ ...config, seer: parameters.parse(value) }),
            serialize: (config) => parameters.parse(config.seer ?? {}),
        },
        init: (roleComp, ctx) => {
            (0, ports_2.setSeerState)(roleComp, {
                lastTarget: null,
                lastIsWerewolf: null,
                lastResult: null,
                history: [],
                ...(ctx.boardConfig?.seer?.targetPolicy === "awa_fresh_others_v1"
                    ? { targetPolicy: ctx.boardConfig.seer.targetPolicy }
                    : {}),
                ...(ctx.boardConfig?.seer?.actionPolicy === "awa_optional_v1"
                    ? { actionPolicy: ctx.boardConfig.seer.actionPolicy }
                    : {}),
            });
        },
        toolSpecs: tool_specs_1.SEER_TOOL_SPECS,
        validationRules: seer_tool_admission_1.SEER_VALIDATION_RULES,
        nightStages: night_stages_1.SEER_NIGHT_STAGES,
        llmRepair: {
            coerce: {
                check_identity: (args) => {
                    const target = (0, helpers_1.numberOrNull)(args.target_id);
                    return target === null ? null : { target_id: target };
                },
            },
        },
        baselineAction: (roleComp, request, pickAliveNotSelf, _byCamp, _locale, world) => {
            if (!request.allowedTools.includes("check_identity")) {
                return null;
            }
            const ability = (0, abilities_1.activeNightAbility)(roleComp, "seer_check", request.context.day, request.context.ability_id);
            const target = world && ability
                ? (world
                    .getAliveEntityIds()
                    .find((id) => id !== request.actorId &&
                    (0, ports_1.seerTargetAllowed)(ability.state, request.actorId, id) &&
                    (0, night_action_history_1.luckyTargetAllowed)(world, request.actorId, ability, request.context.day, "check", id)) ?? null)
                : pickAliveNotSelf();
            return target !== null ? { name: "check_identity", args: { target_id: target } } : null;
        },
    },
    presentation: (0, presentation_contribution_1.nativeRolePresentation)("seer"),
};
