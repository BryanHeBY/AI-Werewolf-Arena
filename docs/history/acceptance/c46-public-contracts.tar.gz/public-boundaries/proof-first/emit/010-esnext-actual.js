import { openExileUnit, exileUnitOf } from "../domain/exile-unit";
import { nightUnitOf } from "../domain/night-unit";
import { PhaseRevisionClock } from "./phase-revision";
import { damagePoisonRoutes } from "../domain/damage-evidence";
import { prepareGameSetup, installFragrantGameSetup } from "../rulesets/game-setup";
import { prepareSpecialNightDamage } from "../rulesets/special-night-damage-preparation";
import { prepareOrdinaryNightDeaths, ordinaryNightDeathPublication } from "../rulesets/ordinary-night-death-preparation";
import { bindBoardParameters } from "../rulesets/board-parameters";
import { RulePlan } from "../rulesets/rule-plan";
import { prepareMistDelayedNight, settleMistDelayedNight } from "../rulesets/mist-delayed-night-settlement";
import { demonHunterActorId, assertDemonOriginalRoster, assertDemonNightReadable, } from "../features/demon-hunter/ports";
import { demonWitchMarksSafe } from "../features/demon-hunter/ports";
import { weddingSetup, } from "../features/ghost-bride/ports";
import { publishInitialIdentityDeal } from "../features/initial-identity/ports";
import { WallNotesWindow } from "../features/wall-notes/window-ports";
import { GameActionRequestFactory } from "./actions/action-request-factory";
import { TERMINAL_VICTORY_POLICY } from "../rulesets/terminal-victory-policy";
import { settleRedMoonExpiry } from "../rulesets/red-moon-expiry-settlement";
import { text } from "@ai-werewolf-arena/game-text";
import { NightFaultPlan } from "./fault-plan";
import { ActionWindow, Phase, DeathCause, } from "../domain/model";
import { findSheriffId } from "../features/sheriff/badge-ports";
import { DeathResolution } from "./death-resolution";
import { EventRegistry } from "./events/event-registry";
import { DayPipeline } from "./phases/day-pipeline";
import { NightPipeline } from "./phases/night-pipeline";
import { VotingPipeline } from "./phases/voting-pipeline";
import { COMPONENT } from "../domain/components/names";
import { commitSelfDestructSelection } from "../features/self-destruct/selection-ports";
import { settleKnightDay } from "../rulesets/knight-day-settlement";
import { prepareAnimalExileDeaths, captureAnimalExileFeedback, captureOrdinaryExileFeedback, prepareOrdinaryExileDeaths } from "../rulesets/exile-death-preparation";
import { prepareBeautyExileVictory, resolveBeautyExileVictory, beautyExileVictoryOverrides, } from "../rulesets/beauty-exile-victory";
import { captureDawnKnowledge, publishDawnKnowledge } from "../rulesets/dawn-knowledge-publication";
import { beginAnimalExileUnit, completeAndPublishAnimalExileUnit, } from "../features/animal-dream/ports";
import { aliveLifeVersion } from "../domain/components/alive";
import { createRandom } from "../domain/random";
export class PhaseManager {
    world;
    toolGateway;
    roleRegistry;
    conditionRegistry;
    damageResolutionSystem;
    random;
    #rulePlan;
    config;
    events = [];
    eventRegistry;
    nightPipeline;
    dayPipeline;
    votingPipeline;
    deathResolution;
    previousExile = null;
    phaseRevision = new PhaseRevisionClock();
    mistPending = null;
    nightFaultPlan;
    state = {
        day: 1,
        phase: Phase.Night,
        gameOver: false,
        result: null,
    };
    constructor(world, config, toolGateway, roleRegistry, conditionRegistry, damageResolutionSystem, random = createRandom(), options = {}) {
        this.world = world;
        this.toolGateway = toolGateway;
        this.roleRegistry = roleRegistry;
        this.conditionRegistry = conditionRegistry;
        this.damageResolutionSystem = damageResolutionSystem;
        this.random = random;
        const parameters = bindBoardParameters(world, config);
        config = parameters.board;
        this.#rulePlan = RulePlan.compile(parameters);
        this.config = config;
        installFragrantGameSetup(config, { world: () => world, events: () => this.events });
        if (options.faultPlan !== undefined) {
            if (demonHunterActorId(world) === null)
                throw new Error("fault_plan_demon_board_required");
            this.nightFaultPlan = new NightFaultPlan(world, options.faultPlan);
        }
        this.eventRegistry = new EventRegistry();
        this.deathResolution = new DeathResolution(world, this.events, toolGateway, this.eventRegistry, this.state, config);
        this.nightPipeline = new NightPipeline({
            rulePlan: this.#rulePlan,
            world,
            toolGateway,
            damageResolutionSystem,
            events: this.events,
            random: random.fork("night"),
        });
        this.dayPipeline = new DayPipeline({
            world,
            roleRegistry,
            toolGateway,
            events: this.events,
        });
        this.votingPipeline = new VotingPipeline({
            world,
            roleRegistry,
            toolGateway,
            eventRegistry: this.eventRegistry,
            events: this.events,
        });
        this.events.push({
            timestamp: Date.now(),
            type: "god_private_game_info",
            payload: {
                boardSize: this.config.boardSize,
                players: this.world.getAliveEntityIds().map((id) => {
                    const identity = this.world.getComponent(id, COMPONENT.Identity);
                    const role = this.world.getComponent(id, COMPONENT.Role);
                    return {
                        id,
                        seat: identity?.seat ?? id,
                        name: identity?.name ?? text(this.world.locale, "common.player_name", { id }),
                        role: role?.role ?? "unknown",
                        camp: (role && this.world.getComponent(id, COMPONENT.Camp)?.camp) ?? "unknown",
                    };
                }),
            },
        });
        publishInitialIdentityDeal({
            world: () => this.world,
            events: () => this.events,
            boardSize: () => this.config.boardSize,
        });
        this.events.push({
            timestamp: Date.now(),
            type: "phase_changed",
            payload: {
                phase: Phase.Night,
                day: this.state.day,
            },
        });
        const initialSheriffId = findSheriffId(this.world);
        this.#rulePlan.wolfKnifeInheritance({
            world: () => this.world,
            events: () => this.events,
            day: () => this.state.day,
        });
        if (initialSheriffId !== null) {
            this.events.push({
                timestamp: Date.now(),
                type: "sheriff_elected",
                payload: {
                    winnerId: initialSheriffId,
                    source: "initial_configuration",
                },
            });
        }
    }
    getFaultPlan() {
        return this.nightFaultPlan?.plan;
    }
    assertFaultPlanConsumed() {
        this.nightFaultPlan?.assertConsumed();
    }
    getSnapshot() {
        return structuredClone(this.state);
    }
    getEvents() {
        return this.events.map((event) => {
            const copy = structuredClone(event);
            if ("audience" in copy)
                Object.freeze(copy.audience);
            return copy;
        });
    }
    jumpTo(phase) {
        if (this.config.mistRaven &&
            !this.state.gameOver &&
            this.pureWhiteStartedDays.has(this.state.day))
            throw new Error("mist_phase_reentry");
        const manager = this;
        this.#rulePlan.phaseJumpAdmission({
            get world() { return manager.world; },
            get state() { return manager.state; },
        });
        this.phaseRevision.advance();
        this.setPhase(phase);
    }
    pureWhiteStartedDays = new Set();
    async runSingleCycle(actionProvider, maxDays = 20) {
        if ((this.config.animalDream ||
            this.config.fragrantPairSeer ||
            this.config.mistRaven ||
            this.config.pureWhite ||
            this.config.evilKnight ||
            this.config.magician) &&
            !this.state.gameOver) {
            if (this.pureWhiteStartedDays.has(this.state.day))
                throw new Error(this.config.animalDream
                    ? "animal_cycle_reentry"
                    : this.config.fragrantPairSeer
                        ? "fragrant_cycle_reentry"
                        : this.config.mistRaven
                            ? "mist_cycle_reentry"
                            : this.config.magician
                                ? "magician_cycle_reentry"
                                : this.config.evilKnight
                                    ? "evil_knight_cycle_reentry"
                                    : "pure_white_cycle_reentry");
            this.pureWhiteStartedDays.add(this.state.day);
        }
        const startedDay = this.state.day;
        const manager = this;
        const lifecycle = this.#rulePlan.createNightManagerLifecycle({
            get world() {
                return manager.world;
            },
            get config() {
                return manager.config;
            },
            abortMistPending() {
                manager.mistPending?.abort();
            },
        });
        let completed = false;
        try {
            const result = await this.runSingleCycleInternal(actionProvider, maxDays, lifecycle);
            completed = this.state.gameOver || this.state.day > startedDay;
            return result;
        }
        catch (error) {
            lifecycle.abortOnError();
            throw error;
        }
        finally {
            lifecycle.abortCycle(completed);
        }
    }
    async runSingleCycleInternal(actionProvider, maxDays = 20, lifecycle) {
        const manager = this;
        this.#rulePlan.cycleAdmission({
            get world() { return manager.world; },
            get state() { return manager.state; },
        });
        if (this.state.gameOver) {
            return this.getSnapshot();
        }
        if (demonHunterActorId(this.world) !== null) {
            const underlying = actionProvider;
            const assertReadable = () => this.assertDemonReadable();
            actionProvider = {
                getAction: async (request) => {
                    assertReadable();
                    const action = await underlying.getAction(request);
                    assertReadable();
                    return action;
                },
            };
        }
        if (this.state.day > maxDays) {
            this.sealResult({ winner: null, reason: "max_days_reached", outcome: { kind: "no_winner" } }, this.#rulePlan.checkpoints.maxDays, Phase.Night);
            return this.getSnapshot();
        }
        this.setPhase(Phase.Night);
        if (this.config.mistRaven) {
            this.mistPending?.abort();
            this.mistPending = null;
        }
        const nightDay = this.state.day, nightRevision = this.phaseRevision.current;
        const nightIsCurrent = () => this.state.day === nightDay &&
            this.state.phase === Phase.Night &&
            !this.state.gameOver &&
            this.phaseRevision.current === nightRevision;
        const setupSequence = prepareGameSetup({
            world: () => this.world,
            toolGateway: () => this.toolGateway,
            events: () => this.events,
            config: () => this.config,
        }, actionProvider, nightDay, nightIsCurrent);
        let setupStep = setupSequence.next();
        while (!setupStep.done)
            setupStep = setupSequence.next(await setupStep.value);
        if (!setupStep.value)
            return this.getSnapshot();
        assertDemonOriginalRoster(this.world);
        const bearFrame = captureDawnKnowledge({
            world: () => this.world,
            signalPolicy: () => this.config.bear?.signalPolicy,
        }, nightDay);
        const night = await this.nightPipeline.execute(this.config, actionProvider, this.state.day, {
            previousExile: this.previousExile,
            isCurrent: nightIsCurrent,
            lifecycleHandoff: lifecycle,
        });
        if (night.interrupted || !nightIsCurrent()) {
            lifecycle.abortSpecialNight(night, nightDay);
            return this.getSnapshot();
        }
        const ownsWedding = weddingSetup(this.world) !== null;
        const ownsDemon = demonHunterActorId(this.world) !== null;
        const ownsPureWhite = this.config.pureWhite !== undefined;
        const ownsEvilKnight = this.config.evilKnight !== undefined;
        if (ownsWedding || ownsDemon || ownsPureWhite || ownsEvilKnight) {
            try {
                const { deaths, sources, originalLives, sourceDamage, livingBeforeChain } = prepareSpecialNightDamage({
                    get world() { return manager.world; },
                    get config() { return manager.config; },
                    get events() { return manager.events; },
                    get nightFaultPlan() { return manager.nightFaultPlan; },
                    assertReadable() { manager.assertDemonReadable(); },
                }, night, nightDay, ownsWedding, ownsDemon, lifecycle);
                await this.deathResolution.resolve(deaths, sources, actionProvider, Phase.Night, Phase.Night, {}, {
                    nightOriginIds: deaths,
                    isCurrent: nightIsCurrent,
                    originalLives,
                    poisonRoutes: damagePoisonRoutes(sourceDamage),
                    execution: { night: nightUnitOf(night), phaseRevision: nightRevision },
                    blocksPassiveNightShot: (id) => night.blocksPassiveNightShot?.(id) ?? false,
                });
                this.assertDemonReadable();
                if (!nightIsCurrent())
                    return this.getSnapshot();
                const expirySettlement = settleRedMoonExpiry({
                    get world() { return manager.world; },
                    get events() { return manager.events; },
                    get registry() { return manager.conditionRegistry; },
                    get config() { return manager.config; },
                    get checkpoint() { return manager.#rulePlan.checkpoints.nightSettled; },
                }, ownsDemon, nightDay);
                const expiryStep = expirySettlement.next();
                let beforeExpiryResult = expiryStep.done ? expiryStep.value : null;
                if (!expiryStep.done) {
                    const expiryActor = expiryStep.value;
                    await this.deathResolution.resolve([expiryActor], { [expiryActor]: [DeathCause.RedMoonExpiry] }, actionProvider, Phase.Night, Phase.Night, {}, { nightOriginIds: [expiryActor], isCurrent: nightIsCurrent, execution: { night: nightUnitOf(night), phaseRevision: nightRevision } });
                    this.assertDemonReadable();
                    if (!nightIsCurrent())
                        return this.getSnapshot();
                    beforeExpiryResult = expirySettlement.next().value;
                }
                const completeDeaths = [
                    ...deaths,
                    ...[...livingBeforeChain]
                        .filter(([id, scope]) => !deaths.includes(id) &&
                        this.world.getComponent(id, COMPONENT.Alive) === scope.life &&
                        !scope.life.alive &&
                        aliveLifeVersion(scope.life) === scope.version + 1)
                        .map(([id]) => id),
                ];
                this.emitNightResolved(completeDeaths);
                if (beforeExpiryResult) {
                    this.sealResult(TERMINAL_VICTORY_POLICY.replaceFactionResult(this.world, beforeExpiryResult), this.#rulePlan.checkpoints.nightSettled, this.state.phase);
                    return this.getSnapshot();
                }
                if (this.checkAndSealResult(this.#rulePlan.checkpoints.nightSettled))
                    return this.getSnapshot();
            }
            finally {
                lifecycle.abortSpecialNight(night, nightDay);
            }
        }
        const firstDaySheriffBeforeNightInfo = !ownsWedding &&
            !ownsDemon &&
            !ownsPureWhite &&
            !ownsEvilKnight &&
            this.state.day === 1 &&
            this.config.enableSheriff === true;
        this.setPhase(Phase.Day);
        const cycleDay = this.state.day, dayRevision = this.phaseRevision.current;
        const dayIsCurrent = () => this.state.day === cycleDay &&
            this.state.phase === Phase.Day &&
            !this.state.gameOver &&
            this.phaseRevision.current === dayRevision;
        let nightSettled = ownsWedding || ownsDemon || ownsPureWhite || ownsEvilKnight;
        if (night.mistDelay) {
            this.mistPending = prepareMistDelayedNight({
                get world() { return manager.world; },
                get cycleDay() { return cycleDay; },
                get night() { return night; },
            });
        }
        const settleMist = async (alreadyClaimed = false, interrupted = false) => {
            if (nightSettled)
                return this.state.gameOver;
            const settlement = settleMistDelayedNight({
                get pending() { return manager.mistPending; },
                get world() { return manager.world; },
                get events() { return manager.events; },
                get toolGateway() { return manager.toolGateway; },
                get lifecycle() { return lifecycle; },
                get cycleDay() { return cycleDay; },
            }, actionProvider, dayIsCurrent, alreadyClaimed);
            const healed = await settlement.next().value;
            const { damage, current } = settlement.next(healed).value;
            this.emitNightResolved(damage.deaths);
            await this.deathResolution.resolve(damage.deaths, damage.deathSources, actionProvider, Phase.Night, Phase.Day, {}, {
                dreams: night.dreamFrame,
                nightOriginIds: damage.deaths,
                isCurrent: current,
                poisonRoutes: damagePoisonRoutes(damage),
                execution: { night: nightUnitOf(night), phaseRevision: dayRevision },
            });
            settlement.next();
            nightSettled = true;
            return this.checkAndSealResult(interrupted
                ? this.#rulePlan.checkpoints.dayInterrupted
                : this.#rulePlan.checkpoints.nightSettled);
        };
        const settleNight = async (blast, animalSkip, skippedUnit) => {
            if (nightSettled)
                return this.state.gameOver;
            nightSettled = true;
            const ordinaryNightRuntime = {
                get world() { return manager.world; },
                get night() { return night; },
                get config() { return manager.config; },
                publishNightResolved(deaths) { return manager.emitNightResolved(deaths()); },
            };
            const { sourceDamage, originalLives, retainedSources, nightDeaths, sources, deaths, deathPhases } = prepareOrdinaryNightDeaths(ordinaryNightRuntime, blast);
            try {
                await this.deathResolution.resolve(deaths, sources, actionProvider, Phase.Night, Phase.Day, deathPhases, {
                    dreams: night.dreamFrame,
                    nightOriginIds: nightDeaths,
                    isCurrent: dayIsCurrent,
                    originalLives,
                    poisonRoutes: damagePoisonRoutes(sourceDamage),
                    execution: { night: nightUnitOf(night), exile: skippedUnit, phaseRevision: dayRevision },
                    ...(animalSkip ? { animalUnit: animalSkip } : {}),
                    ...ordinaryNightDeathPublication(ordinaryNightRuntime, nightDeaths, retainedSources),
                });
                lifecycle.finishDay(cycleDay, dayIsCurrent);
            }
            finally {
                lifecycle.abortInner();
            }
            if (!dayIsCurrent())
                return this.state.gameOver;
            if (animalSkip) {
                completeAndPublishAnimalExileUnit({
                    world: () => this.world,
                    events: () => this.events,
                    day: () => cycleDay,
                }, () => animalSkip);
            }
            publishDawnKnowledge(bearFrame, {
                world: () => this.world,
                events: () => this.events,
                animalDream: () => this.config.animalDream,
            }, cycleDay, dayIsCurrent);
            return this.checkAndSealResult(blast !== undefined
                ? this.#rulePlan.checkpoints.dayInterrupted
                : this.#rulePlan.checkpoints.nightSettled);
        };
        if (!night.mistDelay && !firstDaySheriffBeforeNightInfo && (await settleNight()))
            return this.getSnapshot();
        const dayResult = await this.dayPipeline.execute(this.config, actionProvider, {
            day: cycleDay,
            isCurrent: dayIsCurrent,
            commitSelfDestruct: async (choice, window) => {
                if (!dayIsCurrent())
                    return false;
                if (!nightSettled &&
                    choice.kind === "white_wolf_king" &&
                    night.damage.deaths.includes(choice.actorId))
                    return false;
                const blast = commitSelfDestructSelection(this.world, choice, window, Phase.Day, this.events);
                if (!blast)
                    return false;
                const animalSkip = this.config.animalDream
                    ? beginAnimalExileUnit(this.world, cycleDay, "skipped_day", dayIsCurrent)
                    : undefined;
                const skippedUnit = openExileUnit(cycleDay, "skipped_day", animalSkip);
                if (!nightSettled && this.mistPending) {
                    this.mistPending.claim(dayIsCurrent);
                    await this.deathResolution.resolve(blast.deaths, blast.sources, actionProvider, Phase.Day, Phase.Day, {}, { isCurrent: dayIsCurrent, execution: { exile: skippedUnit, phaseRevision: dayRevision } });
                    if (dayIsCurrent())
                        await settleMist(true, true);
                }
                else if (!nightSettled)
                    await settleNight(blast, animalSkip, skippedUnit);
                else {
                    await this.deathResolution.resolve(blast.deaths, blast.sources, actionProvider, Phase.Day, Phase.Day, {}, { isCurrent: dayIsCurrent, execution: { exile: skippedUnit, phaseRevision: dayRevision }, ...(animalSkip ? { animalUnit: animalSkip } : {}) });
                    if (animalSkip) {
                        completeAndPublishAnimalExileUnit({
                            world: () => this.world,
                            events: () => this.events,
                            day: () => cycleDay,
                        }, () => animalSkip);
                    }
                }
                return true;
            },
            ...(firstDaySheriffBeforeNightInfo && !night.mistDelay
                ? { afterSheriffElection: () => settleNight() }
                : {}),
            commitKnightDuel: async (choice) => {
                const settlement = settleKnightDay({
                    get world() { return manager.world; },
                    get events() { return manager.events; },
                    get isCurrent() { return dayIsCurrent; },
                    get nightSettled() { return nightSettled; },
                    get dayRevision() { return dayRevision; },
                    checkResult() { return manager.checkAndSealResult(manager.#rulePlan.checkpoints.dayInterrupted); },
                }, choice);
                const step = settlement.next();
                if (step.done)
                    return step.value;
                const { duel, duelMetadata } = step.value;
                await this.deathResolution.resolve(duel.deaths, duel.sources, actionProvider, Phase.Day, Phase.Day, {}, duelMetadata);
                return settlement.next().value;
            },
        });
        if (night.mistDelay && !nightSettled && dayIsCurrent())
            await settleMist();
        if (this.state.gameOver || !dayIsCurrent())
            return this.getSnapshot();
        if (dayResult.interrupted) {
            if (this.state.gameOver ||
                this.checkAndSealResult(this.#rulePlan.checkpoints.dayInterrupted)) {
                return this.getSnapshot();
            }
            this.state.day += 1;
            this.setPhase(Phase.Night);
            return this.getSnapshot();
        }
        this.setPhase(Phase.Voting);
        const votingRevision = this.phaseRevision.current;
        const votingIsCurrent = () => this.state.day === cycleDay &&
            this.state.phase === Phase.Voting &&
            !this.state.gameOver &&
            this.phaseRevision.current === votingRevision;
        const votingResult = await this.votingPipeline.execute(this.config, actionProvider, {
            day: cycleDay,
            isCurrent: votingIsCurrent,
            commitSelfDestruct: async (choice) => {
                if (!votingIsCurrent())
                    return false;
                const blast = commitSelfDestructSelection(this.world, choice, ActionWindow.OnPreVote, Phase.Voting, this.events);
                if (!blast)
                    return false;
                const animalSkip = this.config.animalDream
                    ? beginAnimalExileUnit(this.world, cycleDay, "skipped_day", votingIsCurrent)
                    : undefined;
                const skippedUnit = openExileUnit(cycleDay, "skipped_day", animalSkip);
                await this.deathResolution.resolve(blast.deaths, blast.sources, actionProvider, Phase.Voting, Phase.Voting, {}, { isCurrent: votingIsCurrent, execution: { exile: skippedUnit, phaseRevision: votingRevision }, ...(animalSkip ? { animalUnit: animalSkip } : {}) });
                if (animalSkip) {
                    completeAndPublishAnimalExileUnit({
                        world: () => this.world,
                        events: () => this.events,
                        day: () => cycleDay,
                    }, () => animalSkip);
                }
                return true;
            },
        });
        if (!votingIsCurrent())
            return this.getSnapshot();
        if (votingResult.interrupted) {
            if (this.checkAndSealResult(this.#rulePlan.checkpoints.dayInterrupted)) {
                return this.getSnapshot();
            }
            this.state.day += 1;
            this.setPhase(Phase.Night);
            return this.getSnapshot();
        }
        let beautyCandidate = null;
        if (votingResult.animalUnit) {
            const { sources, ids } = prepareAnimalExileDeaths(votingResult);
            await this.deathResolution.resolve(ids, sources, actionProvider, Phase.Voting, Phase.Voting, {}, { isCurrent: votingIsCurrent, animalUnit: votingResult.animalUnit, execution: { exile: exileUnitOf(votingResult), phaseRevision: votingRevision } });
            if (!votingIsCurrent())
                return this.getSnapshot();
            completeAndPublishAnimalExileUnit({
                world: () => this.world,
                events: () => this.events,
                day: () => cycleDay,
            }, () => votingResult.animalUnit);
            this.previousExile = captureAnimalExileFeedback(() => this.world, votingResult, sources, cycleDay);
        }
        else if (votingResult.removed.length > 0) {
            const { target, candidate } = prepareBeautyExileVictory(votingResult, () => this.world);
            beautyCandidate = candidate;
            this.previousExile = captureOrdinaryExileFeedback(() => this.world, votingResult, target, cycleDay);
            const sources = prepareOrdinaryExileDeaths(votingResult);
            await this.deathResolution.resolve(votingResult.removed, sources, actionProvider, Phase.Voting, Phase.Voting, {}, { isCurrent: votingIsCurrent, execution: { exile: exileUnitOf(votingResult), phaseRevision: votingRevision } });
        }
        if (!votingIsCurrent())
            return this.getSnapshot();
        const beautyResult = resolveBeautyExileVictory(this.world, beautyCandidate);
        if (this.checkAndSealResult(this.#rulePlan.checkpoints.exileSettled, beautyExileVictoryOverrides(beautyResult))) {
            return this.getSnapshot();
        }
        await new WallNotesWindow(this.world, this.toolGateway, this.events).execute(this.config, new GameActionRequestFactory(this.world, this.events, cycleDay), actionProvider, cycleDay, votingIsCurrent, () => this.random.fork("wall_notes"));
        if (!votingIsCurrent())
            return this.getSnapshot();
        this.state.day += 1;
        return this.getSnapshot();
    }
    async runUntilGameOver(actionProvider, maxDays = 20) {
        while (!this.state.gameOver) {
            await this.runSingleCycle(actionProvider, maxDays);
        }
        return this.getSnapshot();
    }
    getRulePlan() {
        return this.#rulePlan;
    }
    checkAndSealResult(checkpoint, overrides = {}) {
        if (this.state.gameOver)
            return true;
        const result = this.conditionRegistry.evaluateMany(this.world, TERMINAL_VICTORY_POLICY.conditions({ world: () => this.world, config: () => this.config }), checkpoint, overrides);
        if (!result)
            return false;
        this.sealResult(TERMINAL_VICTORY_POLICY.replaceFactionResult(this.world, result), checkpoint, this.state.phase);
        return true;
    }
    sealResult(decision, checkpoint, phase) {
        if (this.state.gameOver)
            return;
        this.assertFaultPlanConsumed();
        const { winner, outcome, decidedAt } = TERMINAL_VICTORY_POLICY.validateCandidate(decision, checkpoint, phase, () => this.world, () => this.state.day);
        this.state.result = { winner, reason: decision.reason, outcome, decidedAt };
        this.state.gameOver = true;
        this.setPhase(Phase.GameOver);
        this.events.push({
            timestamp: Date.now(),
            type: "game_over",
            payload: structuredClone(this.state.result),
        });
    }
    assertDemonReadable() {
        if (demonHunterActorId(this.world) === null)
            return;
        assertDemonNightReadable(this.world);
        if (!this.world.entityIds().every((id) => demonWitchMarksSafe(this.world, id)))
            throw new Error("demon_hunter_unreadable_marks");
    }
    emitNightResolved(deaths) {
        const event = {
            timestamp: Date.now(),
            type: "night_resolved",
            payload: {
                deaths: [...deaths],
            },
        };
        this.events.push(event);
        return event;
    }
    debugResult() {
        return this.state.result === null ? null : structuredClone(this.state.result);
    }
    setPhase(phase) {
        const previous = this.state.phase;
        this.state.phase = phase;
        if (previous === phase) {
            return;
        }
        this.phaseRevision.advance();
        this.world.closeDeathActions();
        const gameOverPayload = phase === Phase.GameOver && this.state.result
            ? {
                winner: this.state.result.winner,
                reason: this.state.result.reason,
                outcome: structuredClone(this.state.result.outcome),
                decidedAt: { ...this.state.result.decidedAt },
            }
            : {};
        this.events.push({
            timestamp: Date.now(),
            type: "phase_changed",
            payload: {
                phase,
                day: this.state.day,
                ...gameOverPayload,
            },
        });
    }
}
