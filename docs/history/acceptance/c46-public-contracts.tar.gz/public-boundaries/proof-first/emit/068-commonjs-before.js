"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WITCH_STATE_SLOT = void 0;
exports.setWitchState = setWitchState;
exports.getWitchState = getWitchState;
exports.resetWitchNightState = resetWitchNightState;
exports.refreshWitchSelfHeal = refreshWitchSelfHeal;
exports.closeWitchPotionTurn = closeWitchPotionTurn;
exports.consumeWitchHeal = consumeWitchHeal;
exports.consumeWitchPoison = consumeWitchPoison;
exports.consumeRecipientPoison = consumeRecipientPoison;
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const abilities_1 = require("../night-abilities/abilities");
const abilities_2 = require("../night-abilities/abilities");
function setWitchState(roleComp, state) {
    return (0, abilities_2.commitPreparedNativeAbility)(roleComp, "potion", exports.WITCH_STATE_SLOT.create(state));
}
function getWitchState(roleComp, abilityId) {
    return (0, abilities_1.findNightAbility)(roleComp, "potion", abilityId)?.state;
}
function resetWitchNightState(state, currentDay) {
    state.healUsedThisNight = false;
    state.poisonUsedThisNight = false;
    state.canSelfHeal =
        state.selfHealRule === game_contract_1.WitchSelfHealRule.Always ||
            (state.selfHealRule === game_contract_1.WitchSelfHealRule.FirstNightOnly && currentDay() === 1);
}
function refreshWitchSelfHeal(ability, day) {
    const state = ability.state;
    state.canSelfHeal =
        ability.state.selfHealRule === game_contract_1.WitchSelfHealRule.Always ||
            (ability.state.selfHealRule === game_contract_1.WitchSelfHealRule.FirstNightOnly && day === 1);
}
function closeWitchPotionTurn(ability, day) {
    ability.state.potionTurnClosedDay = day;
}
function consumeWitchHeal(state) {
    state.heal -= 1;
    state.healUsedThisNight = true;
}
function consumeWitchPoison(state) {
    state.poison -= 1;
    state.poisonUsedThisNight = true;
}
function consumeRecipientPoison(ability) {
    ability.state.poison--;
    ability.state.poisonUsedThisNight = true;
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.selfHealRule,
        ability.state.knifeVisibility,
        ability.state.potionPolicy]);
}
exports.WITCH_STATE_SLOT = Object.freeze({
    create: (abilities_1.copyAbilityData),
    schema: (abilities_1.copyAbilityData),
    install: setWitchState,
    get: getWitchState,
    allowedWrites: Object.freeze({
        resetWitchNightState,
        refreshWitchSelfHeal,
        closeWitchPotionTurn,
        consumeWitchHeal,
        consumeWitchPoison,
        consumeRecipientPoison,
    }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
