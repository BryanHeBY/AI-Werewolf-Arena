"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SHELTER_STATE_SLOT = void 0;
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const inventory_ports_2 = require("../night-abilities/inventory-ports");
const shelter_state_1 = require("./shelter-state");
function installShelterState(role, state) {
    return (0, inventory_ports_2.commitPreparedNativeAbility)(role, "shelter", exports.SHELTER_STATE_SLOT.prepare(state));
}
function recordShelterSelection(ability, next) {
    Object.assign(ability.state, next);
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.policy]);
}
exports.SHELTER_STATE_SLOT = Object.freeze({
    create: shelter_state_1.createShelterState,
    prepare: (inventory_ports_1.copyAbilityData),
    schema: shelter_state_1.readShelterState,
    select: shelter_state_1.selectShelter,
    project: shelter_state_1.projectShelterState,
    install: installShelterState,
    allowedWrites: Object.freeze({ recordShelterSelection }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
