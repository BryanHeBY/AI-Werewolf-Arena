"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DREAMER_STATE_SLOT = void 0;
exports.setDreamerState = setDreamerState;
exports.getDreamerState = getDreamerState;
exports.recordDreamSelection = recordDreamSelection;
const abilities_1 = require("../night-abilities/abilities");
const abilities_2 = require("../night-abilities/abilities");
function setDreamerState(roleComp, state) {
    return (0, abilities_2.commitPreparedNativeAbility)(roleComp, "dream", exports.DREAMER_STATE_SLOT.create(state));
}
function getDreamerState(roleComp, abilityId) {
    return (0, abilities_1.findNightAbility)(roleComp, "dream", abilityId)?.state;
}
function recordDreamSelection(state, targetId, day) {
    state.lastTarget = targetId;
    state.lastDay = day;
    state.history.push({ day, targetId });
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.protectionPolicy]);
}
exports.DREAMER_STATE_SLOT = Object.freeze({
    create: (abilities_1.copyAbilityData),
    schema: (abilities_1.copyAbilityData),
    install: setDreamerState,
    get: getDreamerState,
    allowedWrites: Object.freeze({ recordDreamSelection }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
