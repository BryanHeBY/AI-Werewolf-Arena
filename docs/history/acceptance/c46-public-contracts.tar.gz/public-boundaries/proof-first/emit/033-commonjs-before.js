"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hunterDeathHook = void 0;
const model_1 = require("../../domain/model");
const native_death_gun_resources_1 = require("../death-actions/native-death-gun-resources");
const native_gun_ports_1 = require("../demon-hunter/native-gun-ports");
const native_death_shot_settlement_1 = require("../death-actions/native-death-shot-settlement");
const hunterDeathHook = (world, ids, sources, choose, events, context) => (0, native_death_shot_settlement_1.resolveNativeDeathShots)(world, ids, sources, choose, events, {
    role: model_1.Role.Hunter,
    state: native_death_gun_resources_1.getHunterState,
    get openHunterStock() { return native_gun_ports_1.openDemonHunterStockFrame; },
    permits: (sources) => (0, model_1.permitsHunterShot)(sources),
    policy: (state) => state.deathActionPolicy ?? "awa_qualified_sources_v1",
    poisonEvent: (hunterId) => ({
        timestamp: Date.now(),
        type: "hunter_silent_due_to_poison",
        payload: { hunterId },
    }),
    shotEvent: (hunterId, targetId) => ({
        timestamp: Date.now(),
        type: "hunter_shot",
        payload: { hunterId, targetId },
    }),
}, context);
exports.hunterDeathHook = hunterDeathHook;
