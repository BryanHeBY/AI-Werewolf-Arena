"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.captureNightAbilityScope = captureNightAbilityScope;
const turn_ports_1 = require("../radiant-eclipse/turn-ports");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const names_1 = require("../../domain/components/names");
const night_effects_1 = require("../../domain/night-effects");
const abilities_1 = require("./abilities");
const alive_1 = require("../../domain/components/alive");
const ports_1 = require("../dreamer/ports");
const shelter_slot_ports_1 = require("../radiant-eclipse/shelter-slot-ports");
const ports_2 = require("../seer/ports");
const ports_3 = require("../guard/ports");
const ports_4 = require("../witch/ports");
const ports_5 = require("../role-inspection/ports");
function policyIdentity(ability) {
    switch (ability.kind) {
        case "pair_check":
            return JSON.stringify([ability.state.policy]);
        case "shelter":
            return shelter_slot_ports_1.SHELTER_STATE_SLOT.invalidations.policyIdentity(ability);
        case "seer_check":
            return ports_2.SEER_STATE_SLOT.invalidations.policyIdentity(ability);
        case "potion":
            return ports_4.WITCH_STATE_SLOT.invalidations.policyIdentity(ability);
        case "guard":
            return ports_3.GUARD_STATE_SLOT.invalidations.policyIdentity(ability);
        case "role_check":
            return ports_5.ROLE_INSPECTION_STATE_SLOT.checkpoint.policyIdentity(ability);
        case "dream":
            return ports_1.DREAMER_STATE_SLOT.invalidations.policyIdentity(ability);
    }
}
function captureNightAbilityScope(world, actorId, ability, day, phaseCurrent) {
    const role = world.getComponent(actorId, names_1.COMPONENT.Role), life = (0, night_effects_1.captureNightLife)(world, actorId);
    if (!role || !life)
        return null;
    const radiantCurrent = (0, turn_ports_1.captureRadiantTurn)(world, actorId, ability, day);
    const roleKind = role.role, camp = world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp, privateState = role.privateState;
    const state = ability.state, kind = ability.kind, activation = ability.activation, id = ability.id;
    const source = ability.source, sourceKind = source.kind, sourceOwner = source.kind === "native" ? source.role : source.actorId, sourceId = source.kind === "copy" || source.kind === "transfer" ? source.abilityId : undefined;
    const policy = policyIdentity(ability);
    const starts = ability.startsOnDay, expires = ability.expiresAfterDay, maxUses = ability.maxUses, disclosed = ability.sourceDisclosed;
    const ownerCurrent = (allowFirstDeath = false) => phaseCurrent() &&
        world.getComponent(actorId, names_1.COMPONENT.Role) === role &&
        role.role === roleKind &&
        world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === camp &&
        role.privateState === privateState &&
        ((0, night_effects_1.livingNightLife)(world, life) ||
            (allowFirstDeath &&
                world.getComponent(actorId, names_1.COMPONENT.Alive) === life.life &&
                !life.life.alive &&
                (0, alive_1.aliveLifeVersion)(life.life) === life.version + 1)) &&
        ability.id === id &&
        ability.kind === kind &&
        ability.activation === activation &&
        ability.state === state &&
        policyIdentity(ability) === policy &&
        role.privateState.abilities?.[id] === ability &&
        ability.source === source &&
        source.kind === sourceKind &&
        (source.kind === "native" ? source.role : source.actorId) === sourceOwner &&
        (source.kind === "copy" || source.kind === "transfer" ? source.abilityId : undefined) ===
            sourceId &&
        ability.startsOnDay === starts &&
        ability.expiresAfterDay === expires &&
        ability.maxUses === maxUses &&
        ability.sourceDisclosed === disclosed;
    return {
        role,
        life,
        state,
        isOwnerCurrent: ownerCurrent,
        isEligible: () => radiantCurrent() &&
            ownerCurrent() &&
            !(0, role_execution_authority_1.isRoleExecutionRetired)(role) &&
            (0, abilities_1.activeNightAbility)(role, kind, day, id) === ability,
    };
}
