import { copyAbilityData } from "../night-abilities/inventory-ports";
import { commitPreparedNativeAbility } from "../night-abilities/inventory-ports";
import { createShelterState, readShelterState, selectShelter, projectShelterState } from "./shelter-state";
function installShelterState(role, state) {
    return commitPreparedNativeAbility(role, "shelter", SHELTER_STATE_SLOT.prepare(state));
}
function recordShelterSelection(ability, next) {
    Object.assign(ability.state, next);
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.policy]);
}
export const SHELTER_STATE_SLOT = Object.freeze({
    create: createShelterState,
    prepare: (copyAbilityData),
    schema: readShelterState,
    select: selectShelter,
    project: projectShelterState,
    install: installShelterState,
    allowedWrites: Object.freeze({ recordShelterSelection }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
