"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setHunterState = exports.getHunterState = void 0;
var native_death_gun_resources_1 = require("../death-actions/native-death-gun-resources");
Object.defineProperty(exports, "getHunterState", { enumerable: true, get: function () { return native_death_gun_resources_1.getHunterState; } });
Object.defineProperty(exports, "setHunterState", { enumerable: true, get: function () { return native_death_gun_resources_1.setHunterState; } });
