"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolValidationRuleRegistry = void 0;
exports.getDefaultToolValidationRuleRegistry = getDefaultToolValidationRuleRegistry;
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const common_validation_rules_1 = require("./common-validation-rules");
const role_catalog_assembly_1 = require("../../rulesets/roles/role-catalog-assembly");
const validation_ports_1 = require("../../features/sheriff/validation-ports");
const gift_gun_ports_1 = require("../../features/death-actions/gift-gun-ports");
function buildDefaultRules(roleProfileRegistry) {
    const rules = {
        ...common_validation_rules_1.COMMON_VALIDATION_RULES,
        ...validation_ports_1.SHERIFF_VALIDATION_RULES,
    };
    for (const { runtime: profile } of roleProfileRegistry.allRuntime()) {
        if (profile.validationRules) {
            Object.assign(rules, profile.validationRules);
        }
    }
    return rules;
}
class ToolValidationRuleRegistry {
    roleProfileRegistry;
    rules;
    useProfileRules;
    constructor(rules, roleProfileRegistry = (0, role_catalog_assembly_1.getDefaultRoleCatalog)()) {
        this.roleProfileRegistry = roleProfileRegistry;
        this.rules = { ...(rules ?? buildDefaultRules(roleProfileRegistry)) };
        this.useProfileRules = rules === undefined;
    }
    validate(ctx) {
        if (this.useProfileRules && ctx.toolCall.name === "shoot" && ctx.abilityId !== undefined)
            return (0, gift_gun_ports_1.validateGiftGun)({ ...ctx, roleCatalog: this.roleProfileRegistry });
        const rule = (this.useProfileRules
            ? this.roleProfileRegistry.runtime(ctx.role.role)?.validationRules?.[ctx.toolCall.name]
            : undefined) ?? this.rules[ctx.toolCall.name];
        if (!rule) {
            return { code: game_contract_1.RuleError.UnknownTool };
        }
        const result = rule({ ...ctx, roleCatalog: this.roleProfileRegistry });
        return !result
            ? null
            : typeof result === "string"
                ? { code: game_contract_1.RuleError.CustomRuleError, message: result }
                : result;
    }
}
exports.ToolValidationRuleRegistry = ToolValidationRuleRegistry;
let defaultRegistry = null;
function getDefaultToolValidationRuleRegistry() {
    if (!defaultRegistry) {
        defaultRegistry = new ToolValidationRuleRegistry();
    }
    return defaultRegistry;
}
