"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeathCommitter = void 0;
const death_wave_1 = require("./death-wave");
const context_1 = require("../recording/session/context");
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const alive_1 = require("../domain/components/alive");
const names_1 = require("../domain/components/names");
const model_1 = require("../domain/model");
const ports_1 = require("../features/animal-dream/ports");
const ports_2 = require("../features/noble-secret-body/ports");
const ports_3 = require("../features/noble-secret-body/ports");
const ports_4 = require("../features/wild-child/ports");
const death_abilities_1 = require("../features/death-actions/death-abilities");
const abilities_1 = require("../features/night-abilities/abilities");
const ports_5 = require("../features/hidden-wolf/ports");
const ports_6 = require("../features/gargoyle/ports");
const ports_7 = require("../features/mechanical-wolf/ports");
const ports_8 = require("../features/awakened-hidden-wolf/ports");
class DeathCommitter {
    context;
    settledLives = new Map();
    constructor(context) {
        this.context = context;
    }
    isSettledLife(id) {
        const alive = this.context.world.getComponent(id, names_1.COMPONENT.Alive), settled = this.settledLives.get(id);
        return (alive !== undefined &&
            settled?.component === alive &&
            settled.version === (0, alive_1.aliveLifeVersion)(alive));
    }
    markPlayersDead(playerIds, refreshInheritance = true, gunsToExpire = [], reveal = false, sources = {}, animalScope, wave) {
        if (wave && (wave.ids !== playerIds || wave.sources !== sources))
            throw new Error("death_wave_commit_input_mismatch");
        const committedWave = wave ?? (0, death_wave_1.planDeathWave)(playerIds, sources, "legacy");
        const entries = [];
        for (const id of playerIds) {
            const alive = this.context.world.getComponent(id, names_1.COMPONENT.Alive);
            if (!alive) {
                continue;
            }
            const firstSettlement = !this.isSettledLife(id);
            if (firstSettlement)
                (0, ports_4.recordWildChildDeathCommit)(this.context.world, id);
            alive.alive = false;
            if (firstSettlement && (0, ports_1.isAnimalDreamBoard)(this.context.world)) {
                if ((sources[id] ?? []).includes(model_1.DeathCause.WolfKill) &&
                    this.context.world.getComponent(id, names_1.COMPONENT.Role)?.role === model_1.Role.Pufferfish) {
                    (0, ports_1.commitAnimalPufferKnifeDeath)(this.context.world, this.context.state.day, sources[id] ?? [], animalScope ?? (() => !this.context.state.gameOver));
                }
                if ((sources[id] ?? []).includes(model_1.DeathCause.Exile))
                    this.context.events.push({
                        timestamp: Date.now(),
                        type: "voted_out",
                        payload: { target: id },
                    });
                else if ((sources[id] ?? []).some((c) => c === model_1.DeathCause.PufferRetaliation || c === model_1.DeathCause.WhiteCatExpiry))
                    this.context.events.push({
                        timestamp: Date.now(),
                        type: "additional_deaths",
                        payload: { deaths: [id] },
                    });
            }
            if (firstSettlement && (0, ports_2.isNobleBodyBoard)(this.context.world)) {
                const closed = (0, ports_2.closeServantForDeath)(this.context.world, this.context.state.day, id);
                const payload = {
                    policy: "awa_noble_secret_body_v1",
                    actorId: id,
                    day: this.context.state.day,
                    causes: [...(sources[id] ?? [])],
                };
                this.context.events.push({
                    timestamp: Date.now(),
                    type: "noble_body_death_committed",
                    payload,
                    audience: Object.freeze([]),
                });
                (0, context_1.getSessionRecorder)()?.recordRequiredLogicOp({
                    scope: "resolution",
                    op: "noble_body_death_committed",
                    phase: this.context.state.phase,
                    status: "ok",
                    output: {
                        policy: payload.policy,
                        playerId: id,
                        day: payload.day,
                        causes: payload.causes,
                    },
                });
                if (closed)
                    (0, ports_3.appendNobleContractClosure)(this.context.world, this.context.state.day, closed, this.context.events, this.context.state.phase);
            }
            const role = this.context.world.getComponent(id, names_1.COMPONENT.Role)?.role;
            if (reveal && firstSettlement && (0, game_contract_1.isRoleId)(role))
                this.context.events.push({
                    timestamp: Date.now(),
                    type: "player_role_revealed",
                    payload: { playerId: id, role },
                });
            gunsToExpire.push(...(0, death_abilities_1.firstDeathGuns)(this.context.world, id));
            (0, abilities_1.expireLuckyAbilitiesOnDeath)(this.context.world, id, this.context.events);
            let settled;
            this.settledLives.set(id, (settled = { component: alive, version: (0, alive_1.aliveLifeVersion)(alive) }));
            Object.freeze(settled);
            entries.push((0, death_wave_1.committedDeathEntry)(committedWave, id, firstSettlement, settled));
        }
        if (refreshInheritance) {
            (0, ports_5.refreshHiddenWolfInheritance)(this.context.world, this.context.events, this.context.state.day);
            (0, ports_6.refreshGargoyleInheritance)(this.context.world, this.context.events, this.context.state.day);
            (0, ports_7.refreshMechanicalInheritance)(this.context.world, this.context.state.day, this.context.events);
            (0, ports_8.refreshAwakenedInheritance)(this.context.world, this.context.state.day, this.context.events);
        }
        return new death_wave_1.DeathCommitReceipt(committedWave, Object.freeze(entries));
    }
}
exports.DeathCommitter = DeathCommitter;
