"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasRoleInspectionNightCommit = hasRoleInspectionNightCommit;
exports.beginRoleInspectionNight = beginRoleInspectionNight;
exports.recordRoleInspectionNightCommit = recordRoleInspectionNightCommit;
exports.recordRoleInspectionCompletion = recordRoleInspectionCompletion;
exports.completedGargoyleInspection = completedGargoyleInspection;
const role_inspection_policy_1 = require("@ai-werewolf-arena/game-contract/role-inspection-policy");
const alive_1 = require("../../domain/components/alive");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const ports_1 = require("../gargoyle/ports");
const state_slot_1 = require("./state-slot");
const nights = new WeakMap();
const committed = new WeakMap();
function hasRoleInspectionNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
function beginRoleInspectionNight(world, day) {
    if (nights.get(world)?.day !== day)
        nights.set(world, { day, completed: new Map() });
}
function recordRoleInspectionNightCommit(world, day, isCurrent) {
    if (!isCurrent())
        return;
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
function recordRoleInspectionCompletion(world, actorId, day, ability, isCurrent) {
    if (!isCurrent())
        return;
    recordRoleInspectionNightCommit(world, day, isCurrent);
    const role = world.getComponent(actorId, names_1.COMPONENT.Role), state = role && (0, ports_1.getGargoyleState)(role), life = world.getComponent(actorId, names_1.COMPONENT.Alive), version = life && (0, alive_1.aliveLifeVersion)(life);
    if ((0, role_inspection_policy_1.roleInspectionPolicy)(ability.state) !== "gargoyle" ||
        role?.role !== model_1.Role.Gargoyle ||
        !state ||
        !life?.alive ||
        version === undefined ||
        ability.source.kind !== "native" ||
        ability.source.role !== model_1.Role.Gargoyle)
        return;
    beginRoleInspectionNight(world, day);
    nights.get(world).completed.set(role, {
        actorId,
        role,
        privateState: role.privateState,
        state,
        ability,
        abilityId: ability.id,
        activation: ability.activation,
        inspection: ability.state,
        inspectionPolicy: ability.state.inspectionPolicy,
        life,
        version,
        isCurrent,
    });
}
function completedGargoyleInspection(world, role) {
    const scope = nights.get(world)?.completed.get(role);
    if (!scope ||
        !scope.isCurrent() ||
        role.privateState !== scope.privateState ||
        (0, ports_1.getGargoyleState)(role) !== scope.state ||
        role.role !== model_1.Role.Gargoyle ||
        scope.ability.id !== scope.abilityId ||
        scope.ability.activation !== scope.activation ||
        (0, inventory_ports_1.findNightAbility)(role, "role_check", scope.abilityId) !== scope.ability ||
        scope.ability.source.kind !== "native" ||
        scope.ability.source.role !== model_1.Role.Gargoyle ||
        scope.ability.disabled ||
        state_slot_1.ROLE_INSPECTION_STATE_SLOT.invalidations.payloadChanged(scope))
        return false;
    return (world.getComponent(scope.actorId, names_1.COMPONENT.Role) === role &&
        world.getComponent(scope.actorId, names_1.COMPONENT.Alive) === scope.life &&
        scope.life.alive &&
        (0, alive_1.aliveLifeVersion)(scope.life) === scope.version);
}
