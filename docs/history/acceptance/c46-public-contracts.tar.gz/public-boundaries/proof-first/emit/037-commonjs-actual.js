"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mechanicalDeathHook = void 0;
const model_1 = require("../../domain/model");
const settlement_ports_1 = require("../death-actions/settlement-ports");
const state_1 = require("./state");
const native_resource_ports_1 = require("../death-actions/native-resource-ports");
const mechanicalDeathHook = (world, ids, sources, choose, events, context) => {
    const readGun = (0, native_resource_ports_1.createMechanicalGunReader)({ get getMechanicalState() { return state_1.getMechanicalState; } });
    return (0, settlement_ports_1.resolveNativeDeathShots)(world, ids, sources, choose, events, {
        role: model_1.Role.MechanicalWolf,
        state: readGun,
        permits: model_1.permitsDeathShot,
        shotEvent: (actorId, targetId) => ({
            timestamp: Date.now(),
            type: "mechanical_shot",
            payload: { actorId, targetId },
        }),
    }, context);
};
exports.mechanicalDeathHook = mechanicalDeathHook;
