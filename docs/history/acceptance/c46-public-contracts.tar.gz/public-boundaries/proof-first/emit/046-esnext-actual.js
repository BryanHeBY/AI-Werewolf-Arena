import { Role } from "../../domain/model";
import { projectPairState, copyAbilityData, commitPreparedNativeAbility } from "./abilities";
import { DREAMER_STATE_SLOT } from "../dreamer/ports";
import { SHELTER_STATE_SLOT } from "../radiant-eclipse/shelter-slot-ports";
import { SEER_STATE_SLOT } from "../seer/ports";
import { GUARD_STATE_SLOT } from "../guard/ports";
import { WITCH_STATE_SLOT } from "../witch/ports";
import { ROLE_INSPECTION_STATE_SLOT } from "../role-inspection/ports";
export function installNativeAbility(role, kind, state, mayCommit) {
    if (kind === "pair_check" && role.role !== Role.AwakenedSeer)
        throw Error("ability_pair_native_role_invalid");
    const ownedState = (kind === "pair_check"
        ? copyAbilityData(projectPairState(state))
        : kind === "role_check"
            ? ROLE_INSPECTION_STATE_SLOT.create(state)
            : kind === "seer_check"
                ? SEER_STATE_SLOT.create(state)
                : kind === "guard"
                    ? GUARD_STATE_SLOT.create(state)
                    : kind === "potion"
                        ? WITCH_STATE_SLOT.create(state)
                        : kind === "dream"
                            ? DREAMER_STATE_SLOT.create(state)
                            : kind === "shelter"
                                ? SHELTER_STATE_SLOT.prepare(state)
                                : copyAbilityData(state));
    return mayCommit
        ? commitPreparedNativeAbility(role, kind, ownedState, mayCommit)
        : commitPreparedNativeAbility(role, kind, ownedState);
}
