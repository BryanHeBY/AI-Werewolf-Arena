import { roleInspectionPolicy } from "@ai-werewolf-arena/game-contract/role-inspection-policy";
import { nativeRolePresentation } from "../../rulesets/roles/presentation-contribution";
import { inspectionConfiguration } from "../role-inspection/contribution-ports";
import { roleName, text } from "@ai-werewolf-arena/game-text";
import { Camp, Role } from "../../domain/model";
import { setRoleInspectionState } from "../role-inspection/ports";
import { findNightAbility, retiredNightAbilityIds } from "../night-abilities/abilities";
import { numberOrNull } from "../../agents/tool-repair/helpers";
import { MIRROR_INSPECTION_STAGE } from "../role-inspection/contribution-ports";
import { ROLE_INSPECTION_TOOL, validateRoleInspection, roleInspectionTargets, } from "../role-inspection/contribution-ports";
import { nativeMirror, freshMirrorInspectionState } from "./native-inspection";
export { freshMirrorInspectionState } from "./native-inspection";
export const MIRROR_GIRL_ROLE_PROFILE = {
    metadata: {
        role: Role.MirrorGirl,
        camp: Camp.Good,
        goodSide: "god",
        maxCount: 1,
        label: roleName("mirror_girl"),
        skillBrief: text("zh-CN", "role.mirror_girl.brief"),
        supportedBoardRoles: [
            Role.CursedFox,
            Role.MirrorGirl,
            Role.AwakenedHiddenWolf,
            Role.Wolf,
            Role.WolfKing,
            Role.HiddenWolf,
            Role.Gargoyle,
            Role.Psychic,
            Role.Seer,
            Role.Witch,
            Role.Guard,
            Role.Hunter,
            Role.Idiot,
            Role.Villager,
        ],
    },
    runtime: {
        init: (role, ctx) => {
            const native = nativeMirror(role);
            if (native?.kind === "role_check" && roleInspectionPolicy(native.state) !== "mirror")
                throw new Error("mirror_native_policy_invalid");
            if (!native && !retiredNightAbilityIds(role).some((id) => id.startsWith("native:role_check")))
                setRoleInspectionState(role, {
                    ...freshMirrorInspectionState(),
                    ...(ctx.boardConfig?.mirrorGirl?.inspectionPolicy &&
                        ctx.boardConfig.mirrorGirl.inspectionPolicy !== "awa_unique_optional_v1"
                        ? { inspectionPolicy: ctx.boardConfig.mirrorGirl.inspectionPolicy }
                        : {}),
                });
        },
        configuration: inspectionConfiguration("mirrorGirl", "awa_unique_optional_v1"),
        toolSpecs: [ROLE_INSPECTION_TOOL],
        validationRules: { inspect_role: validateRoleInspection },
        nightStages: [MIRROR_INSPECTION_STAGE],
        possibleNightAbilities: ["role_check"],
        llmRepair: {
            coerce: {
                inspect_role: (args) => {
                    const target = numberOrNull(args.target_id);
                    return target === null ? null : { target_id: target };
                },
            },
        },
        baselineAction: (role, request, _pick, _byCamp, _locale, world) => {
            if (!world || !request.allowedTools.includes("inspect_role"))
                return null;
            const ability = findNightAbility(role, "role_check", request.context.ability_id), target = ability
                ? roleInspectionTargets(world, request.actorId, ability.state)[0]
                : undefined;
            return target === undefined ? null : { name: "inspect_role", args: { target_id: target } };
        },
    },
    presentation: nativeRolePresentation("mirror_girl"),
};
