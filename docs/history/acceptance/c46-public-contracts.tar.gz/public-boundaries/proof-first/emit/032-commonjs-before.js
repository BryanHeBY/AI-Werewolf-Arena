"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GUARD_STATE_SLOT = void 0;
exports.setGuardState = setGuardState;
exports.getGuardState = getGuardState;
exports.recordGuardTarget = recordGuardTarget;
exports.recordRecipientGuardTarget = recordRecipientGuardTarget;
const abilities_1 = require("../night-abilities/abilities");
const abilities_2 = require("../night-abilities/abilities");
function setGuardState(roleComp, state) {
    return (0, abilities_2.commitPreparedNativeAbility)(roleComp, "guard", exports.GUARD_STATE_SLOT.create(state));
}
function getGuardState(roleComp, abilityId) {
    return (0, abilities_1.findNightAbility)(roleComp, "guard", abilityId)?.state;
}
function recordGuardTarget(state, targetId) {
    state.lastTarget = targetId;
}
function recordRecipientGuardTarget(ability, target) {
    const state = ability.state;
    state.lastTarget = target.id;
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.repeatPolicy]);
}
exports.GUARD_STATE_SLOT = Object.freeze({
    create: (abilities_1.copyAbilityData),
    schema: (abilities_1.copyAbilityData),
    install: setGuardState,
    get: getGuardState,
    allowedWrites: Object.freeze({
        recordGuardTarget,
        recordRecipientGuardTarget,
    }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
