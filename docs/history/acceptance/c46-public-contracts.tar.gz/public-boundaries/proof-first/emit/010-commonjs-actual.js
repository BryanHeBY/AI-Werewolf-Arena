"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhaseManager = void 0;
const exile_unit_1 = require("../domain/exile-unit");
const night_unit_1 = require("../domain/night-unit");
const phase_revision_1 = require("./phase-revision");
const damage_evidence_1 = require("../domain/damage-evidence");
const game_setup_1 = require("../rulesets/game-setup");
const special_night_damage_preparation_1 = require("../rulesets/special-night-damage-preparation");
const ordinary_night_death_preparation_1 = require("../rulesets/ordinary-night-death-preparation");
const board_parameters_1 = require("../rulesets/board-parameters");
const rule_plan_1 = require("../rulesets/rule-plan");
const mist_delayed_night_settlement_1 = require("../rulesets/mist-delayed-night-settlement");
const ports_1 = require("../features/demon-hunter/ports");
const ports_2 = require("../features/demon-hunter/ports");
const ports_3 = require("../features/ghost-bride/ports");
const ports_4 = require("../features/initial-identity/ports");
const window_ports_1 = require("../features/wall-notes/window-ports");
const action_request_factory_1 = require("./actions/action-request-factory");
const terminal_victory_policy_1 = require("../rulesets/terminal-victory-policy");
const red_moon_expiry_settlement_1 = require("../rulesets/red-moon-expiry-settlement");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const fault_plan_1 = require("./fault-plan");
const model_1 = require("../domain/model");
const badge_ports_1 = require("../features/sheriff/badge-ports");
const death_resolution_1 = require("./death-resolution");
const event_registry_1 = require("./events/event-registry");
const day_pipeline_1 = require("./phases/day-pipeline");
const night_pipeline_1 = require("./phases/night-pipeline");
const voting_pipeline_1 = require("./phases/voting-pipeline");
const names_1 = require("../domain/components/names");
const selection_ports_1 = require("../features/self-destruct/selection-ports");
const knight_day_settlement_1 = require("../rulesets/knight-day-settlement");
const exile_death_preparation_1 = require("../rulesets/exile-death-preparation");
const beauty_exile_victory_1 = require("../rulesets/beauty-exile-victory");
const dawn_knowledge_publication_1 = require("../rulesets/dawn-knowledge-publication");
const ports_5 = require("../features/animal-dream/ports");
const alive_1 = require("../domain/components/alive");
const random_1 = require("../domain/random");
class PhaseManager {
    world;
    toolGateway;
    roleRegistry;
    conditionRegistry;
    damageResolutionSystem;
    random;
    #rulePlan;
    config;
    events = [];
    eventRegistry;
    nightPipeline;
    dayPipeline;
    votingPipeline;
    deathResolution;
    previousExile = null;
    phaseRevision = new phase_revision_1.PhaseRevisionClock();
    mistPending = null;
    nightFaultPlan;
    state = {
        day: 1,
        phase: model_1.Phase.Night,
        gameOver: false,
        result: null,
    };
    constructor(world, config, toolGateway, roleRegistry, conditionRegistry, damageResolutionSystem, random = (0, random_1.createRandom)(), options = {}) {
        this.world = world;
        this.toolGateway = toolGateway;
        this.roleRegistry = roleRegistry;
        this.conditionRegistry = conditionRegistry;
        this.damageResolutionSystem = damageResolutionSystem;
        this.random = random;
        const parameters = (0, board_parameters_1.bindBoardParameters)(world, config);
        config = parameters.board;
        this.#rulePlan = rule_plan_1.RulePlan.compile(parameters);
        this.config = config;
        (0, game_setup_1.installFragrantGameSetup)(config, { world: () => world, events: () => this.events });
        if (options.faultPlan !== undefined) {
            if ((0, ports_1.demonHunterActorId)(world) === null)
                throw new Error("fault_plan_demon_board_required");
            this.nightFaultPlan = new fault_plan_1.NightFaultPlan(world, options.faultPlan);
        }
        this.eventRegistry = new event_registry_1.EventRegistry();
        this.deathResolution = new death_resolution_1.DeathResolution(world, this.events, toolGateway, this.eventRegistry, this.state, config);
        this.nightPipeline = new night_pipeline_1.NightPipeline({
            rulePlan: this.#rulePlan,
            world,
            toolGateway,
            damageResolutionSystem,
            events: this.events,
            random: random.fork("night"),
        });
        this.dayPipeline = new day_pipeline_1.DayPipeline({
            world,
            roleRegistry,
            toolGateway,
            events: this.events,
        });
        this.votingPipeline = new voting_pipeline_1.VotingPipeline({
            world,
            roleRegistry,
            toolGateway,
            eventRegistry: this.eventRegistry,
            events: this.events,
        });
        this.events.push({
            timestamp: Date.now(),
            type: "god_private_game_info",
            payload: {
                boardSize: this.config.boardSize,
                players: this.world.getAliveEntityIds().map((id) => {
                    const identity = this.world.getComponent(id, names_1.COMPONENT.Identity);
                    const role = this.world.getComponent(id, names_1.COMPONENT.Role);
                    return {
                        id,
                        seat: identity?.seat ?? id,
                        name: identity?.name ?? (0, game_text_1.text)(this.world.locale, "common.player_name", { id }),
                        role: role?.role ?? "unknown",
                        camp: (role && this.world.getComponent(id, names_1.COMPONENT.Camp)?.camp) ?? "unknown",
                    };
                }),
            },
        });
        (0, ports_4.publishInitialIdentityDeal)({
            world: () => this.world,
            events: () => this.events,
            boardSize: () => this.config.boardSize,
        });
        this.events.push({
            timestamp: Date.now(),
            type: "phase_changed",
            payload: {
                phase: model_1.Phase.Night,
                day: this.state.day,
            },
        });
        const initialSheriffId = (0, badge_ports_1.findSheriffId)(this.world);
        this.#rulePlan.wolfKnifeInheritance({
            world: () => this.world,
            events: () => this.events,
            day: () => this.state.day,
        });
        if (initialSheriffId !== null) {
            this.events.push({
                timestamp: Date.now(),
                type: "sheriff_elected",
                payload: {
                    winnerId: initialSheriffId,
                    source: "initial_configuration",
                },
            });
        }
    }
    getFaultPlan() {
        return this.nightFaultPlan?.plan;
    }
    assertFaultPlanConsumed() {
        this.nightFaultPlan?.assertConsumed();
    }
    getSnapshot() {
        return structuredClone(this.state);
    }
    getEvents() {
        return this.events.map((event) => {
            const copy = structuredClone(event);
            if ("audience" in copy)
                Object.freeze(copy.audience);
            return copy;
        });
    }
    jumpTo(phase) {
        if (this.config.mistRaven &&
            !this.state.gameOver &&
            this.pureWhiteStartedDays.has(this.state.day))
            throw new Error("mist_phase_reentry");
        const manager = this;
        this.#rulePlan.phaseJumpAdmission({
            get world() { return manager.world; },
            get state() { return manager.state; },
        });
        this.phaseRevision.advance();
        this.setPhase(phase);
    }
    pureWhiteStartedDays = new Set();
    async runSingleCycle(actionProvider, maxDays = 20) {
        if ((this.config.animalDream ||
            this.config.fragrantPairSeer ||
            this.config.mistRaven ||
            this.config.pureWhite ||
            this.config.evilKnight ||
            this.config.magician) &&
            !this.state.gameOver) {
            if (this.pureWhiteStartedDays.has(this.state.day))
                throw new Error(this.config.animalDream
                    ? "animal_cycle_reentry"
                    : this.config.fragrantPairSeer
                        ? "fragrant_cycle_reentry"
                        : this.config.mistRaven
                            ? "mist_cycle_reentry"
                            : this.config.magician
                                ? "magician_cycle_reentry"
                                : this.config.evilKnight
                                    ? "evil_knight_cycle_reentry"
                                    : "pure_white_cycle_reentry");
            this.pureWhiteStartedDays.add(this.state.day);
        }
        const startedDay = this.state.day;
        const manager = this;
        const lifecycle = this.#rulePlan.createNightManagerLifecycle({
            get world() {
                return manager.world;
            },
            get config() {
                return manager.config;
            },
            abortMistPending() {
                manager.mistPending?.abort();
            },
        });
        let completed = false;
        try {
            const result = await this.runSingleCycleInternal(actionProvider, maxDays, lifecycle);
            completed = this.state.gameOver || this.state.day > startedDay;
            return result;
        }
        catch (error) {
            lifecycle.abortOnError();
            throw error;
        }
        finally {
            lifecycle.abortCycle(completed);
        }
    }
    async runSingleCycleInternal(actionProvider, maxDays = 20, lifecycle) {
        const manager = this;
        this.#rulePlan.cycleAdmission({
            get world() { return manager.world; },
            get state() { return manager.state; },
        });
        if (this.state.gameOver) {
            return this.getSnapshot();
        }
        if ((0, ports_1.demonHunterActorId)(this.world) !== null) {
            const underlying = actionProvider;
            const assertReadable = () => this.assertDemonReadable();
            actionProvider = {
                getAction: async (request) => {
                    assertReadable();
                    const action = await underlying.getAction(request);
                    assertReadable();
                    return action;
                },
            };
        }
        if (this.state.day > maxDays) {
            this.sealResult({ winner: null, reason: "max_days_reached", outcome: { kind: "no_winner" } }, this.#rulePlan.checkpoints.maxDays, model_1.Phase.Night);
            return this.getSnapshot();
        }
        this.setPhase(model_1.Phase.Night);
        if (this.config.mistRaven) {
            this.mistPending?.abort();
            this.mistPending = null;
        }
        const nightDay = this.state.day, nightRevision = this.phaseRevision.current;
        const nightIsCurrent = () => this.state.day === nightDay &&
            this.state.phase === model_1.Phase.Night &&
            !this.state.gameOver &&
            this.phaseRevision.current === nightRevision;
        const setupSequence = (0, game_setup_1.prepareGameSetup)({
            world: () => this.world,
            toolGateway: () => this.toolGateway,
            events: () => this.events,
            config: () => this.config,
        }, actionProvider, nightDay, nightIsCurrent);
        let setupStep = setupSequence.next();
        while (!setupStep.done)
            setupStep = setupSequence.next(await setupStep.value);
        if (!setupStep.value)
            return this.getSnapshot();
        (0, ports_1.assertDemonOriginalRoster)(this.world);
        const bearFrame = (0, dawn_knowledge_publication_1.captureDawnKnowledge)({
            world: () => this.world,
            signalPolicy: () => this.config.bear?.signalPolicy,
        }, nightDay);
        const night = await this.nightPipeline.execute(this.config, actionProvider, this.state.day, {
            previousExile: this.previousExile,
            isCurrent: nightIsCurrent,
            lifecycleHandoff: lifecycle,
        });
        if (night.interrupted || !nightIsCurrent()) {
            lifecycle.abortSpecialNight(night, nightDay);
            return this.getSnapshot();
        }
        const ownsWedding = (0, ports_3.weddingSetup)(this.world) !== null;
        const ownsDemon = (0, ports_1.demonHunterActorId)(this.world) !== null;
        const ownsPureWhite = this.config.pureWhite !== undefined;
        const ownsEvilKnight = this.config.evilKnight !== undefined;
        if (ownsWedding || ownsDemon || ownsPureWhite || ownsEvilKnight) {
            try {
                const { deaths, sources, originalLives, sourceDamage, livingBeforeChain } = (0, special_night_damage_preparation_1.prepareSpecialNightDamage)({
                    get world() { return manager.world; },
                    get config() { return manager.config; },
                    get events() { return manager.events; },
                    get nightFaultPlan() { return manager.nightFaultPlan; },
                    assertReadable() { manager.assertDemonReadable(); },
                }, night, nightDay, ownsWedding, ownsDemon, lifecycle);
                await this.deathResolution.resolve(deaths, sources, actionProvider, model_1.Phase.Night, model_1.Phase.Night, {}, {
                    nightOriginIds: deaths,
                    isCurrent: nightIsCurrent,
                    originalLives,
                    poisonRoutes: (0, damage_evidence_1.damagePoisonRoutes)(sourceDamage),
                    execution: { night: (0, night_unit_1.nightUnitOf)(night), phaseRevision: nightRevision },
                    blocksPassiveNightShot: (id) => night.blocksPassiveNightShot?.(id) ?? false,
                });
                this.assertDemonReadable();
                if (!nightIsCurrent())
                    return this.getSnapshot();
                const expirySettlement = (0, red_moon_expiry_settlement_1.settleRedMoonExpiry)({
                    get world() { return manager.world; },
                    get events() { return manager.events; },
                    get registry() { return manager.conditionRegistry; },
                    get config() { return manager.config; },
                    get checkpoint() { return manager.#rulePlan.checkpoints.nightSettled; },
                }, ownsDemon, nightDay);
                const expiryStep = expirySettlement.next();
                let beforeExpiryResult = expiryStep.done ? expiryStep.value : null;
                if (!expiryStep.done) {
                    const expiryActor = expiryStep.value;
                    await this.deathResolution.resolve([expiryActor], { [expiryActor]: [model_1.DeathCause.RedMoonExpiry] }, actionProvider, model_1.Phase.Night, model_1.Phase.Night, {}, { nightOriginIds: [expiryActor], isCurrent: nightIsCurrent, execution: { night: (0, night_unit_1.nightUnitOf)(night), phaseRevision: nightRevision } });
                    this.assertDemonReadable();
                    if (!nightIsCurrent())
                        return this.getSnapshot();
                    beforeExpiryResult = expirySettlement.next().value;
                }
                const completeDeaths = [
                    ...deaths,
                    ...[...livingBeforeChain]
                        .filter(([id, scope]) => !deaths.includes(id) &&
                        this.world.getComponent(id, names_1.COMPONENT.Alive) === scope.life &&
                        !scope.life.alive &&
                        (0, alive_1.aliveLifeVersion)(scope.life) === scope.version + 1)
                        .map(([id]) => id),
                ];
                this.emitNightResolved(completeDeaths);
                if (beforeExpiryResult) {
                    this.sealResult(terminal_victory_policy_1.TERMINAL_VICTORY_POLICY.replaceFactionResult(this.world, beforeExpiryResult), this.#rulePlan.checkpoints.nightSettled, this.state.phase);
                    return this.getSnapshot();
                }
                if (this.checkAndSealResult(this.#rulePlan.checkpoints.nightSettled))
                    return this.getSnapshot();
            }
            finally {
                lifecycle.abortSpecialNight(night, nightDay);
            }
        }
        const firstDaySheriffBeforeNightInfo = !ownsWedding &&
            !ownsDemon &&
            !ownsPureWhite &&
            !ownsEvilKnight &&
            this.state.day === 1 &&
            this.config.enableSheriff === true;
        this.setPhase(model_1.Phase.Day);
        const cycleDay = this.state.day, dayRevision = this.phaseRevision.current;
        const dayIsCurrent = () => this.state.day === cycleDay &&
            this.state.phase === model_1.Phase.Day &&
            !this.state.gameOver &&
            this.phaseRevision.current === dayRevision;
        let nightSettled = ownsWedding || ownsDemon || ownsPureWhite || ownsEvilKnight;
        if (night.mistDelay) {
            this.mistPending = (0, mist_delayed_night_settlement_1.prepareMistDelayedNight)({
                get world() { return manager.world; },
                get cycleDay() { return cycleDay; },
                get night() { return night; },
            });
        }
        const settleMist = async (alreadyClaimed = false, interrupted = false) => {
            if (nightSettled)
                return this.state.gameOver;
            const settlement = (0, mist_delayed_night_settlement_1.settleMistDelayedNight)({
                get pending() { return manager.mistPending; },
                get world() { return manager.world; },
                get events() { return manager.events; },
                get toolGateway() { return manager.toolGateway; },
                get lifecycle() { return lifecycle; },
                get cycleDay() { return cycleDay; },
            }, actionProvider, dayIsCurrent, alreadyClaimed);
            const healed = await settlement.next().value;
            const { damage, current } = settlement.next(healed).value;
            this.emitNightResolved(damage.deaths);
            await this.deathResolution.resolve(damage.deaths, damage.deathSources, actionProvider, model_1.Phase.Night, model_1.Phase.Day, {}, {
                dreams: night.dreamFrame,
                nightOriginIds: damage.deaths,
                isCurrent: current,
                poisonRoutes: (0, damage_evidence_1.damagePoisonRoutes)(damage),
                execution: { night: (0, night_unit_1.nightUnitOf)(night), phaseRevision: dayRevision },
            });
            settlement.next();
            nightSettled = true;
            return this.checkAndSealResult(interrupted
                ? this.#rulePlan.checkpoints.dayInterrupted
                : this.#rulePlan.checkpoints.nightSettled);
        };
        const settleNight = async (blast, animalSkip, skippedUnit) => {
            if (nightSettled)
                return this.state.gameOver;
            nightSettled = true;
            const ordinaryNightRuntime = {
                get world() { return manager.world; },
                get night() { return night; },
                get config() { return manager.config; },
                publishNightResolved(deaths) { return manager.emitNightResolved(deaths()); },
            };
            const { sourceDamage, originalLives, retainedSources, nightDeaths, sources, deaths, deathPhases } = (0, ordinary_night_death_preparation_1.prepareOrdinaryNightDeaths)(ordinaryNightRuntime, blast);
            try {
                await this.deathResolution.resolve(deaths, sources, actionProvider, model_1.Phase.Night, model_1.Phase.Day, deathPhases, {
                    dreams: night.dreamFrame,
                    nightOriginIds: nightDeaths,
                    isCurrent: dayIsCurrent,
                    originalLives,
                    poisonRoutes: (0, damage_evidence_1.damagePoisonRoutes)(sourceDamage),
                    execution: { night: (0, night_unit_1.nightUnitOf)(night), exile: skippedUnit, phaseRevision: dayRevision },
                    ...(animalSkip ? { animalUnit: animalSkip } : {}),
                    ...(0, ordinary_night_death_preparation_1.ordinaryNightDeathPublication)(ordinaryNightRuntime, nightDeaths, retainedSources),
                });
                lifecycle.finishDay(cycleDay, dayIsCurrent);
            }
            finally {
                lifecycle.abortInner();
            }
            if (!dayIsCurrent())
                return this.state.gameOver;
            if (animalSkip) {
                (0, ports_5.completeAndPublishAnimalExileUnit)({
                    world: () => this.world,
                    events: () => this.events,
                    day: () => cycleDay,
                }, () => animalSkip);
            }
            (0, dawn_knowledge_publication_1.publishDawnKnowledge)(bearFrame, {
                world: () => this.world,
                events: () => this.events,
                animalDream: () => this.config.animalDream,
            }, cycleDay, dayIsCurrent);
            return this.checkAndSealResult(blast !== undefined
                ? this.#rulePlan.checkpoints.dayInterrupted
                : this.#rulePlan.checkpoints.nightSettled);
        };
        if (!night.mistDelay && !firstDaySheriffBeforeNightInfo && (await settleNight()))
            return this.getSnapshot();
        const dayResult = await this.dayPipeline.execute(this.config, actionProvider, {
            day: cycleDay,
            isCurrent: dayIsCurrent,
            commitSelfDestruct: async (choice, window) => {
                if (!dayIsCurrent())
                    return false;
                if (!nightSettled &&
                    choice.kind === "white_wolf_king" &&
                    night.damage.deaths.includes(choice.actorId))
                    return false;
                const blast = (0, selection_ports_1.commitSelfDestructSelection)(this.world, choice, window, model_1.Phase.Day, this.events);
                if (!blast)
                    return false;
                const animalSkip = this.config.animalDream
                    ? (0, ports_5.beginAnimalExileUnit)(this.world, cycleDay, "skipped_day", dayIsCurrent)
                    : undefined;
                const skippedUnit = (0, exile_unit_1.openExileUnit)(cycleDay, "skipped_day", animalSkip);
                if (!nightSettled && this.mistPending) {
                    this.mistPending.claim(dayIsCurrent);
                    await this.deathResolution.resolve(blast.deaths, blast.sources, actionProvider, model_1.Phase.Day, model_1.Phase.Day, {}, { isCurrent: dayIsCurrent, execution: { exile: skippedUnit, phaseRevision: dayRevision } });
                    if (dayIsCurrent())
                        await settleMist(true, true);
                }
                else if (!nightSettled)
                    await settleNight(blast, animalSkip, skippedUnit);
                else {
                    await this.deathResolution.resolve(blast.deaths, blast.sources, actionProvider, model_1.Phase.Day, model_1.Phase.Day, {}, { isCurrent: dayIsCurrent, execution: { exile: skippedUnit, phaseRevision: dayRevision }, ...(animalSkip ? { animalUnit: animalSkip } : {}) });
                    if (animalSkip) {
                        (0, ports_5.completeAndPublishAnimalExileUnit)({
                            world: () => this.world,
                            events: () => this.events,
                            day: () => cycleDay,
                        }, () => animalSkip);
                    }
                }
                return true;
            },
            ...(firstDaySheriffBeforeNightInfo && !night.mistDelay
                ? { afterSheriffElection: () => settleNight() }
                : {}),
            commitKnightDuel: async (choice) => {
                const settlement = (0, knight_day_settlement_1.settleKnightDay)({
                    get world() { return manager.world; },
                    get events() { return manager.events; },
                    get isCurrent() { return dayIsCurrent; },
                    get nightSettled() { return nightSettled; },
                    get dayRevision() { return dayRevision; },
                    checkResult() { return manager.checkAndSealResult(manager.#rulePlan.checkpoints.dayInterrupted); },
                }, choice);
                const step = settlement.next();
                if (step.done)
                    return step.value;
                const { duel, duelMetadata } = step.value;
                await this.deathResolution.resolve(duel.deaths, duel.sources, actionProvider, model_1.Phase.Day, model_1.Phase.Day, {}, duelMetadata);
                return settlement.next().value;
            },
        });
        if (night.mistDelay && !nightSettled && dayIsCurrent())
            await settleMist();
        if (this.state.gameOver || !dayIsCurrent())
            return this.getSnapshot();
        if (dayResult.interrupted) {
            if (this.state.gameOver ||
                this.checkAndSealResult(this.#rulePlan.checkpoints.dayInterrupted)) {
                return this.getSnapshot();
            }
            this.state.day += 1;
            this.setPhase(model_1.Phase.Night);
            return this.getSnapshot();
        }
        this.setPhase(model_1.Phase.Voting);
        const votingRevision = this.phaseRevision.current;
        const votingIsCurrent = () => this.state.day === cycleDay &&
            this.state.phase === model_1.Phase.Voting &&
            !this.state.gameOver &&
            this.phaseRevision.current === votingRevision;
        const votingResult = await this.votingPipeline.execute(this.config, actionProvider, {
            day: cycleDay,
            isCurrent: votingIsCurrent,
            commitSelfDestruct: async (choice) => {
                if (!votingIsCurrent())
                    return false;
                const blast = (0, selection_ports_1.commitSelfDestructSelection)(this.world, choice, model_1.ActionWindow.OnPreVote, model_1.Phase.Voting, this.events);
                if (!blast)
                    return false;
                const animalSkip = this.config.animalDream
                    ? (0, ports_5.beginAnimalExileUnit)(this.world, cycleDay, "skipped_day", votingIsCurrent)
                    : undefined;
                const skippedUnit = (0, exile_unit_1.openExileUnit)(cycleDay, "skipped_day", animalSkip);
                await this.deathResolution.resolve(blast.deaths, blast.sources, actionProvider, model_1.Phase.Voting, model_1.Phase.Voting, {}, { isCurrent: votingIsCurrent, execution: { exile: skippedUnit, phaseRevision: votingRevision }, ...(animalSkip ? { animalUnit: animalSkip } : {}) });
                if (animalSkip) {
                    (0, ports_5.completeAndPublishAnimalExileUnit)({
                        world: () => this.world,
                        events: () => this.events,
                        day: () => cycleDay,
                    }, () => animalSkip);
                }
                return true;
            },
        });
        if (!votingIsCurrent())
            return this.getSnapshot();
        if (votingResult.interrupted) {
            if (this.checkAndSealResult(this.#rulePlan.checkpoints.dayInterrupted)) {
                return this.getSnapshot();
            }
            this.state.day += 1;
            this.setPhase(model_1.Phase.Night);
            return this.getSnapshot();
        }
        let beautyCandidate = null;
        if (votingResult.animalUnit) {
            const { sources, ids } = (0, exile_death_preparation_1.prepareAnimalExileDeaths)(votingResult);
            await this.deathResolution.resolve(ids, sources, actionProvider, model_1.Phase.Voting, model_1.Phase.Voting, {}, { isCurrent: votingIsCurrent, animalUnit: votingResult.animalUnit, execution: { exile: (0, exile_unit_1.exileUnitOf)(votingResult), phaseRevision: votingRevision } });
            if (!votingIsCurrent())
                return this.getSnapshot();
            (0, ports_5.completeAndPublishAnimalExileUnit)({
                world: () => this.world,
                events: () => this.events,
                day: () => cycleDay,
            }, () => votingResult.animalUnit);
            this.previousExile = (0, exile_death_preparation_1.captureAnimalExileFeedback)(() => this.world, votingResult, sources, cycleDay);
        }
        else if (votingResult.removed.length > 0) {
            const { target, candidate } = (0, beauty_exile_victory_1.prepareBeautyExileVictory)(votingResult, () => this.world);
            beautyCandidate = candidate;
            this.previousExile = (0, exile_death_preparation_1.captureOrdinaryExileFeedback)(() => this.world, votingResult, target, cycleDay);
            const sources = (0, exile_death_preparation_1.prepareOrdinaryExileDeaths)(votingResult);
            await this.deathResolution.resolve(votingResult.removed, sources, actionProvider, model_1.Phase.Voting, model_1.Phase.Voting, {}, { isCurrent: votingIsCurrent, execution: { exile: (0, exile_unit_1.exileUnitOf)(votingResult), phaseRevision: votingRevision } });
        }
        if (!votingIsCurrent())
            return this.getSnapshot();
        const beautyResult = (0, beauty_exile_victory_1.resolveBeautyExileVictory)(this.world, beautyCandidate);
        if (this.checkAndSealResult(this.#rulePlan.checkpoints.exileSettled, (0, beauty_exile_victory_1.beautyExileVictoryOverrides)(beautyResult))) {
            return this.getSnapshot();
        }
        await new window_ports_1.WallNotesWindow(this.world, this.toolGateway, this.events).execute(this.config, new action_request_factory_1.GameActionRequestFactory(this.world, this.events, cycleDay), actionProvider, cycleDay, votingIsCurrent, () => this.random.fork("wall_notes"));
        if (!votingIsCurrent())
            return this.getSnapshot();
        this.state.day += 1;
        return this.getSnapshot();
    }
    async runUntilGameOver(actionProvider, maxDays = 20) {
        while (!this.state.gameOver) {
            await this.runSingleCycle(actionProvider, maxDays);
        }
        return this.getSnapshot();
    }
    getRulePlan() {
        return this.#rulePlan;
    }
    checkAndSealResult(checkpoint, overrides = {}) {
        if (this.state.gameOver)
            return true;
        const result = this.conditionRegistry.evaluateMany(this.world, terminal_victory_policy_1.TERMINAL_VICTORY_POLICY.conditions({ world: () => this.world, config: () => this.config }), checkpoint, overrides);
        if (!result)
            return false;
        this.sealResult(terminal_victory_policy_1.TERMINAL_VICTORY_POLICY.replaceFactionResult(this.world, result), checkpoint, this.state.phase);
        return true;
    }
    sealResult(decision, checkpoint, phase) {
        if (this.state.gameOver)
            return;
        this.assertFaultPlanConsumed();
        const { winner, outcome, decidedAt } = terminal_victory_policy_1.TERMINAL_VICTORY_POLICY.validateCandidate(decision, checkpoint, phase, () => this.world, () => this.state.day);
        this.state.result = { winner, reason: decision.reason, outcome, decidedAt };
        this.state.gameOver = true;
        this.setPhase(model_1.Phase.GameOver);
        this.events.push({
            timestamp: Date.now(),
            type: "game_over",
            payload: structuredClone(this.state.result),
        });
    }
    assertDemonReadable() {
        if ((0, ports_1.demonHunterActorId)(this.world) === null)
            return;
        (0, ports_1.assertDemonNightReadable)(this.world);
        if (!this.world.entityIds().every((id) => (0, ports_2.demonWitchMarksSafe)(this.world, id)))
            throw new Error("demon_hunter_unreadable_marks");
    }
    emitNightResolved(deaths) {
        const event = {
            timestamp: Date.now(),
            type: "night_resolved",
            payload: {
                deaths: [...deaths],
            },
        };
        this.events.push(event);
        return event;
    }
    debugResult() {
        return this.state.result === null ? null : structuredClone(this.state.result);
    }
    setPhase(phase) {
        const previous = this.state.phase;
        this.state.phase = phase;
        if (previous === phase) {
            return;
        }
        this.phaseRevision.advance();
        this.world.closeDeathActions();
        const gameOverPayload = phase === model_1.Phase.GameOver && this.state.result
            ? {
                winner: this.state.result.winner,
                reason: this.state.result.reason,
                outcome: structuredClone(this.state.result.outcome),
                decidedAt: { ...this.state.result.decidedAt },
            }
            : {};
        this.events.push({
            timestamp: Date.now(),
            type: "phase_changed",
            payload: {
                phase,
                day: this.state.day,
                ...gameOverPayload,
            },
        });
    }
}
exports.PhaseManager = PhaseManager;
