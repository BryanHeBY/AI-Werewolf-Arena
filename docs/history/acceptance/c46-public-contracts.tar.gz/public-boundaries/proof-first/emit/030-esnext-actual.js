export { getGuardState, recordGuardTarget, recordRecipientGuardTarget } from "./state-slot";
export function guardTargetRepeated(ability, day, targetId) {
    return (ability.state.lastTarget === targetId &&
        (ability.state.repeatPolicy !== "netease_consecutive_nights_v1" ||
            ability.lastUsedDay === day - 1));
}
export { GUARD_STATE_SLOT } from "./state-slot";
export { setGuardState } from "./state-slot";
