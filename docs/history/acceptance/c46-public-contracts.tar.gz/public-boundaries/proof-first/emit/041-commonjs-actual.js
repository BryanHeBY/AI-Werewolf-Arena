"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MIRACLE_MERCHANT_STAGE = void 0;
exports.hasMerchantNightCommit = hasMerchantNightCommit;
const state_1 = require("./state");
const names_1 = require("../../domain/components/names");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const model_1 = require("../../domain/model");
const night_effects_1 = require("../../domain/night-effects");
const grant_ports_1 = require("../night-abilities/grant-ports");
const state_2 = require("./state");
const committed = new WeakMap();
function hasMerchantNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
function recordCommit(world, day) {
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
exports.MIRACLE_MERCHANT_STAGE = {
    id: "miracle_merchant",
    priority: 125,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const actorId of ctx.getAliveByRole(model_1.Role.MiracleMerchant)) {
            const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role), state = (0, state_2.getMerchantState)(role), life = (0, night_effects_1.captureNightLife)(ctx.world, actorId);
            if (!state || !life || ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Good)
                continue;
            const privateState = role.privateState;
            const ownerCurrent = () => ctx.isCurrent() &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Role) === role &&
                role.role === model_1.Role.MiracleMerchant &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Good &&
                role.privateState === privateState &&
                (0, state_2.getMerchantState)(role) === state &&
                (0, night_effects_1.livingNightLife)(ctx.world, life);
            const current = () => ownerCurrent() && (0, state_2.canMerchantTrade)(state, day) && !(0, role_execution_authority_1.isRoleExecutionRetired)(role);
            if (!current())
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current())
                    break;
                const targets = new Map(ctx.world
                    .getAliveEntityIds()
                    .filter((id) => id !== actorId)
                    .map((id) => {
                    const targetRole = ctx.world.getComponent(id, names_1.COMPONENT.Role);
                    return [
                        id,
                        {
                            life: (0, night_effects_1.captureNightLife)(ctx.world, id),
                            role: targetRole,
                            kind: targetRole.role,
                            camp: ctx.world.getComponent(id, names_1.COMPONENT.Camp)?.camp,
                            privateState: targetRole.privateState,
                        },
                    ];
                }));
                if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                    break;
                let action = null;
                if (targets.size) {
                    const provider = ctx.actionProvider, getAction = provider.getAction, makeRequest = ctx.makeRequest, requestArgs = [actorId, ["bestow_ability"], {
                            stage: "miracle_merchant",
                            requiresAction: false,
                            ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                        }], invoke = Reflect.apply.bind(Reflect);
                    if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                        break;
                    const request = invoke(makeRequest, ctx, requestArgs), actionArgs = [request];
                    if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                        break;
                    action = await invoke(getAction, provider, actionArgs);
                }
                if (!current())
                    break;
                if (action === null) {
                    const closeTrade = state_1.closeMerchantTrade;
                    if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                        break;
                    closeTrade(state, day);
                    recordCommit(ctx.world, day);
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "merchant_trade_skipped",
                        payload: { actorId, day },
                    });
                    completed = true;
                    break;
                }
                if (action.name !== "bestow_ability")
                    continue;
                const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                    phase: model_1.Phase.Night,
                    day,
                });
                if (!current() || !valid.ok || valid.sanitizedCall?.name !== "bestow_ability")
                    continue;
                const { target_id: targetId, skill } = valid.sanitizedCall.args, target = targets.get(targetId);
                if (!target ||
                    !(0, night_effects_1.livingNightLife)(ctx.world, target.life) ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Role) !== target.role ||
                    target.role.role !== target.kind ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Camp)?.camp !== target.camp ||
                    target.role.privateState !== target.privateState)
                    continue;
                const failure = target.camp === model_1.Camp.Wolf;
                if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                    break;
                if (!failure) {
                    const base = {
                        id: "gift:miracle",
                        activation: "lucky",
                        source: { kind: "gift", actorId },
                        sourceDisclosed: false,
                        startsOnDay: day,
                        maxUses: 1,
                    };
                    if (skill === "check") {
                        const grant = grant_ports_1.grantNightAbility, grantArgs = [
                            ctx.world,
                            targetId,
                            {
                                ...base,
                                kind: "seer_check",
                                state: { lastTarget: null, lastIsWerewolf: null, lastResult: null, history: [] },
                            },
                            ctx.events,
                        ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                        if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                            break;
                        grant(grantWorld, grantTarget, grantInput, grantEvents);
                    }
                    if (skill === "guard") {
                        const grant = grant_ports_1.grantNightAbility, grantArgs = [
                            ctx.world,
                            targetId,
                            { ...base, kind: "guard", state: { lastTarget: null } },
                            ctx.events,
                        ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                        if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                            break;
                        grant(grantWorld, grantTarget, grantInput, grantEvents);
                    }
                    if (skill === "poison") {
                        const grant = grant_ports_1.grantNightAbility, grantArgs = [
                            ctx.world,
                            targetId,
                            {
                                ...base,
                                kind: "potion",
                                state: {
                                    heal: 0,
                                    poison: 1,
                                    selfHealRule: model_1.WitchSelfHealRule.Disabled,
                                    canSelfHeal: false,
                                    healUsedThisNight: false,
                                    poisonUsedThisNight: false,
                                },
                            },
                            ctx.events,
                        ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                        if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                            break;
                        grant(grantWorld, grantTarget, grantInput, grantEvents);
                    }
                }
                const recordTrade = state_1.recordMerchantTrade;
                if (failure && (0, role_execution_authority_1.isRoleExecutionRetired)(role))
                    break;
                recordTrade(state, day, targetId, skill);
                recordCommit(ctx.world, day);
                if (failure)
                    (ctx.state.merchantBacklashes ??= []).push({ target: life, isCurrent: ownerCurrent });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "merchant_trade_committed",
                    payload: { actorId, day, targetId, skill },
                });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "merchant_trade_resolved",
                    payload: { actorId, day, targetId, skill, outcome: failure ? "backlash" : "granted" },
                });
                completed = true;
                break;
            }
            if (!completed && current())
                throw new Error("merchant_valid_action_missing");
        }
    },
};
