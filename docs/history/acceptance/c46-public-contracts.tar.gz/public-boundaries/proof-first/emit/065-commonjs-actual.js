"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.electSheriffIfNeeded = electSheriffIfNeeded;
const wedding_ports_1 = require("../ghost-bride/wedding-ports");
const night_effects_1 = require("../../domain/night-effects");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const badge_1 = require("./badge");
const participation_1 = require("../../engine/participation");
async function electSheriffIfNeeded(input) {
    if (!current(input) || (0, wedding_ports_1.weddingBadgeSwallowed)(input.world))
        return null;
    const { world, events, day, enableSheriff, config } = input;
    const currentSheriff = (0, badge_1.findSheriffId)(world, input.roleCatalog);
    if (!enableSheriff || day !== 1 || currentSheriff !== null)
        return currentSheriff;
    const aliveIds = world.getAliveEntityIds().filter((id) => (0, participation_1.canVote)(world, id, input.roleCatalog));
    const requests = new input.requestFactory(world, events, day);
    const initialCandidates = await collectNominations(input, requests, aliveIds);
    if (!current(input))
        return null;
    const candidateSet = new Set(initialCandidates);
    await collectCampaignSpeeches(input, requests, candidateSet);
    if (!current(input))
        return null;
    const finalizedCandidates = await collectWithdrawals(input, requests, candidateSet);
    if (!current(input))
        return null;
    const pk = config?.sheriff?.electionPolicy === "awa_nomination_offstage_pk_v1";
    const forbidden = pk ? new Set(initialCandidates) : candidateSet;
    let { tally, votes } = pk && finalizedCandidates.length === 1
        ? { tally: new Map([[finalizedCandidates[0], 0]]), votes: [] }
        : await collectSheriffVotes(input, requests, aliveIds, finalizedCandidates, forbidden);
    if (!current(input))
        return null;
    let round = 1;
    let eligible = finalizedCandidates.filter((id) => (0, participation_1.canBeSheriff)(world, id, input.roleCatalog));
    const top = positiveLeaders(eligible, tally);
    if (pk && top.length > 1) {
        events.push({
            timestamp: Date.now(),
            type: "sheriff_vote_summary",
            payload: { votes, winnerId: null, round: 1 },
        });
        events.push({
            timestamp: Date.now(),
            type: "sheriff_pk_started",
            payload: { candidates: top },
        });
        await collectCampaignSpeeches(input, requests, new Set(top), "sheriff_pk_speech");
        if (!current(input))
            return null;
        const tied = top.filter((id) => (0, participation_1.canBeSheriff)(world, id, input.roleCatalog));
        ({ tally, votes } = await collectSheriffVotes(input, requests, aliveIds, tied, new Set(top), 2));
        if (!current(input))
            return null;
        eligible = tied.filter((id) => (0, participation_1.canBeSheriff)(world, id, input.roleCatalog));
        round = 2;
    }
    let winner = pk && finalizedCandidates.length === 1 && eligible.length === 1
        ? eligible[0]
        : pickSheriffWinner(world, eligible, tally, pk ? "no_elimination" : (config?.tieBreaker?.sheriffVote ?? "min_seat"));
    if (winner !== null && !(0, badge_1.assignSheriff)(world, winner, config, input.roleCatalog))
        winner = null;
    events.push({
        timestamp: Date.now(),
        type: "sheriff_vote_summary",
        payload: { votes, winnerId: winner, ...(pk ? { round } : {}) },
    });
    if (winner !== null) {
        events.push({
            timestamp: Date.now(),
            type: "sheriff_elected",
            payload: {
                winnerId: winner,
                candidates: finalizedCandidates,
                tally: Object.fromEntries(tally.entries()),
            },
        });
    }
    return winner;
}
async function collectNominations(input, requests, aliveIds) {
    const { world, events, toolGateway, actionProvider } = input;
    const candidates = [];
    const nominationRequests = aliveIds
        .filter((id) => (0, participation_1.canBeSheriff)(world, id, input.roleCatalog))
        .map((actorId) => ({
        actorId,
        life: (0, night_effects_1.captureNightLife)(world, actorId),
        request: requests.create({
            phase: model_1.Phase.Day,
            actorId,
            allowedTools: ["run_for_sheriff"],
            stage: "sheriff_nomination",
            requiresAction: true,
            summary: { key: "request.summary.sheriff_nomination" },
            context: {},
        }),
    }));
    const nominationResults = await Promise.all(nominationRequests.map(async ({ actorId, request, life }) => {
        if (!current(input))
            return null;
        const action = await actionProvider.getAction(request);
        if (!current(input) ||
            !life ||
            !(0, night_effects_1.livingNightLife)(world, life) ||
            action?.name !== "run_for_sheriff") {
            return null;
        }
        const result = toolGateway.validateAndSanitize(world, actorId, action, {
            phase: model_1.Phase.Day,
        });
        if (!current(input) || !result.ok || !result.sanitizedCall) {
            return null;
        }
        return {
            actorId,
            run: result.sanitizedCall.args.run === true,
            life,
        };
    }));
    if (!current(input))
        return [];
    for (const item of nominationResults) {
        if (!item ||
            !(0, night_effects_1.livingNightLife)(world, item.life) ||
            !(0, participation_1.canBeSheriff)(world, item.actorId, input.roleCatalog)) {
            continue;
        }
        events.push({
            timestamp: Date.now(),
            type: "sheriff_candidate_declared",
            payload: { actorId: item.actorId, run: item.run },
        });
        if (item.run) {
            candidates.push(item.actorId);
        }
    }
    const initialCandidates = sortBySeat(world, candidates);
    events.push({
        timestamp: Date.now(),
        type: "sheriff_nomination_summary",
        payload: { candidates: initialCandidates },
    });
    return initialCandidates;
}
async function collectCampaignSpeeches(input, requests, candidateSet, stage = "sheriff_campaign_speech") {
    const { world, events, toolGateway, actionProvider } = input;
    const campaignOrder = sortBySeat(world, [...candidateSet]);
    for (const candidateId of campaignOrder) {
        if (!current(input))
            return;
        if (!candidateSet.has(candidateId) || !(0, participation_1.canBeSheriff)(world, candidateId, input.roleCatalog)) {
            continue;
        }
        const life = (0, night_effects_1.captureNightLife)(world, candidateId);
        if (!life)
            continue;
        const speechReq = requests.create({
            phase: model_1.Phase.Day,
            actorId: candidateId,
            allowedTools: ["speak"],
            stage,
            requiresAction: true,
            summary: { key: "request.summary.sheriff_campaign" },
            context: {
                sheriff_candidates: [...candidateSet],
            },
        });
        const speechAction = await actionProvider.getAction(speechReq);
        if (!current(input))
            return;
        if (speechAction?.name === "speak") {
            const speechResult = toolGateway.validateAndSanitize(world, candidateId, speechAction, {
                phase: model_1.Phase.Day,
            });
            if (current(input) &&
                (0, night_effects_1.livingNightLife)(world, life) &&
                speechResult.ok &&
                speechResult.sanitizedCall &&
                (0, participation_1.canBeSheriff)(world, candidateId, input.roleCatalog)) {
                events.push({
                    timestamp: Date.now(),
                    type: "day_speech",
                    payload: {
                        actorId: candidateId,
                        text: speechResult.sanitizedCall.args.text,
                    },
                });
            }
        }
    }
}
async function collectWithdrawals(input, requests, candidateSet) {
    const { world, events, toolGateway, actionProvider } = input;
    const orderedCandidates = sortBySeat(world, [...candidateSet].filter((id) => (0, participation_1.canBeSheriff)(world, id, input.roleCatalog)));
    const withdrawRequests = orderedCandidates.map((candidateId) => ({
        candidateId,
        life: (0, night_effects_1.captureNightLife)(world, candidateId),
        request: requests.create({
            phase: model_1.Phase.Day,
            actorId: candidateId,
            allowedTools: ["run_for_sheriff"],
            stage: "sheriff_withdraw",
            requiresAction: true,
            summary: { key: "request.summary.sheriff_withdraw" },
            context: {
                sheriff_candidates: [...candidateSet],
            },
        }),
    }));
    const withdrawResults = await Promise.all(withdrawRequests.map(async ({ candidateId, request, life }) => {
        if (!current(input))
            return null;
        const withdrawAction = await actionProvider.getAction(request);
        if (!current(input) ||
            !life ||
            !(0, night_effects_1.livingNightLife)(world, life) ||
            withdrawAction?.name !== "run_for_sheriff") {
            return null;
        }
        const withdrawResult = toolGateway.validateAndSanitize(world, candidateId, withdrawAction, {
            phase: model_1.Phase.Day,
        });
        if (!current(input) || !withdrawResult.ok || !withdrawResult.sanitizedCall) {
            return null;
        }
        return {
            candidateId,
            keepRunning: withdrawResult.sanitizedCall.args.run === true,
            life,
        };
    }));
    if (!current(input))
        return [];
    const withdrawn = [];
    for (const item of withdrawResults) {
        if (!item || !(0, night_effects_1.livingNightLife)(world, item.life) || item.keepRunning) {
            continue;
        }
        candidateSet.delete(item.candidateId);
        withdrawn.push(item.candidateId);
        events.push({
            timestamp: Date.now(),
            type: "sheriff_candidate_declared",
            payload: { actorId: item.candidateId, run: false },
        });
    }
    events.push({
        timestamp: Date.now(),
        type: "sheriff_withdraw_summary",
        payload: { withdrawn: sortBySeat(world, withdrawn) },
    });
    for (const id of candidateSet)
        if (!(0, participation_1.canBeSheriff)(world, id, input.roleCatalog))
            candidateSet.delete(id);
    const finalizedCandidates = sortBySeat(world, [...candidateSet]);
    events.push({
        timestamp: Date.now(),
        type: "sheriff_candidates_finalized",
        payload: { candidates: finalizedCandidates },
    });
    return finalizedCandidates;
}
async function collectSheriffVotes(input, requests, aliveIds, finalizedCandidates, candidateSet, round = 1) {
    const { world, events, toolGateway, actionProvider } = input;
    const tally = new Map();
    for (const id of finalizedCandidates) {
        tally.set(id, 0);
    }
    if (finalizedCandidates.length === 0)
        return { tally, votes: [] };
    const sheriffVoterIds = aliveIds.filter((id) => !candidateSet.has(id) && (0, participation_1.canVote)(world, id, input.roleCatalog));
    const candidateLives = new Map(finalizedCandidates.map((id) => [id, (0, night_effects_1.captureNightLife)(world, id)]));
    const sheriffVoteRequests = sheriffVoterIds.map((actorId) => ({
        actorId,
        life: (0, night_effects_1.captureNightLife)(world, actorId),
        request: requests.create({
            phase: model_1.Phase.Day,
            actorId,
            allowedTools: ["vote_for_sheriff"],
            stage: round === 2 ? "sheriff_pk_vote" : "sheriff_vote",
            requiresAction: true,
            summary: { key: "request.summary.sheriff_vote" },
            context: {
                sheriff_candidates: finalizedCandidates,
                ...(round === 2 ? { round: 2, max_rounds: 2 } : {}),
            },
        }),
    }));
    const sheriffVoteResults = await Promise.all(sheriffVoteRequests.map(async ({ actorId, request, life }) => {
        if (!current(input))
            return null;
        const action = await actionProvider.getAction(request);
        if (!current(input) ||
            !life ||
            !(0, night_effects_1.livingNightLife)(world, life) ||
            action?.name !== "vote_for_sheriff") {
            return null;
        }
        const result = toolGateway.validateAndSanitize(world, actorId, action, {
            phase: model_1.Phase.Day,
            sheriffCandidates: finalizedCandidates,
        });
        if (!current(input) || !result.ok || !result.sanitizedCall) {
            return null;
        }
        const abstain = result.sanitizedCall.args.abstain === true;
        const targetId = result.sanitizedCall.args.target_id;
        return { actorId, targetId, abstain, life };
    }));
    if (!current(input))
        return { tally, votes: [] };
    const acceptedVotes = [];
    for (const item of sheriffVoteResults) {
        if (!item ||
            !(0, night_effects_1.livingNightLife)(world, item.life) ||
            !(0, participation_1.canVote)(world, item.actorId, input.roleCatalog) ||
            candidateSet.has(item.actorId) ||
            (!item.abstain &&
                (item.targetId === null ||
                    !finalizedCandidates.includes(item.targetId) ||
                    !candidateLives.get(item.targetId) ||
                    !(0, night_effects_1.livingNightLife)(world, candidateLives.get(item.targetId)) ||
                    !(0, participation_1.canBeSheriff)(world, item.targetId, input.roleCatalog)))) {
            continue;
        }
        acceptedVotes.push({ actorId: item.actorId, targetId: item.targetId, abstain: item.abstain });
        events.push({
            timestamp: Date.now(),
            type: "sheriff_vote_cast",
            payload: {
                actorId: item.actorId,
                targetId: item.targetId,
                abstain: item.abstain,
            },
        });
        if (!item.abstain && item.targetId !== null) {
            tally.set(item.targetId, (tally.get(item.targetId) ?? 0) + 1);
        }
    }
    return { tally, votes: acceptedVotes };
}
function current(input) {
    if ((0, wedding_ports_1.weddingBadgeSwallowed)(input.world))
        return false;
    return input.isCurrent?.() ?? true;
}
function pickSheriffWinner(world, candidates, tally, strategy) {
    if (candidates.length === 0) {
        return null;
    }
    const withSeat = candidates.map((id) => {
        const identity = world.getComponent(id, names_1.COMPONENT.Identity);
        return { id, seat: identity?.seat ?? id, score: tally.get(id) ?? 0 };
    });
    withSeat.sort((a, b) => {
        const diff = b.score - a.score;
        if (diff !== 0) {
            return diff;
        }
        if (strategy === "min_id") {
            return a.id - b.id;
        }
        return a.seat - b.seat;
    });
    if ((withSeat[0]?.score ?? 0) <= 0)
        return null;
    if (withSeat.length >= 2 && withSeat[0].score === withSeat[1].score) {
        if (strategy === "no_elimination" || strategy === "no_kill") {
            return null;
        }
    }
    return withSeat[0]?.id ?? null;
}
function sortBySeat(world, ids) {
    return [...ids].sort((a, b) => {
        const aSeat = world.getComponent(a, names_1.COMPONENT.Identity)?.seat ?? a;
        const bSeat = world.getComponent(b, names_1.COMPONENT.Identity)?.seat ?? b;
        return aSeat - bSeat;
    });
}
function positiveLeaders(candidates, tally) {
    const maximum = Math.max(0, ...candidates.map((id) => tally.get(id) ?? 0));
    return maximum > 0 ? candidates.filter((id) => (tally.get(id) ?? 0) === maximum) : [];
}
