import { DeathCommitReceipt, committedDeathEntry, planDeathWave, } from "./death-wave";
import { getSessionRecorder } from "../recording/session/context";
import { isRoleId } from "@ai-werewolf-arena/game-contract";
import { aliveLifeVersion } from "../domain/components/alive";
import { COMPONENT } from "../domain/components/names";
import { DeathCause, Role, } from "../domain/model";
import { isAnimalDreamBoard, commitAnimalPufferKnifeDeath, } from "../features/animal-dream/ports";
import { isNobleBodyBoard, closeServantForDeath, } from "../features/noble-secret-body/ports";
import { appendNobleContractClosure } from "../features/noble-secret-body/ports";
import { recordWildChildDeathCommit } from "../features/wild-child/ports";
import { firstDeathGuns } from "../features/death-actions/gift-gun-ports";
import { expireLuckyAbilitiesOnDeath } from "../features/night-abilities/inventory-ports";
import { refreshHiddenWolfInheritance } from "../features/hidden-wolf/ports";
import { refreshGargoyleInheritance } from "../features/gargoyle/ports";
import { refreshMechanicalInheritance } from "../features/mechanical-wolf/ports";
import { refreshAwakenedInheritance } from "../features/awakened-hidden-wolf/ports";
export class DeathCommitter {
    context;
    settledLives = new Map();
    constructor(context) {
        this.context = context;
    }
    isSettledLife(id) {
        const alive = this.context.world.getComponent(id, COMPONENT.Alive), settled = this.settledLives.get(id);
        return (alive !== undefined &&
            settled?.component === alive &&
            settled.version === aliveLifeVersion(alive));
    }
    markPlayersDead(playerIds, refreshInheritance = true, gunsToExpire = [], reveal = false, sources = {}, animalScope, wave) {
        if (wave && (wave.ids !== playerIds || wave.sources !== sources))
            throw new Error("death_wave_commit_input_mismatch");
        const committedWave = wave ?? planDeathWave(playerIds, sources, "legacy");
        const entries = [];
        for (const id of playerIds) {
            const alive = this.context.world.getComponent(id, COMPONENT.Alive);
            if (!alive) {
                continue;
            }
            const firstSettlement = !this.isSettledLife(id);
            if (firstSettlement)
                recordWildChildDeathCommit(this.context.world, id);
            alive.alive = false;
            if (firstSettlement && isAnimalDreamBoard(this.context.world)) {
                if ((sources[id] ?? []).includes(DeathCause.WolfKill) &&
                    this.context.world.getComponent(id, COMPONENT.Role)?.role === Role.Pufferfish) {
                    commitAnimalPufferKnifeDeath(this.context.world, this.context.state.day, sources[id] ?? [], animalScope ?? (() => !this.context.state.gameOver));
                }
                if ((sources[id] ?? []).includes(DeathCause.Exile))
                    this.context.events.push({
                        timestamp: Date.now(),
                        type: "voted_out",
                        payload: { target: id },
                    });
                else if ((sources[id] ?? []).some((c) => c === DeathCause.PufferRetaliation || c === DeathCause.WhiteCatExpiry))
                    this.context.events.push({
                        timestamp: Date.now(),
                        type: "additional_deaths",
                        payload: { deaths: [id] },
                    });
            }
            if (firstSettlement && isNobleBodyBoard(this.context.world)) {
                const closed = closeServantForDeath(this.context.world, this.context.state.day, id);
                const payload = {
                    policy: "awa_noble_secret_body_v1",
                    actorId: id,
                    day: this.context.state.day,
                    causes: [...(sources[id] ?? [])],
                };
                this.context.events.push({
                    timestamp: Date.now(),
                    type: "noble_body_death_committed",
                    payload,
                    audience: Object.freeze([]),
                });
                getSessionRecorder()?.recordRequiredLogicOp({
                    scope: "resolution",
                    op: "noble_body_death_committed",
                    phase: this.context.state.phase,
                    status: "ok",
                    output: {
                        policy: payload.policy,
                        playerId: id,
                        day: payload.day,
                        causes: payload.causes,
                    },
                });
                if (closed)
                    appendNobleContractClosure(this.context.world, this.context.state.day, closed, this.context.events, this.context.state.phase);
            }
            const role = this.context.world.getComponent(id, COMPONENT.Role)?.role;
            if (reveal && firstSettlement && isRoleId(role))
                this.context.events.push({
                    timestamp: Date.now(),
                    type: "player_role_revealed",
                    payload: { playerId: id, role },
                });
            gunsToExpire.push(...firstDeathGuns(this.context.world, id));
            expireLuckyAbilitiesOnDeath(this.context.world, id, this.context.events);
            let settled;
            this.settledLives.set(id, (settled = { component: alive, version: aliveLifeVersion(alive) }));
            Object.freeze(settled);
            entries.push(committedDeathEntry(committedWave, id, firstSettlement, settled));
        }
        if (refreshInheritance) {
            refreshHiddenWolfInheritance(this.context.world, this.context.events, this.context.state.day);
            refreshGargoyleInheritance(this.context.world, this.context.events, this.context.state.day);
            refreshMechanicalInheritance(this.context.world, this.context.state.day, this.context.events);
            refreshAwakenedInheritance(this.context.world, this.context.state.day, this.context.events);
        }
        return new DeathCommitReceipt(committedWave, Object.freeze(entries));
    }
}
