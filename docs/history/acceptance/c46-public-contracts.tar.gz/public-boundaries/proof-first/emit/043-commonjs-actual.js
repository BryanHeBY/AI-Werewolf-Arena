"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeMirror = exports.freshMirrorInspectionState = void 0;
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const freshMirrorInspectionState = () => ({
    policy: "mirror",
    lastTarget: null,
    lastDay: null,
    history: [],
});
exports.freshMirrorInspectionState = freshMirrorInspectionState;
const nativeMirror = (role) => (0, inventory_ports_1.allNightAbilities)(role).find((ability) => ability.kind === "role_check" &&
    ability.source.kind === "native" &&
    ability.source.role === game_contract_1.Role.MirrorGirl);
exports.nativeMirror = nativeMirror;
