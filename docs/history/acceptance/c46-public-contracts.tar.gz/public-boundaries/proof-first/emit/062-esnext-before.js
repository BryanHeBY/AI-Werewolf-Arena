import { copyAbilityData, findNightAbility } from "../night-abilities/abilities";
import { commitPreparedNativeAbility } from "../night-abilities/abilities";
export function setSeerState(roleComp, state) {
    return commitPreparedNativeAbility(roleComp, "seer_check", SEER_STATE_SLOT.create(state));
}
export function getSeerState(roleComp, abilityId) {
    return findNightAbility(roleComp, "seer_check", abilityId)?.state;
}
export function recordSeerInspection(state, targetId, isWerewolf, inspection) {
    state.lastTarget = targetId;
    state.lastIsWerewolf = isWerewolf;
    state.lastResult = { ...inspection };
    state.history.push({ targetId, isWerewolf, result: { ...inspection } });
}
export function recordRecipientSeerInspection(ability, target, isWerewolf, result) {
    ability.state.lastTarget = target.id;
    ability.state.lastIsWerewolf = isWerewolf;
    ability.state.lastResult = { ...result };
    ability.state.history.push({
        targetId: target.id,
        isWerewolf,
        result: { ...result },
    });
}
function encodePolicyIdentity(ability) {
    return JSON.stringify([ability.state.targetPolicy, ability.state.actionPolicy]);
}
export const SEER_STATE_SLOT = Object.freeze({
    create: (copyAbilityData),
    schema: (copyAbilityData),
    install: setSeerState,
    get: getSeerState,
    allowedWrites: Object.freeze({
        recordSeerInspection,
        recordRecipientSeerInspection,
    }),
    checkpoint: Object.freeze({ policyIdentity: encodePolicyIdentity }),
    invalidations: Object.freeze({ policyIdentity: encodePolicyIdentity }),
});
