import { nativeRolePresentation } from "../../rulesets/roles/presentation-contribution";
import { GUARD_VALIDATION_RULES } from "../../rulesets/guard-tool-admission";
import { z } from "zod";
import { GUARD_REPEAT_POLICIES } from "../../domain/board";
import { guardTargetRepeated } from "./ports";
import { roleName, text } from "@ai-werewolf-arena/game-text";
import { Camp, Role } from "../../domain/model";
import { setGuardState } from "./ports";
import { numberOrNull } from "../../agents/tool-repair/helpers";
import { GUARD_NIGHT_STAGES } from "./night-stages";
import { GUARD_TOOL_SPECS } from "./tool-specs";
import { activeNightAbility } from "../night-abilities/abilities";
import { luckyTargetAllowed } from "../night-abilities/night-action-history";
const parameters = z.strictObject({
    repeatPolicy: z.enum(GUARD_REPEAT_POLICIES).default("awa_last_action_v1"),
});
export const GUARD_ROLE_PROFILE = {
    metadata: {
        role: Role.Guard,
        camp: Camp.Good,
        label: roleName("guard"),
        skillBrief: text("zh-CN", "role.guard.brief"),
        goodSide: "god",
    },
    runtime: {
        configuration: {
            schema: parameters,
            defaults: { repeatPolicy: "awa_last_action_v1" },
            apply: (config, value) => ({ ...config, guard: parameters.parse(value) }),
            serialize: (config) => parameters.parse(config.guard ?? {}),
        },
        init: (roleComp, ctx) => {
            setGuardState(roleComp, {
                lastTarget: null,
                ...(ctx.boardConfig?.guard?.repeatPolicy === "netease_consecutive_nights_v1"
                    ? { repeatPolicy: ctx.boardConfig.guard.repeatPolicy }
                    : {}),
            });
        },
        toolSpecs: GUARD_TOOL_SPECS,
        validationRules: GUARD_VALIDATION_RULES,
        nightStages: GUARD_NIGHT_STAGES,
        llmRepair: {
            coerce: {
                guard: (args) => {
                    const abstain = Boolean(args.abstain);
                    if (abstain)
                        return { target_id: null, abstain: true };
                    const target = numberOrNull(args.target_id);
                    return target === null ? null : { target_id: target, abstain: false };
                },
            },
        },
        baselineAction: (roleComp, request, pickAliveNotSelf, _byCamp, _locale, world) => {
            if (!request.allowedTools.includes("guard")) {
                return null;
            }
            const ability = activeNightAbility(roleComp, "guard", request.context.day, request.context.ability_id);
            const target = world && ability
                ? (world
                    .getAliveEntityIds()
                    .find((id) => id !== request.actorId &&
                    !guardTargetRepeated(ability, request.context.day, id) &&
                    luckyTargetAllowed(world, request.actorId, ability, request.context.day, "guard", id)) ?? null)
                : pickAliveNotSelf();
            if (target !== null &&
                ability &&
                !guardTargetRepeated(ability, request.context.day, target)) {
                return { name: "guard", args: { target_id: target, abstain: false } };
            }
            return { name: "guard", args: { target_id: null, abstain: true } };
        },
    },
    presentation: nativeRolePresentation("guard"),
};
