"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LUCKY_ABILITY_STAGE = exports.recordLuckyNightCommit = exports.hasLuckyNightCommit = void 0;
const recipient_ability_stage_1 = require("../night-abilities/recipient-ability-stage");
const hasLuckyNightCommit = (world, day) => (0, recipient_ability_stage_1.hasRecipientNightCommit)(world, day, "lucky");
exports.hasLuckyNightCommit = hasLuckyNightCommit;
const recordLuckyNightCommit = (world, day) => (0, recipient_ability_stage_1.recordRecipientNightCommit)(world, day, "lucky");
exports.recordLuckyNightCommit = recordLuckyNightCommit;
exports.LUCKY_ABILITY_STAGE = (0, recipient_ability_stage_1.recipientAbilityStage)("lucky", 700);
