"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.freshBlackMarketState = void 0;
exports.getBlackMarketState = getBlackMarketState;
exports.setBlackMarketState = setBlackMarketState;
exports.projectBlackMarketState = projectBlackMarketState;
exports.canBlackMarketTrade = canBlackMarketTrade;
exports.closeBlackMarketTrade = closeBlackMarketTrade;
exports.recordBlackMarketTrade = recordBlackMarketTrade;
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const freshBlackMarketState = () => ({
    remaining: 1,
    closedDay: null,
    choice: null,
});
exports.freshBlackMarketState = freshBlackMarketState;
function getBlackMarketState(role) {
    return role?.privateState.black_market_merchant;
}
function setBlackMarketState(role, state) {
    role.privateState.black_market_merchant =
        (0, inventory_ports_1.copyAbilityData)(state);
}
function projectBlackMarketState(state) {
    return {
        remaining: state.remaining,
        closedDay: state.closedDay,
        choice: state.choice
            ? { day: state.choice.day, targetId: state.choice.targetId, skill: state.choice.skill }
            : null,
    };
}
function canBlackMarketTrade(state, day) {
    return state.remaining === 1 && day >= 1 && (state.closedDay === null || state.closedDay < day);
}
function closeBlackMarketTrade(state, day) {
    state.closedDay = day;
}
function recordBlackMarketTrade(state, day, targetId, skill) {
    state.remaining = 0;
    state.closedDay = day;
    state.choice = { day, targetId, skill };
}
