"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.freshMechanicalState = freshMechanicalState;
exports.getMechanicalState = getMechanicalState;
exports.setMechanicalState = setMechanicalState;
exports.mechanicalLearning = mechanicalLearning;
exports.recordMechanicalInheritance = recordMechanicalInheritance;
exports.canMechanicalMimic = canMechanicalMimic;
exports.closeMechanicalMimic = closeMechanicalMimic;
exports.learnMechanicalRole = learnMechanicalRole;
exports.advanceMechanicalNight = advanceMechanicalNight;
exports.canSelectMechanicalMode = canSelectMechanicalMode;
exports.selectMechanicalMode = selectMechanicalMode;
exports.mechanicalSkillForNight = mechanicalSkillForNight;
exports.closeMechanicalSkill = closeMechanicalSkill;
exports.mechanicalKnifeSelected = mechanicalKnifeSelected;
exports.canMechanicalExtraKnife = canMechanicalExtraKnife;
exports.chooseMechanicalGuard = chooseMechanicalGuard;
exports.projectMechanicalState = projectMechanicalState;
exports.recordMechanicalInspection = recordMechanicalInspection;
exports.consumeMechanicalPoison = consumeMechanicalPoison;
exports.closeMechanicalExtraKnife = closeMechanicalExtraKnife;
const abilities_1 = require("../night-abilities/abilities");
const native_death_gun_resources_1 = require("../death-actions/native-death-gun-resources");
function freshMechanicalState() {
    return {
        learned: null,
        mimicClosedDay: null,
        mode: null,
        hasInheritedKnife: false,
        firstKnifeNight: null,
        skillClosedDay: null,
    };
}
function getMechanicalState(role) {
    return role
        ?.privateState.mechanical_wolf;
}
function setMechanicalState(role, state) {
    const owned = (0, abilities_1.copyAbilityData)(state);
    role.privateState.mechanical_wolf = owned;
    return owned;
}
function mechanicalLearning(targetId, role, day) {
    let skill;
    switch (role) {
        case "villager":
            skill = { kind: "villager" };
            break;
        case "psychic":
            skill = { kind: "inspection", history: [] };
            break;
        case "witch":
            skill = { kind: "poison", remaining: 1 };
            break;
        case "guard":
            skill = { kind: "guard", lastTarget: null, lastGuardDay: null };
            break;
        case "hunter":
            skill = (0, native_death_gun_resources_1.createLearnedNativeGun)();
            break;
        case "wolf":
            skill = { kind: "wolf", extraKnife: "available" };
            break;
        default:
            throw new Error("mechanical_learning_role_not_supported");
    }
    return { targetId, role, day, readyOnNight: day + 1, skill };
}
function recordMechanicalInheritance(state, day) {
    if (state.hasInheritedKnife)
        return false;
    state.hasInheritedKnife = true;
    state.firstKnifeNight = Math.max(2, day + 1);
    return true;
}
function canMechanicalMimic(state, day) {
    return (day >= 1 &&
        state.learned === null &&
        (state.mimicClosedDay === null || state.mimicClosedDay < day));
}
function closeMechanicalMimic(state, day, mayCommit) {
    if (!canMechanicalMimic(state, day))
        return false;
    if (mayCommit && !mayCommit())
        return false;
    state.mimicClosedDay = day;
    return true;
}
function learnMechanicalRole(state, targetId, role, day, mayCommit) {
    if (!canMechanicalMimic(state, day))
        return false;
    const learned = mechanicalLearning(targetId, role, day);
    if (learned.skill.kind === "wolf" &&
        state.firstKnifeNight !== null &&
        day >= state.firstKnifeNight) {
        learned.skill.extraKnife = "expired";
    }
    if (mayCommit && !mayCommit())
        return false;
    state.learned = learned;
    state.mimicClosedDay = day;
    return true;
}
function advanceMechanicalNight(state, day) {
    const learned = state.learned;
    if (!learned)
        return;
    (0, native_death_gun_resources_1.armMechanicalNativeGun)(learned, day);
    if (learned.skill.kind === "wolf" &&
        learned.skill.extraKnife === "available" &&
        state.firstKnifeNight !== null &&
        day > state.firstKnifeNight) {
        learned.skill.extraKnife = "expired";
    }
}
function canSelectMechanicalMode(state, day) {
    return day >= 2 && (state.mode === null || state.mode.day < day);
}
function selectMechanicalMode(state, day, mode, mayCommit) {
    if (!canSelectMechanicalMode(state, day))
        return false;
    if (mayCommit && !mayCommit())
        return false;
    state.mode = { day, kind: mode };
    const learned = state.learned;
    if (mode === "skill" &&
        state.firstKnifeNight === day &&
        learned?.skill.kind === "wolf" &&
        learned.skill.extraKnife === "available") {
        learned.skill.extraKnife = "expired";
    }
    return true;
}
function mechanicalSkillForNight(state, day) {
    if (day < 2 ||
        state.mode?.day !== day ||
        state.mode.kind !== "skill" ||
        !state.learned ||
        state.learned.readyOnNight > day ||
        (state.skillClosedDay !== null && state.skillClosedDay >= day))
        return undefined;
    return state.learned.skill;
}
function closeMechanicalSkill(state, day, mayCommit) {
    if (!mechanicalSkillForNight(state, day))
        return false;
    if (mayCommit && !mayCommit())
        return false;
    state.skillClosedDay = day;
    return true;
}
function mechanicalKnifeSelected(state, day) {
    return (day >= 2 &&
        state.hasInheritedKnife &&
        state.firstKnifeNight !== null &&
        day >= state.firstKnifeNight &&
        state.mode?.day === day &&
        state.mode.kind === "kill");
}
function canMechanicalExtraKnife(state, day) {
    const learned = state.learned;
    return (mechanicalKnifeSelected(state, day) &&
        state.firstKnifeNight === day &&
        learned !== null &&
        learned.readyOnNight <= day &&
        learned.skill.kind === "wolf" &&
        learned.skill.extraKnife === "available");
}
function chooseMechanicalGuard(skill, targetId, day, mayCommit) {
    const failed = targetId !== null && skill.lastTarget === targetId && skill.lastGuardDay === day - 1;
    if (mayCommit && !mayCommit())
        return null;
    skill.lastTarget = targetId;
    skill.lastGuardDay = day;
    return { failed };
}
function projectMechanicalState(state) {
    const learned = state.learned;
    let skill;
    if (learned)
        switch (learned.skill.kind) {
            case "villager":
                skill = { kind: "villager" };
                break;
            case "inspection":
                skill = {
                    kind: "inspection",
                    history: learned.skill.history.map((report) => ({
                        day: report.day,
                        targetId: report.targetId,
                        result: { kind: "role", role: report.result.role },
                    })),
                };
                break;
            case "poison":
                skill = { kind: "poison", remaining: learned.skill.remaining };
                break;
            case "guard":
                skill = {
                    kind: "guard",
                    lastTarget: learned.skill.lastTarget,
                    lastGuardDay: learned.skill.lastGuardDay,
                };
                break;
            case "hunter":
                skill = { kind: "hunter", canShoot: learned.skill.canShoot, armed: learned.skill.armed };
                break;
            case "wolf":
                skill = { kind: "wolf", extraKnife: learned.skill.extraKnife };
                break;
        }
    return {
        learned: learned && skill
            ? {
                targetId: learned.targetId,
                role: learned.role,
                day: learned.day,
                readyOnNight: learned.readyOnNight,
                skill,
            }
            : null,
        mimicClosedDay: state.mimicClosedDay,
        mode: state.mode ? { day: state.mode.day, kind: state.mode.kind } : null,
        hasInheritedKnife: state.hasInheritedKnife,
        firstKnifeNight: state.firstKnifeNight,
        skillClosedDay: state.skillClosedDay,
    };
}
function recordMechanicalInspection(skill, day, target, result, mayCommit) {
    if (!mayCommit) {
        skill.history.push({
            day,
            targetId: target.id,
            result: { ...result },
        });
        return;
    }
    const history = skill.history;
    const append = history.push;
    const entry = {
        day,
        targetId: target.id,
        result: { ...result },
    };
    const invoke = Reflect.apply.bind(Reflect);
    if (!mayCommit())
        return false;
    invoke(append, history, [entry]);
    return true;
}
function consumeMechanicalPoison(skill) {
    skill.remaining = 0;
}
function closeMechanicalExtraKnife(skill, target) {
    skill.extraKnife = target
        ? "spent"
        : "expired";
}
