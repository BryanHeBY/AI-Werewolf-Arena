import { Role } from "../../domain/model";
export function nativePotionsCanCombine(ability) {
    return (ability.source.kind === "native" &&
        ability.state.potionPolicy === "awa_both_native_experimental_v1");
}
export function witchKnifeVisible(ability) {
    const policy = ability.source.kind === "native" && ability.source.role === Role.Witch
        ? ability.state.knifeVisibility
        : undefined;
    if (policy === "awa_always_v1")
        return true;
    return (ability.state.heal > 0 &&
        !ability.state.healUsedThisNight &&
        (nativePotionsCanCombine(ability) || !ability.state.poisonUsedThisNight));
}
export function nativePotionSecondTurn(ability, day) {
    return (nativePotionsCanCombine(ability) &&
        ability.state.potionTurnClosedDay !== day &&
        ((ability.state.healUsedThisNight &&
            !ability.state.poisonUsedThisNight &&
            ability.state.poison > 0) ||
            (ability.state.poisonUsedThisNight &&
                !ability.state.healUsedThisNight &&
                ability.state.heal > 0)));
}
