import { Role, permitsDeathShot } from "../../domain/model";
import { resolveNativeDeathShots } from "../death-actions/settlement-ports";
import { getAwakenedState } from "./state";
import { createAwakenedGunReader } from "../death-actions/native-resource-ports";
export const awakenedDeathHook = (world, ids, sources, choose, events, context) => {
    const readGun = createAwakenedGunReader({ get getAwakenedState() { return getAwakenedState; } });
    return resolveNativeDeathShots(world, ids, sources, choose, events, {
        role: Role.AwakenedHiddenWolf,
        state: readGun,
        permits: permitsDeathShot,
        shotEvent: (actorId, targetId) => ({
            timestamp: Date.now(),
            type: "player_shot",
            payload: { actorId, targetId },
        }),
    }, context);
};
