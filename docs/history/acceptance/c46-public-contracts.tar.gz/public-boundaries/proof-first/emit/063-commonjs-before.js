"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.commitSelfDestructSelection = commitSelfDestructSelection;
const ports_1 = require("../red-moon/ports");
const authority_1 = require("../demon-hunter/authority");
const capability_1 = require("./capability");
const authority_2 = require("../ghost-bride/authority");
const model_1 = require("../../domain/model");
const names_1 = require("../../domain/components/names");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const ports_2 = require("../white-wolf-king/ports");
const role_catalog_assembly_1 = require("../../rulesets/roles/role-catalog-assembly");
function commitSelfDestructSelection(world, choice, window, phase, events) {
    if (!Object.values(model_1.ActionWindow).includes(window) ||
        phase !== (window === model_1.ActionWindow.OnPreVote ? model_1.Phase.Voting : model_1.Phase.Day))
        return null;
    const role = world.getComponent(choice.actorId, names_1.COMPONENT.Role);
    if (!role || !world.getComponent(choice.actorId, names_1.COMPONENT.Alive)?.alive)
        return null;
    const ownsWedding = (0, authority_2.weddingSetup)(world) !== null;
    if (ownsWedding &&
        (!(0, authority_2.ghostBrideReady)(world) ||
            role.role !== model_1.Role.Wolf ||
            (0, authority_2.weddingMember)(world, role) ||
            ![model_1.ActionWindow.OnPreElection, model_1.ActionWindow.OnPreVote].includes(window)))
        return null;
    const deaths = [choice.actorId], sources = { [choice.actorId]: [model_1.DeathCause.SelfDestruct] };
    if (choice.kind === "ordinary") {
        const redMoon = String(role.role) === ports_1.RED_MOON_ROLE;
        if (choice.targetId !== null ||
            (redMoon
                ? ![model_1.ActionWindow.OnPreElection, model_1.ActionWindow.OnPreVote].includes(window)
                : !(0, capability_1.canRoleSelfDestruct)(role, (0, role_catalog_assembly_1.getDefaultRoleCatalog)(), () => world.getComponent(choice.actorId, names_1.COMPONENT.Camp))))
            return null;
        if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
            return null;
        const moon = redMoon ? (0, authority_1.commitDemonRedMoonBlast)(world, choice.actorId) : null;
        if (redMoon && !moon)
            return null;
        if (ownsWedding)
            (0, authority_2.swallowWeddingBadges)(world, events);
        events.push({
            timestamp: Date.now(),
            type: "wolf_self_destruct",
            payload: { wolfId: choice.actorId, window },
        });
        if (moon?.sealsNight)
            events.push({
                timestamp: Date.now(),
                type: "red_moon_night_sealed",
                payload: { actorId: choice.actorId, day: moon.day, night: moon.day + 1 },
            });
    }
    else if (choice.kind === "white_wolf_king") {
        const state = (0, ports_2.getWhiteWolfKingState)(role);
        if (role.role !== model_1.Role.WhiteWolfKing || state?.canDetonate !== true)
            return null;
        if (choice.targetId !== null) {
            if (choice.targetId === choice.actorId ||
                !world.getComponent(choice.targetId, names_1.COMPONENT.Alive)?.alive)
                return null;
            deaths.push(choice.targetId);
            sources[choice.targetId] = [model_1.DeathCause.WhiteWolfBlast];
        }
        if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
            return null;
        (0, ports_2.consumeWhiteWolfDetonation)(state);
        events.push({
            timestamp: Date.now(),
            type: "white_wolf_king_self_destruct",
            payload: { actorId: choice.actorId, targetId: choice.targetId, window },
        });
    }
    else
        return null;
    return { deaths, sources };
}
