"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assignSheriff = assignSheriff;
exports.transferOrDestroySheriffBadge = transferOrDestroySheriffBadge;
exports.commitSheriffBadgeChoice = commitSheriffBadgeChoice;
exports.badgeSuccessorEligible = badgeSuccessorEligible;
exports.findSheriffId = findSheriffId;
exports.assignInitialSheriff = assignInitialSheriff;
const authority_1 = require("../demon-hunter/authority");
const authority_2 = require("../ghost-bride/authority");
const names_1 = require("../../domain/components/names");
const participation_1 = require("../../engine/participation");
const SHERIFF_VOTE_WEIGHT = 1.5;
function assignSheriff(world, sheriffId, config, catalog) {
    (0, authority_1.assertDemonBadgeReadable)(world);
    if ((0, authority_2.weddingBadgeSwallowed)(world) || !(0, participation_1.canBeSheriff)(world, sheriffId, catalog))
        return false;
    const frame = (0, authority_1.openDemonBadgeFrame)(world);
    const weight = config?.sheriff?.voteWeight ?? SHERIFF_VOTE_WEIGHT;
    for (const id of world.getAliveEntityIds()) {
        const badge = world.getComponent(id, names_1.COMPONENT.Badge);
        if (badge) {
            badge.isSheriff = id === sheriffId;
            badge.destroyed = false;
            badge.voteWeight = weight;
            if (config?.sheriff?.badgePolicy === "awa_holder_choice_v1")
                badge.handoffPolicy = "awa_holder_choice_v1";
            else
                delete badge.handoffPolicy;
        }
        const voting = world.getComponent(id, names_1.COMPONENT.VotingRight);
        if (voting?.canVote)
            voting.weight = id === sheriffId ? weight : 1;
    }
    frame?.commit({
        kind: "assign",
        sheriffId,
        weight,
        policy: config?.sheriff?.badgePolicy === "awa_holder_choice_v1" ? "awa_holder_choice_v1" : undefined,
    });
    return true;
}
function transferOrDestroySheriffBadge(world, fromId, reason, events, catalog) {
    (0, authority_1.assertDemonBadgeReadable)(world);
    const badge = world.getComponent(fromId, names_1.COMPONENT.Badge);
    if (!badge?.isSheriff || badge.destroyed)
        return null;
    return commitSheriffBadgeChoice(world, fromId, reason, events, badge.handoffPolicy === "awa_holder_choice_v1"
        ? null
        : pickNextSheriffCandidate(world, fromId, catalog), catalog);
}
function commitSheriffBadgeChoice(world, fromId, reason, events, targetId, catalog, onDomainCommitted, beforeDomainCommit) {
    (0, authority_1.assertDemonBadgeReadable)(world);
    const badge = world.getComponent(fromId, names_1.COMPONENT.Badge);
    if (!badge?.isSheriff || badge.destroyed)
        return null;
    const frame = (0, authority_1.openDemonBadgeFrame)(world);
    const weight = badge.voteWeight ?? SHERIFF_VOTE_WEIGHT;
    const policy = badge.handoffPolicy;
    const nextSheriffId = targetId !== null && badgeSuccessorEligible(world, fromId, targetId, catalog) ? targetId : null;
    if (beforeDomainCommit !== undefined && beforeDomainCommit() !== true)
        return null;
    badge.isSheriff = false;
    badge.destroyed = true;
    resetVotingWeight(world, fromId);
    if (nextSheriffId === null) {
        frame?.commit({ kind: "handoff", fromId, toId: null, weight, policy });
        onDomainCommitted?.();
        events.push({
            timestamp: Date.now(),
            type: "sheriff_badge_destroyed",
            payload: { targetId: fromId, reason },
        });
        return { fromId, toId: null, destroyed: true };
    }
    const nextBadge = world.getComponent(nextSheriffId, names_1.COMPONENT.Badge);
    if (nextBadge) {
        nextBadge.isSheriff = true;
        nextBadge.destroyed = false;
        nextBadge.voteWeight = weight;
        if (policy)
            nextBadge.handoffPolicy = policy;
        else
            delete nextBadge.handoffPolicy;
    }
    const nextVoting = world.getComponent(nextSheriffId, names_1.COMPONENT.VotingRight);
    if (nextVoting)
        nextVoting.weight = weight;
    frame?.commit({ kind: "handoff", fromId, toId: nextSheriffId, weight, policy });
    onDomainCommitted?.();
    events.push({
        timestamp: Date.now(),
        type: "sheriff_badge_transferred",
        payload: { fromId, toId: nextSheriffId, reason },
    });
    return { fromId, toId: nextSheriffId, destroyed: false };
}
function resetVotingWeight(world, entityId) {
    const voting = world.getComponent(entityId, names_1.COMPONENT.VotingRight);
    if (voting)
        voting.weight = voting.canVote ? 1 : 0;
}
function badgeSuccessorEligible(world, fromId, id, catalog) {
    (0, authority_1.assertDemonBadgeReadable)(world);
    return (id !== fromId &&
        (0, participation_1.canBeSheriff)(world, id, catalog) &&
        world.getComponent(id, names_1.COMPONENT.Alive)?.alive === true &&
        world.getComponent(id, names_1.COMPONENT.VotingRight)?.canVote === true &&
        world.getComponent(id, names_1.COMPONENT.Badge)?.destroyed === false);
}
function pickNextSheriffCandidate(world, fromId, catalog) {
    (0, authority_1.assertDemonBadgeReadable)(world);
    const candidates = world
        .getAliveEntityIds()
        .filter((id) => badgeSuccessorEligible(world, fromId, id, catalog));
    candidates.sort((a, b) => {
        const aSeat = world.getComponent(a, names_1.COMPONENT.Identity)?.seat ?? a;
        const bSeat = world.getComponent(b, names_1.COMPONENT.Identity)?.seat ?? b;
        return aSeat - bSeat;
    });
    return candidates[0] ?? null;
}
function findSheriffId(world, catalog) {
    (0, authority_1.assertDemonBadgeReadable)(world);
    return (world.getAliveEntityIds().find((id) => {
        const badge = world.getComponent(id, names_1.COMPONENT.Badge);
        return (badge?.isSheriff === true && badge.destroyed === false && (0, participation_1.canBeSheriff)(world, id, catalog));
    }) ?? null);
}
function assignInitialSheriff(world, config, playerIds) {
    if (!config.enableSheriff || config.initialSheriffSeat === undefined)
        return;
    const sheriffId = playerIds.find((id) => world.getComponent(id, names_1.COMPONENT.Identity)?.seat === config.initialSheriffSeat);
    if (sheriffId !== undefined)
        assignSheriff(world, sheriffId, config);
}
