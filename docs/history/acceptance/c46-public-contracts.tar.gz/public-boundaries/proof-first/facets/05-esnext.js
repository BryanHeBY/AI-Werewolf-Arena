export { DEATH_SHOT_REPAIR, DEATH_SHOT_TOOL_SPECS, validateDeathShot, } from "./death-shot";
