export { deathActionConfiguration, renderDeathActionPolicy, } from "./death-action-policy";
