export { finishDeathGuns, firstDeathGuns, grantDeathGun, validateGiftGun, } from "./death-abilities";
