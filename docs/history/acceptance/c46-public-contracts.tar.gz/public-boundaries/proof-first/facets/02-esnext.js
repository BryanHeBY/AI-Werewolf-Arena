export { prohibitsLoversVote, } from "./relation";
