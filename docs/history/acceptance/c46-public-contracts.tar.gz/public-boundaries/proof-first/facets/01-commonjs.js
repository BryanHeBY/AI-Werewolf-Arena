"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.animalPackKnifeBlocked = void 0;
var authority_1 = require("./authority");
Object.defineProperty(exports, "animalPackKnifeBlocked", { enumerable: true, get: function () { return authority_1.animalPackKnifeBlocked; } });
