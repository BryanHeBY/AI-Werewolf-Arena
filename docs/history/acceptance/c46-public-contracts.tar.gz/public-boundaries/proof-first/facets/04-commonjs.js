"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderDeathActionPolicy = exports.deathActionConfiguration = void 0;
var death_action_policy_1 = require("./death-action-policy");
Object.defineProperty(exports, "deathActionConfiguration", { enumerable: true, get: function () { return death_action_policy_1.deathActionConfiguration; } });
Object.defineProperty(exports, "renderDeathActionPolicy", { enumerable: true, get: function () { return death_action_policy_1.renderDeathActionPolicy; } });
