export { giftGunDeathHook, } from "./gift-gun-death-hook";
