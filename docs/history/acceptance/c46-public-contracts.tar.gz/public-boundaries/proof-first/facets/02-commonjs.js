"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prohibitsLoversVote = void 0;
var relation_1 = require("./relation");
Object.defineProperty(exports, "prohibitsLoversVote", { enumerable: true, get: function () { return relation_1.prohibitsLoversVote; } });
