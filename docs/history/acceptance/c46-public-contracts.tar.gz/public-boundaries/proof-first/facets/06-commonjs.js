"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.giftGunDeathHook = void 0;
var gift_gun_death_hook_1 = require("./gift-gun-death-hook");
Object.defineProperty(exports, "giftGunDeathHook", { enumerable: true, get: function () { return gift_gun_death_hook_1.giftGunDeathHook; } });
