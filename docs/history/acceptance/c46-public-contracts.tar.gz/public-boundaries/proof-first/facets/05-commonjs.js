"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeathShot = exports.DEATH_SHOT_TOOL_SPECS = exports.DEATH_SHOT_REPAIR = void 0;
var death_shot_1 = require("./death-shot");
Object.defineProperty(exports, "DEATH_SHOT_REPAIR", { enumerable: true, get: function () { return death_shot_1.DEATH_SHOT_REPAIR; } });
Object.defineProperty(exports, "DEATH_SHOT_TOOL_SPECS", { enumerable: true, get: function () { return death_shot_1.DEATH_SHOT_TOOL_SPECS; } });
Object.defineProperty(exports, "validateDeathShot", { enumerable: true, get: function () { return death_shot_1.validateDeathShot; } });
