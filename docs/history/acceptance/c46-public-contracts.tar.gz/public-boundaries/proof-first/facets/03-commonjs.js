"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateGiftGun = exports.grantDeathGun = exports.firstDeathGuns = exports.finishDeathGuns = void 0;
var death_abilities_1 = require("./death-abilities");
Object.defineProperty(exports, "finishDeathGuns", { enumerable: true, get: function () { return death_abilities_1.finishDeathGuns; } });
Object.defineProperty(exports, "firstDeathGuns", { enumerable: true, get: function () { return death_abilities_1.firstDeathGuns; } });
Object.defineProperty(exports, "grantDeathGun", { enumerable: true, get: function () { return death_abilities_1.grantDeathGun; } });
Object.defineProperty(exports, "validateGiftGun", { enumerable: true, get: function () { return death_abilities_1.validateGiftGun; } });
