/**
 * 负责本批有限公开边界的完整程序、具名声明与原有序依赖证明。
 * 只读固定 Git、已冻结候选和 Root 应用后的 owned 源；只在显式新输出目录写证明材料。
 * 不执行产品模块，不做类型诊断、业务测试或结构门禁；新公共面不是新的许可或库存。
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const args = process.argv.slice(2);
const argument = (name) => { const at = args.indexOf(name); assert(at >= 0 && args[at + 1], `missing ${name}`); return args[at + 1]; };
const repo = path.resolve(argument('--repo'));
const bundle = path.resolve(argument('--bundle'));
const out = path.resolve(argument('--out'));
const expectedBase = '7a85ad67ac808aab3e1d6d91078262a64382ca93';
const sha = (value) => createHash('sha256').update(value).digest('hex');
const inputLocks = {
  'before.json': 'ca25077a28ea388d31ad82230e96f483976f5794b9c8cb09a694592347490bde',
  'candidate.json': 'a4183804e64360efe2edcd53959302f97e6c373db593a0e6cabb0e36239310e1',
};
for (const [name, expected] of Object.entries(inputLocks)) assert.equal(sha(fs.readFileSync(path.join(bundle, name))), expected, `input:${name}`);
const before = JSON.parse(fs.readFileSync(path.join(bundle, 'before.json'), 'utf8'));
const candidate = JSON.parse(fs.readFileSync(path.join(bundle, 'candidate.json'), 'utf8'));
assert.equal(before.baseCommit, expectedBase);
assert.equal(candidate.baseCommit, expectedBase);
assert.equal(candidate.files.length, 72);
assert.equal(candidate.publicFacets.length, 37);
assert.equal(candidate.edgeRoutes.length, 138);
assert(!fs.existsSync(out), 'output directory must be fresh; preserve any first result');
const git = (...argv) => cp.execFileSync('git', argv, { cwd: repo, maxBuffer: 32 * 1024 * 1024 });
assert.equal(git('rev-parse', `${expectedBase}^{commit}`).toString().trim(), expectedBase);
const allTracked = new Map(git('ls-tree', '-r', expectedBase).toString().trimEnd().split('\n').map((line) => {
  const at = line.indexOf('\t'), [mode, kind, blob] = line.slice(0, at).split(' ');
  return [line.slice(at + 1), { mode, kind, blob }];
}));
const gitCache = new Map();
const gitBytes = (file) => {
  assert(allTracked.has(file), `not fixed Git input:${file}`);
  if (!gitCache.has(file)) gitCache.set(file, git('show', `${expectedBase}:${file}`));
  return gitCache.get(file);
};
const modeOf = (stat) => stat.mode & 0o100 ? '100755' : '100644';
function actual(file, expectedMode, expectedSHA) {
  const p = path.join(repo, file), stat = fs.lstatSync(p);
  assert(stat.isFile() && !stat.isSymbolicLink(), `regular owned source:${file}`);
  assert.equal(modeOf(stat), expectedMode, `mode:${file}`);
  const bytes = fs.readFileSync(p);
  assert.equal(sha(bytes), expectedSHA, `current SHA:${file}`);
  return bytes.toString('utf8');
}
const sourceRows = new Map(before.sources.map((row) => [row.path, row]));
for (const row of before.sources) {
  const meta = allTracked.get(row.path); assert(meta && meta.kind === 'blob', `before tracked:${row.path}`);
  assert.equal(meta.mode, row.mode); assert.equal(meta.blob, row.blob);
  const bytes = gitBytes(row.path); assert.equal(sha(bytes), row.sha256); assert.equal(bytes.length, row.bytes);
  assert.equal(bytes.toString('utf8'), row.text, `complete Git text:${row.path}`);
}
for (const file of before.newAbsence) assert(!allTracked.has(file), `new path was tracked:${file}`);
assert.equal(before.newAbsence.length, 36);
for (const row of before.controls) {
  assert.equal(allTracked.get(row.path)?.blob, row.blob);
  assert.equal(allTracked.get(row.path)?.mode, row.mode);
  assert.equal(sha(gitBytes(row.path)), row.sha256);
  actual(row.path, row.mode, row.sha256);
}
function applyEdits(text, edits, inverse = false) {
  if (!inverse) {
    const ordered = [...edits].sort((a, b) => a.start - b.start);
    let cursor = -1;
    for (const e of ordered) { assert(e.start >= cursor); assert(e.end >= e.start); assert.equal(text.slice(e.start, e.end), e.before); cursor = e.end; }
    for (const e of ordered.reverse()) text = text.slice(0, e.start) + e.after + text.slice(e.end);
    return text;
  }
  const ordered = [...edits].sort((a, b) => a.start - b.start);
  let delta = 0;
  const inverted = ordered.map((e) => { const start = e.start + delta; delta += e.after.length - e.before.length; return { start, end: start + e.after.length, before: e.after, after: e.before }; });
  return applyEdits(text, inverted);
}
const overlay = new Map();
const outputs = new Map();
const members = [];
const addOutput = (name, text) => { assert(!outputs.has(name)); outputs.set(name, text); members.push({ path: name, sha256: sha(text), bytes: Buffer.byteLength(text) }); };
for (const row of candidate.files) {
  const captured = sourceRows.get(row.path); assert(captured);
  assert.equal(row.before, captured.text); assert.equal(sha(row.before), row.beforeSHA256);
  assert.equal(applyEdits(row.before, row.edits), row.after, `whole forward:${row.path}`);
  assert.equal(sha(row.after), row.afterSHA256);
  overlay.set(row.path, actual(row.path, row.mode, row.afterSHA256));
}
for (const row of candidate.publicFacets) {
  if (row.action === 'new-bounded-public-facet') {
    assert(before.newAbsence.includes(row.publicPath));
    assert.equal(row.bytes, Buffer.byteLength(row.source)); assert.equal(sha(row.source), row.sha256);
    overlay.set(row.publicPath, actual(row.publicPath, row.mode, row.sha256));
  } else {
    assert.equal(row.action, 'reuse-existing-public-api');
    assert.equal(row.source, sourceRows.get(row.publicPath)?.text);
    actual(row.publicPath, allTracked.get(row.publicPath).mode, row.sha256);
  }
}
assert.equal(overlay.size, 108);
const ts = require(path.join(repo, 'backend/node_modules/typescript'));
const printer = ts.createPrinter({ removeComments: true });
const parse = (file, text, js = false) => {
  const sf = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, js ? ts.ScriptKind.JS : ts.ScriptKind.TS);
  assert.equal(sf.parseDiagnostics.length, 0, `parse:${file}`); return sf;
};
let typedNodes = 0, arrays = 0, leaves = 0, tokens = 0;
function completeTree(node, sf) {
  typedNodes++;
  const children = [];
  ts.forEachChild(node,
    (child) => { children.push(completeTree(child, sf)); },
    (array) => { arrays++; children.push(['NodeArray', array.hasTrailingComma === true, ...array.map((child) => completeTree(child, sf))]); });
  if (!children.length) { leaves++; return [node.kind, node.getText(sf)]; }
  return [node.kind, ...children];
}
function completeTokens(text) {
  const scanner = ts.createScanner(ts.ScriptTarget.Latest, true, ts.LanguageVariant.Standard, text), list = [];
  while (true) { const kind = scanner.scan(); if (kind === ts.SyntaxKind.EndOfFileToken) break; tokens++; list.push([kind, scanner.getTokenText()]); }
  return list;
}
function bindingReferences(sf) {
  const rows = [];
  const add = (node, expression, kind, typeOnly, names, sites) => {
    assert(ts.isStringLiteralLike(expression), `literal module:${sf.fileName}`);
    rows.push({ node, expression, specifier: expression.text, line: sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1,
      binding: { kind, typeOnly, symbols: [...names].sort() }, sites });
  };
  const walk = (node) => {
    if (ts.isImportDeclaration(node)) {
      const clause = node.importClause, named = clause?.namedBindings;
      const names = [], sites = [];
      if (clause?.name) { names.push('default'); sites.push({ name: 'default', node: clause.name }); }
      if (named && ts.isNamedImports(named)) for (const e of named.elements) {
        const name = (e.propertyName ?? e.name).text;
        names.push(`${e.isTypeOnly ? 'type' : 'value'}:${name}`); sites.push({ name, node: e.name });
      }
      else if (named && ts.isNamespaceImport(named)) names.push('namespace:*');
      add(node, node.moduleSpecifier, 'import', clause?.isTypeOnly ?? false, names.length ? names : ['side-effect'], sites);
    } else if (ts.isExportDeclaration(node) && node.moduleSpecifier) {
      const names = [], sites = [];
      if (node.exportClause && ts.isNamedExports(node.exportClause)) for (const e of node.exportClause.elements) {
        const name = (e.propertyName ?? e.name).text;
        names.push(`${e.isTypeOnly ? 'type' : 'value'}:${name}->${e.name.text}`); sites.push({ name, node: e.name });
      } else names.push('namespace:*');
      add(node, node.moduleSpecifier, 'export', node.isTypeOnly, names, sites);
    } else if (ts.isImportTypeNode(node) && ts.isLiteralTypeNode(node.argument)) {
      add(node, node.argument.literal, 'import-type', true, [node.qualifier?.getText(sf) ?? 'namespace:*'], node.qualifier ? [{ name: node.qualifier.getText(sf), node: node.qualifier }] : []);
    }
    ts.forEachChild(node, (child) => { walk(child); });
  };
  walk(sf); return rows;
}
const emit = (file, text, module) => ts.transpileModule(text, { fileName: file, compilerOptions: { target: ts.ScriptTarget.ES2022, module, removeComments: true } }).outputText;
const modeledPaths = new Set([...allTracked.keys(), ...overlay.keys()]);
function resolveEdge(from, literal) {
  if (!literal.startsWith('.')) return `external:${literal}`;
  const base = path.posix.normalize(path.posix.join(path.posix.dirname(from), literal));
  for (const file of [base, `${base}.ts`, `${base}.tsx`, `${base}.mts`, `${base}.cts`, `${base}.js`, `${base}/index.ts`, `${base}/index.js`]) if (modeledPaths.has(file)) return file;
  throw new Error(`unresolved modeled edge:${from}:${literal}`);
}
const fold = new Map(candidate.publicFacets.map((row) => [row.publicPath, row.target]));
const folded = (file) => fold.get(file) ?? file;
function staticEdges(file, js) {
  const sf = parse(`${file}.emitted.js`, js, true), rows = [];
  for (const node of sf.statements) if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier) {
    assert(ts.isStringLiteral(node.moduleSpecifier)); rows.push(resolveEdge(file, node.moduleSpecifier.text));
  }
  return rows;
}
function jsModuleSites(sf) {
  const result = [];
  const walk = (n) => {
    if ((ts.isImportDeclaration(n) || ts.isExportDeclaration(n)) && n.moduleSpecifier && ts.isStringLiteral(n.moduleSpecifier)) result.push(n.moduleSpecifier);
    else if (ts.isCallExpression(n) && ((ts.isIdentifier(n.expression) && n.expression.text === 'require') || n.expression.kind === ts.SyntaxKind.ImportKeyword) && n.arguments.length === 1 && ts.isStringLiteral(n.arguments[0])) result.push(n.arguments[0]);
    ts.forEachChild(n, (child) => { walk(child); });
  };
  walk(sf); return result;
}
function requireDeclarations(sf) {
  const list = [];
  const walk = (n) => {
    if (ts.isVariableDeclaration(n) && ts.isIdentifier(n.name) && n.initializer) {
      const refs = [];
      const inner = (c) => { if (ts.isCallExpression(c) && ts.isIdentifier(c.expression) && c.expression.text === 'require' && c.arguments.length === 1 && ts.isStringLiteral(c.arguments[0])) refs.push(c.arguments[0].text); ts.forEachChild(c, (child) => { inner(child); }); };
      inner(n.initializer);
      if (refs.length === 1) list.push({ name: n.name, specifier: refs[0] });
    }
    ts.forEachChild(n, (child) => { walk(child); });
  };
  walk(sf); return list;
}
// 实际 CJS 的编译器 namespace 名字会随模块叶名改变；只按 require 声明的局部 Symbol 对应恢复。
function mappedActualOutput(file, original, actualText, routeMap) {
  const a = parse(file + '.before.js', original, true), b = parse(file + '.actual.js', actualText, true);
  const oldSites = jsModuleSites(a), newSites = jsModuleSites(b), patches = [];
  assert.equal(newSites.length, oldSites.length, `emitted module site count:${file}`);
  oldSites.forEach((oldNode, index) => {
    const newNode = newSites[index], restored = routeMap.get(newNode.text) ?? newNode.text;
    assert.equal(restored, oldNode.text, `emitted module target:${file}`);
    if (newNode.getText(b) !== oldNode.getText(a)) patches.push({ start: newNode.getStart(b), end: newNode.end, text: oldNode.getText(a) });
  });
  const oldDecls = requireDeclarations(a), newDecls = requireDeclarations(b);
  assert.equal(newDecls.length, oldDecls.length, `CJS require binding count:${file}`);
  const renames = [];
  for (let i = 0; i < oldDecls.length; i++) {
    assert.equal(routeMap.get(newDecls[i].specifier) ?? newDecls[i].specifier, oldDecls[i].specifier);
    if (oldDecls[i].name.text !== newDecls[i].name.text) renames.push({ old: oldDecls[i].name.text, actual: newDecls[i].name.text, declaration: newDecls[i].name, originalModule: oldDecls[i].specifier, actualModule: newDecls[i].specifier });
  }
  if (renames.length) {
    const virtual = path.resolve(repo, '__awa_local_namespace_only__.js');
    const localHost = {
      getSourceFile: (name) => name === virtual ? b : undefined,
      getDefaultLibFileName: () => '', writeFile() {}, getCurrentDirectory: () => repo,
      getDirectories: () => [], fileExists: (name) => name === virtual,
      readFile: (name) => name === virtual ? actualText : undefined,
      getCanonicalFileName: (name) => name, useCaseSensitiveFileNames: () => true, getNewLine: () => '\n',
    };
    // 文件名统一给 checker；只解析这个 JS 的局部变量，不解析 require、不获取诊断。
    const jsFile = ts.createSourceFile(virtual, actualText, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
    localHost.getSourceFile = (name) => name === virtual ? jsFile : undefined;
    const program = ts.createProgram([virtual], { allowJs: true, checkJs: false, noResolve: true, noLib: true }, localHost), checker = program.getTypeChecker();
    const localDecls = requireDeclarations(jsFile);
    const symbols = new Map();
    for (const rename of renames) {
      const d = localDecls.find((x) => x.name.text === rename.actual);
      assert(d, `generated namespace declaration:${file}:${rename.actual}`);
      const symbol = checker.getSymbolAtLocation(d.name); assert(symbol, `local namespace symbol:${file}`); symbols.set(symbol, rename.old);
    }
    const visit = (n) => {
      if (ts.isIdentifier(n)) {
        const replacement = symbols.get(checker.getSymbolAtLocation(n));
        if (replacement) patches.push({ start: n.getStart(jsFile), end: n.end, text: replacement });
      }
      ts.forEachChild(n, (child) => { visit(child); });
    };
    visit(jsFile);
  }
  patches.sort((x, y) => y.start - x.start);
  let end = actualText.length, restored = actualText;
  for (const patch of patches) { assert(patch.end <= end, `overlapping emitted patch:${file}`); restored = restored.slice(0, patch.start) + patch.text + restored.slice(patch.end); end = patch.start; }
  assert.equal(restored, original, `complete actual emitted normalization:${file}`);
  return { sameAfterBoundedModuleAndGeneratedNamespaceNormalization: true, moduleLiteralPatches: newSites.filter((n, i) => n.getText(b) !== oldSites[i].getText(a)).length,
    generatedNamespaceRenames: renames.map(({ declaration, ...row }) => row) };
}
const programs = [];
let editCount = 0, actualBindings = 0;
for (const [index, row] of candidate.files.entries()) {
  const text = overlay.get(row.path), inverse = applyEdits(text, row.edits, true);
  assert.equal(inverse, row.before, `whole inverse:${row.path}`);
  const oldSF = parse(row.path, row.before), restoredSF = parse(row.path, inverse);
  assert.deepEqual(completeTree(oldSF, oldSF), completeTree(restoredSF, restoredSF), `complete typed tree:${row.path}`);
  assert.deepEqual(completeTokens(row.before), completeTokens(inverse), `complete noncomment tokens:${row.path}`);
  const beforeRefs = bindingReferences(oldSF), afterRefs = bindingReferences(parse(row.path, text));
  assert.equal(beforeRefs.length, afterRefs.length, `all consumer refs:${row.path}`);
  beforeRefs.forEach((oldRef, i) => {
    const current = afterRefs[i]; assert.deepEqual(current.binding, oldRef.binding);
    const e = row.edits.find((e) => e.diagnosticLine === oldRef.line && e.before === oldRef.specifier);
    assert.equal(current.specifier, e ? e.after : oldRef.specifier);
  });
  for (const e of row.edits) {
    const matches = beforeRefs.filter((r) => r.line === e.diagnosticLine && r.specifier === e.before);
    assert.equal(matches.length, 1, `exact original reference:${row.path}:${e.diagnosticLine}`);
    assert.deepEqual(matches[0].binding, e.binding); editCount++;
  }
  const routeMap = new Map(row.edits.map((e) => [e.after, e.before]));
  assert.equal(routeMap.size, new Set(row.edits.map((e) => e.before)).size, `one-to-one route literals:${row.path}`);
  const emitted = [];
  for (const [label, module] of [['esnext', ts.ModuleKind.ESNext], ['commonjs', ts.ModuleKind.CommonJS]]) {
    const original = emit(row.path, row.before, module), actualText = emit(row.path, text, module), normalized = emit(row.path, inverse, module);
    assert.equal(normalized, original, `complete inverse removeComments output:${row.path}:${label}`);
    const mapping = mappedActualOutput(row.path, original, actualText, routeMap);
    const stem = `emit/${String(index + 1).padStart(3, '0')}-${label}`;
    addOutput(stem + '-before.js', original); addOutput(stem + '-actual.js', actualText); addOutput(stem + '-inverse.js', normalized);
    if (label === 'esnext') assert.deepEqual(staticEdges(row.path, actualText).map(folded), staticEdges(row.path, original).map(folded), `folded ordered original value edges:${row.path}`);
    emitted.push({ module: label, originalSHA256: sha(original), actualSHA256: sha(actualText), inverseSHA256: sha(normalized), actualRawSame: actualText === original, inverseRawSame: true, actualNormalization: mapping });
  }
  programs.push({ path: row.path, beforeSHA256: row.beforeSHA256, afterSHA256: row.afterSHA256, exactEdits: row.edits.length, wholeForwardInverse: true, wholeTypedTokensAndNodeArrays: true, allModuleBindingsAndOrderUnchangedExceptDeclaredRoutes: true, outputs: emitted });
}
assert.equal(editCount, 138);
const facets = [];
for (const [i, row] of candidate.publicFacets.entries()) {
  const text = row.action === 'new-bounded-public-facet' ? overlay.get(row.publicPath) : row.source;
  const sf = parse(row.publicPath, text), collected = [];
  for (const node of sf.statements) {
    assert(ts.isExportDeclaration(node) && node.moduleSpecifier && ts.isStringLiteral(node.moduleSpecifier) && node.exportClause && ts.isNamedExports(node.exportClause), `only named reexports:${row.publicPath}`);
    assert.equal(resolveEdge(row.publicPath, node.moduleSpecifier.text), row.target, `single original target:${row.publicPath}`);
    for (const item of node.exportClause.elements) {
      assert(!item.propertyName, `no new alias:${row.publicPath}`);
      collected.push({ name: item.name.text, typeOnly: node.isTypeOnly || item.isTypeOnly });
    }
  }
  if (row.action === 'new-bounded-public-facet') assert.deepEqual(collected.sort((a,b) => a.name.localeCompare(b.name)), [...row.symbols].sort((a,b) => a.name.localeCompare(b.name)));
  else for (const s of row.symbols) assert(collected.some((x) => x.name === s.name && x.typeOnly === s.typeOnly));
  const es = emit(row.publicPath, text, ts.ModuleKind.ESNext), cjs = emit(row.publicPath, text, ts.ModuleKind.CommonJS);
  assert.deepEqual(staticEdges(row.publicPath, es), [row.target], `one emitted runtime dependency:${row.publicPath}`);
  addOutput(`facets/${String(i + 1).padStart(2, '0')}-esnext.js`, es);
  addOutput(`facets/${String(i + 1).padStart(2, '0')}-commonjs.js`, cjs);
  facets.push({ path: row.publicPath, originalTarget: row.target, action: row.action, necessaryExports: row.symbols, actualPublicExports: collected, onlyNamedReexports: true, exactlyOneOriginalRuntimeDependency: true });
}
// 固定 Git 的其它模块不作候选变更；类型 checker 只用于导航实际别名终点，不获取类型诊断或执行源码。
const absolute = (file) => path.resolve(repo, file);
const relative = (file) => path.relative(repo, path.resolve(file)).split(path.sep).join('/');
const installed = (file) => path.resolve(file).split(path.sep).includes('node_modules');
const publicFixed = (p) => allTracked.has(p) && /\.(?:[cm]?tsx?|json)$/.test(p) && !p.startsWith('docs/history/');
function makeHost(useOverlay, options) {
  const host = ts.createCompilerHost(options, true);
  host.fileExists = (file) => {
    const p = relative(file);
    return (useOverlay && overlay.has(p)) || publicFixed(p) || (installed(file) && ts.sys.fileExists(file));
  };
  host.readFile = (file) => {
    const p = relative(file);
    if (useOverlay && overlay.has(p)) return overlay.get(p);
    if (publicFixed(p)) return gitBytes(p).toString('utf8');
    return installed(file) ? ts.sys.readFile(file) : undefined;
  };
  host.getSourceFile = (file, version) => { const text = host.readFile(file); return text === undefined ? undefined : ts.createSourceFile(file, text, version, true); };
  host.getCurrentDirectory = () => repo;
  host.writeFile = () => { throw new Error('compiler emit writing is forbidden'); };
  return host;
}
const fixedConfig = absolute('backend/tsconfig.tests.json');
const configHost = makeHost(false, {});
const config = ts.readConfigFile(fixedConfig, configHost.readFile); assert(!config.error);
const parsed = ts.parseJsonConfigFileContent(config.config, { ...ts.sys, fileExists: configHost.fileExists, readFile: configHost.readFile }, absolute('backend'), { noEmit: true }, fixedConfig);
assert.equal(parsed.errors.length, 0, 'fixed config parse');
const compilerOptions = { ...parsed.options, noEmit: true };
const oldProgram = ts.createProgram(candidate.files.map((r) => absolute(r.path)), compilerOptions, makeHost(false, compilerOptions));
const newProgram = ts.createProgram([...overlay.keys()].map(absolute), compilerOptions, makeHost(true, compilerOptions));
const oldChecker = oldProgram.getTypeChecker(), newChecker = newProgram.getTypeChecker();
function ultimate(checker, node) {
  let symbol = checker.getSymbolAtLocation(node); assert(symbol, `binding symbol:${node.getText()}`);
  const seen = new Set();
  while (symbol.flags & ts.SymbolFlags.Alias) { assert(!seen.has(symbol)); seen.add(symbol); symbol = checker.getAliasedSymbol(symbol); }
  assert(symbol.declarations?.length, `ultimate declaration:${node.getText()}`);
  return symbol.declarations.map((declaration) => ({
    path: relative(declaration.getSourceFile().fileName), kind: ts.SyntaxKind[declaration.kind],
    textSHA256: sha(declaration.getText(declaration.getSourceFile())),
    completePrinterSHA256: sha(printer.printNode(ts.EmitHint.Unspecified, declaration, declaration.getSourceFile())),
  }));
}
const bindingRows = [];
for (const row of candidate.files) {
  const a = oldProgram.getSourceFile(absolute(row.path)), b = newProgram.getSourceFile(absolute(row.path)); assert(a && b);
  const left = bindingReferences(a), right = bindingReferences(b);
  for (const edit of row.edits) {
    const at = left.findIndex((r) => r.line === edit.diagnosticLine && r.specifier === edit.before);
    assert(at >= 0); const oldRef = left[at], newRef = right[at];
    assert.equal(newRef.specifier, edit.after); assert.deepEqual(oldRef.binding, newRef.binding);
    assert.equal(oldRef.sites.length, newRef.sites.length);
    const symbols = [];
    oldRef.sites.forEach((site, i) => {
      const other = newRef.sites[i]; assert.equal(other.name, site.name);
      const oldDeclaration = ultimate(oldChecker, site.node), currentDeclaration = ultimate(newChecker, other.node);
      assert.deepEqual(currentDeclaration, oldDeclaration, `same actual ultimate declaration:${row.path}:${site.name}`);
      symbols.push({ name: site.name, declarations: oldDeclaration }); actualBindings++;
    });
    assert(symbols.length, 'changed routes must have a named binding');
    bindingRows.push({ diagnosticId: edit.diagnosticId, path: row.path, originalLine: edit.diagnosticLine, before: edit.before, after: edit.after, originalBinding: edit.binding, actualSameUltimateSymbols: symbols });
  }
}
assert.equal(bindingRows.length, 138);
const facetBindings = [];
for (const row of candidate.publicFacets.filter((r) => r.action === 'new-bounded-public-facet')) {
  const sf = newProgram.getSourceFile(absolute(row.publicPath)); assert(sf);
  const checker = newChecker;
  for (const node of sf.statements) for (const element of node.exportClause.elements) {
    const declarations = ultimate(checker, element.name);
    // 部分原模块本来具名重导到真正 writer；公开入口继续到同一声明，而不强称声明就在第一目标叶中。
    const expected = bindingRows.flatMap((r) => r.actualSameUltimateSymbols).filter((s) => s.name === element.name.text && candidate.edgeRoutes.some((e) => e.newPublicTarget === row.publicPath && e.binding.symbols.some((n) => n.replace(/^(?:value|type):/, '').split('->')[0] === s.name)));
    assert(expected.some((s) => JSON.stringify(s.declarations) === JSON.stringify(declarations)), `facet ultimate needed by actual original caller:${row.publicPath}:${element.name.text}`);
    facetBindings.push({ publicPath: row.publicPath, exportedName: element.name.text, declarations });
  }
}
const foreignChanges = git('diff', '--name-only', expectedBase, '--', 'backend/src', 'packages').toString().trim().split('\n').filter(Boolean).filter((p) => !overlay.has(p));
const report = {
  decision: 'proved-within-declared-fixed-Git-overlay', baseCommit: expectedBase,
  inputs: Object.entries(inputLocks).map(([name, sha256]) => ({ path: path.join(bundle, name), sha256 })),
  actualSource: [...overlay].map(([file, text]) => ({ path: file, mode: allTracked.get(file)?.mode ?? '100644', sha256: sha(text), bytes: Buffer.byteLength(text) })),
  deleted: [], controls: before.controls, programs, facets, bindings: bindingRows, facetBindings,
  summary: { completeConsumerPrograms: 72, exactModuleLiteralEdits: 138, newPublicFacets: 36, existingPublicFacetReused: 1, capturedFixedGitPrograms: before.sources.length,
    cumulativeTypedNodesBothSides: typedNodes, cumulativeNodeArraysBothSides: arrays, cumulativeLeavesBothSides: leaves, cumulativeNoncommentTokensBothSides: tokens,
    completeInverseOutputs: 144, completeActualMappedOutputs: 144, actualFacetOutputs: 74, actualOriginalConsumerSymbolBindings: actualBindings, actualNewFacetSymbolBindings: facetBindings.length },
  graph: { basis: 'Per-consumer complete emitted ESNext static dependency sequence, new single-target named facets; existing pure deal facet folded on both sides',
    originalOrderedValueEdgesSameAfterSingleNodeFold: true, newSingleTargetNodes: 36, unchangedModelPrograms: 'All files outside this 108-source overlay are read from the same fixed Git; no global current-tree equivalence claim.',
    outsideOwnOverlayCurrentDiffPaths: foreignChanges, productionColdExecution: false, dynamicExecutionGraphProved: false },
  identity: { typescriptVersion: ts.version, typescriptPackageSHA256: sha(fs.readFileSync(path.join(repo, 'backend/node_modules/typescript/package.json'))),
    proofSHA256: sha(fs.readFileSync(__filename)), fixedGitBlobTextsActuallyRead: gitCache.size, fixedGitBlobReadDigest: sha(JSON.stringify([...gitCache].sort(([a],[b]) => a.localeCompare(b)).map(([p,b]) => [p,sha(b)]))) },
  outputMembers: members,
  limits: [
    'This is a finite mechanical/binding proof, not semantic type diagnostics, tests, architecture gate, or a production import.',
    'Actual JS contains new public module paths, exports and compiler namespace identifiers. Exact source inverse emits match; actual output normalization changes only parsed module literals and corresponding generated require-local Symbols.',
    'Single-node contraction preserves original ordered static dependency edges in the fixed Git overlay; it is not arbitrary CommonJS module namespace monkeypatch equivalence, a cold-run experiment or a proof of every dynamic dependency.',
    'Original owner functions/classes/objects and overload declarations are compared by full raw and printer SHA. This does not expand their accepted inputs, grants, writable capabilities or semantic guarantees.',
    'Parallel changes outside the owned overlay are listed, not silently included in the fixed Git proof. Root integration gates remain separate.',
  ],
};
// 所有源码、比较与声明核对成功后才产生独立输出；不覆盖首结果目录。
fs.mkdirSync(out, { recursive: false });
for (const [name, text] of outputs) { const file = path.join(out, name); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, text, { flag: 'wx' }); }
fs.writeFileSync(path.join(out, 'proof.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ decision: report.decision, baseCommit: expectedBase, summary: report.summary, graph: report.graph, reportPath: path.join(out, 'proof.json'), reportSHA256: sha(fs.readFileSync(path.join(out, 'proof.json'))) }));
