from pathlib import Path
import json,subprocess,hashlib,collections,posixpath,re,difflib
ROOT=Path('/home/hby/dev/AI-Werewolf-Arena'); OUT=Path('/tmp/awa-c47-dependency-public-boundaries')
BASE='7a85ad67ac808aab3e1d6d91078262a64382ca93'
RAW=Path('/tmp/awa-c47-7a85ad67/receipts/architecture-strict-attempt-1/stdout.raw')
def sh(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def dump(n,d): (OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def source(p):return git('show',BASE+':'+p).decode()
tracked={}
for ln in git('ls-tree','-r',BASE).decode().splitlines():
 m,p=ln.split('\t');mode,kind,blob=m.split();tracked[p]={'mode':mode,'blob':blob}
f=[x for x in json.loads(RAW.read_text())['failures'] if x['rule'].startswith('dependency.')]
# 公共边界由实际调用职责确定；每项新值出口只依赖原来的一个 owner，避免重聚合初始化。
specs={
 'animal-dream/authority':('wolf-team-ports','公开动物梦境对普通狼刀的既有阻断查询','输入为原 World；输出为原当夜阻断结果。只读本族现有权威，不能凭查询结果建立刀权或更换夜单元。'),
 'cupid/relation':('vote-ports','公开丘比特已建立关系的投票限制查询','输入为原 World、投票人和目标；输出为原禁止投票判定。关系付款、阵营与胜利归属仍在原 owner，不创建或撤销关系。'),
 'death-actions/death-abilities':('gift-gun-ports','公开赠枪原工具预检、授予与死亡生命周期的共同接口','输入为原校验上下文或原 World、玩家和枪实例参数；输出为原拒绝、授予实例或生命周期结果。授予和 first／finish 具有原写入，不以此将已付 pending 改成未付资格。'),
 'death-actions/death-action-policy':('policy-ports','公开原生死亡枪的配置与纯展示政策','输入为原角色死亡政策与配置值；输出为原 schema 配置贡献或原文案。该接口不授枪权、不读取实际库存，也不提前消费配置 getter。'),
 'death-actions/death-shot':('tool-ports','公开死亡枪工具规格、参数修复与预检贡献','输入为原工具候选和校验上下文；输出为原规格、修复结果或拒绝代码。规格和校验不扣枪、不产生死亡许可，实际付款由结算 owner 负责。'),
 'death-actions/gift-gun-death-hook':('gift-hook-ports','公开赠枪死亡钩子的原贡献对象','输入为原死亡波和钩子端口；输出为同一个钩子绑定。消费、已付 pending 与追加死亡仍由原 hook／生命周期 owner 完成，不增加另一份回执。'),
 'death-actions/native-death-gun-resources':('native-resource-ports','公开原生及已学习死亡枪的唯一资源接口','输入为原角色、库存引用及调用方已有查询端口；输出为原状态、工厂、reader 或武装结果。setter／arm 仍是实际写端口，reader 的裸查询和晚阵营 source 顺序归原 owner；不增加 schema 或第二库存。'),
 'death-actions/native-death-shot-settlement':('settlement-ports','公开原生死亡枪的完整异步结算接口','输入为原规则、库存和死亡行动端口；输出为原有序结算。await 后守卫、五处首付与已付 pending 的不同当前性仍在同一算法中，失败保留已写前缀。'),
 'debater/authority':('vote-ports','公开杠精辩论权限与投票阻断的既有权威查询','输入为原 World 和玩家参数；输出为原 authority 或投票阻断结果。返回 authority 保持原引用与能力面，不把本端口宣称为裁剪后的只读 DTO 或新许可。'),
 'demon-hunter/authority':('death-frame-ports','公开猎魔板子自爆提交与警徽审计 frame 接口','输入为原 World、玩家和原事件／回调；输出为原反噬提交、警徽可读断言或 frame。frame 是实际权威能力，写入、清理和审计的原顺序与异常前缀不由本端口包装。'),
 'fragrant-pair-seer/state':('pair-data-ports','公开觉醒预言家原 pair 状态的纯数据 reader','输入为原未知状态值；输出为原可读 pair 数据或拒绝。reader 的原字段访问／接受集合保持，不查询 World 或授予查验权限，也不提前严格化安装输入。'),
 'ghost-bride/authority':('wedding-ports','公开婚约对狼队、自爆与警徽的具体协作接口','输入为原 World、婚约成员和原操作参数；输出为原准备状态、成员查询、吞徽提交或吞徽状态。查询、知识与实际吞徽写入各保原政策，不把已付 chat／knife 统一按请求 envelope 撤回。'),
 'initial-identity/deal':('deal-ports','REUSE','原公开轻端口已有 initialIdentitySetupReady；本批只重定向调用方，不修改其任何出口或初始化依赖。'),
 'last-words/last-words-mechanism':('grant-ports','公开遗言政策授予的默认机制与上下文类型','输入为原死因、来源阶段和初始波上下文；输出为原默认单例及原类型绑定。默认实例仍只在原 getDefaultLastWordsMechanism 调用的首次空值分支惰性创建；本接口不替代真实发言窗口或开放死亡许可。'),
 'last-words/window':('window-ports','公开完整遗言行动窗口的原类绑定','输入为原 World、事件、构造依赖和日次；输出为同一窗口类。构造与第二日次读取仍由调用方在原表达式位置完成，许可 finally／领域完成与错误优先不在此重写。'),
 'night-abilities/abilities':('inventory-ports','公开普通夜能力唯一库存的查询、复制、安装与已付 metadata 命令','输入为原角色、能力实例、日期或已经准备的 payload；输出为原同引用视图或库存命令结果。commitPreparedNativeAbility 是受信已准备数据的实际安装接口，不新增 payload 验证；record／expire／retire 的写入和已付前缀不当作纯读或新行动许可。'),
 'night-abilities/ability-changes':('native-installation-ports','公开原生夜能力完整 payload 准备及安装接口','输入为原角色、kind、原状态及可选未付提交回调；输出保留原三参结果或受控拒绝。七种原准备政策和安装首写仍在同一 owner，已创建字典、回调异常与实际写入前缀不回滚。'),
 'night-abilities/ability-scope':('scope-ports','公开原夜能力原体捕获与未付资格接口','输入为原 World、角色、来源和夜号；输出为原 scope。scope 的纯 ownerCurrent／已付效果当前性与未付 isEligible 分别保持，不在公共出口新增统一退休、关窗或深层 DTO 校验。'),
 'night-abilities/night-ability-actors':('actor-query-ports','公开本夜能力演员查询的原绑定与类型契约','输入为原上下文上的本夜查询；输出为原绑定入口和查询类型。绑定只捕获原 World 并装配原查询闭包，不在绑定时枚举名单或能力；公开类型和绑定不复制实例、不执行阶段或授予新能力。'),
 'night-abilities/night-ability-grants':('grant-ports','公开夜能力授予的原资源命令','输入为原来源、接收人、kind 和已选参数；输出为原授予实例或错误。来源／目标资格、库存与通知先后仍由原 owner 执行，授予成功后的商人完成前缀不由本端口截断。'),
 'night-abilities/night-action-history':('history-ports','公开本人夜行动历史写入与幸运目标政策查询','输入为原角色、目标、日期与原事件端口；输出为原目标判定或本人历史写入。历史和库存当前许可独立，事件先后、重复读取与失败已写前缀保持，不构造第二日志。'),
 'night-abilities/recipient-ability-stage':('recipient-stage-ports','公开受赠夜能力的完整执行阶段与当夜提交记录','输入为原阶段上下文和原受赠来源；输出为原阶段执行及其提交记录。该 owner 保选择、预检、首付、后续效果和记录顺序，查询提交记录不等于新授行动权限。'),
 'nightmare/night-frame':('wolf-team-ports','公开梦魇对普通狼队刀权的既有阻断查询','输入为原 World；输出为原当夜恐惧对狼刀的阻断结果。仍由原 frame 复验 roster、原体与当前夜，不能仅凭布尔值绕过狼队自身资格。'),
 'radiant-eclipse/night-frame':('turn-ports','公开流光伯爵与蚀日侍女的原回合捕获接口','输入为原 World、夜号、角色及能力；输出为原捕获回合或原拒绝。保原体、库存与借用政策，不把未付回合和已付效果合成一个统一许可，也不加载其他 frame。'),
 'radiant-eclipse/shelter-state-slot':('shelter-slot-ports','公开庇护的完整受信状态槽契约','输入为调用方原已准备状态或原实例；输出为同一个 SHELTER_STATE_SLOT 对象。对象含 prepare／schema／install／allowedWrites／checkpoint／invalidations，确实包含受信写能力；原 prepare 与严格 reader 接受集合不同，不能伪称只读或完整行动校验。'),
 'scholar-mentor/night-frame':('wolf-team-ports','公开学者导师对普通狼队刀权的既有阻断查询','输入为原 World；输出为原当夜导师政策阻断结果。完整 bonus 与已付效果生命周期仍归原 frame，不新增狼阵营、成员知识或刀权推导。'),
 'self-destruct/commit':('selection-ports','公开自爆候选的完整领域提交接口','输入为原 World、候选、事件和当前性；输出为原提交结果。首付、反噬与婚约／猎魔特殊前缀保持原顺序，不把候选预检当作已经完成或新增清理事务。'),
 'sheriff/badge-choice':('choice-ports','公开死亡持徽选择的完整请求与提交接口','输入为原警徽、死亡许可、provider 和构造端口；输出为原转移或销毁结果。F02 每请求完成、组件／特殊 frame 全付款点及 finally 原错误优先仍由同一 choice owner 负责。'),
 'sheriff/badge':('badge-ports','公开警徽唯一写方及原接收资格查询','输入为原 World、原持徽者、目标及事件；输出为原警长查询、资格或转移／销毁提交。票重与警徽按原字段序逐项写入；特殊 frame 与事实失败不伪装成原子回滚。'),
 'sheriff/election':('election-ports','公开警长竞选的完整阶段入口','输入为原阶段上下文；输出为原竞选和授徽结果。参选／退水／票与平票处理仍由原 owner 执行，provider 候选不在此被重新解释为事务完成。'),
 'sheriff/speaking-order':('speaking-order-ports','公开警长方向选择与发言名单构造接口','输入为原警徽、存活名单和阶段端口；输出为原方向候选处理或原发言顺序。构造名单与选择方向不授票权，原 null／skip、重复读取和失败时点保持。'),
 'sheriff/tool-specs':('tool-ports','公开警长竞选与方向工具的原规格贡献','输入为装配调用；输出为同一工具规格绑定。规格是提示与结构契约，不授警徽、投票或执行许可；不提前执行候选或注册第二份工具。'),
 'sheriff/validation-rules':('validation-ports','公开警长工具的原预检规则贡献','输入为原工具校验上下文；输出为同一规则绑定和原拒绝结果。预检不扣资源或授予 scope，真实竞选与警徽写入仍归各领域 owner。'),
 'wall-notes/authority':('author-ports','公开留言墙原作者授权的具体查询','输入为原 World、作者及请求参数；输出保留原授权对象或拒绝。作者身份、便签库存与各作者独立回合仍由本族权威保存，不复制授权或把可写工具提示当库存。'),
 'wall-notes/window':('window-ports','公开留言墙完整逐作者请求窗口的原类绑定','输入为原 World、日次与构造／事件端口；输出为同一个窗口类。每位作者独立完成，已发表事实不倒查 closed 请求，finally 逐作者 false 清理及原异常优先保持。'),
 'witch/policies':('potion-policy-ports','公开原生双药同夜第二次用药的原政策查询','输入为原能力实例和夜号；输出为原 nativePotionSecondTurn 判定。只承接既有 uses／政策与回合关闭字段读取，不授用药权限、不扣瓶或把受赠毒混成原生双药。'),
 'wolf-team/permissions':('action-ports','公开狼聊参与人、狼刀持有人与狼队事件受众接口','输入为原 World、Catalog 和原事件参数；输出为原名单或事件。知识、聊天、刀权仍分别推导，当前 Camp 或历史成员身份不自动授执行许可；各角色阻断查询仍由原权限 owner 按原序调用。'),
}
assert len(specs)==37
rows=[];facets=[];snapshots={};editsBy=collections.defaultdict(list);groups=collections.defaultdict(list)
for x in f: groups[x['target']].append(x)
for target,edges in sorted(groups.items()):
 key=target[len('backend/src/features/'):-3];leaf,head,detail=specs[key]
 facet=posixpath.join(posixpath.dirname(target),leaf+'.ts')
 ns=collections.OrderedDict()
 for e in edges:
  b=json.loads(e['binding'])
  for sym in b['symbols']:
   s=re.sub(r'^(value|type):','',sym).split('->')[0]
   assert s not in ['*','namespace:*','default','side-effect']
   typ=b['typeOnly'] or sym.startswith('type:')
   ns[s]=ns.get(s,True) and typ
 # 实际声明类型只作具名 type 重导；调用方原 import mode 不改。
 for s in ['NightAbility','NightAbilityReadView','NightAbilityActorQuery','LastWordsGrantContext']:
  if s in ns:ns[s]=True
 old=source(target);snapshots[target]={'path':target,**tracked[target],'sha256':sh(old.encode()),'bytes':len(old.encode()),'text':old}
 if head=='REUSE':
  public=source(facet);snapshots[facet]={'path':facet,**tracked[facet],'sha256':sh(public.encode()),'bytes':len(public.encode()),'text':public}
  record={'target':target,'publicPath':facet,'action':'reuse-existing-public-api','symbols':[{'name':n,'typeOnly':t} for n,t in sorted(ns.items())],'requiredEdges':len(edges),'source':public,'sha256':sh(public.encode()),'policy':detail}
 else:
  assert facet not in tracked,facet
  rel='./'+posixpath.basename(target)[:-3]
  vals=sorted(n for n,t in ns.items() if not t);types=sorted(n for n,t in ns.items() if t)
  public='/**\n * 负责'+head+'。\n * '+detail+'\n * 本入口只具名重导原单一模块，保留函数、类、对象及类型的原声明绑定；不包装调用或重新注册。\n * 顶层只加载原模块及其原依赖，不聚合其他 owner；调用方仍在原 callee／参数位置读取，原错误和已写前缀照常传播。\n */\n'
  if types:public+='export type {\n'+''.join('  '+n+',\n' for n in types)+'} from "'+rel+'";\n'
  if vals:public+='export {\n'+''.join('  '+n+',\n' for n in vals)+'} from "'+rel+'";\n'
  record={'target':target,'publicPath':facet,'action':'new-bounded-public-facet','symbols':[{'name':n,'typeOnly':t} for n,t in sorted(ns.items())],'requiredEdges':len(edges),'source':public,'sha256':sh(public.encode()),'bytes':len(public.encode()),'mode':'100644','expectedAbsentAtBase':True,'runtimeDependencyExactly':[target] if vals else [],'typeDependencyExactly':[target] if types else [],'policy':detail}
 facets.append(record)
 for e in edges:
  p=e['path'];text=source(p)
  snapshots[p]={'path':p,**tracked[p],'sha256':sh(text.encode()),'bytes':len(text.encode()),'text':text}
  start=sum(len(v) for v in text.splitlines(keepends=True)[:e['line']-1])
  # 诊断给出完整 import/export/type 节点首行；只定位该节点内原 literal，不全局替换。
  pat=re.compile(r'(["\'])'+re.escape(e['specifier'])+r'\1')
  m=pat.search(text,start)
  assert m is not None and text[start:m.start()].count('\n')<25,(p,e)
  new=posixpath.relpath(facet[:-3],posixpath.dirname(p))
  if not new.startswith('.'):new='./'+new
  edit={'start':m.start()+1,'end':m.end()-1,'before':e['specifier'],'after':new,'diagnosticId':e['id'],'diagnosticLine':e['line'],'targetBefore':target,'targetAfter':facet,'binding':json.loads(e['binding'])}
  editsBy[p].append(edit)
  rows.append({'id':e['id'],'rule':e['rule'],'source':p,'line':e['line'],'binding':json.loads(e['binding']),'before':e['specifier'],'after':new,'oldPhysicalTarget':target,'newPublicTarget':facet,'ultimateDeclarationPolicy':'same original declaration via one exact named re-export; no wrapper'})
files=[];diff=[]
for p,edits in sorted(editsBy.items()):
 before=snapshots[p]['text'];after=before
 for a,b in zip(sorted(edits,key=lambda e:e['start']),sorted(edits,key=lambda e:e['start'])[1:]):assert a['end']<=b['start'],p
 for e in sorted(edits,key=lambda e:e['start'],reverse=True):
  assert after[e['start']:e['end']]==e['before'];after=after[:e['start']]+e['after']+after[e['end']:]
 files.append({'path':p,'mode':tracked[p]['mode'],'beforeSHA256':sh(before.encode()),'afterSHA256':sh(after.encode()),'before':before,'after':after,'edits':sorted(edits,key=lambda e:e['start'])})
 diff.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
for record in facets:
 if record['action'].startswith('new-'):
  diff.extend(difflib.unified_diff([],record['source'].splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+record['publicPath']))
controls=[]
for p in ['backend/src/domain/world.ts','backend/src/domain/request-lease.ts','backend/src/rulesets/roles/builtin-contributions.ts','backend/src/recording/verification/assembly.ts','tooling/refactor/architecture/dependency-check.ts']:
 t=source(p);controls.append({'path':p,**tracked[p],'sha256':sh(t.encode()),'bytes':len(t.encode())})
dump('before.json',{'baseCommit':BASE,'capture':'fixed Git blobs, no working-tree source mutation','sources':list(snapshots.values()),'newAbsence':[r['publicPath'] for r in facets if r['action'].startswith('new-')],'controls':controls})
dump('candidate.json',{'baseCommit':BASE,'preparedOnly':True,'files':files,'publicFacets':facets,'edgeRoutes':rows,'controls':controls,'checksExecuted':False})
(OUT/'candidate.diff').write_text(''.join(diff))
dump('summary.json',{'sourceBase':BASE,'diagnostics':len(f),'rules':dict(collections.Counter(x['rule'] for x in f)),'consumersChanged':len(files),'originalPhysicalTargets':len(groups),'newFacets':sum(r['action'].startswith('new-') for r in facets),'reusedPublicFacets':[r['publicPath'] for r in facets if r['action']=='reuse-existing-public-api'],'publicExportSymbols':sum(len(r['symbols']) for r in facets),'changedPaths':len(files)+sum(r['action'].startswith('new-') for r in facets),'beforeCapturedPrograms':len(snapshots),'sourceReady':False,'repositoryWritten':False,'checkerPolicyChanged':False,'validationExecuted':False,'raw':{'path':str(RAW),'sha256':sh(RAW.read_bytes()),'bytes':RAW.stat().st_size}})
print(json.dumps(json.loads((OUT/'summary.json').read_text()),ensure_ascii=False,indent=2))
