# C47 首轮 138 条实际依赖边：有限公共边界候选

## 状态和输入

仅 TMP 完整候选；未应用、未执行 TypeScript／checker／业务／emit。固定源为 `7a85ad67ac808aab3e1d6d91078262a64382ca93`。C47 原 stdout 保持，不重写149首红：本候选只处理138依赖，11职责头由另一作者单独处理。

原始138边落在72个调用程序、37个原目标；共同 night-abilities 与 death-actions 已是完整数据／运行 owner，不迁回中央 Role 分派。本候选公布它们的真实外部 API，不重拆算法。36新轻入口＋1已存在 deal-ports；72 consumer 仅改138个原模块字面，合108候选源。

## 为什么这些是公共契约

- 每入口按实际跨机制职责列有限具名 symbol；无 star／default／namespace 公共扩散，无新函数、类或注册表。不是将旧实现文件改名加后缀。原37实现文件保有完整算法与唯一存储，现有同族内部消费可继续读实现。
- 只暴露本次真实 consumer 所需的83个新增出口位置（加已有deal入口1个引用，共84个 target/symbol）；公开面中含4个 type-only 声明，其余是实际函数／类／对象，不把类型或查询当许可。
- `inventory-ports` 明确含受信 `commitPreparedNativeAbility` 和 metadata 写命令，不能当任意输入完整校验。`shelter-slot-ports` 的原对象确含 `allowedWrites`／prepare／invalidations，不能标只读。
- 查询/窗口/政策按不同原module拆公开面。不会因为现有重 ports 提供部分同名函数就把 authority 查询接到 night-lifecycle/setup/death-wave 的新聚合。
- wolf-team 的五种本族阻断/成员/准备查询仍各保实际政策；原不同ref/value、知识/刀权与已付关系没有统一强化。

## 原初始化、调用和异常边界

- 每新入口的运行 export 仅到原单一目标；type export同目标但不增加值依赖。调用方原 import/export/type-query 顺序、局部 alias、模式和全部非模块字面不变。原表达式的 receiver、callee、getter、参数、await、首付、记录、facts、finally 不改。
- 构想的图证据是将新增单依赖节点折回原边，比较原节点的有序静态依赖和 DFS；尚未运行该证明，不能将设计属性说成实际冷执行或所有动态模块图已验收。
- 原依赖自身的时钟捕获、WeakMap／Map／单例／循环保同物理owner，新增入口没有时钟、调用、注册或存储。LastWords 默认实例仍原 getter 首次调用惰性创建，不是 import 时创建。
- actual emitted JS 与模块图必然增加公开节点；外部通过 CommonJS module namespace 猴补、任意反射替换导出对象不是这里承诺的整环境等价。原新公开 API 和 sourceHash 变化必须作为C47修复后候选身份登记。
- `engine/index.ts` 仅将原同名警徽 named export 接到有限端口，根 API 名称和位置不增 star；旧37内部实现不在本候选退休。

## 完整边界清单

| 原唯一 owner | 公共面 | 类型／值出口 | 对应首红边 |
| --- | --- | --- | --- |
| `backend/src/features/animal-dream/authority.ts` | `backend/src/features/animal-dream/wolf-team-ports.ts` | `animalPackKnifeBlocked` | 1 |
| `backend/src/features/cupid/relation.ts` | `backend/src/features/cupid/vote-ports.ts` | `prohibitsLoversVote` | 1 |
| `backend/src/features/death-actions/death-abilities.ts` | `backend/src/features/death-actions/gift-gun-ports.ts` | `finishDeathGuns`, `firstDeathGuns`, `grantDeathGun`, `validateGiftGun` | 4 |
| `backend/src/features/death-actions/death-action-policy.ts` | `backend/src/features/death-actions/policy-ports.ts` | `deathActionConfiguration`, `renderDeathActionPolicy` | 2 |
| `backend/src/features/death-actions/death-shot.ts` | `backend/src/features/death-actions/tool-ports.ts` | `DEATH_SHOT_REPAIR`, `DEATH_SHOT_TOOL_SPECS`, `validateDeathShot` | 5 |
| `backend/src/features/death-actions/gift-gun-death-hook.ts` | `backend/src/features/death-actions/gift-hook-ports.ts` | `giftGunDeathHook` | 1 |
| `backend/src/features/death-actions/native-death-gun-resources.ts` | `backend/src/features/death-actions/native-resource-ports.ts` | `armAwakenedNativeGun`, `armMechanicalNativeGun`, `createAwakenedGunReader`, `createHunterState`, `createLearnedNativeGun`, `createMechanicalGunReader`, `createWolfKingState`, `getHunterState`, `getWolfKingState`, `setHunterState`, `setWolfKingState` | 9 |
| `backend/src/features/death-actions/native-death-shot-settlement.ts` | `backend/src/features/death-actions/settlement-ports.ts` | `resolveNativeDeathShots` | 4 |
| `backend/src/features/debater/authority.ts` | `backend/src/features/debater/vote-ports.ts` | `debateAuthority`, `debateVoteBlocked` | 2 |
| `backend/src/features/demon-hunter/authority.ts` | `backend/src/features/demon-hunter/death-frame-ports.ts` | `assertDemonBadgeReadable`, `commitDemonRedMoonBlast`, `openDemonBadgeFrame` | 2 |
| `backend/src/features/fragrant-pair-seer/state.ts` | `backend/src/features/fragrant-pair-seer/pair-data-ports.ts` | `readPairSeerState` | 1 |
| `backend/src/features/ghost-bride/authority.ts` | `backend/src/features/ghost-bride/wedding-ports.ts` | `ghostBrideReady`, `swallowWeddingBadges`, `weddingBadgeSwallowed`, `weddingMember`, `weddingSetup` | 4 |
| `backend/src/features/initial-identity/deal.ts` | `backend/src/features/initial-identity/deal-ports.ts`（已有，零改） | `initialIdentitySetupReady` | 1 |
| `backend/src/features/last-words/last-words-mechanism.ts` | `backend/src/features/last-words/grant-ports.ts` | type `LastWordsGrantContext`, `getDefaultLastWordsMechanism` | 2 |
| `backend/src/features/last-words/window.ts` | `backend/src/features/last-words/window-ports.ts` | `LastWordsWindow` | 1 |
| `backend/src/features/night-abilities/abilities.ts` | `backend/src/features/night-abilities/inventory-ports.ts` | type `NightAbility`, type `NightAbilityReadView`, `abilityStatus`, `activeNightAbility`, `allNightAbilities`, `commitPreparedNativeAbility`, `copyAbilityData`, `expireLuckyAbilitiesOnDeath`, `findNightAbility`, `initializeNightAbilityInventory`, `recordNightAbilityUse`, `retireBorrowedNightAbility`, `retiredNightAbilityIds`, `setNightAbilityStartDay` | 56 |
| `backend/src/features/night-abilities/ability-changes.ts` | `backend/src/features/night-abilities/native-installation-ports.ts` | `installNativeAbility` | 3 |
| `backend/src/features/night-abilities/ability-scope.ts` | `backend/src/features/night-abilities/scope-ports.ts` | `captureNightAbilityScope` | 7 |
| `backend/src/features/night-abilities/night-ability-actors.ts` | `backend/src/features/night-abilities/actor-query-ports.ts` | type `NightAbilityActorQuery`, `bindNightAbilityActorQuery` | 2 |
| `backend/src/features/night-abilities/night-ability-grants.ts` | `backend/src/features/night-abilities/grant-ports.ts` | `grantNightAbility` | 3 |
| `backend/src/features/night-abilities/night-action-history.ts` | `backend/src/features/night-abilities/history-ports.ts` | `luckyTargetAllowed`, `recordOwnNightAction` | 6 |
| `backend/src/features/night-abilities/recipient-ability-stage.ts` | `backend/src/features/night-abilities/recipient-stage-ports.ts` | `hasRecipientNightCommit`, `recipientAbilityStage`, `recordRecipientNightCommit` | 2 |
| `backend/src/features/nightmare/night-frame.ts` | `backend/src/features/nightmare/wolf-team-ports.ts` | `nightmareKnifeBlocked` | 1 |
| `backend/src/features/radiant-eclipse/night-frame.ts` | `backend/src/features/radiant-eclipse/turn-ports.ts` | `captureRadiantTurn` | 1 |
| `backend/src/features/radiant-eclipse/shelter-state-slot.ts` | `backend/src/features/radiant-eclipse/shelter-slot-ports.ts` | `SHELTER_STATE_SLOT` | 2 |
| `backend/src/features/scholar-mentor/night-frame.ts` | `backend/src/features/scholar-mentor/wolf-team-ports.ts` | `scholarMentorPackBlocked` | 1 |
| `backend/src/features/self-destruct/commit.ts` | `backend/src/features/self-destruct/selection-ports.ts` | `commitSelfDestructSelection` | 1 |
| `backend/src/features/sheriff/badge-choice.ts` | `backend/src/features/sheriff/choice-ports.ts` | `resolveSheriffBadge` | 1 |
| `backend/src/features/sheriff/badge.ts` | `backend/src/features/sheriff/badge-ports.ts` | `badgeSuccessorEligible`, `commitSheriffBadgeChoice`, `findSheriffId`, `transferOrDestroySheriffBadge` | 4 |
| `backend/src/features/sheriff/election.ts` | `backend/src/features/sheriff/election-ports.ts` | `electSheriffIfNeeded` | 1 |
| `backend/src/features/sheriff/speaking-order.ts` | `backend/src/features/sheriff/speaking-order-ports.ts` | `buildSpeakerOrder`, `chooseSpeakerDirection` | 1 |
| `backend/src/features/sheriff/tool-specs.ts` | `backend/src/features/sheriff/tool-ports.ts` | `SHERIFF_TOOL_SPECS` | 1 |
| `backend/src/features/sheriff/validation-rules.ts` | `backend/src/features/sheriff/validation-ports.ts` | `SHERIFF_VALIDATION_RULES` | 1 |
| `backend/src/features/wall-notes/authority.ts` | `backend/src/features/wall-notes/author-ports.ts` | `authorizedWallAuthor` | 1 |
| `backend/src/features/wall-notes/window.ts` | `backend/src/features/wall-notes/window-ports.ts` | `WallNotesWindow` | 1 |
| `backend/src/features/witch/policies.ts` | `backend/src/features/witch/potion-policy-ports.ts` | `nativePotionSecondTurn` | 1 |
| `backend/src/features/wolf-team/permissions.ts` | `backend/src/features/wolf-team/action-ports.ts` | `wolfChatParticipants`, `wolfKnifeHolders`, `wolfTeamEvent` | 1 |

## 文件和后继执行边界

- `before.json`：99个实际Git程序的完整文本／mode／blob／SHA，以及36真实新路径 absence 与5稳定控制。原目标也可能同时是某另一边的调用方，不能把它们冒末完全不改的 controls。
- `candidate.json`：72完整before/after和138坐标 edits、37公开面（36新/1复用）、138诊断ID→路线→原binding。`candidate.diff` 是全部108路径的可审差分。
- `prepare-candidate.py` 仅用stdlib读取固定Git/原JSON并生成TMP，没有执行仓库TS、checker或产品。这里的Python坐标断言只保证候选构造，非编译／业务／图验收。
- Root应用前应对完整base/mode/SHA与newabsence预检；若并行头注释涉及同源，只合精确comment delta，不whole覆盖。当前已知另一作者6头与本72consumer无交集（以Root最终合并清单为准）。
- 只需Root裁定后准备/执行实际 consumer 全文精确逆、公共symbol ultimate原声明、原API次序及单节点静态图折回证明；不能因为文件名通过检查器就宣称证明完成。
- 后续Root选真实修复候选运行失败架构根；本包未运行旧业务、类型、emit或门禁，也不提前改变C48矩阵状态。
