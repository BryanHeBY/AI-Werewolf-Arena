# 有限机械证明工具（仅准备）

`prove.cjs` 尚未执行。Root 先审工具，再应用本批候选，最后可唯一执行：

```sh
bun --no-env-file /tmp/awa-c47-dependency-public-boundaries/prove.cjs --repo /home/hby/dev/AI-Werewolf-Arena --bundle /tmp/awa-c47-dependency-public-boundaries --out /tmp/awa-c47-dependency-public-boundaries/proof-first
```

输出目录必须不存在；若首执行失败，保脚本／完整 stdout／真实 exit，不覆盖已有结果或自动重试。工具不写源、不运行业务或架构门禁、不获取 semantic diagnostics，不补造测试。

## 精确输入和阶段

- 脚本内锁定 `before.json`／`candidate.json` 实际 SHA，固定 Git 为 `7a85ad67ac808aab3e1d6d91078262a64382ca93`。
- 99 个完整前态逐项核 fixed Git mode／blob／SHA／bytes／text，36新路径必须原 Git absent，5 controls 当前 mode／SHA 必须同原。
- 72 个当前 consumer 必须恰为各冻结 `after`；36 新入口恰为冻结完整源。首准备候选全稿保存到 `first-candidate-snapshot`，四个新入口只后继中文精度修订；72程序／138路线／37出口集合不变。
- 其它作者的并行工作不被 source host 暗中读取为“固定前态”；workspace 包的 node_modules 链接先 realpath 回仓库物理路径，再读同一 fixed Git 或本108源 overlay，包括 package.json。真正外部 installed 依赖仍读实际磁盘物理输入，逐项记 SHA／bytes，不能称它们是 fixed Git。报告另列 owned 之外的已跟踪 diff；后续真正集成门禁仍检查实际新候选。

## 比较范围

1. 72完整 consumer 的138坐标 edit 正演／逆演；全部 typed AST、NodeArray（含 trailing comma）、叶文本和 scanner 非注释词项双侧比较。原无关语句、注释、机器字串和 directive 由完整 source inverse 保证。
2. ESNext／CommonJS 各保存完整 before、actual、inverse 输出，共432个成员；仅138源模块字面逆回原文后，144份 removeComments 完整输出与原相同。
3. 另对144份实际输出做严格对照：ES 模块文字／require 文字回原；CJS 编译器生成的 namespace 名字按相应 require 的局部 Symbol 回原（可能包括叶名冲突影响的另一 namespace），不按任意业务 identifier 字串全局替换。规范化后完整 raw 必须相同。不能把此结果说成 actual JS 本来字节相同。
4. 36新入口实际 AST 只能含到原单一 target 的具名 `export type`／具名 value export，无包装、调用、变量、star、default 或新的局部 alias；集合精确等于候选所需出口。已有deal入口原文保，不缩改其既有21出口。
5. 两个虚拟 TypeScript Program 仅导航声明，不运行类型诊断／产品；逐138原binding确认 kind／typeOnly／原symbol集合与局部程序保持，并比较通过公共面解析到的实际 ultimate 全部声明。用完整 declaration raw SHA 和 removeComments printer SHA，不只名字或第一个 overload。
6. 新入口的83个导出位置也逐个核实际ultimate，与该入口对应的原consumer绑定相同；已有deal入口的必要1个绑定由原caller证明。
7. 保存37个入口各两份真实输出，共74份。每个值入口只有到原目标的1条 emitted ESNext 顶层依赖。逐72consumer完整有序静态值依赖，经单节点折回与原相同；已存在的纯deal入口在两侧折回。

计数为双侧累计，不称 distinct AST nodes。输出 `proof.json` 记真实读取的 Git blobs／工具与 TypeScript身份、所有成员 SHA／bytes、实际 current owned SHA／mode、输出和声明对应。不得从该有限证明推断任意 CommonJS monkeypatch、动态依赖图或实际冷启动等价。

## 尚未执行的项目

此交接没有 proof／类型／业务／head／strict 的新结果。Root 读取、应用、唯一首执行之后再登记真实命令与收据。原 C47 strict 149 首红保持：这里只准备138依赖边修复，11头及其它集成输入另有独立来源。

## 首工具静态 host 精度后继

原 cf7d4b57 完整脚本、命令说明和 HANDOFF 保在 `proof-host-first-snapshot/`。仅修 TypeScript host 的 workspace symlink 选源及准确报告边界；候选 ab2abca6、99前态和实际108源不改。当前工具仍未执行。
