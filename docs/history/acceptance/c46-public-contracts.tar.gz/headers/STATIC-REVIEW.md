# C47 首次 strict 六源中文职责头候选静态复核

## 状态与写权

本候选基于实际 Git `7a85ad67ac808aab3e1d6d91078262a64382ca93` 六源；捕获时六份工作树原文与该 Git 全字节相同。仅在 TMP 保存完整 before、candidate 和每源一条首头 exact delta。没有仓库写入，没有执行解析器、编译、门禁、测试、生产导入或该候选证明。

C47 首次 strict 的 149 条诊断由 Root 实际执行产生，其中此批只回应 11 条职责头形状诊断／6 源。其余 138 依赖边由另一作者处理。本批不改分类规则或豁免，不预报重检通过。

## 逐源真实语义

| 源 | 原缺项与补充 | 实际依据与限界 |
| --- | --- | --- |
| console-presenter | 补副作用、期限和取消职责 | 同步调用传入 log／console。ACP 缓冲按玩家、类别、messageId 分段，flush 只输出尾段和清工具显示 Map。game-runner／player-agent-factory 管理请求预算、关闭与 observer.flush；此处没有 AbortSignal、timer 或会话关闭。日志／getter 异常不被统一 catch，已经输出的内容不回滚。 |
| session-file-store | 补期限与取消边界，并明确文件副作用 | initialize 显式 mkdir；writeAtomic 顺序 writeFile→rename。没有取消或超时 API；不得把取消上层等待说成撤销已发起的 fs Promise。JSON.stringify 保持位于宽 write catch 外；严格写入保原异常。 |
| agent-exports | 补实际 input，并使首段明确职责 | 四条原 star reexport 完整保留。输入是这些模块公开绑定，不假设叶模块无顶层初始化，不把此入口当会话／期限 owner。 |
| audit-agent-exports | 补实际 input | 六条原 reexport 保顺序，契约、工厂、SDK／ACP 执行器、MCP 控制和工具协议仍各持自己的实现。入口不新建任何审计任务。 |
| game-api | 补首职责、input 和 responsibility | 三条原 star clause 保留，原 engine index 还真实导出 Sheriff badge 及各 pipelines；本补丁不声称删去叶模块求值或注册副作用，只区分聚合入口本身不执行对局。 |
| session/lifecycle | 补真实 invariant | flushChain 串行追加；finalize 的 ??= 复用已存入的 Promise，包含异步拒绝。仅说已存入，避免把 persist 同步抛错说成已缓存。closing／closed 角色和 markClosed 管理器时点不改，必需失败账本不被本 owner 清空。 |

已有内部注释已覆盖 Unicode 代理对分段、工具状态去重、JSON 编码与 catch 范围、临时文件非事务前缀、closing 队列等待及首次 Promise 复用。本批没有为了数量增添逐行说明或修改这些原注释。

## 应用与后继验证

Root 应在未来实际来源上按每条 `before` 唯一匹配替换首头，勿用完整 candidate 覆盖另一作者的 import 修复。若同源后继 route 已改，应单独绑定该阶段和注释桥；不能称候选 wholefile 与旧 Git 程序全字节相同。

所附 candidate 仅静态人工复核。后继全文 AST／NodeArray／非注释叶／受保护 JSDoc 和实际 ES／CJS 输出，以及六个失败头的有限重检，均由 Root 决定并唯一执行；本记录不冒这些结果。sourceHash 将随注释变化，严格身份仍按真实版本判断。
