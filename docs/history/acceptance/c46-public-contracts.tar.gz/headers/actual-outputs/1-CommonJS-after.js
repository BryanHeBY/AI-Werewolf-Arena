"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReplayFileStore = void 0;
const error_diagnostic_1 = require("../../utils/error-diagnostic");
const fs_1 = require("fs");
const path_1 = require("path");
class ReplayFileStore {
    sessionDir;
    locale;
    constructor(sessionDir, locale = "zh-CN") {
        this.sessionDir = sessionDir;
        this.locale = locale;
    }
    async initialize() {
        await fs_1.promises.mkdir(path_1.default.join(this.sessionDir, "players"), { recursive: true });
    }
    async writeJson(relativePath, data) {
        await this.write(relativePath, JSON.stringify(data, null, 2), "json");
    }
    async writeText(relativePath, data) {
        await this.write(relativePath, data, "text");
    }
    async writeJsonStrict(relativePath, data) {
        await this.writeAtomic(relativePath, JSON.stringify(data, null, 2));
    }
    async write(relativePath, content, kind) {
        try {
            await this.writeAtomic(relativePath, content);
        }
        catch (error) {
            console.warn(`[observability] write_${kind}_failed file=${relativePath} err=${(0, error_diagnostic_1.formatErrorDiagnostic)(error, this.locale)}`);
        }
    }
    async writeAtomic(relativePath, content) {
        const target = path_1.default.join(this.sessionDir, relativePath);
        const temporary = `${target}.tmp`;
        await fs_1.promises.writeFile(temporary, content, "utf-8");
        await fs_1.promises.rename(temporary, target);
    }
}
exports.ReplayFileStore = ReplayFileStore;
