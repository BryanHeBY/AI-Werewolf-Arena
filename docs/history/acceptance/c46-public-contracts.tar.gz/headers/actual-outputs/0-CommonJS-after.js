"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toChatLines = toChatLines;
exports.createConsoleLog = createConsoleLog;
exports.presentStreamEvents = presentStreamEvents;
exports.presentGameResult = presentGameResult;
exports.createAcpConsoleLogger = createAcpConsoleLogger;
const error_diagnostic_1 = require("../../utils/error-diagnostic");
const game_text_1 = require("@ai-werewolf-arena/game-text");
const game_presentation_1 = require("@ai-werewolf-arena/game-presentation");
const game_api_1 = require("../../engine/game-api");
const ansi_1 = require("../../utils/ansi");
function toChatLines(events, locale = "zh-CN") {
    const registry = (0, game_api_1.getDefaultScriptEventRenderRegistry)();
    return events.flatMap((event) => {
        const line = registry.toChatLine(event, locale);
        return line ? [line] : [];
    });
}
function createConsoleLog(color) {
    const enabled = (0, ansi_1.isAnsiEnabled)(color);
    return (text, tone = "info") => console.log((0, ansi_1.colorize)(text, tone, enabled));
}
function presentStreamEvents(events, printPrivateEvents, log, locale = "zh-CN") {
    const registry = (0, game_api_1.getDefaultScriptEventRenderRegistry)();
    for (const event of events) {
        for (const render of registry.toLiveRender(event, printPrivateEvents, locale)) {
            const tone = render.kind === "chat"
                ? "accent"
                : render.kind === "private"
                    ? "warn"
                    : render.kind === "action"
                        ? "info"
                        : render.kind === "god"
                            ? "god"
                            : "ok";
            log(render.text, tone);
        }
    }
}
function presentGameResult(input) {
    const { board, snapshot, events, timedOut, log } = input;
    log(`[run_game] done board=${board} gameOver=${snapshot.gameOver} day=${snapshot.day} winner=${snapshot.result?.winner ?? "none"} timedOut=${timedOut} · ${(0, game_text_1.text)(input.locale ?? "zh-CN", "runtime.done")}`, "ok");
    log(`[run_game] events=${events.length} · ${(0, game_text_1.text)(input.locale ?? "zh-CN", "runtime.event_count")}`, "info");
    if (snapshot.result) {
        const locale = input.locale ?? "zh-CN";
        log(`[result] ${(0, game_presentation_1.outcomeLabel)(snapshot.result.outcome, locale)} · ${(0, game_presentation_1.outcomeWinnersLabel)(snapshot.result.outcome, locale)} · ${(0, game_presentation_1.victoryPointLabel)(snapshot.result.decidedAt, locale)}`, "ok");
    }
    if (input.printAllEvents)
        console.log(JSON.stringify(events, null, 2));
    if (input.printChat && !input.streamEvents) {
        for (const line of toChatLines(events, input.locale))
            console.log(line);
    }
}
function asRecord(value) {
    return value && typeof value === "object" ? value : null;
}
function updateText(value) {
    if (typeof value === "string")
        return value;
    const record = asRecord(value);
    return typeof record?.text === "string" ? record.text : "";
}
function compact(value, maxLength = 500) {
    const normalized = value.replace(/\s+/g, " ").trim();
    return normalized.length > maxLength ? `${normalized.slice(0, maxLength)}…` : normalized;
}
function createAcpConsoleLogger(actorId, log, locale = "zh-CN", options = {
    printThinking: true,
    printLlmIo: false,
}) {
    const textLabel = (key) => (0, game_text_1.text)(locale, key);
    let pending = null;
    const toolStates = new Map();
    const emitText = (kind, value) => {
        if (kind === "thought" ? !options.printThinking : !options.printThinking && !options.printLlmIo)
            return;
        const text = compact(value, Infinity);
        if (text && !/^\*?conversation interrupted\*?$/i.test(text)) {
            log(`[acp][${actorId}][${kind}] ${kind === "thought" ? textLabel("runtime.acp.thought") : textLabel("runtime.acp.message")}: ${text}`, "muted");
        }
    };
    const flush = () => {
        const previous = pending;
        pending = null;
        if (previous)
            emitText(previous.kind, previous.text);
    };
    const observer = (update) => {
        const event = asRecord(update);
        if (!event || typeof event.sessionUpdate !== "string")
            return;
        const type = event.sessionUpdate;
        if (type === "agent_message_chunk" || type === "agent_thought_chunk") {
            const kind = type === "agent_message_chunk" ? "message" : "thought";
            if (kind === "thought" ? !options.printThinking : !options.printThinking && !options.printLlmIo) {
                flush();
                return;
            }
            const messageId = typeof event.messageId === "string" ? event.messageId : "unknown";
            if (pending && (pending.kind !== kind || pending.id !== messageId))
                flush();
            if (!pending)
                pending = { kind, id: messageId, text: "" };
            pending.text += updateText(event.content);
            while (pending.text.length) {
                const newline = pending.text.search(/[\r\n]/);
                let end = newline >= 0 && newline <= 500 ? newline : 500;
                if (newline < 0 && pending.text.length <= 500)
                    break;
                const hasNewline = end === newline;
                if (!hasNewline && /[\uD800-\uDBFF]/.test(pending.text[end - 1]))
                    end--;
                emitText(kind, pending.text.slice(0, end));
                pending.text = pending.text.slice(end + (hasNewline ? 1 : 0));
            }
            return;
        }
        flush();
        if (!options.printThinking)
            return;
        if (type === "tool_call") {
            const rawInput = asRecord(event.rawInput);
            const server = typeof rawInput?.server === "string" ? rawInput.server : undefined;
            const tool = typeof rawInput?.tool === "string" ? rawInput.tool : undefined;
            const title = typeof event.title === "string" ? compact(event.title, 180) : "tool";
            const label = server && tool ? `${server}.${tool}` : title;
            const toolCallId = typeof event.toolCallId === "string" ? event.toolCallId : undefined;
            if (toolCallId)
                toolStates.set(toolCallId, {
                    label,
                    status: typeof event.status === "string" ? event.status : undefined,
                    error: "",
                });
            log(`[acp][${actorId}][tool] start ${label} · ${textLabel("runtime.acp.start")}`, "muted");
            return;
        }
        if (type === "tool_call_update") {
            const toolCallId = typeof event.toolCallId === "string" ? event.toolCallId : undefined;
            const previous = toolCallId ? toolStates.get(toolCallId) : undefined;
            const label = typeof event.title === "string" ? compact(event.title, 180) : (previous?.label ?? "tool");
            const status = typeof event.status === "string" ? event.status : undefined;
            const error = event.error === undefined || event.error === null || event.error === ""
                ? ""
                : (0, error_diagnostic_1.formatErrorDiagnostic)(event.error, locale);
            const changed = (status !== undefined && status !== previous?.status) ||
                (error !== "" && error !== previous?.error);
            if (toolCallId)
                toolStates.set(toolCallId, {
                    label,
                    status: status ?? previous?.status,
                    error: error || previous?.error || "",
                });
            if (!changed)
                return;
            const displayStatus = status ?? previous?.status ?? "error";
            const statusKey = `runtime.acp.${displayStatus}`;
            const explanation = Object.hasOwn(game_text_1.dictionaries[locale], statusKey)
                ? textLabel(statusKey)
                : displayStatus;
            log(`[acp][${actorId}][tool] ${displayStatus} ${label} · ${explanation}${error ? ` error=${error}` : ""}`, error || status === "failed" ? "warn" : "muted");
        }
    };
    return Object.assign(observer, {
        flush: () => {
            flush();
            toolStates.clear();
        },
    });
}
