const FLUSH_DEBOUNCE_MS = 100;
export class SessionRecordingLifecycle {
    flushDirtyFiles;
    warnFlushFailure;
    closed = false;
    closing = false;
    flushTimer = null;
    flushChain = Promise.resolve();
    finalMeta = null;
    finalization = null;
    constructor(flushDirtyFiles, warnFlushFailure) {
        this.flushDirtyFiles = flushDirtyFiles;
        this.warnFlushFailure = warnFlushFailure;
    }
    get isClosed() {
        return this.closed;
    }
    get isClosing() {
        return this.closing;
    }
    get finalMetadata() {
        return this.finalMeta;
    }
    async flushNow() {
        if (this.closed)
            return;
        if (this.closing) {
            await this.flushChain;
            return;
        }
        if (this.flushTimer) {
            clearTimeout(this.flushTimer);
            this.flushTimer = null;
        }
        await this.enqueueFlush();
    }
    finalize(persist) {
        this.finalization ??= persist();
        return this.finalization;
    }
    beginClosing(meta) {
        this.closing = true;
        this.finalMeta = meta;
        if (this.flushTimer) {
            clearTimeout(this.flushTimer);
            this.flushTimer = null;
        }
        return this.enqueueFlush();
    }
    markClosed() {
        this.closed = true;
    }
    scheduleFlush() {
        if (this.closing || this.closed || this.flushTimer)
            return;
        this.flushTimer = setTimeout(() => {
            this.flushTimer = null;
            if (this.closing || this.closed)
                return;
            void this.enqueueFlush();
        }, FLUSH_DEBOUNCE_MS);
    }
    enqueueFlush() {
        this.flushChain = this.flushChain
            .then(() => this.flushDirtyFiles())
            .catch((error) => {
            this.warnFlushFailure(error);
        });
        return this.flushChain;
    }
}
