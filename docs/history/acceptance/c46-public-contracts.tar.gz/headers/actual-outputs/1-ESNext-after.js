import { formatErrorDiagnostic } from "../../utils/error-diagnostic";
import { promises as fs } from "fs";
import path from "path";
export class ReplayFileStore {
    sessionDir;
    locale;
    constructor(sessionDir, locale = "zh-CN") {
        this.sessionDir = sessionDir;
        this.locale = locale;
    }
    async initialize() {
        await fs.mkdir(path.join(this.sessionDir, "players"), { recursive: true });
    }
    async writeJson(relativePath, data) {
        await this.write(relativePath, JSON.stringify(data, null, 2), "json");
    }
    async writeText(relativePath, data) {
        await this.write(relativePath, data, "text");
    }
    async writeJsonStrict(relativePath, data) {
        await this.writeAtomic(relativePath, JSON.stringify(data, null, 2));
    }
    async write(relativePath, content, kind) {
        try {
            await this.writeAtomic(relativePath, content);
        }
        catch (error) {
            console.warn(`[observability] write_${kind}_failed file=${relativePath} err=${formatErrorDiagnostic(error, this.locale)}`);
        }
    }
    async writeAtomic(relativePath, content) {
        const target = path.join(this.sessionDir, relativePath);
        const temporary = `${target}.tmp`;
        await fs.writeFile(temporary, content, "utf-8");
        await fs.rename(temporary, target);
    }
}
