# C47 138 依赖边公共边界候选：非作者静态审查

## 审查结论

批准范围仅为当前 TMP 有界候选。138 条既有跨边界调用改到 36 个新具名公共面与 1 个既有 deal-ports；72 个 consumer 仅 138 个模块字面变化，原 37 target 完整算法与唯一存储不复制、不退休。本次没有发现需要阻止 Root 准备应用的业务／权限／中文语义问题。没有执行作者 Python、TS parser、编译、门禁、emit、运行时导入或业务测试。

## 真实职责及权限

- 普通夜能力：inventory 持原查询／复制／受信安装／metadata 写；native-installation 承接原七种准备到唯一安装；scope、actor query、history、grant、recipient stage 分开。实际 owner 本来就完整，不是搬走函数后留空旧实现。commitPreparedNativeAbility 可写真实库存，不能冒 DTO 或自带完整输入验证；SHELTER_STATE_SLOT 的 install／allowedWrites／invalidations 也明确是受信能力面。
- 死亡行动：native resource setter／arm 与 reader、原生 async settlement、gift lifecycle／hook、tool 预检和 policy 各接原 owner。未付退休入口和已付 pending/current 仍原体；原五处 consume 及事实／保护先后没有夹改。death-abilities 的四值最终还沿原 reexport 归 death-gun-lifecycle，不把中间入口误作新库存。
- 实际权威：Debater 返回原 authority 引用，Demon badge frame 可提交原审计，Ghost 吞徽可写；新头都没有谎称这些是只读数据。WolfTeam 的知识／chat／knife 与三板阻断不统一权限，Initial setupReady 复用已有轻 owner。Cupid vote 只查询既有关系。
- 窗口／贡献：LastWords 的默认 getter 仍在首次调用创建同一实例，window 是原类绑定；Wall 每作者 completion／finally、Badge 领域 true 点及 close/body 优先级仍属旧正文。Sheriff 工具规格、校验和阶段各有实际用途，不把 schema 当票权或新许可。

## 路由、模块与单例

37 公共面完整声明和 138 旧／新 route、type-only／import-type／具名 export alias 已逐项阅读；99 份实际 Git 原文、mode、blob、字节与提供的 before 相同；72 完整 candidate 由各原模块字面的 exact delta 重建相同。36 新入口全部只有到各原单个 target 的有限具名重导，没有 star/default、新 class/function、调用、时钟捕获、注册或状态。四个 type 声明明确 type export；原 consumer 的 type-only 模式未改。engine/index 的原警徽 named export 条款位置与名字保留，未扩根 API 成 star。

具体静态加载链已读：abilities→Fragrant data／Witch policy，ability-changes→SHELTER slot→abilities，scope→Radiant frame→grant→玩家投影，以及 gift lifecycle／tool／玩家投影；这些跨点的值和类型区分真实。Sheriff→Demon／Ghost、self-destruct→Catalog 与角色装配链也读核；Catalog 的 builtin／native capture 仍在原函数内 lazy require。新入口不主动拉另一 target 聚合，因此不会凭“已有 heavy ports 同名”提前引入额外 clock／state／registration owner。Animal 原 Date.now.bind、Demon 原 nativeArrayPush、各 WeakMap 与 RequestLease 常量仍在唯一旧模块。

新增公开节点及其 emitted JS 是实际变化。单目标节点折回后的有序依赖／DFS、最终 ultimate declaration 及保留原程序的机器证明仍待 Root 执行；本审查没有冒已跑冷执行，也不以静态设计宣称任意 CJS module cache／namespace 猴补、动态加载或初始化失败栈全等。未发现当前声明中新增第二实例、将 type import 强制为值或多拉不相关 owner 的具体路径。

## 边界和后继

这不是改变结构检查器或通过文件名发豁免：checker 是稳定控制，公共面逐项说明真实写权／查询责任。原 37 实现叶没有本批删除，所以不冒旧内部 API 已全面退休；新增端口名与 sourceHash 应纳修复后真实来源。Root 仍须在实际应用树保存输入和重跑所需失败架构根／必要证明，不能拿 prepared 批准称 C47 149 首红已清。

Root 独立六头补丁与此 72 consumer 无路径交集。5 控制全文与 base/current 一致；36 新路径在原 Git 和当前工作树均缺席。原 C47 stdout 不修改，不新增 N/A／忽略项，不外推未知仓外消费者兼容。
