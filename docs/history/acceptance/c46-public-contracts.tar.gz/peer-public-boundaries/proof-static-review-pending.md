# prove.cjs 非作者静态审查（首工具 cf7d4b57）

完整阅读406行、PROOF-HANDOFF、四头精度记录和当前108源候选说明；没有执行该工具、TS parser／checker、emit、门禁、类型诊断或产品。

## 目前成立的工具范围

- before／candidate SHA固定，99个实际Git完整文本／mode／blob核对，36base absence、5current controls；actual108强核预期候选SHA。
- 每72consumer完整正逆只改明确138模块字面；完整source相等兜住无关程序／注释／directive，另完整walker带NodeArray与叶、scanner不注释词项作程序核。
- ES/CJS真实before／actual／inverse三份分别保全；144 actual输出只归一化parsed模块字面与实际require局部Symbol，最终完整raw对照，不用全局字符串替换来抹任意业务identifier。
- require namespace变化按前后require声明对应，局部Program只解析当前JS，不resolve依赖或拿semantic诊断；symbol所指引用才替换。新增模块字面保明确映射。
- 36新facet只允许有限具名重导到原单target，既有deal面允许原完整额外既有出口；public type不强加运行依赖。consumer导入／export alias／import-type的实际模式和顺序逐节点保。
- ultimate alias导航比较每一原symbol的全部declaration raw＋printer SHA，不拿第一层模块入口冒物理声明。
- static graph只宣称每consumer完整emitted ESNext顶层静态依赖序折回，没有实际DFS／动态依赖／冷运行／CJS任意猴补保证；未说actual emitted字节原本相同。
- 所有比较通过才写freshout；失败的脚本／stdout／exit由Root保留，不覆盖首目录。

## 首静态 finding：固定Git source host的workspace链接入口

`makeHost`首稿315–319行对含node_modules的路径直接走ts.sys.readFile。实际backend/node_modules/@ai-werewolf-arena下五包是到repo/packages的workspace链接，当前backend paths只额外声明typescript。包解析会先读取这些链接路径的package.json，故foreign package.json后继可能被old/new虚拟Program共同读入，报告“All files outside108 are fixedGit”没有被host完全保证。

最窄建议：把repo内workspace symlink realpath映射回publicFixed／overlay后再读，真正外部node_modules仍原依赖读取并在限制中明确。无需产品变体或新框架。本finding是静态推导，不称工具运行红；已经发送Root／作者，最终准备批准等待该delta。

## 四头后继

history不接事件端口，自爆真实五参无current，Demon blast返回day／sealsNight不是反噬结果，actorQuery接World绑定再actors(kind,day)查询。四句已对实际原函数核准；72consumer、138routes、37出口集合相同，不需要重复业务源审。
