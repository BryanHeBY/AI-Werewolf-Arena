import pathlib,json,hashlib,stat,collections,datetime
root=pathlib.Path('/tmp/awa-c43-fixture-io-repair');repo=pathlib.Path('/home/hby/dev/AI-Werewolf-Arena')
def sha(b):return hashlib.sha256(b).hexdigest()
h=json.loads((root/'HANDOFF.json').read_text());before=json.loads((root/'before.json').read_text());deltas=json.loads((root/'deltas.json').read_text());controls=json.loads((root/'controls.json').read_text());master=json.loads((repo/'tooling/refactor/fixtures/manifest.json').read_text())
refs=[]
for f in h['files']:
 p=pathlib.Path(f['path']);b=p.read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'];refs.append(f)
for r in h['originalEvidenceCopies']:assert pathlib.Path(r['from']).read_bytes()==pathlib.Path(r['to']).read_bytes() and sha(pathlib.Path(r['to']).read_bytes())==r['sha256']
by_before={r['path']:r for r in before['source']};by_edit=collections.defaultdict(list)
for e in deltas['edits']:by_edit[e['path']].append(e)
assert len(h['source'])==len(by_before)==252
master_assets={a['currentPath']:a for a in master['sourceAssets'] if a['kind']=='test-support'}
assert len(master_assets)==2
summary=[]
for f in h['source']:
 r=by_before[f['path']];old=r['text'];b=old.encode();candidate=(root/'candidates'/f['path']).read_bytes();new=candidate.decode();assert len(b)==f['beforeBytes'] and sha(b)==f['beforeSha256'];assert len(candidate)==f['candidateBytes'] and sha(candidate)==f['candidateSha256']
 assert r['gitMode']==f['gitMode']=='100644'
 steps=by_edit[f['path']]
 if f['path'].endswith('fixture-manifest.test.ts'):
  assert len(steps)==1 and old.count(steps[0]['before'])==1 and old.replace(steps[0]['before'],steps[0]['after'])==new
  # 只删去唯一复制列表替换，外围完整原程序恢复，断言／声明保持。
  assert new.replace(steps[0]['after'],steps[0]['before'])==old
 else:
  assert len(steps)==4
  actual_old=json.loads(old);actual_new=json.loads(new)
  expected=json.loads(old)
  for s in steps:
   i=int(s['pointer'].split('/')[2]);field=s['pointer'].split('/')[3]
   assert field in ['currentSha256','currentBytes'];asset=expected['sourceAssets'][i];assert asset['currentPath']==s['assetCurrentPath']
   assert old[s['offsetCodepoints']:s['endCodepoints']]==s['beforeLiteral'];assert json.loads(s['beforeLiteral'])==s['beforeValue']
   assert asset[field]==s['beforeValue'];expected['sourceAssets'][i][field]=s['afterValue']
   assert s['afterValue']==master_assets[asset['currentPath']][field]
   raw=(repo/asset['currentPath']).read_bytes();assert s['afterValue']==(sha(raw) if field=='currentSha256' else len(raw))
  assert actual_new==expected
  rebuilt=old
  for s in sorted(steps,key=lambda e:e['offsetCodepoints'],reverse=True):rebuilt=rebuilt[:s['offsetCodepoints']]+s['afterLiteral']+rebuilt[s['endCodepoints']:]
  assert rebuilt==new
  restored=new
  for s in sorted(steps,key=lambda e:e['candidateOffsetCodepoints'],reverse=True):
   at=s['candidateOffsetCodepoints'];assert restored[at:at+len(s['afterLiteral'])]==s['afterLiteral'];restored=restored[:at]+s['beforeLiteral']+restored[at+len(s['afterLiteral']):]
  assert restored==old
 stage='before' if (repo/f['path']).read_bytes()==b else ('candidate' if (repo/f['path']).read_bytes()==candidate else 'other')
 assert stage in ['before','candidate']
 summary.append({'path':f['path'],'edits':len(steps),'beforeSha256':sha(b),'candidateSha256':sha(candidate),'actualCurrentStageAtRead':stage})
for f in controls['readOnlySource']:
 p=repo/f['path'];b=p.read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes'];assert b==f['text'].encode();assert ('100755' if p.stat().st_mode&0o100 else '100644')==f['gitMode']
for r in controls['archiveInputs']:
 b=(repo/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'];assert r['sha256']==r['originalSha256'] and r['bytes']==r['originalBytes']
assert len(controls['archiveInputs'])==904
out={'decision':'approved_as_prepared_bounded_candidate','role':'peer','reviewer':'/root/native_final_architecture_review','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'handoffSHA256':sha((root/'HANDOFF.json').read_bytes()),'refs':refs,'source':summary,'deleted':[],'counts':{'candidateFiles':252,'testHeaderExactEdit':1,'manifestScalarEdits':1004,'localManifests':251,'readOnlySourceControls':len(controls['readOnlySource']),'bytePreservedArchives':904},'findings':[],'scope':['One existing negative fixture only extends exact copied input closure (4 registered relocation leaves + 5 GC files), preserving original canary/symlink/expected error/finally and full outside-body text.','251 local derived manifests change only two existing test-support currentSha256/currentBytes tokens (4 per file); complete exact forward/inverse and all other parsed fields/raw ranges remain.','Actual main source metadata and actual support files agree with the new values; no golden/body/program/binding/origin/acceptance is changed.','904 actual archived fixture files are still their original exact bytes, independent of local metadata candidates.','Production generate/derive checker and C43 frozen5511 history are controls, not candidate writes.'],'execution':{'preparedCandidateApply':False,'productGeneratorOrDerive':False,'parserOrCompiler':False,'testOrGate':False,'repositoryWrites':False,'activity':'Read-only stdlib JSON/raw-byte reconstruction/hash binding and source reading; this TMP peer report only.'},'firstFailure':'Root ce6eb8/session9247→7005d3 original23pass/2fail/119expect preserved; this peer is static and does not turn candidate into a successful runtime result.'}
p=pathlib.Path('/tmp/awa-c43-fixture-io-repair-independent-review.json');p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p.read_bytes()),'handoffSHA256':out['handoffSHA256'],'decision':out['decision'],'counts':out['counts'],'currentStages':dict(collections.Counter(r['actualCurrentStageAtRead'] for r in summary))},ensure_ascii=False))
