# C43 实际交付末前审

状态：实际来源／字节／阶段的只读审查已完成，当前无新增 finding。正式 scope、MD、evidence 和真实收据合集尚待 Root 封定，本文件不作为最终交付批准，也不宣称 C47/C48 已通过。

## 实际输入与历史归属

固定捕获提交为 `14e7951787f4464573407a7bcc270303a3975856`，prepared SHA 为 `842e9d66bc228d8312065c244ea0fbfed3331ac2be84f768a5fec41ba68e0956`。独立只读 Git/blob 与当前文件逐项绑定：5,511 个原成员、168,795,320 bytes、blob／mode／SHA／正文均无差异。原路径索引逐项同该实际 Git；两个冻结历史根只有这 5,511 项及两个现行 README，共 5,513 项，旧两根已无文件。

两份 ignore 未跟踪日志由 Root 另存 TMP，合 37,322 bytes；备份与 manifest 摘要一致，没有伪纳入原 Git 的 5,511 集合。前两次全集预检拒绝、跨文件系统 rename 失败及后继 copy2 属各自实际阶段，不能将最后成功覆盖为一次无失败迁移；工具调用／终态身份在正式 receipts 中继续由 Root 提供。

## 现行页面、I/O 与 companion

73 页现行资料已沿发布候选 → 实际 companion → 格式化前样 → 当前文件完整绑定。固定 Git 的 50 份原有现行／规则／I/O 文本也逐字绑定。七个真实 I/O 适配保留 origin 协议值，只改实际读取落点；其中 fixture-source-relocations 的复制输入改物理历史落点，合成协议及断言原文保留。

四源 companion 的 12 个精确变化实际到位：portable guard 中文维护帮助与解释、根 check:history 及原 check 顺序、现行 validation 和 delivery owner。guard 独立核固定原 Git 全集与当前历史原字节；当前 README 不是历史成员。新 acceptance 归属位于冻结两根之外，不因此成为历史守卫已审核的内容，也不新增 blanket 格式豁免。

当前 i18n 策略五条记录只改四条实际 canonical 源路径，text/count/reason 原值保留；旧策略文件完整保在历史。现行进度归 architecture/delivery-status，未来矩阵须根据真实同源证据登记，缺席不造空壳。

## 格式化与链接结论的范围

Root 正常格式化选择 76 项：73 MD、来源索引、根 package、现行 i18n policy。实际只有九份 MD 改动；逐表格单元内容和非表格行一致，变化是 padding 与 separator 连字符数量。首次发布候选不是末格式化字节，已分别登记 SHA。

Root 链接扫描实际结果为 73 页、267 个本地目标、0 缺失。源码是有限 regex：排除代码块／行内代码，匹配 Markdown inline destination 和 reference definition，剥离 fragment/query，只核目标文件或目录存在。它不核 heading anchors、外网、完整 CommonMark／HTML 链接或历史内嵌相对链接；不称完整导航语义验收。九份格式化保原 href，未重复扫描。

## fixture 后继候选

另份真正非作者 prepared peer 已批准：252 个候选只包括一个失败负例的输入复制列表，以及 251 个 local manifest 各四个现有支持源 currentSha256/currentBytes 标量。1004 个精确标量正逆、其余 parsed 字段和 raw 范围完整保留，目标值同主清单与实际两支持源；904 个原档案仍是原始字节。负例补四个已登记 relocation 叶和五个明确 GC 文件，原 canary、symlink、错误预期、声明、断言和清理不变。生产 checker 与原历史均不改。

首执行的 23 pass／2 fail／119 expect 保留；候选批准不是运行通过。Root 后继仅复这两个失败声明，其真实终态待正式收据绑定。

## 审查资产

- `history-binding.json` SHA `5a8a9af557578fc675067866aeb229a959276e5c9cd8de798c5e4c3165dfa462`
- `publication-stage-binding.json` SHA `25af8352b26256337ca7439e43e3aa0f7b72bc97058a1dde8664a16cda707b3c`
- `/tmp/awa-c43-fixture-io-repair-independent-review.json` SHA `099cf5b0ffc6665304d05232f560f23681be0eec09619be0efe605d7075ba7b7`

本轮只读源码、JSON／字节、Git 元数据并写 TMP 绑定报告；没有运行迁移器、guard、产品 parser／generator／derive、类型、测试、门禁或网络，也没有仓库写入。审查者参与过 C43 上游候选准备，因此历史／发布范围绑定不冒称对自己原工具算法的全新非作者审查；fixture 修复由另一作者编写，本轮作独立审查。
