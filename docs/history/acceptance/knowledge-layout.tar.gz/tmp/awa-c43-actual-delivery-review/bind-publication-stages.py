import pathlib,json,hashlib,subprocess,stat,re,collections
repo=pathlib.Path('/home/hby/dev/AI-Werewolf-Arena');tmp=pathlib.Path('/tmp');p=json.loads((tmp/'awa-c43-actual-14e79517/prepared.json').read_text());cb=json.loads((tmp/'awa-c43-current-contract-companion/before.json').read_text());ce=json.loads((tmp/'awa-c43-current-contract-companion/edits.json').read_text())['edits'];cf=json.loads((tmp/'awa-c43-current-format-before.json').read_text())['source'];fr=json.loads((tmp/'awa-c43-current-format-receipt.json').read_text());fs={r['path']:r for r in fr['source']};fc={r['path']:r for r in cf}
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(t):
 out=[]
 for line in t.splitlines():
  if line.lstrip().startswith('|'):
   cells=[c.strip() for c in line.strip().strip('|').split('|')]
   if all(re.fullmatch(':?-+:?',c) for c in cells):continue
   out.append(('table',cells))
  else:out.append(('line',line.rstrip()))
 return out
comp={};comps=[]
for b in cb['source']:
 name=b['path'];old=b['text'];assert sha(old.encode())==b['sha256'];new=old;es=[e for e in ce if e['path']==name]
 for e in es:
  assert new.count(e['before'])==e.get('count',1)==1;new=new.replace(e['before'],e['after'])
 assert new==(tmp/'awa-c43-current-contract-companion/candidates'/name).read_text();comp[name]=new;comps.append({'path':name,'exactEdits':len(es),'beforeSHA256':sha(old.encode()),'candidateSHA256':sha(new.encode())})
assert sum(r['exactEdits'] for r in comps)==12
batch=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
def gitblob(oid):
 batch.stdin.write((oid+'\n').encode());batch.stdin.flush();head=batch.stdout.readline().decode().strip().split();assert head[0]==oid and head[1]=='blob';b=batch.stdout.read(int(head[2]));assert batch.stdout.read(1)==b'\n';return b
# 固定Git全文的current/rulecard与7I/O captures；未存在的新current只核发布链。
orig_count=0
for r in p['currentDocs']+p['ruleCards']+p['adaptations']:
 if r['gitBlob'] is not None:assert gitblob(r['gitBlob'])==r['before'].encode();orig_count+=1
batch.stdin.close();assert batch.wait()==0
current=[]
for r in p['currentDocs']+p['ruleCards']:
 name=r['path'];expected=comp.get(name,r['after']);assert sha(r['after'].encode())==r['afterSha256'];assert fc[name]['text']==expected
 actual=(repo/name).read_bytes();assert sha(actual)==fs[name]['sha256'];assert canon(actual.decode())==canon(expected)
 current.append({'path':name,'initialPublishedSHA256':r['afterSha256'],'preFormatSHA256':sha(expected.encode()),'finalSHA256':sha(actual),'formatted':actual!=expected.encode(),'gitMode':'100755' if (repo/name).stat().st_mode&0o100 else '100644'})
assert len(current)==73 and sum(r['formatted'] for r in current)==9
# 76正常format仅73MD + index + package + activepolicy，无冻结历史正文。
extras=[]
for name in sorted(set(fc)-{r['path'] for r in current}):
 actual=(repo/name).read_bytes();old=fc[name]['text'];assert sha(old.encode())==fc[name]['sha256'];assert actual==old.encode() and sha(actual)==fs[name]['sha256'];extras.append({'path':name,'sha256':sha(actual),'unchangedByFormat':True})
assert len(extras)==3
assert (repo/'package.json').read_text()==comp['package.json'];assert (repo/'tooling/refactor/history-integrity.py').read_text()==comp['tooling/refactor/history-integrity.py']
io=[]
for r in p['adaptations']:
 assert sha(r['before'].encode())==r['beforeSha256'] and sha(r['after'].encode())==r['afterSha256'];current_b=(repo/r['path']).read_bytes()
 stage='initial-history-adaptation' if current_b==r['after'].encode() else 'followup-fixture-candidate'
 if stage!='initial-history-adaptation':assert current_b==(tmp/'awa-c43-fixture-io-repair/candidates'/r['path']).read_bytes()
 io.append({'path':r['path'],'gitBeforeSHA256':r['beforeSha256'],'initialAdaptationSHA256':r['afterSha256'],'actualCurrentSHA256':sha(current_b),'actualStage':stage})
policy=p['policy'];assert (repo/policy['path']).read_text()==policy['after'];assert (repo/p['prettier']['path']).read_text()==p['prettier']['after']
manifest=json.loads((repo/'docs/history/origin-paths.json').read_text());oldpolicy=json.loads((repo/'docs/history/expansion/i18n-source-exceptions.json').read_text());newpolicy=json.loads((repo/policy['path']).read_text())
assert len(oldpolicy)==len(newpolicy)==5
for old,new in zip(oldpolicy,newpolicy):
 e=dict(old);e['file']=e['file'].replace('backend/src/audit/deterministic_checks.ts','backend/src/audit/deterministic-checks.ts');assert e==new
logs=json.loads((tmp/'awa-c43-uncaptured-workspace-logs/manifest.json').read_text())
for r in logs['source']:
 b=pathlib.Path(r['temporaryPath']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'];assert not(repo/r['originPath']).exists();assert r['originPath'] not in {x['originPath'] for x in manifest['files']}
links=json.loads((tmp/'awa-c43-current-links-report.json').read_text());assert links['files']==73 and links['localLinks']==267 and links['failures']==[]
out={'kind':'static-read-and-byte-binding-of-Root-executed-C43-stages-not-rerun','baseCommit':p['baseCommit'],'fixedGitOriginalProgramTextsBound':orig_count,'currentPages':73,'normalFormatSelected':76,'normalFormatChanged':9,'formatSemanticLimit':'For all9 exact table cell strings and non-table lines remain; only table padding/separator dash counts differ. No Markdown parser was run.','current':current,'formatExtraFiles':extras,'companion':comps,'companionExactEdits':12,'ioAdaptations':io,'activePolicy':'Only4 existing backend exception paths canonicalized; all5rows text/count/reason preserved; original historical policy untouched.','formatExemptScope':'Only2 frozen roots with currentREADME negations; acceptance is outside frozen roots and not a new blanket exemption.','ignoredLogBackup':{'files':2,'bytes':sum(r['bytes'] for r in logs['source']),'manifestSHA256':sha((tmp/'awa-c43-uncaptured-workspace-logs/manifest.json').read_bytes()),'separateFrom5511Git':True},'linkReport':{'files':73,'localTargets':267,'missingTargets':0,'scriptSHA256':sha((tmp/'awa-c43-current-links.py').read_bytes()),'reportSHA256':sha((tmp/'awa-c43-current-links-report.json').read_bytes()),'limits':['Only regex-recognized inline Markdown destinations/reference definitions in73current pages outside ignored fenced/inline code.','Existence of local file/directory targets only; fragments stripped, anchors not checked, external links not visited; historical embedded relative links deliberately byte-preserved.','Not a full CommonMark/HTML link graph or semantic navigation verifier.','Actual Root link run was before9format changes; reviewed exact table cells preserve hrefs but no new scan is claimed.']},'checksExecutedByReviewer':False,'repositoryWrites':False,'pending':'Final formal source/scope/document/evidence/artifact receipts binding after Root supplies metadata; fixture successor runtime still independently Root-owned.'}
path=tmp/'awa-c43-actual-delivery-review/publication-stage-binding.json';path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(path),'sha256':sha(path.read_bytes()),'fixedGitOriginalTexts':orig_count,'currentPages':73,'formatSelected':76,'formatChanged':9,'io':len(io),'companionEdits':12,'ignoredBackupBytes':out['ignoredLogBackup']['bytes'],'actualIOStages':dict(collections.Counter(r['actualStage'] for r in io))},ensure_ascii=False))
