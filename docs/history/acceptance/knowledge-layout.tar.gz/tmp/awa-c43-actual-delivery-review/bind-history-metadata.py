import pathlib,json,hashlib,subprocess,stat,os
repo=pathlib.Path('/home/hby/dev/AI-Werewolf-Arena')
prep=pathlib.Path('/tmp/awa-c43-actual-14e79517/prepared.json')
doc=json.loads(prep.read_text());base=doc['baseCommit'];rows=doc['history']
def sha(b):return hashlib.sha256(b).hexdigest()
entries={}
raw=subprocess.check_output(['git','-C',str(repo),'ls-tree','-rz','--full-tree',base,'--','docs/expansion','docs/refactor'])
for r in raw.split(b'\0'):
 if not r:continue
 meta,name=r.split(b'\t',1);mode,kind,blob=meta.decode().split();assert kind=='blob';entries[name.decode()]=(mode,blob)
assert len(rows)==len(entries)==5511
assert set(r['path'] for r in rows)==set(entries)
index_path=repo/'docs/history/origin-paths.json';index=json.loads(index_path.read_text());assert index['originCommit']==base
ir={r['originPath']:r for r in index['files']};assert set(ir)==set(entries)
batch=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
result=[];total=0
for r in rows:
 name=r['path'];assert name.startswith(('docs/expansion/','docs/refactor/'))
 mode,blob=entries[name];assert (mode,blob)==(r['gitMode'],r['gitBlob'])
 cur=r['currentPath'];assert cur==name.replace('docs/','docs/history/',1)
 original=repo/name;assert not original.exists() and not original.is_symlink()
 path=repo/cur
 for p in [path,*path.parents]:
  if p==repo.parent:break
  assert not p.is_symlink(),cur
 st=path.lstat();assert stat.S_ISREG(st.st_mode);gitmode='100755' if st.st_mode&0o100 else '100644';assert gitmode==mode
 batch.stdin.write((blob+'\n').encode());batch.stdin.flush();head=batch.stdout.readline().decode().strip().split();assert head[0]==blob and head[1]=='blob'
 data=batch.stdout.read(int(head[2]));assert batch.stdout.read(1)==b'\n'
 actual=path.read_bytes();assert actual==data
 s=sha(data);assert s==r['sha256'] and len(data)==r['bytes']
 ix=ir[name];assert ix['currentPath']==cur and ix['originCommit']==base and ix['mode']==mode and ix['originalGitBlob']==blob and ix['sha256']==s and ix['bytes']==len(data)
 result.append({'originPath':name,'currentPath':cur,'mode':mode,'originalGitBlob':blob,'bytes':len(data),'sha256':s});total+=len(data)
batch.stdin.close();code=batch.wait();error=batch.stderr.read();assert code==0,error
actual=set()
for prefix in ['docs/history/expansion','docs/history/refactor']:
 for dirpath,dirs,files in os.walk(repo/prefix,followlinks=False):
  for dirname in dirs:assert not (pathlib.Path(dirpath)/dirname).is_symlink()
  for name in files:actual.add((pathlib.Path(dirpath)/name).relative_to(repo).as_posix())
assert actual==set(r['currentPath'] for r in result)|{'docs/history/expansion/README.md','docs/history/refactor/README.md'}
old_remaining=[]
for prefix in ['docs/expansion','docs/refactor']:
 for dp,ds,fs in os.walk(repo/prefix,followlinks=False):old_remaining += [str(pathlib.Path(dp)/f) for f in fs]
assert not old_remaining
out={'kind':'read-only-independent-byte-and-Git-metadata-binding-not-execution-of-migration-or-guard','baseCommit':base,'preparedSha256':sha(prep.read_bytes()),'originIndexSha256':sha(index_path.read_bytes()),'historyFiles':len(result),'bytes':total,'mismatches':0,'originalGitTreeMembers':len(entries),'frozenCurrentMembers':len(actual),'oldRootFiles':0,'files':result}
p=pathlib.Path('/tmp/awa-c43-actual-delivery-review/history-binding.json');p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['kind','baseCommit','preparedSha256','originIndexSha256','historyFiles','bytes','mismatches','originalGitTreeMembers','frozenCurrentMembers','oldRootFiles']},ensure_ascii=False));print('reportSHA256',sha(p.read_bytes()))
