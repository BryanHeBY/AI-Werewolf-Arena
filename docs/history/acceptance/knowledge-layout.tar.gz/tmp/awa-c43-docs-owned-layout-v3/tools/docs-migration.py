#!/usr/bin/env python3
"""Deferred C43 application tool. No command is run by preparing this file.

prepare: require explicit Git --base; record metadata, not copies of history.
apply-current: publish reviewed current pages; history links remain pending phase B.
apply-history: exact history moves + current I/O/link/policy adaptation.
verify-history: verify every archived entry and live adaptation against the bundle.

All commands require --base. Mutation commands additionally require --apply.
Only Root should execute them after freezing and reviewing the actual new base.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys

HISTORY_ROOTS = ('docs/expansion/', 'docs/refactor/')
ARCHIVE_ROOTS = ('docs/history/expansion/', 'docs/history/refactor/')
ORIGIN_INDEX = 'docs/history/origin-paths.json'
POLICY_ORIGIN = 'docs/expansion/i18n-source-exceptions.json'
POLICY_CURRENT = 'tooling/refactor/policies/i18n-source-exceptions.json'
SCHEMA = 'awa-doc-history-capture-v1'

def fail(message):
    raise RuntimeError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def canonical(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()

def safe_relative(value):
    p = PurePosixPath(value)
    if not value or p.is_absolute() or '..' in p.parts or '\\' in value or str(p) != value:
        fail('unsafe relative path: ' + value)
    return value

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def base_commit(repo, requested):
    if not requested or requested in ('HEAD', '@'):
        fail('--base must be an explicitly chosen commit, not implicit/current HEAD')
    return git(repo, 'rev-parse', '--verify', requested + '^{commit}').decode().strip()

def tree(repo, base, *paths):
    data = git(repo, 'ls-tree', '-rz', '--full-tree', base, '--', *paths)
    result = []
    for entry in data.split(b'\0'):
        if not entry:
            continue
        info, name = entry.split(b'\t', 1)
        mode, kind, oid = info.decode().split()
        name = safe_relative(name.decode('utf-8'))
        if kind != 'blob' or mode not in ('100644', '100755', '120000'):
            fail('unsupported tracked entry: ' + repr((name, mode, kind)))
        result.append({'path': name, 'gitMode': mode, 'gitBlob': oid})
    return sorted(result, key=lambda x: x['path'].encode())

def blobs_metadata(repo, entries):
    # Stream each Git blob through SHA256; do not materialize/copy the archive in TMP.
    process = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for row in entries:
            process.stdin.write((row['gitBlob'] + '\n').encode())
            process.stdin.flush()
            header = process.stdout.readline().decode().strip().split()
            if len(header) != 3 or header[0] != row['gitBlob'] or header[1] != 'blob':
                fail('Git object read failed: ' + row['path'])
            size = int(header[2])
            remaining = size
            h = hashlib.sha256()
            while remaining:
                chunk = process.stdout.read(min(remaining, 1024 * 1024))
                if not chunk:
                    fail('truncated blob: ' + row['path'])
                h.update(chunk)
                remaining -= len(chunk)
            if process.stdout.read(1) != b'\n':
                fail('Git batch framing error')
            row.update(bytes=size, sha256=h.hexdigest())
    finally:
        process.stdin.close()
        process.stdout.close()
        if process.wait() != 0:
            fail('Git batch exited nonzero')

def tracked(repo, base, path):
    rows = tree(repo, base, path)
    if not rows:
        return None
    if len(rows) != 1 or rows[0]['path'] != path or rows[0]['gitMode'] == '120000':
        fail('ordinary tracked file required: ' + path)
    return rows[0]

def source(repo, base, path):
    row = tracked(repo, base, path)
    if row is None:
        fail('required base file absent: ' + path)
    return git(repo, 'cat-file', 'blob', row['gitBlob'])

def workspace_bytes(repo, relative):
    safe_relative(relative)
    target = repo / relative
    parent = target.parent
    while parent != repo:
        if parent.is_symlink():
            fail('symlink ancestor: ' + str(parent))
        parent = parent.parent
    if target.is_symlink():
        return os.readlink(target).encode(), '120000'
    if not target.is_file():
        fail('file missing or invalid kind: ' + relative)
    mode = '100755' if target.stat().st_mode & 0o100 else '100644'
    return target.read_bytes(), mode

def expect_workspace(repo, row, key='path'):
    data, mode = workspace_bytes(repo, row[key])
    if mode != row['gitMode'] or len(data) != row['bytes'] or digest(data) != row['sha256']:
        fail('source drift: ' + row[key])

def replace(text, old, new, count=1):
    if text.count(old) != count:
        fail('exact adaptation anchor changed: ' + repr(old))
    return text.replace(old, new)

def io_candidates(repo, base):
    changes = []
    def add(path, transform):
        before = source(repo, base, path)
        after = transform(before.decode()).encode()
        row = tracked(repo, base, path)
        changes.append({'path': path, 'gitMode': row['gitMode'], 'gitBlob': row['gitBlob'],
                        'before': before.decode(), 'after': after.decode(),
                        'beforeSha256': digest(before), 'afterSha256': digest(after)})

    def gate(text):
        text = replace(text, r'!/^docs\/refactor\/[a-zA-Z0-9_./-]+\.json$/.test(relative)',
                       r'!/^docs\/history\/refactor\/[a-zA-Z0-9_./-]+\.json$/.test(relative)')
        return replace(text, 'path.join(repository, "docs/refactor/generated/architecture-debt.json")',
                       'path.join(repository, "docs/history/refactor/generated/architecture-debt.json")')
    add('tooling/refactor/architecture/run.ts', gate)

    def fixture(text):
        text = replace(text, 'const inventoryPath = "docs/refactor/generated/baseline-fixtures.json";',
                       'const inventoryPath = "docs/refactor/generated/baseline-fixtures.json";\n// 协议 origin 保原身份；实际冻结文件只从精确归档落点读取。\nconst inventoryFilePath = "docs/history/refactor/generated/baseline-fixtures.json";')
        text = replace(text, 'relative !== inventoryPath &&', 'relative !== inventoryFilePath &&')
        return replace(text, 'const inventoryBytes = await safeFile(inventoryPath),',
                       'const inventoryBytes = await safeFile(inventoryFilePath),')
    add('tooling/refactor/fixture-manifest.ts', fixture)

    def fixture_test(text):
        for old, new in [
            ('path.join(actualRoot, "docs/refactor/generated")', 'path.join(actualRoot, "docs/history/refactor/generated")'),
            ('path.join(actualRoot, "docs/refactor/generated/baseline-fixtures.json")', 'path.join(actualRoot, "docs/history/refactor/generated/baseline-fixtures.json")'),
            ('for (const relative of [\n      "docs/refactor/generated/baseline-fixtures.json",', 'for (const relative of [\n      "docs/history/refactor/generated/baseline-fixtures.json",'),
            ('const directory = path.join(temporary, "docs/refactor/generated");', 'const directory = path.join(temporary, "docs/history/refactor/generated");'),
        ]:
            text = replace(text, old, new)
        # The synthetic baseline.inventoryPath origin literal above is intentionally unchanged.
        return text
    add('tooling/refactor/fixture-manifest.test.ts', fixture_test)
    # 只改临时repo真实FS输入；document.baseline.inventoryPath协议身份与断言原值不变。
    add('tooling/refactor/fixture-source-relocations.test.ts', lambda t: replace(t,
        '    const inputs = new Set([\n      document.baseline.inventoryPath,',
        '    const inputs = new Set([\n      "docs/history/refactor/generated/baseline-fixtures.json",'))
    add('backend/tests/architecture/engine-fingerprint-review.test.ts', lambda t: replace(t,
        'path.join(root, "docs/refactor/generated/baseline-source-hash.json")',
        'path.join(root, "docs/history/refactor/generated/baseline-source-hash.json")'))
    add('backend/scripts/check-i18n-literals.mjs', lambda t: replace(t,
        '"docs/expansion/i18n-source-exceptions.json"', '"tooling/refactor/policies/i18n-source-exceptions.json"'))
    add('backend/tests/integration/tooling/i18n-source-discovery.test.ts', lambda t: replace(t,
        '"../docs/expansion/i18n-source-exceptions.json"', '"../tooling/refactor/policies/i18n-source-exceptions.json"'))
    return changes

def absent(repo, path):
    target = repo / safe_relative(path)
    if target.exists() or target.is_symlink():
        fail('target already exists: ' + path)
    parent = target.parent
    while parent != repo:
        if parent.is_symlink():
            fail('target ancestor symlink: ' + str(parent))
        parent = parent.parent

def prepare(args, repo, base, bundle):
    if bundle.exists():
        fail('bundle must be a fresh directory: ' + str(bundle))
    candidates = Path(args.candidates).resolve()
    candidate = json.loads((candidates / 'candidate-manifest.json').read_text())
    mapping_data = Path(args.source_map).read_bytes()
    mapping = json.loads(mapping_data)
    routes = {r['from']: r['to'] for r in mapping['mapping']}
    original_plan = json.loads((Path(candidate['originalCandidateDirectory']) / 'application-plan.json').read_text())
    # 明确canonical九叶是未来输入前置条件；不改它们内部固定旧Git模板或猜测HEAD。
    basename_input = (candidates / 'basename-paths.json').read_bytes()
    basename_routes = json.loads(basename_input)['mapping']
    if len(basename_routes) != 9:
        fail('exact nine basename routes required')
    basename_targets = []
    for route in basename_routes:
        if tracked(repo, base, route['from']) is not None:
            fail('approved old basename still active in explicit base: ' + route['from'])
        row = tracked(repo, base, route['to'])
        if row is None:
            fail('approved canonical basename missing in explicit base: ' + route['to'])
        basename_targets.append(dict(row, originPath=route['from']))
    blobs_metadata(repo, basename_targets)
    originals = tree(repo, base, 'docs/expansion', 'docs/refactor')
    if not originals:
        fail('explicit base has no history inputs')
    blobs_metadata(repo, originals)
    for row in originals:
        if not row['path'].startswith(HISTORY_ROOTS):
            fail('history root escaped')
        row['currentPath'] = row['path'].replace('docs/', 'docs/history/', 1)

    current_docs = []
    for row in candidate['candidateFiles']:
        if row['path'] not in candidate['phaseAPaths']:
            continue
        data = (candidates / row['path']).read_bytes()
        if digest(data) != row['sha256']:
            fail('candidate drift: ' + row['path'])
        old = tracked(repo, base, row['path'])
        # Existing navigation must not silently discard newer independent edits.
        if old is not None:
            origin = tracked(repo, original_plan['snapshotCommit'], row['path'])
            if origin is None or source(repo, base, row['path']) != source(repo, original_plan['snapshotCommit'], row['path']):
                fail('existing current document needs explicit rebase/review: ' + row['path'])
        current_docs.append({'path': row['path'], 'before': source(repo, base, row['path']).decode() if old else None,
                             'gitMode': old['gitMode'] if old else '100644', 'gitBlob': old['gitBlob'] if old else None,
                             'after': data.decode(), 'afterSha256': digest(data)})
    rule_cards = []
    for row in candidate['ruleCardNavigationPlan']:
        text = source(repo, base, row['path']).decode()
        before = text
        for change in row['onlyLinkEdits']:
            # Match an actual Markdown href, not a code block/string occurrence.
            needle = '](' + change['from'] + ')'
            if needle not in text:
                fail('rule-card href anchor missing: ' + row['path'] + ' ' + needle)
            text = text.replace(needle, '](' + change['to'] + ')', 1)
        original = tracked(repo, base, row['path'])
        rule_cards.append({'path': row['path'], 'gitMode': original['gitMode'], 'gitBlob': original['gitBlob'],
                           'before': before, 'after': text,
                           'beforeSha256': digest(before.encode()), 'afterSha256': digest(text.encode())})

    adaptations = io_candidates(repo, base)
    original_policy = source(repo, base, POLICY_ORIGIN)
    policy = json.loads(original_policy)
    policy_text = original_policy.decode()
    file_changes = []
    for old_path in dict.fromkeys(row['file'] for row in policy):
        new_path = routes.get(old_path, old_path)
        if tracked(repo, base, new_path) is None:
            fail('policy target not in explicit base: ' + new_path)
        if new_path != old_path:
            old_field = '"file": ' + json.dumps(old_path)
            new_field = '"file": ' + json.dumps(new_path)
            expected = sum(r['file'] == old_path for r in policy)
            policy_text = replace(policy_text, old_field, new_field, expected)
            file_changes.append({'from': old_path, 'to': new_path, 'rows': expected})
    policy_next = json.loads(policy_text)
    for old, new in zip(policy, policy_next):
        if dict(old, file=routes.get(old['file'], old['file'])) != new:
            fail('policy changes more than exact file route')
    if tracked(repo, base, POLICY_CURRENT) is not None:
        fail('current policy already exists; review and reconcile before migration')

    prettier_before = source(repo, base, '.prettierignore')
    prettier_after = replace(prettier_before.decode(), 'docs/refactor/generated/\n',
        '# 仅原字节历史归档由 origin-paths manifest 逐项守卫；当前源码、测试与新文档仍参加格式检查。\n/docs/history/expansion/**\n!/docs/history/expansion/README.md\n/docs/history/refactor/**\n!/docs/history/refactor/README.md\n')
    # Original historical content is never formatted or rewritten by this tool.
    targets = {r['currentPath'] for r in originals}
    if len(targets) != len(originals) or targets.intersection(r['path'] for r in current_docs):
        fail('archive/current candidate collision; keep original files and choose new current landing-page path')
    if tracked(repo, base, ORIGIN_INDEX) is not None:
        fail('origin index already exists; incremental history reconciliation needs explicit review')

    payload = {
        'schema': SCHEMA, 'baseCommit': base, 'requestedBase': args.base,
        'candidateManifestSha256': digest((candidates / 'candidate-manifest.json').read_bytes()),
        'sourceMapSha256': digest(mapping_data),
        'basenamePathSpecSha256': digest(basename_input), 'basenameTargets': basename_targets,
        'history': originals, 'currentDocs': current_docs, 'ruleCards': rule_cards,
        'adaptations': adaptations,
        'policy': {'origin': POLICY_ORIGIN, 'path': POLICY_CURRENT, 'beforeSha256': digest(original_policy),
                   'after': policy_text, 'afterSha256': digest(policy_text.encode()), 'fileChanges': file_changes},
        'prettier': {'path': '.prettierignore', 'before': prettier_before.decode(), 'after': prettier_after,
                     'beforeSha256': digest(prettier_before), 'afterSha256': digest(prettier_after.encode())},
        'scope': 'Metadata capture only; no historical blob copies, repository mutations, checks or execution approval.',
    }
    bundle.mkdir(parents=True)
    data = canonical(payload)
    (bundle / 'prepared.json').write_bytes(data)
    (bundle / 'prepared.sha256').write_text(digest(data) + '\n')
    print(json.dumps({'baseCommit': base, 'historyFiles': len(originals), 'currentPages': len(current_docs),
                      'ruleCards': len(rule_cards), 'preparedSha256': digest(data)}))

def load_bundle(bundle, base):
    data = (bundle / 'prepared.json').read_bytes()
    if digest(data) != (bundle / 'prepared.sha256').read_text().strip():
        fail('prepared manifest digest drift')
    value = json.loads(data)
    if value['schema'] != SCHEMA or value['baseCommit'] != base:
        fail('explicit base or schema mismatch')
    return value

def exact_text(repo, row, before=True):
    wanted = row['before'] if before else row['after']
    if wanted is None:
        absent(repo, row['path'])
    else:
        actual, mode = workspace_bytes(repo, row['path'])
        if actual != wanted.encode() or mode != row.get('gitMode', '100644'):
            fail('current file drift: ' + row['path'])

def write_file(repo, relative, data, mode='100644'):
    target = repo / safe_relative(relative)
    parent = target.parent
    while parent != repo:
        if parent.is_symlink():
            fail('write ancestor symlink')
        parent = parent.parent
    target.parent.mkdir(parents=True, exist_ok=True)
    # Same-directory exclusive temp + replace is a single-file publish, not a multi-file transaction.
    temp = target.with_name(target.name + '.c43-publish-tmp')
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o755 if mode == '100755' else 0o644)
    with os.fdopen(fd, 'wb') as out:
        out.write(data)
    os.chmod(temp, 0o755 if mode == '100755' else 0o644)
    os.replace(temp, target)

def journal(bundle, phase, event):
    with (bundle / (phase + '-journal.jsonl')).open('a') as out:
        out.write(json.dumps(event, ensure_ascii=False) + '\n')

def apply_current(args, repo, bundle, prepared):
    if not args.apply:
        fail('mutation requires --apply')
    for row in prepared['currentDocs']:
        exact_text(repo, row)
    journal(bundle, 'current', {'status': 'all_preconditions_passed', 'baseCommit': prepared['baseCommit']})
    for row in prepared['currentDocs']:
        write_file(repo, row['path'], row['after'].encode(), row['gitMode'])
        journal(bundle, 'current', {'written': row['path'], 'sha256': row['afterSha256']})
    journal(bundle, 'current', {'status': 'published_current_pages_history_links_pending_not_C43_complete'})

def history_inventory(repo):
    result = set()
    for prefix in HISTORY_ROOTS:
        root = repo / prefix
        if not root.exists():
            continue
        for directory, dirs, files in os.walk(root, followlinks=False):
            for name in list(dirs):
                p = Path(directory) / name
                if p.is_symlink():
                    fail('historical directory symlink: ' + str(p))
            for name in files:
                result.add(str((Path(directory) / name).relative_to(repo)))
    return result

def origin_index(prepared):
    return {
        'schema': 'awa-history-origin-index-v1', 'originCommit': prepared['baseCommit'],
        'purpose': 'Exact original bytes/mode/source location; not a runtime resolver or acceptance result.',
        'files': [{'originPath': row['path'], 'currentPath': row['currentPath'],
                   'originCommit': prepared['baseCommit'], 'originalGitBlob': row['gitBlob'],
                   'mode': row['gitMode'], 'bytes': row['bytes'], 'sha256': row['sha256']}
                  for row in prepared['history']],
    }

def apply_history(args, repo, bundle, prepared):
    if not args.apply:
        fail('mutation requires --apply')
    if history_inventory(repo) != {r['path'] for r in prepared['history']}:
        fail('history inputs differ from explicit Git capture, including untracked additions')
    for row in prepared['history']:
        expect_workspace(repo, row)
        absent(repo, row['currentPath'])
    for row in prepared['currentDocs']:
        exact_text(repo, row, False)
    for row in prepared['ruleCards'] + prepared['adaptations']:
        exact_text(repo, row)
    exact_text(repo, prepared['prettier'])
    absent(repo, POLICY_CURRENT)
    absent(repo, ORIGIN_INDEX)
    journal(bundle, 'history', {'status': 'all_preconditions_passed', 'baseCommit': prepared['baseCommit']})
    # Stop on first exception. Journal + original Git are recovery inputs; no claim of multi-file atomicity.
    for row in prepared['history']:
        target = repo / row['currentPath']
        target.parent.mkdir(parents=True, exist_ok=True)
        os.rename(repo / row['path'], target)
        journal(bundle, 'history', {'moved': row['path'], 'to': row['currentPath'], 'sha256': row['sha256']})
    for row in prepared['ruleCards'] + prepared['adaptations']:
        write_file(repo, row['path'], row['after'].encode(), row.get('gitMode', '100644'))
        journal(bundle, 'history', {'written': row['path'], 'sha256': row['afterSha256']})
    write_file(repo, POLICY_CURRENT, prepared['policy']['after'].encode())
    write_file(repo, '.prettierignore', prepared['prettier']['after'].encode())
    index = canonical(origin_index(prepared))
    write_file(repo, ORIGIN_INDEX, index)
    journal(bundle, 'history', {'index': ORIGIN_INDEX, 'sha256': digest(index), 'status': 'writes_finished_guard_required'})
    verify_history(repo, prepared)

def verify_history(repo, prepared):
    # This integrity guard must run before treating archive roots as format-exempt evidence.
    if (repo / ORIGIN_INDEX).read_bytes() != canonical(origin_index(prepared)):
        fail('origin index content changed')
    archived = set()
    for prefix in ARCHIVE_ROOTS:
        for directory, dirs, files in os.walk(repo / prefix, followlinks=False):
            for name in dirs:
                if (Path(directory) / name).is_symlink():
                    fail('archive directory symlink')
            for name in files:
                archived.add(str((Path(directory) / name).relative_to(repo)))
    expected = {r['currentPath'] for r in prepared['history']}
    current_landing = {r['path'] for r in prepared['currentDocs'] if r['path'].startswith(ARCHIVE_ROOTS)}
    if archived != expected | current_landing:
        fail('archive path set differs, including unknown additions')
    for row in prepared['history']:
        expect_workspace(repo, row, 'currentPath')
        if (repo / row['path']).exists() or (repo / row['path']).is_symlink():
            fail('old historical duplicate remains: ' + row['path'])
    for row in prepared['currentDocs'] + prepared['ruleCards'] + prepared['adaptations']:
        exact_text(repo, row, False)
    for row in (prepared['policy'], prepared['prettier']):
        if (repo / row['path']).read_bytes() != row['after'].encode():
            fail('live adaptation drift: ' + row['path'])
    if history_inventory(repo):
        fail('old roots contain unexpected files')
    print(json.dumps({'integrity': 'all_captured_history_bytes_modes_and_live_inputs_match',
                      'baseCommit': prepared['baseCommit'], 'historyFiles': len(prepared['history']),
                      'notClaimed': 'No type/test/gate/P9 or arbitrary external-link acceptance.'}))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare', 'apply-current', 'apply-history', 'verify-history'])
    parser.add_argument('--repo', required=True)
    parser.add_argument('--base', required=True)
    parser.add_argument('--bundle', required=True)
    parser.add_argument('--candidates')
    parser.add_argument('--source-map')
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    repo = Path(args.repo).resolve()
    bundle = Path(args.bundle).resolve()
    if bundle == repo or repo in bundle.parents:
        fail('bundle must be outside repository; do not insert new evidence into the history being captured')
    base = base_commit(repo, args.base)
    if args.command == 'prepare':
        if not args.candidates or not args.source_map:
            fail('prepare requires --candidates and --source-map')
        prepare(args, repo, base, bundle)
    else:
        prepared = load_bundle(bundle, base)
        if args.command == 'apply-current':
            apply_current(args, repo, bundle, prepared)
        elif args.command == 'apply-history':
            apply_history(args, repo, bundle, prepared)
        else:
            verify_history(repo, prepared)

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('C43 migration stopped: ' + str(error), file=sys.stderr)
        sys.exit(1)
