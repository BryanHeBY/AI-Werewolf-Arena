# C43 当前入口与后继证据伴随候选

只在 TMP，四路径；冻结 v3 完整算法及包保持不变。Root 已明确选择 `14e7951787f4464573407a7bcc270303a3975856` 为实际 C43 捕获基线并绑定根命令；C43 尚未因此被声明通过，本文没有执行候选。

## Root 应用顺序

1. 原 C43 捕获基线已由 Root 指定为 `14e7951787f4464573407a7bcc270303a3975856`；按此 v3 prepare/两阶段迁移/守卫实际形成 origin index，不改回 HEAD 或另猜 hash。
2. 对当时完整 package、新工具 absence 和已发布两 current 文档重新采真实 before，按 exact anchor 核对本候选；若已有平行变化停止核实，不能 wholefile 覆盖。
3. 新工具按 100644 落 current tooling owner。仅中文 docstring/help 和维护注释不同；原函数、判断、错误、流式原字节、成员与 owner executable 核仍照 v3。
4. 根 check:history 填上述同一 fullSHA，check strict 后接一次。不把 prepare、apply、guard 或根 aggregate 的准备态当成功收据；直接 guard 与完整 check 按当次需要择一，避免同输入重复。
5. 新小 JSON/MD 先格式化再 freeze，封 acceptance tar.gz 后按不透明原字节、成员和摘要登记。后继 stager 必须采用新 current/acceptance 路径；不保旧 docs/refactor 壳，不向两冻结根追加。

## 范围

持久守卫保历史字节不变；current 进度和将来矩阵独立维护。acceptance 不在该守卫所比较的两个旧历史根里，需当次 scope/收据/非作者另核。没有新增格式豁免、matrix 假数据、新 service/harness，也不改游戏、工具 machine error 文本或原 frozen hash。

`before.json` 区分实际当前 package Git 来源和 v3 候选来源；`edits.json` 给完整精确片段，`candidate.patch` 供逐处审核。不能把 candidates 全文用于覆盖后继真实源码或 imports。
