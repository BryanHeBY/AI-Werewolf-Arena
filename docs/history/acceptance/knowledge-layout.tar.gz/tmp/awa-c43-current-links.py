"""核对本次73份现行文档的本地href实物；不改历史正文，不把文件存在冒作标题锚点验收。"""
import pathlib, json, re, urllib.parse
root = pathlib.Path('/home/hby/dev/AI-Werewolf-Arena')
prepared = json.loads(pathlib.Path('/tmp/awa-c43-actual-14e79517/prepared.json').read_text())
paths = sorted({r['path'] for r in prepared['currentDocs']+prepared['ruleCards']})
links, failures = [], []
for p in paths:
    lines, fence = [], None
    for line in (root/p).read_text().splitlines():
        m = re.match(r'^\s*(`{3,}|~{3,})', line)
        if m:
            marker = m[1][0]
            fence = None if fence == marker else marker
            continue
        if fence is None:
            # 行内代码中的示例href不是导航；真实行内链接在移除代码段后检查。
            lines.append(re.sub(r'(`+).*?\1', '', line))
    text = '\n'.join(lines)
    hrefs = [m.group(1) or m.group(2) for m in re.finditer(r'\[[^\]]*\]\((?:<([^>]+)>|([^\s)]+))(?:\s+[^)]*)?\)',text)]
    hrefs += [m.group(1) for m in re.finditer(r'^\s*\[[^\]]+\]:\s*<?([^\s>]+)>?',text,re.M)]
    for href in hrefs:
        if href.startswith(('#','http:','https:','mailto:','data:')): continue
        target = urllib.parse.unquote(href.split('#')[0].split('?')[0])
        actual = (root/p).parent/target
        record = {'source':p,'href':href,'resolved':str(actual.resolve().relative_to(root)) if actual.resolve().is_relative_to(root) else str(actual.resolve())}
        links.append(record)
        if not actual.exists():failures.append(record)
report = {'files':len(paths),'localLinks':len(links),'failures':failures,'links':links,
          'limits':['仅本次current73页文件/目录目标，跳过代码示例、外网与fragment；不重写原history相对链接，不验证heading anchor。']}
pathlib.Path('/tmp/awa-c43-current-links-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(paths),'localLinks':len(links),'failures':len(failures)}))
if failures:raise SystemExit(1)
