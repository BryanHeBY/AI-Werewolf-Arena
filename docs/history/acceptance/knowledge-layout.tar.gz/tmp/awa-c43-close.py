#!/usr/bin/env python3
"""封存 C43 的真实阶段与已存在输出；只建交付材料，不执行产品或检查器。"""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/hby/dev/AI-Werewolf-Arena')
DEST = ROOT / 'docs/history/acceptance'
BASE = '14e7951787f4464573407a7bcc270303a3975856'
PREFIX = 'knowledge-layout'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert not git('diff', '--cached', '--name-only')
origin = json.loads((ROOT / 'docs/history/origin-paths.json').read_text())
old = {row['originPath'] for row in origin['files']}
new = {row['currentPath'] for row in origin['files']}
deleted = {p.decode() for p in git('diff', '--diff-filter=D', '--name-only', '-z').split(b'\0') if p}
assert deleted == old and len(old) == 5511
# 历史成员已经由独立守卫核验；封包只收来源索引，不重复复制这一全集。
changed = {p.decode() for p in git('diff', '--diff-filter=ACMRT', '--name-only', '-z').split(b'\0') if p}
untracked = {p.decode() for p in git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0') if p}
untracked -= new
untracked = {p for p in untracked if not p.startswith('docs/history/acceptance/')}
allowed = ('docs/architecture/', 'docs/contracts/', 'docs/decisions/', 'docs/guides/', 'docs/history/', 'tooling/refactor/')
assert all(p.startswith(allowed) for p in untracked), sorted(untracked)
source = sorted(changed | untracked)
source_rows = []
for name in source:
    path = ROOT / name
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    previous = subprocess.run(['git', 'cat-file', '-e', f'{BASE}:{name}'], cwd=ROOT, capture_output=True)
    before = None
    if previous.returncode == 0:
        raw = git('show', f'{BASE}:{name}')
        before = {'sha256': sha(raw), 'bytes': len(raw), 'gitBlob': git('rev-parse', f'{BASE}:{name}').decode().strip()}
    source_rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data), 'mode': '100755' if path.stat().st_mode & 0o100 else '100644', 'before': before})
write_json(DEST / f'{PREFIX}.scope.json', {
    'schema': 1, 'baseCommit': BASE,
    'purpose': 'C43实际来源与最终文件身份；不是全量门禁或逐机制完成矩阵。',
    'historyMoves': {'count': len(old), 'bytes': sum(row['bytes'] for row in origin['files']), 'index': 'docs/history/origin-paths.json', 'sha256': sha((ROOT / 'docs/history/origin-paths.json').read_bytes())},
    'liveSourceCount': len(source_rows), 'source': source_rows,
    'excludedMetadata': ['knowledge-layout.md', 'knowledge-layout.receipts.json', 'knowledge-layout.evidence.json', 'knowledge-layout.scope.json', 'knowledge-layout.peer-review.json', 'knowledge-layout.tar.gz'],
})

# 每项分别保留自己的调用、终态及原输出，不能把修复前后合成一次绿。
phases = [
    ('prepare', ['d08e77'], 0, '/tmp/awa-c43-prepare-output.txt', '实际14e795捕获；不变更历史'),
    ('apply-current', ['26dddb'], 0, '/tmp/awa-c43-apply-current-output.txt', '发布现行资料与I/O'),
    ('apply-history-first', ['a9e3b9'], 1, '/tmp/awa-c43-apply-history-output.txt', '预检拒绝两个未捕获日志，未迁移'),
    ('quarantine-rename', ['44d41a'], 1, None, 'os.rename跨文件系统EXDEV，未移动文件'),
    ('apply-history-second-precheck', ['bf5523'], 1, '/tmp/awa-c43-apply-history-successor-output.txt', '同一残留预检仍拒绝，未迁移'),
    ('quarantine-copy-verify', ['da3282'], 0, '/tmp/awa-c43-uncaptured-workspace-logs/manifest.json', '复制核对两日志再移出旧根；37322 bytes'),
    ('apply-history-final', ['c98336', 'session:9053', 'd947cb'], 0, '/tmp/awa-c43-apply-history-final-output.txt', '5511原成员迁移及精确核验'),
    ('apply-companion', ['b33c91'], 0, '/tmp/awa-c43-companion-actual/before-after.json', '四文件12精确修改，实际阶段前态'),
    ('history-guard', ['d30e6b', 'session:64533', '154fe1'], 0, '/tmp/awa-c43-portable-guard-output.txt', '5511项原字节一致'),
    ('backend-io-tests', ['183cbb', 'session:68282', '23466e'], 0, '/tmp/awa-c43-backend-io-tests-output.txt', '17 pass /0 fail /30 expect'),
    ('fixture-io-first', ['ce6eb8', 'session:9247', '7005d3'], 1, '/tmp/awa-c43-fixture-io-tests-output.txt', '23 pass /2 fail /119 expect'),
    ('derived-cache-diagnostic', ['14e0b3'], 0, '/tmp/awa-c43-derived-manifest-differences.json', '251清单1004标量；不是全局生成验收'),
    ('fixture-repair-first-prewrite', ['83275a'], 1, '/tmp/awa-c43-fixture-repair-apply-output.txt', 'KeyError before；写入前退出'),
    ('fixture-repair-apply', ['5bc949'], 0, '/tmp/awa-c43-fixture-repair-apply-successor-output.txt', '252文件精确应用；904归档与13控制未变'),
    ('fixture-failed-only', ['b8cfab', 'session:78298', '003fb6'], 0, '/tmp/awa-c43-fixture-failed-only-output.txt', '2 pass /0 fail /14 filtered /9 expect'),
    ('current-link-scan', ['29ef4a'], 0, '/tmp/awa-c43-current-links-report.json', '73页267本地目标0missing；不是锚点/HTML全语法检查'),
    ('current-format', ['af16dc', 'session:34512', 'f7ab66'], 0, '/tmp/awa-c43-current-format-receipt.json', '76选择，仅9份表格格式变化'),
    ('final-pages-format', ['6c4878'], 0, '/tmp/awa-c43-final-pages-format-output.txt', '最后三个现行页面及新增acceptance MD正常格式化，再冻结scope'),
]
rows = []
for name, calls, code, raw, boundary in phases:
    row = {'phase': name, 'rootToolReceipts': calls, 'exitCode': code, 'boundary': boundary}
    if raw:
        p = Path(raw)
        assert p.is_file(), raw
        row['raw'] = {'archivePath': 'tmp/' + p.name if p.parent == Path('/tmp') else 'tmp/' + str(p.relative_to('/tmp')), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
    else:
        row['raw'] = None
        row['limitation'] = '原工具输出身份保留；未另外伪造stdout文件。'
    rows.append(row)
write_json(DEST / f'{PREFIX}.receipts.json', {'schema': 1, 'baseCommit': BASE, 'executionOwner': 'Root', 'phases': rows, 'notExecuted': ['C47最终全量门禁', '付费模型', '私有配置或认证', '网络安装或push']})

inputs = [
    '/tmp/awa-c43-docs-owned-layout-v2',
    '/tmp/awa-c43-docs-owned-layout-v3',
    '/tmp/awa-c43-docs-owned-layout-v3-first-f525-snapshot',
    '/tmp/awa-c43-docs-owned-layout-v3-assembly-first-snapshot',
    '/tmp/awa-c43-docs-owned-layout-v3-independent',
    '/tmp/awa-c43-actual-14e79517',
    '/tmp/awa-c43-actual-delivery-review',
    '/tmp/awa-c43-current-contract-companion',
    '/tmp/awa-c43-current-contract-companion-first-ff3792f5',
    '/tmp/awa-c43-current-contract-companion-independent',
    '/tmp/awa-c43-companion-actual',
    '/tmp/awa-c43-fixture-io-repair',
    '/tmp/awa-c43-fixture-io-repair-actual',
    '/tmp/awa-c43-uncaptured-workspace-logs',
    '/tmp/awa-c43-fixture-io-repair-independent-review.json',
    '/tmp/awa-c43-current-format-before.json',
    '/tmp/awa-c43-current-format-receipt.json',
    '/tmp/awa-c43-current-links.py',
    '/tmp/awa-c43-current-links-report.json',
    '/tmp/awa-c43-fixture-repair-apply-first-keyerror.py',
    '/tmp/awa-c43-fixture-repair-apply.py',
    '/tmp/awa-c43-derived-manifest-differences.json',
    '/tmp/awa-owned-layout-map.json',
    '/tmp/awa-c43-close.py',
    '/tmp/awa-request-candidate-completion-boundary',
    '/tmp/awa-c43-close-independent',
]
inputs += [raw for _, _, _, raw, _ in phases if raw]
inputs += [str(p) for p in Path('/tmp').glob('awa-c43-*-output.txt')]
members = {}
for name in inputs:
    path = Path(name)
    assert path.exists(), name
    leaves = sorted(path.rglob('*')) if path.is_dir() else [path]
    for p in leaves:
        assert not p.is_symlink(), str(p)
        if p.is_file():
            members['tmp/' + str(p.relative_to('/tmp'))] = p
archive = DEST / f'{PREFIX}.tar.gz'
index = []
# 固定元数据便于核对成员；摘要绑定实际字节，不依赖打包时间或TMP绝对目录。
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, path in sorted(members.items()):
                data = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o755 if path.stat().st_mode & 0o100 else 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
                index.append({'path': name, 'bytes': len(data), 'sha256': sha(data), 'mode': oct(info.mode)})
write_json(DEST / f'{PREFIX}.evidence.json', {'schema': 1, 'archive': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'members': index, 'scope': '仅本次准备/执行/审查材料；原历史5511项由origin索引及原Git绑定，不再次打包。'})
print(json.dumps({'source': len(source_rows), 'history': len(old), 'archiveMembers': len(index), 'archiveBytes': archive.stat().st_size, 'archiveSha256': sha(archive.read_bytes())}, ensure_ascii=False))
