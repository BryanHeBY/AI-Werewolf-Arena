"""应用两个失败用例的最小输入修补与派生摘要；不生成归档或修改验收状态。"""
from pathlib import Path
import json, hashlib, stat
root = Path('/home/hby/dev/AI-Werewolf-Arena')
bundle = Path('/tmp/awa-c43-fixture-io-repair')
out = Path('/tmp/awa-c43-fixture-io-repair-actual')
assert not out.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
p = json.loads((bundle/'proposal.json').read_text())
before = {r['path']:r for r in json.loads((bundle/'before.json').read_text())['source']}
edits = json.loads((bundle/'deltas.json').read_text())['edits']
controls = json.loads((bundle/'controls.json').read_text())
def guard():
    for r in controls['readOnlySource']+controls['archiveInputs']:
        b = (root/r['path']).read_bytes()
        assert sha(b) == r['sha256'] and len(b) == r['bytes'],r['path']
guard()
rows = []
for r in p['source']:
    path = root/r['path']; info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
    old = path.read_bytes()
    assert sha(old) == r['beforeSha256'] and old.decode() == before[r['path']]['text']
    text = old.decode(); selected = [e for e in edits if e['path'] == r['path']]
    if r['kind'] == 'four-scalar-derived-local-metadata':
        # JSON 标量用已审的双坐标范围，不能全局替换重复数字或把中文字符数当 UTF-8 字节数。
        for e in sorted(selected,key=lambda x:x['offsetCodepoints'],reverse=True):
            start,end=e['offsetCodepoints'],e['endCodepoints']
            assert old[e['offsetUtf8Bytes']:e['endUtf8Bytes']].decode() == e['beforeLiteral']
            assert text[start:end] == e['beforeLiteral']
            text = text[:start]+e['afterLiteral']+text[end:]
        for e in selected:
            start=e['candidateOffsetCodepoints']
            assert text[start:start+len(e['afterLiteral'])] == e['afterLiteral']
    else:
        for e in selected:
            assert text.count(e['before']) == e['count']
            text = text.replace(e['before'], e['after'])
    assert sha(text.encode()) == r['candidateSha256']
    assert text.encode() == (bundle/'candidates'/r['path']).read_bytes()
    if r['kind'] == 'four-scalar-derived-local-metadata':
        assert len(selected) == 4 and len(old) == len(text.encode())
        a,b = json.loads(old),json.loads(text)
        for asset, next_asset in zip(a['sourceAssets'],b['sourceAssets']):
            for key in ('currentSha256','currentBytes'):
                asset[key] = next_asset[key]
        assert a == b
    rows.append((r,text))
assert len(rows) == 252
out.mkdir()
with (out/'journal.jsonl').open('x') as journal:
    for r,text in rows:
        (root/r['path']).write_bytes(text.encode())
        journal.write(json.dumps({'path':r['path'],'sha256':r['candidateSha256']})+'\n'); journal.flush()
guard()
for r,_ in rows: assert sha((root/r['path']).read_bytes()) == r['candidateSha256']
report = {'source':len(rows),'localManifestScalarEdits':1004,'testInputEdits':1,
          'unchangedSourceControls':13,'unchangedArchiveBytes':904,
          'limits':['只变两支持源的当前摘要及负例合法输入闭包；原协议/接受状态/归档不改。','未执行generator、类型或测试；失败用例由Root后继单独运行。']}
(out/'apply.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
