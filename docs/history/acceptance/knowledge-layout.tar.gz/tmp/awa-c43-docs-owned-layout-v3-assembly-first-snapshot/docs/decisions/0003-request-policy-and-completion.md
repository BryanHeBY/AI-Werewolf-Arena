# ADR 0003：请求协议分类与领域完成

## 选择

复用RequestLease与RequestDelivery保存原登记、scope、alias传播、预算和一次完成；不新建平行lease framework。每协议显式决定共享域失效、alias自身失配、expiry和paid边界。

采用F02的窗口，正确观察原envelope／domain／earliest过期后单调关闭；已登记alias自己坏只退自己；unknown／wrong-owner不毒original。dynamic actor／phase／day／stage和声明pins是新可观察输入政策，不称机械等价。

## 理由

真实原行为characterization曾表明字段恢复可重新返回同scope；这不是凭静态布尔推断的“已验证漏洞”。修正需明确接受面与新预期，不能用新window策略统一所有既有复杂authority。

provider返回、gateway接受和领域全部付款是三点。Trace若即时settle会丢失partial与晚错误意义，真实窗口必须在全领域成功后通知true。晚facts或通知错不得二结算，false通知也不能覆盖原body／cleanup错误。

## 后果

Wall 每作者、Cupid／Hybrid 每实际 request、LastWords 每真实 permit 分别完成。Seer 普通夜请求和死亡警徽选择采用各自领域 true 点；不能只凭 provider 返回或首字段写入即完成，部分失败仍 false 并保实际前缀，晚事实失败保 true。Ghost retained first consent 的共享失效与 second 自身 proof 坏分开；已付 chat／knife 保原规则。Animal／Fragrant／Noble 不因不同就自动改成同协议。

来源：[普通 Seer／警徽领域完成](../history/refactor/ordinary-native-badge-request-completion.md)、[C18a四协议](../history/refactor/request-lease-terminal-revocation.md)、[关系窗口](../history/refactor/cupid-hybrid-request-lease-completion.md)、[LastWords](../history/refactor/last-words-request-lease.md)、[Ghost](../history/refactor/ghost-bride-request-terminal-revocation.md)、[Demon](../history/refactor/demon-request-terminal-revocation.md)。
