# 关键决策索引

本目录只登记当前仍有效的选择与理由。各记录区分“接受的政策”与“每个consumer已经完成接入”；不能把ADR写成验收结果。

| 决策 | 状态／适用边界 |
| --- | --- |
| [0001 数据与运行授权分离](0001-data-and-runtime-authority.md) | 已采用；各族宽接受面独立 |
| [0002 实际Camp与执行退休](0002-camp-and-execution-retirement.md) | 已采用；不统一撤销paid效果 |
| [0003 请求协议与领域完成](0003-request-policy-and-completion.md) | 已批准／分协议接入；不是全族同一终态政策 |
| [0004 档案、身份与证据](0004-archive-identities-and-evidence.md) | 已采用；最终兼容矩阵另验 |
| [0005 按稳定职责组织目录](0005-owned-layout-and-public-apis.md) | 已批准目标，具体物理迁移落盘后才验收 |

历史总体决策原文和每次反例在[history](../history/README.md)，不原地覆盖旧理由或把旧停止条件当当前授权。新增／替代决策写明旧轨迹、接受面、consumer、失败前缀、版本及独立证据。
