# 验证与证据范围

## 固定输入优先

先声明实际Git、唯一source范围、互斥owner、旧全文／新absence、controls与依赖阶段。检查记录命令、cwd、输入SHA、原stdout、真实退出和executor；空输出或进程启动不证明通过。首次工具错误、配置错误和产品错误分别保留。

局部纯comments用完整非注释AST／NodeArray／叶、JSDoc类型／指令保护及两emit证明和有限职责头；不因注释重复业务／类型绿。物理路径用完整program正逆、原目标binding／初始化顺序、活跃元路径和集中类型。行为政策先真实characterization，另写有业务区分力的独立字面预期；不能把新结果冒称原等价。

## 当前根命令

```bash
bun --no-env-file run check
bun --no-env-file run lint
bun --no-env-file run format:check
bun --no-env-file run test
```

根脚本仍会调用各workspace子脚本，准确范围以当前package.json／实际命令收据为准。它们是可执行入口，不表示本候选已经运行或全部离线传输都被涵盖。

分层定向时从unit／integration／scenarios／architecture选择真实主目标；runner发现不能因改路径、排除文件或alias而丢测试。真实SDK假HTTP、stdio MCP／ACP、CLI、filesystem和浏览器是不同层，不能由mock单元代替。

## 最后合流

最终固定同一候选输入，按完整计划完成：结构零债／命名／职责中文与内容审查、全生产／测试／脚本／包／tooling类型、fixture原字节与binding、全部发现和所需离线单元／整局／失败／本机通信、两语browser／video及严格兼容矩阵。不得把该列表当每个微提交都重复全套的指令。

首红按具体原因修，限定失败／真实变化根再查；保持旧绿原采样，不伪称末source同输入重绿。统计不同declaration、fixture invocation、expect执行和filtered分别列，不累加重复为不同用例。

## 独立预期与最终登记

预期来自规则来源、手写座位／库存／trace／同Error，不调用生产结算生成oracle；verifier也不能由同一生产规则函数背书。Root或非作者核真输入／语义／部分失败与中文真实性，不能只签hash。

最后矩阵逐真实职责登记owner／commit／证据与业务性N/A；历史pending和结构linter清债都不自动决定机制完成。没有完整同源证据时保明确边界，不标P9完成。
