#!/usr/bin/env python3
"""Portable read-only archive byte/mode guard, prepared but not executed.

Future usage requires the explicit actual capture commit. It independently reads
that Git tree rather than trusting an edited manifest to approve changed history.
It is not a Markdown link checker or a substitute for type/test/architecture gates.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys

ROOTS = ('docs/expansion/', 'docs/refactor/')
TARGETS = ('docs/history/expansion/', 'docs/history/refactor/')
CURRENT_INDEX_PAGES = {'docs/history/expansion/README.md', 'docs/history/refactor/README.md'}

def fail(message):
    raise RuntimeError(message)

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def safe(value):
    path = PurePosixPath(value)
    if path.is_absolute() or '..' in path.parts or '\\' in value or str(path) != value:
        fail('unsafe path')
    return value

def bytes_mode(repo, relative):
    target = repo / safe(relative)
    parent = target.parent
    while parent != repo:
        if parent.is_symlink():
            fail('symlink directory: ' + str(parent))
        parent = parent.parent
    if target.is_symlink():
        return os.readlink(target).encode(), '120000'
    if not target.is_file():
        fail('missing ordinary archive file: ' + relative)
    return target.read_bytes(), '100755' if target.stat().st_mode & 0o111 else '100644'

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', required=True)
    p.add_argument('--base', required=True)
    p.add_argument('--manifest', default='docs/history/origin-paths.json')
    a = p.parse_args()
    if a.base in ('HEAD', '@'):
        fail('pass the explicit captured commit')
    repo = Path(a.repo).resolve()
    base = git(repo, 'rev-parse', '--verify', a.base + '^{commit}').decode().strip()
    manifest_bytes, manifest_mode = bytes_mode(repo, a.manifest)
    if manifest_mode == '120000':
        fail('manifest must not be a symlink')
    manifest = json.loads(manifest_bytes)
    if manifest['schema'] != 'awa-history-origin-index-v1' or manifest['originCommit'] != base:
        fail('manifest/base identity mismatch')
    rows = manifest['files']
    expected = {}
    for entry in git(repo, 'ls-tree', '-rz', '--full-tree', base, '--', 'docs/expansion', 'docs/refactor').split(b'\0'):
        if not entry:
            continue
        info, name = entry.split(b'\t', 1)
        mode, kind, oid = info.decode().split()
        if kind != 'blob' or mode not in ('100644', '100755', '120000'):
            fail('unsupported Git object')
        expected[name.decode()] = (mode, oid)
    if len(rows) != len(expected) or {r['originPath'] for r in rows} != set(expected):
        fail('manifest is not the entire explicit Git history input set')
    batch = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for row in rows:
            origin = safe(row['originPath'])
            current = safe(row['currentPath'])
            if not origin.startswith(ROOTS) or current != origin.replace('docs/', 'docs/history/', 1):
                fail('non-exact origin/target mapping')
            if row['originCommit'] != base or expected[origin] != (row['mode'], row['originalGitBlob']):
                fail('manifest changes original Git mode/blob')
            batch.stdin.write((row['originalGitBlob'] + '\n').encode())
            batch.stdin.flush()
            header = batch.stdout.readline().decode().strip().split()
            if len(header) != 3 or header[0] != row['originalGitBlob'] or header[1] != 'blob':
                fail('Git object unavailable')
            size = int(header[2]); remaining = size; h = hashlib.sha256()
            while remaining:
                data = batch.stdout.read(min(remaining, 1024 * 1024))
                if not data:
                    fail('truncated Git object')
                h.update(data); remaining -= len(data)
            if batch.stdout.read(1) != b'\n' or size != row['bytes'] or h.hexdigest() != row['sha256']:
                fail('manifest changes original bytes/SHA: ' + origin)
            actual, mode = bytes_mode(repo, current)
            if mode != row['mode'] or len(actual) != size or hashlib.sha256(actual).hexdigest() != row['sha256']:
                fail('archive bytes/mode changed: ' + current)
            if (repo / origin).exists() or (repo / origin).is_symlink():
                fail('old historical duplicate remains: ' + origin)
    finally:
        batch.stdin.close(); batch.stdout.close()
        if batch.wait() != 0:
            fail('Git object reader failed')
    # 原路径逐项缺席还不够：旧根后来新增的文件也不得逃过归档全集守卫。
    # 先拒绝根本身的链接，再枚举真实子目录；空目录不属于 Git 文件集合。
    for prefix in ROOTS:
        old_root = repo / prefix
        if old_root.is_symlink():
            fail('old history root symlink: ' + prefix)
        if not old_root.exists():
            continue
        if not old_root.is_dir():
            fail('old history root is not a retired directory: ' + prefix)
        for directory, dirs, files in os.walk(old_root, followlinks=False):
            for name in dirs:
                if (Path(directory) / name).is_symlink():
                    fail('old history directory symlink')
            if files:
                fail('old history roots contain uncaptured files: ' + str(Path(directory) / files[0]))
    actual_paths = set()
    for root in TARGETS:
        for directory, dirs, files in os.walk(repo / root, followlinks=False):
            for name in dirs:
                if (Path(directory) / name).is_symlink():
                    fail('archive directory symlink')
            actual_paths.update(str((Path(directory) / name).relative_to(repo)) for name in files)
    if actual_paths != {r['currentPath'] for r in rows} | CURRENT_INDEX_PAGES:
        fail('unknown/missing file in format-exempt archive roots')
    for page in CURRENT_INDEX_PAGES:
        if bytes_mode(repo, page)[1] == '120000':
            fail('current history landing page must not be a symlink')
    print(json.dumps({'baseCommit': base, 'historyFiles': len(rows), 'originalGitAndArchiveBytesModes': 'match',
                      'limits': 'No claim about current source, links, runtime behavior or final acceptance.'}))

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('archive integrity guard failed: ' + str(error), file=sys.stderr)
        sys.exit(1)
