# C43 两阶段应用方案（仅准备，未执行）

## 当前准备产物

本目录保存第二版 73 份 current Markdown 候选，整合首次独审 11 条精确修正。旧 `/tmp/awa-c43-docs-owned-layout` 的 73 文件、078 历史表和第一次独审均不覆盖。

`app/checkpoint` 五现场 owner 目标已写明，但所有页面仍标准备态；只在对应物理迁移真实落盘后将这些目标当 current 链接。五纯格式／审计叶留 `recording/reproduction/checkpoint`，独立 verifier 留 `recording/verification`。

新工具源码只准备在 `tools/`，**本次未调用 prepare／apply／verify，也未运行语法检查、类型、测试或 gate**。工具将由维护者在后继真实基线和范围冻结后首执行。它不做 Git add／commit 或恢复他人工作。

## 显式输入

- `--base` 必填，传维护者最后明确选择的实际 commit；拒绝 `HEAD`／`@` 省略式输入。后继实际 commit 不在本稿猜测。
- `--repo` 指真实仓库；`--bundle` 是仓库外全新目录。
- `--candidates` 指本第二版目录；`--source-map` 指经审定的实际物理映射文件。
- 当前 672 map 是 source route 依据，不是任何历史文件总数。旧 5282／5327 只保在旧观察稿，工具没有写死该数量。

命令中的 `$C43_BASE`、`$C43_REPO`、`$C43_BUNDLE`、`$C43_CANDIDATES`、`$C43_SOURCE_MAP` 必须由维护者明确设置。不是本次已执行命令。

```bash
python "$C43_CANDIDATES/tools/docs-migration.py" prepare \
  --repo "$C43_REPO" --base "$C43_BASE" --bundle "$C43_BUNDLE" \
  --candidates "$C43_CANDIDATES" --source-map "$C43_SOURCE_MAP"
```

prepare 从指定 Git `ls-tree -rz` 取得 **所有** `docs/expansion/**` 与 `docs/refactor/**` 的实际 tracked path／mode／blob，流式读 blob 计算 byte SHA／长度，仅保存清单，不复制整仓历史。未来 bundle 保存实际原文的只有 34 个 current 候选前态、39 个规则卡和六个小型当前读点；不是几千个历史证据的正文副本。

规则卡用未来 `--base` 的整页原文，只替 39 卡的 71 个已审 href；新近无关文字保留。其他已有导航页若与旧观察原文不同，工具停止，要求维护者先把新的正文改动合到候选，而不盲覆旧 078 整页。活动 I/O 的精确锚点若漂移也停止，不模糊搜索或扩大替换。

准备结果中的历史数、路径和字节总量全部来自这次明确输入。`prepared.json` 和独立 SHA 固定应用输入；在仓库外保留这份 bundle 供审查／恢复，不能将新 bundle 再写进正在捕获的历史根造成循环。

## 阶段 A：发布 current 提炼页，仍标准备态

```bash
python "$C43_CANDIDATES/tools/docs-migration.py" apply-current \
  --repo "$C43_REPO" --base "$C43_BASE" --bundle "$C43_BUNDLE" --apply
```

范围为 manifest 中的 34 页：新的维护文档与导航，不包含 39 规则卡的历史 href 改动。写前全部核当前文件原字节／模式或新文件不存在，避免覆盖其他作者。banner 保留准备状态，历史物理目录仍在旧处；当前页面里的历史链接要等 B 接通，故 A 单独不能作为 C43 完成发布或正常文档链接验收。

维护者可将两阶段连做后一个原子功能提交；若选择分提交，A 必须明确准备状态和未接历史链接，不得虚称全 current。工具本身不 stage。

## 阶段 B：历史字节归属与当前消费者一起接通

```bash
python "$C43_CANDIDATES/tools/docs-migration.py" apply-history \
  --repo "$C43_REPO" --base "$C43_BASE" --bundle "$C43_BUNDLE" --apply
```

所有前置条件先核，再逐项写入：

1. workspace 历史路径全集与捕获 Git **完全相同**，包括拒绝未跟踪／后来追加文件；每项原 mode／bytes／SHA 一致；所有目标不存在；不能跳过已漂移或不认识的文件。
2. 逐项 `docs/expansion/<r>` → `docs/history/expansion/<r>`、`docs/refactor/<r>` → `docs/history/refactor/<r>`；保持原文件名、Git mode、blob 内容与所有内部原 path／SHA／script／raw／error／停止条款，不能格式化或批改正文。
3. 加 `docs/history/origin-paths.json`。它逐项登记真实 origin commit／path／Git blob／mode／bytes SHA 与 currentPath，只定位资料，不是运行 fallback 或旧 URL redirect。
4. 应用 39 规则卡精确 href 与六个真实 I/O 适配，以及唯一当前 i18n policy。见下节。
5. `.prettierignore` 只将旧不存在的 generated 例外换为两个明确历史子根；新 history 索引页用反选继续参加格式检查。没有新增任何当前 source／test／config 格式例外。
6. 最后依据完整 manifest 核新归档／原根缺席／当前读点和页面字节。源身份因真实读取常量／policy 位置改变，必须按实际构建重新捕获；旧 archive、fixture manifest 的来源身份不回写。

工具会保每一阶段 JSONL journal，遇任何异常立即失败。`os.rename` 与文件发布是逐项操作，**没有声称跨几千文件事务或崩溃自动回滚**。恢复依据为完整 prepared manifest、journal 与原 Git；维护者先定位实际已移项，不靠重复执行自动覆盖。当前页与历史 README 若同名冲突，prepare 先拒绝，不能覆盖原历史 README。

## 精确活动 I/O 与 i18n 政策

| 当前 owner | 唯一后继 | 必须保持 |
| --- | --- | --- |
| `tooling/refactor/architecture/run.ts` | 默认债文件及同宽安全前缀改 `docs/history/refactor` | 债内容／1779 原身份／Git 重生成核对，原祖先 symlink 与 unsafe path 拒绝；不额外放开任意 docs |
| `tooling/refactor/fixture-manifest.ts` | 保 `inventoryPath` 作为旧协议 origin；新增 `inventoryFilePath` 为精确归档 I/O，safeFile 与读取只用后者 | manifest／evidence 的原字段、原 SHA 及实际原字节不改；当前所有 sourceAsset 功能保原 |
| `tooling/refactor/fixture-manifest.test.ts` | 只改真实临时 mkdir／write／cp 的 frozen inventory 落点 | 合成 `baseline.inventoryPath` 原字符串保持，负例原断言与输入保 |
| `backend/tests/architecture/engine-fingerprint-review.test.ts` | 只改原冻结 baseline-source-hash 的 readFile 位置 | 原 commit／六根／hash 及其断言不重算 |
| `backend/scripts/check_i18n_literals.mjs` | 只读 `tooling/refactor/policies/i18n-source-exceptions.json` | 无新目录豁免、token／统计／失败策略不改 |
| `backend/tests/integration/tooling/i18n-source-discovery.test.ts` | 同一唯一当前 policy 路径 | 同原查询、异常与统计断言 |

当前 i18n policy 从指定 base 的 `docs/expansion/i18n-source-exceptions.json` 原 bytes 派生；原 bytes 同其他历史一起归档。只有 `file` 按实际已批准 source map 变化：当前已知四行 deterministic_checks → deterministic-checks，FE language selector 原路径不动。所有 `text`／`count`／`reason`、顺序与其他字段不改。不把维护说明翻译混进这份政策数据。两个真实 reader 一起改落点，不留双权威。

以上锚点在工具中为严格一次／明确次数替换；未来 base 里已被另一批改动时停止，不能绕过 sourceAsset 当前合同修复或重写它的历史原文。

若维护者的最终 architecture 命令另有 **current** `--mappings` 操作数，必须先确定该单一文件及其 current owner，再单独审精确允许项。此方案只平移原历史安全前缀，不为猜测中的新参数放开整个 `docs/architecture` 或其他目录。

## 格式豁免与可携带的哈希守卫

拟新增 `.prettierignore` 条目只有：

```gitignore
/docs/history/expansion/**
!/docs/history/expansion/README.md
/docs/history/refactor/**
!/docs/history/refactor/README.md
```

这不是对 `docs/history/**`、所有 generated、tooling 或生产源码的宽豁免。当前 `docs/history/README.md`、origin 索引及新维护文档仍正常格式化。原已有其他 ignore 规则不扩大。

`tools/history-integrity.py` 是可携带只读 guard，不依赖 `/tmp` 的 prepared bundle：它要求真实 `--base`，重新取得完整原 Git 路径／mode／blob，流式核 manifest 的 SHA 与实际归档 bytes／mode，并拒绝额外历史文件及旧根副本。不能只编辑 manifest 来批准已变化历史，因为它还必须与原 Git 全集一致。

```bash
python "$C43_CANDIDATES/tools/history-integrity.py" \
  --repo "$C43_REPO" --base "$C43_BASE" \
  --manifest docs/history/origin-paths.json
```

维护者应将这条 guard 与实际后继格式检查在同一正式验收中固定记录；若要持久接根任务，先给该工具一个明确 current tooling owner，再精确新增调用。此 TMP 方案没有擅改 package.json，也没有仅凭 ignore=true 就宣称格式验收完成。

## 正式发布前仍需由维护者完成

- 给当前进度／最终矩阵／新证据输出和临时 stage/review helper 明确 current owner。B 后不能继续向 `docs/refactor` 或历史根追加现行指令；工具会拒绝多出的未捕获历史路径。
- 真实五 live checkpoint 已移动后核其目标链接；如仍 pending 就保准备措辞。给 Q2/Q3 和 current 物理迁移各自实际提交、source identity 与收据，不能用目录数量代替结论。
- 仅对真实改动的 I/O／policy／链接／工具范围做必要验证，保首红；不运行归档脚本重造旧绿，不重复每个旧 proof，不扩大秘密配置／模型授权。
- current 链接必须真实可点击；history 原内部相对路径仍按 origin 解释，索引不会自动修浏览器 URL。需要 viewer 时另定明确功能，不能在本次引入产品框架。
- 同一正式提交中完整 stage 两阶段需要的文件，独立审真实原字节和当前消费者，再登记 C43。任何 P8／P9 完成必须另有真实同源最终验收。
