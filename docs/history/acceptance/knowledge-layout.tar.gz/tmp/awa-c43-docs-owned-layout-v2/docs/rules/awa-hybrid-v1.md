# AWA Hybrid 1.0.0 规则卡

规则集 `awa_classic` 1.0.0；ID `hybrid`，混血儿／Hybrid；核验日期 2026-10-09。本卡对应 P7 混血儿角色实现；有限组合、双语与完整通路验收见[角色审查](../history/expansion/reviews/p7-hybrid.md)。不代表其它同名版本均受支持。

## 来源与版本边界

[Melbourne Masters 角色图鉴](https://melbournemasters.org/setups/roles/混血儿)规定首夜选择榜样，胜利跟随榜样阵营，自身属性是平民，预言家始终验好。[该组织的预女猎白混板](https://melbournemasters.org/setups/yu-nv-lie-bai-hun)把混血儿放在民边、四张普通狼人之外，并列出首夜先选择榜样的流程。该板的白神与 AWA 白痴不是同一角色，不能把现有白痴换名冒充完整原板。

[GTV100ENTERTAINMENT 官方视频说明（2024-08-08）](https://www.youtube.com/watch?v=kQEJ_xvIe-g)另明确榜样阵营需要本人判断，支持哪方都维持平民属性，狼人屠民必须清除混血儿。依据为官方发布者的 description，不声称已获取字幕或逐帧核验实战。

[langrensha.net 自有角色汇编（2021-06-25）](https://www.langrensha.net/strategy/2021062502.html)描述选择后不能更改，只有混血儿知道支持对象，混血儿不知道对象的身份。其开头明确是多种应用与网杀版本的汇编；它不是网易 `langrensha.com` 官方规则，也不能证明 Melbourne 全部细则。本文只用它标明“不告知目标身份”的既有版本依据，情侣第三方规则留待独立关系卡。

以下精确提交时点、无效响应、信息受众、死亡后获胜、目标变阵营、复活及混合板支持范围都是 **AWA 明确选择**。本版真实狼人全部死亡后按既有 Good 判胜，不再等待清除支持狼方的混血儿。

## hybrid

1. 原生最多一名。真实 `Role=Hybrid`、`Camp=Good`、`goodSide=villager`；不会因榜样是狼而成为真实狼人。原生无攻击、保护、死亡技能、自爆或豁免。`roles.hybrid` 只接受 `{}`；自选阵营、互认、继承刀权、重选或任意时序参数均拒绝。
2. 初始化胜利归属为显式空集合 `[]`，不默认获得 Good 胜利；首夜合法选择才安装一个独立 `VictoryComponent` 阵营归属。原 role/camp、平民人数、Agent、名字、人格与历史不变。
3. 首夜静默重置之后的 110 阶段、所有受支持角色的实际夜行动之前，必须一次 `choose_exemplar {target_id:integer}`，指定另一存活玩家。不可 self/dead/null；候选提示只按公开存活与本人 ID 筛选，不以隐藏阵营/身份排除目标。
4. 首夜选择不可合法等待。一次无效回复不消费次数、不关闭窗口；最多三次 ActionProvider 决策仍无合法动作则明确运行失败，不随机代选、不伪造已经选择。请求显式禁止 SDK/ACP fallback，包括注入的备用策略；模型内部工具修复/必要重试仍受原期限，不能将其网络调用次数冒称恒为三。没有其它存活目标时同样明确失败。合法提交后不再请求，后夜不能补选或更改。
5. 合法应用点冻结榜样的**真实阵营**，不读取预言家伪装标签、其胜利归属或该玩家终局结果。当前支持 Good/Wolf，写入对应 faction affiliation；之后榜样死亡、复活、状态/身份变化不改这份归属，不继承榜样能力、情侣关系或个人目标。
6. 混血儿或榜样出局不取消已安装的胜利归属；死者仍随该阵营获胜。未完成选择的异常局没有默认归属。无胜者终局没有混血儿个人胜利。上述死亡与冻结语义是本版 AWA 选择。
7. 真实狼全部死亡仍按既有 Good 判胜优先级结束，存活狼混不续狼刀、不阻止 Good 胜利。狼人屠民时，混血儿仍是必须清除的实际 Good 民；屠城/人数优势也按原真实 camp 统计。人数、归属与狼队权限分别计算。
8. 普通阵营查验始终验 Good；具体身份查验显示 Hybrid。熊/骑士等真实阵营查询也按 Good；这些组合只有列入下述有限白名单并经实际判例验证后才开放，不能因原则上可查询就自称支持所有板子。
9. 混血儿只知道自己的选择与机会已用，不知道榜样的真实阵营/身份。目标不收到通知；任何狼牌不因此知道混血儿、与其互认、聊天或共享刀权，混血儿不获得狼队历史。不能把冻结 affiliation 放进 ownState、身份提示、工具反馈或普通事件。
10. `hybrid_exemplar_chosen {actorId,day,targetId}` 在玩家投影中只给选择者，保留自己的原始动作事实；隐藏阵营如有因果事件只供 God。普通公开游戏事件与其他玩家档不披露榜样选择或冻结 camp。现有离线 `replay.json` 的 `perspective=god` 是完整裁判视角，可保存这些私有事实；不能将其当成匿名公众/玩家视角文件。终局获胜玩家 ID 是公开结果，可以表明混血儿跟随哪方获胜，但终局 payload 不额外公开 targetId。本笔不新增 public/player 复盘 perspective。
11. actor 原生命/role/camp/privateState、选择次数、原 VictoryComponent 与目标原生命/role/camp 在 await、gateway 和实际应用点复验；原 Victory 对象及其 affiliations 必须仍为空，同引用下被修改也拒绝。撤权/换生命/已选/变阶段后不写新 owner 的状态；并发请求只允许首个合法提交，之后的回复丢弃、不覆盖或误报已完成选择为缺失。choice 与独立 membership 同步提交，中间无 await。提交后归属是独立拥有的值，不持有目标组件引用；已提交前缀不因后续状态变化回滚。
12. 阶段只提交选择和归属，不写 Alive，不判胜。NightPipeline 同一 World/day 重入不能重复选择或清空已提交事实；DeathResolution/PhaseManager 保留全部死亡连锁、遗言/警徽后最终判胜。
13. 初始有限组合：Hybrid/Wolf/WolfKing/HiddenWolf/Seer/Witch/Guard/Hunter/Idiot/Villager。原生最多一混；伪装 HiddenWolf 用真实 Wolf 归属。其它已实现角色、第三方、额外牌/换牌、复制学习/赠予、关系与变阵营角色联合板暂拒绝，由后续独立组合卡与矩阵扩展。parse 与 direct bootstrap 都校验，目标合法性不依隐藏牌筛选。
14. 六人与十二人提供 AWA 示例板，不声称是上述白神原板。所有规则提示、选择工具/错误、私有选择标签、终局展示均提供 `zh-CN`/`en`；机器工具/key/ID、原始玩家文本不翻译。观测机器人只能凭自己的私有选择与公开证据推断榜样阵营。

## 验收要求

- Good/Wolf/伪装 Wolf 榜样；不可自选/死者/缺目标/空回复/后夜/重选，拒绝与重试不消费；actor/target 原生命和组件撤换、gateway 后变化及并发提交。
- 自身与榜样已死仍按冻结 membership 获胜；狼混仍在民边、验好/具体身份 Hybrid、无狼权限、全真狼死 Good 封盘、屠民必须清除狼混；原有死亡/遗言/徽章顺序不变。
- PlayerObservation/SDK/ACP/MCP 真实输入与反馈没有隐藏 camp、目标身份、他人私有选择；中英提示与工具行为一致；God/Tape 保存真实归属，玩家档及普通公开游戏事件只保存该受众允许的信息。
- 六/十二板各不少于 20 受限观察 seed，自然终局、零非法回退，选择与两方获胜分支有正覆盖；字面独立 oracle 的两语 SDK/ACP/混合完整局及每局严格 Tape。
- 前端 God 时间线正确显示私有选择而不误改身份/阵营/存活；终局显示 Good 身份的狼方获胜者及已死获胜成员，普通公开事件不带私有选择；unit/type/build、实际 Chromium、双语实际 PNG；R/A/T/L/D 三路审查与修正复查。
- 启用提交才把目录标记 verified；P7 整阶段、P8–P10、长局及 T6 目标保持。
