# 运行与维护指南

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

- [本地运行与配置检查](run-locally.md)
- [离线复盘、模拟与视频](offline-replay.md)
- [验证与证据范围](validation.md)
- [增加或修改机制](add-mechanism.md)
- [目录、API与档案迁移](migration.md)
- [完整重构目标与阶段退出计划](refactoring-plan.md)

日常维护从current契约进入，不从history里挑一段“下一批”执行。这里列命令与验收方法，不记录本轮已通过数；真实结果留scope／收据并从history按origin定位。
