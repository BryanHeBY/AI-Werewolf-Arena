# ADR 0005：按稳定职责组织目录和公开面

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

## 选择

已成立owner整体按engine／features／rulesets／agents／recording／adapters归属，目录不再沿game大层或阶段编号排列。共同夜能力、死亡枪、Catalog有限组合和独立verifier各有实际目录；不通过增加private→ports转发壳声称完整迁移。

## 理由

逐角色核心分支和重复数据会隐去真实写权；把已有owner继续拆小则只增加callee／初始化／异常面。物理移动应保原实际算法与模块图，再根据具体finding处理真正owner边界。

## 后果

单一class／enum／WeakMap／默认实例。兼容key如保留只指唯一physical target；公开出口只保原名和顺序，未知外部deep-import退休不承诺无影响。time-wolf-consort组织名不改变稳定协议ID、规则版本或原fixture origin。

Catalog→observation原late binding仍是实际已知依赖，不能凭新目录宣称消失。checker必须覆盖新目录，不通过分类漏检使gate变绿。

本决策说明目标归属；物理迁移是否落盘，以对应实际提交、路径映射、元路径与来源身份记录为准。旧 528 路径快照和后继 672 映射是不同采样，不合并成一个当前完成计数；任何一次目录映射也不自行证明 P8 或 P9 通过。
