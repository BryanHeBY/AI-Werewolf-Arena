# 玩法扩充历史索引

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

- [原路线](roadmap.md)、[64项目录](roles.md)：当时目标，不是当前执行支持列表。
- [原进度](progress.md)、[原交付流程](delivery.md)、[P0审查](review-2026-10-07.md)。
- [原配置说明](config-v2.md)、[原契约集合](contracts/current-rule-behavior.md)、[授权整改记录](contracts/implementation-status.md)。
- `reviews/`保存各阶段来源、实际命令、失败与通过范围；单篇phase完成不扩展成所有组合或当前全仓验收。

旧暂停／停止条款、角色数量和下一步保持原文，当前任务由现行计划和Root已批准范围决定。规则卡已在[现行rules](../../rules/README.md)；不把扩充交付文档当第二套规则。
