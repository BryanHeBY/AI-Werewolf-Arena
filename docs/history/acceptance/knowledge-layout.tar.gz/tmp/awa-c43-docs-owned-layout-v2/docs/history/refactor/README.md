# 架构重构历史索引

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

- [原完整计划快照](plan.md)、[原逐切片进度](progress.md)、[原总体决策](decisions.md)。
- [固定双构建方法与首阶段事实](differential.md)。
- [当前阵营变更来源](camp-canonical-input-policy.md)、[失败执行退休](role-execution-failure-policy.md)。
- [C18原协议机械迁移](request-lease-propagation.md)、[F02四窗口](request-lease-terminal-revocation.md)、[关系完成](cupid-hybrid-request-lease-completion.md)、[LastWords](last-words-request-lease.md)。
- [显式档案身份](explicit-archive-identities.md)、[manifest／player身份](manifest-player-archive-identities.md)、[Domain布局](domain-owned-layout.md)。
- `generated/`保存每批before／scope／脚本／raw／receipt／review及首formal快照，不以旧签名覆盖末source或把阶段SHA说成最终复跑。

历史matrix／debt／inventory保其原观察Git。最终Root另发布真正同源闭合矩阵，不能原地重写旧1779债、910格或旧原始实验求完结。
