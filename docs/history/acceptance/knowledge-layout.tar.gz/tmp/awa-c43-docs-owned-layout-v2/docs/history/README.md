# 历史来源与证据入口

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

本目录保存扩充与重构的原文件、审查、真实红灯和验收来源。它回答“在什么输入／commit上发生过什么”，不发布当前规则或工作指令。

- [扩充历史](expansion/README.md)
- [重构历史](refactor/README.md)
- [原路径→现落点](origin-paths.json)：每项保originCommit／Git blob／mode；只有定位，不执行任何脚本。
- 当前规则回到[rules](../rules/README.md)，当前契约回到[contracts](../contracts/README.md)，维护方法回到[guides](../guides/README.md)。

## 如何引用与复查

引用来源时同时给原path、commit、输入／结果范围。旧文中相对链接和嵌入的artifact path以originPath为基准，经origin表定位currentPath；原正文、sourceSHA、工具脚本、stderr和停止条件不因搬目录被重写。

要运行历史程序，应检出对应原Git及依赖／原layout；不是在当前工作树运行归档脚本再把输出当旧输入。历史green不证明当前源码，历史pending也不表示已经交付的owner需要重复开发。

物理搬迁批必须与当前I/O读点、活跃链接和来源文档指向一起落盘，且不留第二活跃知识目录。此候选尚未移动任何原文件；origin表为Root下笔原子归档的实际逐项计划，应用前需重新捕最终Git后继。
