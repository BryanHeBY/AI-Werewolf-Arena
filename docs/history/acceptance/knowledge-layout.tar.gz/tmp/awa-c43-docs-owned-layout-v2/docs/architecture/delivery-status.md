# 当前交付与最终验收边界

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

## 本页的状态含义

本页给维护导航，不替Root登记最终机制矩阵。判断一个格已完成需要真实producer→consumer、规则与失败反例、同源证据和依据充分的不适用理由；文件存在、历史green或结构债ID清除都不够。

已交付的有界切片分别建立状态、许可、生命周期、效果、死亡、观察、checkpoint 和独立 verifier 的实际 owner；这里不据此声明每个角色在每项职责与所有失败输入上均已验收。Cupid／Hybrid真实窗口完成通知、LastWords窗口及其lease、关系独立verifier与Demon／Ghost有界终态修正不应因早期pending标签被重复实施。

## 仍需区分的工作

| 边界 | current含义 | 最后登记要求 |
| --- | --- | --- |
| C41／C42物理布局 | Domain已实交；engine/features/agents/recording等采用已批准映射，应用前不称已迁完 | 一次actual Git前态、物理binding／单例、活跃路径、来源指纹与必要差分 |
| Q2 普通请求 | Seer／死亡持徽选择已在 `24dad9f7` 接入领域完成；仅此有界范围，不推成所有普通技能同契约 | `ordinary-native-badge-request-completion` 正式来源与分段收据；后续物理路径按实际集成记录关联 |
| Q3 普通死亡审计 | `6025b64b` 已追加普通死亡后果历史审核；独立校验与 exact 重执行仍是两层保证 | 限定来源／枪尝试组／遗言／警徽失败前缀，不把 God facts 当 life 证明，不外推为 55 角色全行为验收 |
| C43知识整理 | 本目录是完整候选；current与history两原子批未落前不称完成 | 活跃链接、源文档指向、真实I/O、history字节与origin表 |
| P9最终验收 | 需要固定同一候选输入运行完整门禁及所需离线／本机通信／浏览器／渲染证据 | 输入身份、真实首次红及修复范围、未覆盖或不支持项、最终逐格对账 |

历史台账曾固定13366731等观察提交；其910cells和part计数不代表当前树结论。Root应在最终同源验收后发布新的闭合矩阵，并把原台账原字节归history，不重写原记录以求全完成。

完整目标仍见[实施计划](../guides/refactoring-plan.md)；历史提交及scope从[history](../history/README.md)按origin定位。这里没有新的暂停／停止授权，也没有把旧扩充里程碑重新变成当前任务。
