# 架构与所有权入口

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

当前文档回答“真实职责由谁拥有”，不按类名、文件长度或历史阶段编号分层。

- [模块与依赖](module-ownership.md)：应用、领域、引擎、机制、规则组合、Agent、记录、适配器的实际边界。
- [状态、许可与生命周期](lifecycle-and-authority.md)：原体／版本、未付动作、已付效果、死亡波次和终局。
- [机制索引](feature-ownership.md)：多角色机制、共同能力及对应独立 verifier。
- [交付与最终验收边界](delivery-status.md)：已交职责与还需同源验收的区别。

现行契约在 [contracts](../contracts/README.md)，规则在 [rules](../rules/README.md)。历史切片只是来源，不能根据其当时剩余项再把已成立 owner 拆成新的 public wrapper。
