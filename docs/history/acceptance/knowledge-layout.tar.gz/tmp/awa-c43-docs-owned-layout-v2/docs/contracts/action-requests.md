# 请求、别名与领域完成

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

## 数据和运行权分离

ActionRequest的数据属于共享契约；World、Role、生命版本、库存、来源和真正lease仍是后端运行对象。context中的相同ID、allowedTools、MessageRef或已复制feed不产生权限，不能由DTO重新构造绑定。summary／retry原字符串覆盖与MessageRef保各自优先级，空串能明确清除内置提示。

provider返回是候选，不是accepted、committed或paid。接收器修复与schema／工具校验也不是领域付款。真实窗口必须接完整await两侧、validator后及语义首写前的当前性；所有新增callee／实参getter的观察点须如实注明，不能在最后守卫后又通过新增准备读点恢复未付路径。

## 已批准F02协议，而非全族统一规则

既有RequestLease持登记、scope查询、alias有序比较、继承、最早预算及运行turn；没有新的World服务或中央Role switch。各协议使用独立稳定实例，同request可有多binding，真实窗口只打开自己的turn。dynamic window的actor／phase／day／stage和可选context pins来自捕获scope。

在采用该F02政策的窗口内：

- 正确owner观察到原envelope／共享domain／最早期限失效，共同turn永久关闭，恢复字段或回拨时钟不复活。
- 已登记alias自身context／envelope坏，只永退alias；unknown clone／wrongWorld／wrong-owner只拒输入，不读取并毒化有效original。
- 合法deadline别名只能收紧有限未来预算；非法target pin／过去或延长预算在登记／预算写前拒绝。顶层原键／原值引用和context身份按该协议比较，不推成深JSON schema或freeze。
- close与settle不是同一事实：先落终态再通知；领域全部付款完成后才true，取消／异常未完成false。部分付款保实际前缀；facts或通知晚抛保true且不二结算。

Initial／Wild／Lonely／Wall、Cupid110／Hybrid120／LastWords130、普通夜请求140及警徽150各有实际 scope 及完成点。普通夜协议当前接入 Seer，初次关联和后续 pin 要求原 `ability_id` 与捕获值一致；不为此新增 World 查询。Seer 的 slot、狐提案、checks、use、modifier、reflection 和自身历史全成功后、`seer_checked` 前才 true；警徽在旧徽／旧票重／新徽／新票重及特殊 frame 全完成后、事实前 true，null 销毁同样是合法完成。LastWords额外pin trigger/death_phase/death_action_id；关系窗口无额外context字段pins。LastWords没有独立库存付款，遗言事实push成功本身是提交，所以true在其后；此前sink错误为未完成。不能把所有facts一律当作true之后的晚发布。Wall每位作者独立完成，不能整个墙一个布尔值。

Demon／Ghost的已观察终态政策由各自原authority保存，不因此把所有paid current改成请求envelope检查。Ghost等待第二同意的旧first consent在共享domain失效被观察后退休；second自身proof／期限坏不无差别伤有效first。已付婚礼chat／knife保原纯读政策。

Animal／Fragrant／Noble等已有复杂协议按自己的正式同意／alias／原体和终态政策维护；不能仅因为与dynamic window不同就自动统一。新增协议先characterization，再明确行为差异和手写预期。

## 错误优先与记录

原body与原finally都抛时，保原JS cleanup优先；新增false通知不能盖已有原错，无旧错才传播新通知错。true先落后通知，晚失败不可再发false。Trace等待真实完成通知：defer=false即时结算和deferred领域结算必须区分；settle(false)可能使decision outcome为error，不能假设returned action仍在档案中。

实际owner：`domain/request-lease.ts`、`domain/request-delivery.ts`及每族真实window；SDK／ACP只消费完成端口，不夹入另一套付款判定。
