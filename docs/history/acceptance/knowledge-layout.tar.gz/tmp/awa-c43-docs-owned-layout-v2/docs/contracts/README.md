# 现行维护契约

> 准备状态：C43 第二版 current 候选，尚未写入仓库。已整合有界 Q2／Q3 已提交政策；目录链接须随实际集成核对。`app/checkpoint` 五个现场捕获 owner 是已批准后继目标，应用前的实际路径仍为 `recording/reproduction/checkpoint`，本候选不宣称它们已迁移。历史归档须从维护者显式指定的新 Git 重新捕获，本文不声明 C43、P8／P9 或全机制验收完成。

本目录只维护当前边界，不复制旧交付日志、统计或“下一批”指令。每份契约列真实owner与适用范围；具体玩法来源仍以规则卡为唯一完整角色说明。

- [配置与有限支持](configuration.md)
- [请求、别名与领域完成](action-requests.md)
- [实际阵营、身份与资源](identity-and-resources.md)
- [事件、观察与显示](events-and-observation.md)
- [投票、死亡披露与遗言](voting-and-public-death.md)
- [会话录制、checkpoint与独立复现](recording-and-reproduction.md)
- [公开档案与精确构建身份](archive-compatibility.md)
- [运行回合、取消与资源](agent-runtime.md)

这些页面不能授予动作权限；数据schema、提示或同名字段从不替代World／lease／库存当前性。相关设计理由见[决策](../decisions/README.md)。
