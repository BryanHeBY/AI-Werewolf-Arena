# C43 fixture I/O 两失败输入的 TMP 修复提案

状态：仅候选，尚未应用或执行。首轮由 Root 执行：ce6eb8 / session 9247 → 7005d3，23 pass、2 fail、119 expect；原 raw 与 derive 诊断逐字复制在本目录。

## 1. 祖先链接负例的实际输入图

`tooling/refactor/fixture-manifest.test.ts` 只改失败声明的复制列表：保留原输入先后，补齐登记的 4 个 moduleRelocations 当前叶，以及生产 historicalSourcePackages 明列的 5 个去重 game-contract 当前文件。用 Set 去重共享叶，原 mkdir/cp、Git/依赖链接、外部 canary、frontend 祖先链接、错误字面断言与 finally 清理都不改。这样负例先通过既有源证据检查，才能到原先要验证的 symlink_rejected；没有通过更改生产检查器绕过校验。

## 2. 派生局部 manifest 的四个过期标量

`first-derived-manifest-differences.json` 的 1004 项差异恰为 251 份局部 manifest × 2 个 test-support sourceAssets × currentSha256/currentBytes。候选只替换这 4 个原始 JSON 标量 token；没有整份 JSON 重序列化。目标值既来自 Root 首诊断的 expected，也与当前主 manifest 和实际源文件 SHA/bytes 一致。

| 当前源 | currentSha256 | currentBytes |
| --- | --- | ---: |
| backend/tests/support/builders/audit-summary.ts | 783f468aee2839c9351c59218f3be8858f7ac3f9575c07ea89954178636a7e2c | 1037 |
| backend/tests/support/features/mist-raven/oracles/transport.ts | 3fc402fe63e4e03041e89c82b102287d43900073274b8b84136cf9de45dd9325 | 7533 |

其余 parsed 字段与原 raw 布局均保留：包括原 origin、program/声明摘要、bindings、suite IDs、coverage 与 acceptance。904 个实际档案只作为原始字节控制；没有重写、复制生成或重新派生档案。C43 历史 5511 文件不在候选内。

## 交接与限制

- `before.json`：252 个实际当前完整原文，另记 observed HEAD 14e795… 的 blob/mode；test source 含 C43 I/O WIP，不能冒称整体等于 Git。
- `deltas.json`：1 个失败 fixture 输入列表替换，加 1004 个精确标量 span/字面值；保完整原文与候选 SHA。
- `candidates/`：1 个 test source + 251 个 local manifest 完整候选；没有仓库写入。
- `controls.json`：生产检查器/主 manifest/实际读取输入与 904 档案的原字节摘要。
- `assemble-data.py` 只做 stdlib 数据和文本组装；已执行这一步，不是执行生产 parser、generator、derive、TS、测试或 gate。尚未执行运行验证，也不宣称完整逆证明已运行。

Root 独立审阅并按 before SHA/mode 复核后再应用。后继仅重跑原两条失败声明：`fixture-root ancestor links are rejected before directory enumeration` 与 `generator verifies 904 exact JSON archives and 3 equivalent source fixtures with 258 pending suites`。原另 23 条绿色结果保持首采样，不由此稿重复运行。运行命令与真实收据仍由 Root 决定并记录。
