"""仅组装 Root 已裁定的两个失败输入 TMP 候选；不执行生成器、derive、TS 或测试。"""
from pathlib import Path
from collections import defaultdict
import copy, hashlib, json, re, subprocess, stat
repo=Path('/home/hby/dev/AI-Werewolf-Arena')
out=Path('/tmp/awa-c43-fixture-io-repair')
sha=lambda b:hashlib.sha256(b).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
tree={}
for r in subprocess.check_output(['git','ls-tree','-r','-z',base],cwd=repo).split(b'\0'):
 if r:
  m,n=r.split(b'\t',1);mode,kind,oid=m.decode().split();tree[n.decode()]={'mode':mode,'kind':kind,'blob':oid}
master_path='tooling/refactor/fixtures/manifest.json'
master_raw=(repo/master_path).read_bytes();master=json.loads(master_raw)
source_assets={a['currentPath']:a for a in master['sourceAssets']}
target_assets={p:a for p,a in source_assets.items() if a['kind']=='test-support'}
if set(target_assets)!={'backend/tests/support/builders/audit-summary.ts','backend/tests/support/features/mist-raven/oracles/transport.ts'}:raise ValueError('unexpected target source assets')
for p,a in target_assets.items():
 raw=(repo/p).read_bytes()
 if a['currentSha256']!=sha(raw) or a['currentBytes']!=len(raw):raise ValueError('main asset no longer matches actual source')
raw_path=Path('/tmp/awa-c43-fixture-io-tests-output.txt');diff_path=Path('/tmp/awa-c43-derived-manifest-differences.json')
raw=raw_path.read_bytes();diff_raw=diff_path.read_bytes();differences=json.loads(diff_raw)
if len(differences)!=1004:raise ValueError('not approved1004 data differences')
groups=defaultdict(list)
for d in differences:
 found=re.fullmatch(r'((?:frontend/tests/fixtures|packages/replay-contract/fixtures)/.+/manifest\.json)/sourceAssets/([01])/(currentSha256|currentBytes)',d['path'])
 if not found:raise ValueError('unexpected diagnostic field '+d['path'])
 groups[found[1]].append((int(found[2]),found[3],d))
if len(groups)!=251 or any(len(g)!=4 for g in groups.values()):raise ValueError('not251x4')
for target,original in [('first-fixture-io-output.txt',raw_path),('first-derived-manifest-differences.json',diff_path)]:
 p=out/target
 if p.exists():raise ValueError('preserve existing original evidence')
 p.write_bytes(original.read_bytes())
def info(p,b):
 item={'path':p,'bytes':len(b),'sha256':sha(b),'gitMode':'100755' if (repo/p).stat().st_mode&0o100 else '100644','gitAtObservedHead':tree.get(p)}
 if p in tree:
  gitraw=subprocess.check_output(['git','cat-file','blob',tree[p]['blob']],cwd=repo)
  item['gitAtObservedHead']['bytes']=len(gitraw);item['gitAtObservedHead']['sha256']=sha(gitraw);item['currentEqualsGit']=gitraw==b
 return item
before=[];source=[];edits=[]
def put(p,old,new,records,kind):
 old_b=old.encode();new_b=new.encode();r=info(p,old_b);r.update(text=old,phase='Actual current C43 WIP, observed HEAD '+base);before.append(r)
 target=out/'candidates'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(new_b)
 source.append({'path':p,'kind':kind,'beforeSha256':sha(old_b),'beforeBytes':len(old_b),'candidateSha256':sha(new_b),'candidateBytes':len(new_b),'gitMode':r['gitMode']})
 for x in records:edits.append({'path':p,**x})
# 补足既有负例的实际输入图，不改 canary／symlink、执行目标或 expected error。
p='tooling/refactor/fixture-manifest.test.ts';old=(repo/p).read_text()
header='''    for (const relative of [
      "docs/history/refactor/generated/baseline-fixtures.json",
      fixtureManifestPath,
      "backend/package.json",
      ...layout.sourceAssets.map((asset) => asset.currentPath),
    ]) {'''
replacement='''    // 先备齐已登记声明迁移与两条历史包退桥的当前输入，再布置 frontend 祖先链接负例；不从生产结果生成预期。
    for (const relative of new Set([
      "docs/history/refactor/generated/baseline-fixtures.json",
      fixtureManifestPath,
      "backend/package.json",
      ...layout.sourceAssets.map((asset) => asset.currentPath),
      ...layout.sourceAssets.flatMap((asset) =>
        (asset.moduleRelocations ?? []).map((relocation) => relocation.currentPath),
      ),
      "packages/game-contract/package.json",
      "packages/game-contract/src/index.ts",
      "packages/game-contract/src/locale.ts",
      "packages/game-contract/src/facts/mist-raven.ts",
      "packages/game-contract/src/inert-event-data.ts",
    ])) {'''
if old.count(header)!=1:raise ValueError('unexpected test header')
new=old.replace(header,replacement)
put(p,old,new,[{'before':header,'after':replacement,'count':1,'reason':'Actual input closure before the existing frontend symlink rejection; preserves prior input insertion order and deduplicates shared relocation leaves.'}],'one-failed-test-fixture-input-closure')
# 只在原 sourceAssets 区间改四个 scalar。完整JSON只用于确认其它parsed字段不变，不serialize它。
for p in sorted(groups):
 old=(repo/p).read_text();parsed=json.loads(old)
 if len(parsed['sourceAssets'])!=2 or {a['currentPath'] for a in parsed['sourceAssets']}!=set(target_assets):raise ValueError('unexpected local support asset set')
 start=old.index('  "sourceAssets": [');stop=old.index('  "derivedManifests":',start)
 section=old[start:stop];records=[]
 for idx,field,d in sorted(groups[p],key=lambda r:(r[0],r[1])):
  asset=parsed['sourceAssets'][idx];expected=target_assets[asset['currentPath']][field]
  if d['actual']!=asset[field] or d['expected']!=expected:raise ValueError('approved data differs from current/master')
  before_literal=json.dumps(d['actual'],ensure_ascii=False);after_literal=json.dumps(expected,ensure_ascii=False)
  pattern=re.compile(r'("'+re.escape(field)+r'"\s*:\s*)('+re.escape(before_literal)+r')')
  found=list(pattern.finditer(section))
  if len(found)!=1:raise ValueError('nonunique sourceAssets scalar literal')
  at=start+found[0].start(2);end=start+found[0].end(2)
  records.append({'pointer':'/sourceAssets/'+str(idx)+'/'+field,'assetCurrentPath':asset['currentPath'],'beforeValue':d['actual'],'afterValue':expected,'beforeLiteral':before_literal,'afterLiteral':after_literal,'offsetCodepoints':at,'endCodepoints':end,'offsetUtf8Bytes':len(old[:at].encode()),'endUtf8Bytes':len(old[:end].encode()),'reason':'Only stale local support-asset current byte metadata; origin/program/bindings/acceptance/archives untouched.'})
 new=old
 for r in sorted(records,key=lambda x:x['offsetCodepoints'],reverse=True):new=new[:r['offsetCodepoints']]+r['afterLiteral']+new[r['endCodepoints']:]
 expected_parsed=copy.deepcopy(parsed)
 for idx,field,d in groups[p]:expected_parsed['sourceAssets'][idx][field]=d['expected']
 if json.loads(new)!=expected_parsed:raise ValueError('non-authorized parsed change')
 restored=new
 for r in sorted(records,key=lambda x:x['offsetCodepoints']):
  # 后继位置按前面4个已替换标量的长度差计算，不依据其它相同字符串全局替换。
  delta=sum(len(x['afterLiteral'])-len(x['beforeLiteral']) for x in records if x['offsetCodepoints']<r['offsetCodepoints'])
  r['candidateOffsetCodepoints']=r['offsetCodepoints']+delta
 # 原所有未触区间按拼接结构保留。Root应用应按原SHA+降序原offset，不重serializeJSON。
 put(p,old,new,records,'four-scalar-derived-local-metadata')
# Root可交叉读取的真实新增文件图；原 current 文件只作为输入controls，不纳写入scope。
relocations=[]
for a in master['sourceAssets']:
 for r in a.get('moduleRelocations',[]):
  if r['currentPath'] not in relocations:relocations.append(r['currentPath'])
gc=['packages/game-contract/package.json','packages/game-contract/src/index.ts','packages/game-contract/src/locale.ts','packages/game-contract/src/facts/mist-raven.ts','packages/game-contract/src/inert-event-data.ts']
controls=[]
for p in [master_path,'tooling/refactor/fixture-manifest.ts',*relocations,*gc,*target_assets]:
 raw=(repo/p).read_bytes();r=info(p,raw);r['text']=raw.decode();controls.append(r)
archives=[]
for r in master['files']:
 if r['kind']=='adapter-script':continue
 p=r['currentPath'];raw=(repo/p).read_bytes()
 if len(raw)!=r['currentBytes'] or sha(raw)!=r['currentSha256']:raise ValueError('unexpected current archived fixture drift '+p)
 archives.append({'path':p,'bytes':len(raw),'sha256':sha(raw),'originPath':r['originPath'],'originalSha256':r['sha256'],'originalBytes':r['bytes']})
if len(archives)!=904:raise ValueError('unexpected archive cardinality')
(out/'before.json').write_text(json.dumps({'observedHead':base,'status':'TMP_CANDIDATE_CAPTURE_OF_ACTUAL_CURRENT_C43_WIP','source':before},ensure_ascii=False,indent=2)+'\n')
(out/'deltas.json').write_text(json.dumps({'status':'TMP_EXACT_CANDIDATES_NOT_APPLIED_NOT_EXECUTED','sourceRecords':len(edits),'testInputHeaderRecords':1,'localManifestScalarRecords':1004,'edits':edits},ensure_ascii=False,indent=2)+'\n')
(out/'controls.json').write_text(json.dumps({'readOnlySource':controls,'archiveInputs':archives,'historyNeverWritten':'docs/history/expansion and docs/history/refactor; 5511 frozen members untouched'},ensure_ascii=False,indent=2)+'\n')
proposal={'status':'TMP_ONLY_CANDIDATES_NOT_APPLIED_NO_GENERATOR_DERIVE_TS_TEST','observedHead':base,'source':source,'deleted':[],'counts':{'candidateFiles':len(source),'testSource':1,'localManifests':251,'changedScalarFieldsPerManifest':4,'scalarEdits':1004,'testHeaderEdits':1,'newUniqueRelocationLeafInputs':len(relocations),'newUniqueCurrentGCInputs':len(gc),'archiveByteControls':len(archives)},'failedCases':['fixture-root ancestor links are rejected before directory enumeration','generator verifies 904 exact JSON archives and 3 equivalent source fixtures with 258 pending suites'],'preserve':['Original two failed declarations/titles/expect and canary/symlink target/priority remain, only input preparation expands before original assertion.','All local JSON raw bytes outside four scalar tokens, all other parsed fields, originalProgram/moduleBindings/declaration hashes, suite IDs, acceptance, origins and904 archived fixture bytes unchanged.','No production checker or main manifest/sourceAssets bytes changed; current metadata expected values taken from already matching master+Root diagnostic, not runtime regenerated.','C43 frozen history unchanged. Current frontend/packages local metadata only.'],'sourceInputClosure':{'originalFirstInputs':['docs/history/refactor/generated/baseline-fixtures.json','tooling/refactor/fixtures/manifest.json','backend/package.json','...sourceAssets.currentPath'],'additionalRegisteredRelocationLeaves':relocations,'additionalHistoricalCurrentPackageFiles':gc,'copyPolicy':'Set keeps existing first occurrences/order and deduplicates shared added relocation leaves; original foreach mkdir/cp then Git/dependency links and canary setup remain.'},'rootExecutionOnly':'After independent review and exact current SHA rebind, Root applies candidates then runs only the two failed declarations; original23 pass not rerun. No result is claimed in this proposal.'}
(out/'proposal.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
items=[]
for name in ['assemble-data.py','before.json','deltas.json','controls.json','proposal.json','first-fixture-io-output.txt','first-derived-manifest-differences.json']:
 p=out/name;raw=p.read_bytes();items.append({'path':str(p),'bytes':len(raw),'sha256':sha(raw)})
handoff={'status':'TMP_ONLY_PREPARED_NOT_APPLIED_NOT_EXECUTED','actualObservedHead':base,'source':source,'deleted':[],'files':items,'originalEvidenceCopies':[{'from':str(raw_path),'to':str(out/'first-fixture-io-output.txt'),'sha256':sha(raw_path.read_bytes())},{'from':str(diff_path),'to':str(out/'first-derived-manifest-differences.json'),'sha256':sha(diff_path.read_bytes())}],'candidateGeneratorExecuted':False,'deriveExecuted':False,'TSParserCompilerExecuted':False,'testsOrChecksExecuted':False,'repositoryWrites':False,'rootFirstExecution':{'launch':'ce6eb8','session':9247,'terminal':'7005d3','exitCode':1,'pass':23,'fail':2,'assertions':119},'rootDiagnostic':{'launch':'14e0b3','executionBy':'Root only','source':str(diff_path)},'limits':['stdlib-only TMP text/JSON/rawbyte assembly; not sourceProgramContract, deriveLocalFixtureManifest or any production parser/generator.','Main manifest actual source metadata had already passed before derived local mismatch; fixture input closure still requires Root runtime failed-only result, not claimed green.']}
(out/'HANDOFF.json').write_text(json.dumps(handoff,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidateFiles':len(source),'localManifests':len(groups),'scalarDeltas':len(edits)-1,'relocationLeaves':relocations,'gcInputs':gc,'archives':len(archives),'handoffSha256':sha((out/'HANDOFF.json').read_bytes())}))
