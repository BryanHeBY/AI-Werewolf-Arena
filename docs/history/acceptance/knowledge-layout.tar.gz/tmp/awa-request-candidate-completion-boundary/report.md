# 原始候选与领域事务完成的最小边界

只读静态复核；普通四族 probe 未执行、生产补丁暂停。本文修正前一 ordinary-gap 提案中“未注册 completion 就是计划未完成”的过强结论；原稿／探针原样保留，不把这次重新解释冒作运行结果。

## 已有程序说明了两种合同

| 现行合同 | 实际依据 | 可证明的含义 |
| --- | --- | --- |
| 没有 completion 的普通候选 | `domain/request-delivery.ts:44–52` 返回 false；`recording/reproduction/trace.ts:133–145` 复制候选、核可交付、立即 settle(true) | `outcome.kind=action` 只说明 Provider 返回了可录制候选，不证明 schema／Gateway 已接受，更不证明库存、效果或整个回合成功。 |
| 明确绑定 completion 的事务请求 | `bindRequestDeliveryGuard` 第三参数是可选 identity；`deferRequestDelivery` 用它延后；窗口的 commit/close 才调用 settle | Provider返回后可保pending；true形成action，false形成decision_failed error。先删待通知项后回调，不重结算；当前false策略不保 returned candidate。 |

`ReproductionTrace` 的头也明确“结算回执不表示资源付款”。原 `RecordedDecision`／strict schema只有 pending、action、error三种 outcome，**没有两个独立的候选与付款字段**。不能把同一个 action 标签在所有旧普通窗口重新解释成“领域成功”。

## 原始失败前缀是必要证据，不应抹掉

`tests/scenarios/reproduction/radiant-eclipse/raw-domain-failure.test.ts:15–34` 明确给吞噬／庇护返回同名工具及 `args:{}`，并要求：真实行动点已到、档案finalized、runtime_error、末CP complete=false，**decision仍是action且原args为{}**。

其真实driver `tests/support/features/radiant-eclipse/drivers/recording.ts:92–142` 把 `trace.decide` 接实际PhaseManager；周期错误另记 `noteFailure`／失败CP，最后parse并exact replay。因此保留raw候选使重放再次到达同一领域拒绝或异常点，而不是由Provider先抛错或伪造无候选，后者可能改变已提交前缀与失败时点。这是现有测试与消费意图的静态证据，本轮没有重跑，不宣称当前新树又通过。

## 对计划§7的准确结论

计划最后一句限定“只有对应领域commit可以settle **事务请求**”；前文也要求“已绑定租约”的终态。它不是“所有getAction都必须生成一个domain completion”。候选原始记录不是成功付款轨迹。不能从资源会写、没有RequestLease、factory只有5分支，推出全角色必须转成事务通知。

现行明确事务窗口（既有复杂请求、四首夜、Cupid／Hybrid／LastWords、Q2 Seer／Badge）仍按各自已批准的deferred政策验收，不能为保存raw候选静默改回即时成功，也不改其已付续期或alias区别。普通Guard／Witch／Dreamer／Beauty是否需要额外F02请求绑定，应由各自真正可复用旧请求、期限、外来提交或异步失效反例决定；**目前尚无这四族真实旧请求恢复反例收据**。先前准备的context测试只会观察“未登记所以没额外拒绝”，不证明旧权限false→true，不能作为修复必要性的自证。

所以当前不需要为了§7自动推广全角色completion，普通四族“early Trace action”也不能独自作为产品缺陷。N06首写前原体／资格复验、F05演员退休与已付效果的边界是另一条责任；有具体晚getter缺口应精确审／实验，不能用新增completion掩盖，反之也不能以candidate合同豁免真实授权。

## 最小建议：先守住现有两条边界

1. **本轮不改Trace、schema或全部普通stage。** 在C48分别登记“raw candidate记录”与“已明确事务completion”；raw action＋失败CP／cycle failure可以同时成立，不当付款成功，也不把无defer自动判缺实现。已有deferred false→error保其已批准原文及opaque证据限界。
2. completion只是已有运行元数据／通知身份，不序列化capability，不新增全局store、Role分派或统一Boolean付款。每个需要它的真实窗口自己声明完成点，合法null／none／abstain是否完成依原语义，不能套Seer。
3. **若以后明确要求某个事务同时保留raw候选与完成失败**，现有outcome联合不足，不能用改名或把false仍写action隐含解决。最小录制变化是独立的可选纯数据 `returnedCandidate`（包括合法null），当前outcome/settleOrder继续表达该事务完成结果；候选在安全data复制成功后记录，不把它视作预检／权限。需单列shape／版本兼容，联动writer、strict schema、replay以及受影响独立verifier，保护原pending／error、首错及通知错误前缀。它不需要新事务框架，但也**不是本轮可以顺手加的comment或机械迁移**；现无确定需求时不实施。

后者如果做，旧严格Tape按原构建身份处理；不能重写旧sourceHash或强行把历史action变error。公开replay/player reader不因内部completion而增新授权判断。已有Cupid／Hybrid verifier允许opaque，是当前false丢候选的真实记录边界，不能据新增字段猜补旧档中根本没保存的信息。

## 状态

普通四族未运行的4声明／12fresh探针保持冻结，仅是可选现状输入，**不建议以其“即时记录早于writer”的预设断言证明必须改事务**。没有新测试／类型／parser／程序／门禁执行，没有仓库写入。C43封包脚本等待Root路径后另独审。
