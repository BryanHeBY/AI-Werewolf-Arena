"""对已完成的三媒体作实际探测与视频解码；不再次渲染或运行游戏。人工视觉记录另写。"""
from pathlib import Path
import hashlib,json,subprocess,time
bundle=Path('/var/tmp/awa-refactor-20261015/c47-60fdbfbc');out=Path('/tmp/awa-c47-60fdbfbc-media-inspection');out.mkdir(exist_ok=False)
for name in ['home','tmp']:(out/name).mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','TZ':'UTC'}
ids={'replay-zh-CN.png':'render-png-zh-CN','replay-en.png':'render-png-en','replay-en.mp4':'render-mp4-en'};before={name:sha(bundle/'artifacts'/name) for name in ids};tools={name:{'realpath':str(Path('/usr/bin/'+name).resolve()),'sha256':sha(Path('/usr/bin/'+name).resolve())} for name in ['ffprobe','ffmpeg','ss']};commands=[];metadata={}
def run(label,argv):
 start=time.time();code=None;error=None
 try:
  with (out/(label+'.stdout.raw')).open('wb') as stdout,(out/(label+'.stderr.raw')).open('wb') as stderr:code=subprocess.run(argv,env=env,cwd=out,stdout=stdout,stderr=stderr,timeout=120).returncode
 except BaseException as caught:
  error={'type':type(caught).__name__,'message':str(caught)}
  raise
 finally:
  row={'label':label,'argv':argv,'exitCode':code,'error':error,'seconds':time.time()-start,'raw':[{'path':label+suffix,'sha256':sha(out/(label+suffix)),'bytes':(out/(label+suffix)).stat().st_size} for suffix in ['.stdout.raw','.stderr.raw'] if (out/(label+suffix)).is_file()]};commands.append(row);(out/'command-progress.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
 assert code==0,label;return (out/(label+'.stdout.raw')).read_text()
manifest_path=bundle/'snapshot-manifest.json';actual_manifest_sha=sha(manifest_path);assert actual_manifest_sha=='08cb4b2ba9640566b28b9610ea22c1602d40eee811c47be282128ca8618b591e'
manifest_data=json.loads(manifest_path.read_text());render_receipts=[]
for name,cid in ids.items():
 path=bundle/'receipts'/(cid+'-attempt-1')/'receipt.json';receipt=json.loads(path.read_text());assert receipt['success'] and receipt['id']==cid and receipt['attempt']==1 and receipt['base']=='60fdbfbc57122eeb1d4e9204b66d4daec1eb0157' and receipt['manifestSha256']==actual_manifest_sha
 render_receipts.append({'id':cid,'path':str(path),'sha256':sha(path),'preInputFence':receipt['preInputFence'],'postInputFence':receipt['postInputFence']})
for name in ['ffmpeg','ffprobe']:
 captured=next(row for row in manifest_data['tools'] if row['requested']=='/usr/bin/'+name);assert tools[name]['sha256']==captured['sha256'] and tools[name]['realpath']==captured['realpath'];tools[name]['sameAsCapturedManifestTool']=True
tools['ss']['scope']='Additional tool for the bounded port4173 observation; not a captured render tool.'
launch={'base':'60fdbfbc57122eeb1d4e9204b66d4daec1eb0157','manifestSHA256':'08cb4b2ba9640566b28b9610ea22c1602d40eee811c47be282128ca8618b591e','scriptSHA256':sha(__file__),'tools':tools,'env':env,'artifactsSHA256Before':before,'actualManifest':{'path':str(manifest_path),'sha256':actual_manifest_sha},'renderReceipts':render_receipts}
(out/'launch.json').write_text(json.dumps(launch,ensure_ascii=False,indent=2)+'\n')
first_error=None
try:
 for name,cid in ids.items():
  info=json.loads(run(name,['/usr/bin/ffprobe','-v','error','-show_streams','-show_format','-of','json',str(bundle/'artifacts'/name)]));streams=info['streams'];video=next(s for s in streams if s['codec_type']=='video');assert video['width']==1280 and video['height']==720
  if name.endswith('.png'):assert video['codec_name']=='png'
  else:assert video['codec_name']=='h264' and video['r_frame_rate']=='30/1' and int(video['nb_frames'])==180 and abs(float(info['format']['duration'])-6)<0.001 and not any(s['codec_type']=='audio' for s in streams)
  metadata[name]=info
 run('decode',['/usr/bin/ffmpeg','-v','error','-nostdin','-i',str(bundle/'artifacts/replay-en.mp4'),'-vf',r'select=eq(n\,15)+eq(n\,105)','-fps_mode','passthrough','-frames:v','2',str(out/'frame-%02d.png')]);frames=[out/'frame-01.png',out/'frame-02.png'];assert all(p.is_file() and p.stat().st_size>0 for p in frames)
 port=run('port4173',['/usr/bin/ss','-H','-ltnp','sport = :4173']);assert not port.strip(),'4173 still listening'
 assert before=={name:sha(bundle/'artifacts'/name) for name in ids}
 for name,row in tools.items():assert sha(row['realpath'])==row['sha256']
except BaseException as caught:
 first_error={'type':type(caught).__name__,'message':str(caught)}
 raise
finally:
 # 每个实际步骤及首错均有原始记录；失败不被末成功状态覆盖，也不触发隐式重试。
 after={name:sha(bundle/'artifacts'/name) if (bundle/'artifacts'/name).is_file() else None for name in ids}
 status='FAILED_ACTUAL_MEDIA_INSPECTION' if first_error else 'ACTUAL_METADATA_AND_DECODE_PASSED_VISUAL_REVIEW_PENDING'
 r={**launch,'status':status,'firstError':first_error,'commands':commands,'metadata':metadata,'artifactsSHA256After':after,'mediaBytesPrePostSame':before==after,'decodedFrames':[{'frame':f,'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for f,p in zip([15,105],[out/'frame-01.png',out/'frame-02.png']) if p.is_file()],'port4173ListenerAbsentAtRead':not (out/'port4173.stdout.raw').read_text().strip() if (out/'port4173.stdout.raw').is_file() and any(row['label']=='port4173' and row['exitCode']==0 for row in commands) else None,'limits':['No game or render rerun; only probes/decodes existing media.','Actual image viewing is required before visual approval.','Port4173 observation is bounded, not every escaped process/listener.']}
 (out/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':r['status'],'output':str(out),'artifacts':list(ids),'decodedFrames':[15,105]}))
