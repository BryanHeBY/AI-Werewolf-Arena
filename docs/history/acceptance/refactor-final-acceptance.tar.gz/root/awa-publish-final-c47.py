"""最终42真实成功及人工独审后，封存公开验收证据；准备本脚本不构成验收。"""
from pathlib import Path
import gzip,hashlib,io,json,shutil,stat,tarfile,sys
repo=Path('/home/hby/dev/AI-Werewolf-Arena');config=Path(sys.argv[1]);c=json.loads(config.read_text());base='60fdbfbc57122eeb1d4e9204b66d4daec1eb0157';manifest='08cb4b2ba9640566b28b9610ea22c1602d40eee811c47be282128ca8618b591e';b=Path(c['bundle']);sha=lambda v:hashlib.sha256(v).hexdigest()
assert c['decision']=='APPROVED_FOR_C47_PUBLICATION' and c['base']==base and c['manifestSHA256']==manifest
collection=Path(c['collection']);d=json.loads(collection.read_text());assert d['status']=='COLLECTED_PENDING_INDEPENDENT_REVIEW' and d['base']==base and d['manifestSha256']==manifest and not d['pending'] and not d['errors']
assert len(d['commandIDs'])==len(set(d['commandIDs']))==42 and set(d['successfulIDs'])==set(d['commandIDs']) and len(d['attempts'])>=42
# 原计划允许前一次真实失败后显式人工重试；逐次保留，不把42个ID误作恰好42次尝试。
for cid in d['commandIDs']:
 attempts=sorted([row for row in d['attempts'] if row['id']==cid],key=lambda row:row['attempt']);assert attempts and [row['attempt'] for row in attempts]==list(range(1,len(attempts)+1)) and attempts[-1]['success'] and all(not row['success'] for row in attempts[:-1])
assert sha((b/'snapshot-manifest.json').read_bytes())==manifest
assert d['manifest']['path']==str(b/'snapshot-manifest.json') and d['plan']['path']==str(b/'execution-plan.json') and d['finalSummary']['path']==str(b/'summary-final.json')
summary=json.loads((b/'summary-final.json').read_text());assert summary['status']=='COMMAND_RECEIPTS_COMPLETE_PENDING_SEMANTIC_REVIEW'
assert len(c['independentReviews'])==3 and len({r['reviewer'] for r in c['independentReviews']})==3
# 采集之后的真实字节必须仍相同，不能把被替换的 raw 或计划收入已签的摘要。
def bound(row):
 p=Path(row['path']);assert p.is_file() and not p.is_symlink();raw=p.read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
 if 'posixMode' in row:assert format(stat.S_IMODE(p.stat().st_mode),'04o')==row['posixMode']
 if 'gitMode' in row:assert ('100755' if p.stat().st_mode&0o100 else '100644')==row['gitMode']
 return p
for key in ['manifest','plan','helper','finalSummary','historyIndex']:bound(d[key])
for row in d['attempts']:
 for key in ['receipt','launch','process']:
  if row.get(key):bound(row[key])
 for raw in row['raw']:bound(raw)
assert summary['base']==base and summary['manifestSha256']==manifest
inspection_ref=c['mediaReview']['inspectionReceipt'];visual_ref=c['mediaReview']['visualReview']
for ref in [inspection_ref,visual_ref]:assert sha(Path(ref['path']).read_bytes())==ref['sha256']
inspection=json.loads(Path(inspection_ref['path']).read_text());visual=json.loads(Path(visual_ref['path']).read_text())
assert inspection['status']=='ACTUAL_METADATA_AND_DECODE_PASSED_VISUAL_REVIEW_PENDING' and inspection['base']==base and inspection['manifestSHA256']==manifest and inspection['mediaBytesPrePostSame'] is True and inspection['port4173ListenerAbsentAtRead'] is True
assert visual['status']=='VISUALLY_INSPECTED_WITH_NO_FINDING' and visual['base']==base and visual['manifestSHA256']==manifest and not visual['findings']
expected_images={str(b/'artifacts/replay-zh-CN.png'),str(b/'artifacts/replay-en.png')}|{row['path'] for row in inspection['decodedFrames']}
assert {row['frame'] for row in inspection['decodedFrames']}=={15,105} and len(visual['images'])==4 and {row['path'] for row in visual['images']}==expected_images
for row in visual['images']:assert sha(Path(row['path']).read_bytes())==row['sha256']
for name in ['replay-zh-CN.png','replay-en.png','replay-en.mp4']:
 info=inspection['metadata'][name];video=next(row for row in info['streams'] if row['codec_type']=='video');assert video['width']==1280 and video['height']==720
 assert inspection['artifactsSHA256Before'][name]==inspection['artifactsSHA256After'][name]==sha((b/'artifacts'/name).read_bytes())
 if name.endswith('.png'):assert video['codec_name']=='png'
 else:assert video['codec_name']=='h264' and video['r_frame_rate']=='30/1' and int(video['nb_frames'])==180 and abs(float(info['format']['duration'])-6)<0.001 and not any(row['codec_type']=='audio' for row in info['streams'])
members={}
def add(path,name):
 path=Path(path);assert path.is_file() and not path.is_symlink() and name not in members and not name.startswith('/') and '..' not in Path(name).parts
 members[name]={'bytes':path.read_bytes(),'mode':stat.S_IMODE(path.stat().st_mode)}
for name in ['snapshot-manifest.json','execution-plan.json','git-contract-receipt.json','summary-final.json']:add(b/name,'current/'+name)
for path in sorted((b/'receipts').glob('*/*')):
 if path.is_file():add(path,'current/receipts/'+path.relative_to(b/'receipts').as_posix())
for row in d['media']:
 path=Path(row['path']);assert path.parent==b/'artifacts' and sha(path.read_bytes())==row['sha256'];add(path,'current/artifacts/'+path.name)
assert {Path(r['path']).name for r in d['media']}=={'replay-zh-CN.png','replay-en.png','replay-en.mp4'}
add(collection,'collection/actual-collection.json');add(config,'root/final-publication-decision.json');add(inspection_ref['path'],'media/inspection-receipt.json');add(visual_ref['path'],'media/root-visual-review.json')
collector=Path('/tmp/awa-c47-pure-data-collector-60fdbfbc')
for p in sorted(collector.iterdir()):
 if p.is_file():add(p,'collection/tool/'+p.name)
for name in ['awa-c47-run-final-lanes.py','awa-publish-final-c47.py','awa-c47-final-publication-plan.json']:add('/tmp/'+name,'root/'+name)
helper=Path('/tmp/awa-c47-public-snapshot')
for p in sorted(helper.iterdir()):
 if p.is_file():add(p,'helper/'+p.name)
history=json.loads((collector/'history-index.json').read_text());archival=[]
for i,row in enumerate(history['evidence'],1):
 p=Path(row['path']);assert sha(p.read_bytes())==row['sha256'];name=f'history/evidence-{i:03d}/'+p.name;add(p,name);archival.append({**row,'archivePath':name})
members['history/archival-map.json']={'bytes':(json.dumps(archival,ensure_ascii=False,indent=2)+'\n').encode(),'mode':0o644}
peers=[]
for i,row in enumerate(c['independentReviews'],1):
 p=Path(row['path']);assert sha(p.read_bytes())==row['sha256'] and row['approved'] is True;report=json.loads(p.read_text());assert report['c47PublicationApproved'] is True and report['base']==base and report['manifestSHA256']==manifest and report['reviewer']==row['reviewer'];name=f'independent/review-{i:02d}.json';add(p,name);peers.append({**row,'archivePath':name,'report':report})
for row in c['additionalEvidence']:
 p=Path(row['path']);assert sha(p.read_bytes())==row['sha256'];add(p,row['archivePath'])
index=[{'path':n,'bytes':len(v['bytes']),'mode':oct(v['mode']),'sha256':sha(v['bytes'])} for n,v in sorted(members.items())]
members['archive-index.json']={'bytes':(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode(),'mode':0o644}
out=Path(c['stagingDirectory']);out.mkdir(exist_ok=False);stem='refactor-final-acceptance';archive=out/(stem+'.tar.gz')
with archive.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,value in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(value['bytes']);info.mode=value['mode'];info.mtime=0;tar.addfile(info,io.BytesIO(value['bytes']))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(members)
 for row in json.load(tar.extractfile('archive-index.json')):assert sha(tar.extractfile(row['path']).read())==row['sha256']
receipt={'status':'ACCEPTED_WITH_DECLARED_BOUNDED_SUPPORT','testedSource':base,'manifestSHA256':manifest,'commands':d['commandIDs'],'atomicCommands':42,'executionCollection':d,'independentReviews':[{'reviewer':r['reviewer'],'path':r['archivePath'],'sha256':r['sha256'],'approved':True} for r in peers],'resourceReview':c['resourceReview'],'mediaReview':c['mediaReview'],'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(members)},'publicationIdentity':'Evidence-only commit determined from Git at this exact path; not a new tested source.','limits':['42 command IDs do not prove every input or arbitrary55-role combination.','C48 independently reconciles843 applicable responsibilities and67 reasoned local NAs.','Original failed/interrupted rounds and their source identities remain in the archive; no green is spliced.','Process-group observations do not prove the absence of every escaped descendant or listener.']}
(out/(stem+'.receipts.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');(out/(stem+'.peer-review.json')).write_text(json.dumps({'status':'THREE_ASPECTS_APPROVED_WITH_DECLARED_SCOPE','base':base,'manifestSHA256':manifest,'reviews':peers},ensure_ascii=False,indent=2)+'\n')
rows=[]
for row in d['attempts']:
 if 'bun' in row:
  v=row['bun']['countsActuallyPrinted'];rows.append('| `'+row['id']+'` #'+str(row['attempt'])+' | '+str(v.get('pass','—'))+' | '+str(v.get('fail','—'))+' | '+str(v.get('expect() calls','—'))+' | '+str(v.get('skip','—'))+' |')
pw=next(r['playwright'] for r in d['attempts'] if r['id']=='chromium-e2e' and r['success'])
text='''# 重构最终固定输入验收

受测源码 `'''+base+'''`，公开输入 manifest `'''+manifest+'''`。全部 42 个原子命令在该固定输入、净环境和相同工具链下实际完成，原始输出、Git／来源首末检查和完整命令见[收据](refactor-final-acceptance.receipts.json)及[证据封包](refactor-final-acceptance.tar.gz)。14 个类型项目、两个构建、各层测试及静态门禁分别保留，不重复运行根聚合任务累加结果。

## 实际测试输出

共 `'''+str(len(d['attempts']))+'''` 次实际尝试，42 个命令 ID 取得成功终态。若有前次失败，同输入人工重试须有原始原因、收据和退出记录；各次结果独立列出，不叠加重复用例。

下表只列真实 Bun 末统计；未打印的计数为“—”，不补造零，也不将声明、断言和夹具调用混算。

| 命令 | pass | fail | expect | skip |
| --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+'''

Chromium 实际展开统计为 `'''+json.dumps(pw['stats'],ensure_ascii=False)+'''`，完整 JSON 保存在原始 stdout 中；不能把静态 spec 文件数当执行用例数。

## 中文契约、媒体与独审

严格架构门禁覆盖 3364 份文件，零违规、零未清债务；关键流程的中文结构、权限、生命周期、执行顺序和错误前缀另经人工抽核。完整计划与其有界实现仍由[当前职责矩阵](../../architecture/migration-matrix.json)和[支持边界](../../contracts/mechanism-support-boundaries.md)解释。

实际生成中文、英文 PNG 和英文 H264 MP4，并读取 ffprobe、人工查看两图和视频解码的第 15／105 帧。该样本仅两个玩家、两个事件，1280×720；视频为 30fps、180 帧、6 秒。frame 0 字幕透明属于动画预期，样本不含昵称或终局事件，不宣称验证了完整十二人局或全部角色画面。

[三方面独审](refactor-final-acceptance.peer-review.json)核对架构与来源、规则与媒体、数据与验证边界。原 cb、07ef、f2 等失败／超时轮保留已记录的输入身份、首红／超时／早停终态及实际原始输出和未运行项；后继有限修复没有倒补旧轮绿色。场景组整组预算为实际已审 14400 秒，单用例与原发现集合保持。

本包先于最终文档元数据独立提交；后者不冒称同一整仓快照重新受测。42 命令通过与 843 个适用职责的有界接受是两种登记；67 项本地不适用须有业务理由，55 个运行 Role 不代表任意混搭支持。
'''
(out/(stem+'.md')).write_text(text)
assert len(list(out.iterdir()))==4
for p in out.iterdir():assert not (repo/'docs/history/acceptance'/p.name).exists()
for p in out.iterdir():shutil.copyfile(p,repo/'docs/history/acceptance'/p.name)
print(json.dumps({'stagedFourPieces':str(out),'archiveBytes':archive.stat().st_size,'members':len(members),'source':base}))
