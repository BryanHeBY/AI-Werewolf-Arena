#!/usr/bin/env python3
"""Root 以固定候选运行原42项；耗I/O的tooling独占后置，命令与超时均不变。"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

bundle = Path(sys.argv[1]).resolve()
base = sys.argv[2]
lane = sys.argv[3]
helper = '/tmp/awa-c47-public-snapshot/c47-public-snapshot.py'
groups = json.loads(Path('/tmp/awa-c47-execution-group-review/grouping.json').read_text())
plan = json.loads((bundle / 'execution-plan.json').read_text())
probe = json.loads((bundle / 'git-contract-receipt.json').read_text())
assert probe['status'] == 'INPUT_PROTOCOL_READY_NOT_GAMEPLAY_GATE'
manifest_bytes = (bundle / 'snapshot-manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
manifest_sha = hashlib.sha256(manifest_bytes).hexdigest()
assert manifest['baseCommit'] == base and probe['manifestSha256'] == manifest_sha
assert manifest['helperSha256'] == hashlib.sha256(Path(helper).read_bytes()).hexdigest()
assert manifest['planSha256'] == hashlib.sha256((bundle / 'execution-plan.json').read_bytes()).hexdigest()
by_id = {row['id']: row for row in plan['commands']}
parallel = {name: [item for item in items if item != 'tooling-tests']
            for name, items in groups['parallelLanes'].items()}
tail = groups['serialTailAfterAllLanes']
assigned = [item for items in parallel.values() for item in items] + ['tooling-tests'] + tail
assert len(assigned) == 42 and len(set(assigned)) == 42 and set(assigned) == set(by_id)
assert len(base) == 40 and all(c in '0123456789abcdef' for c in base)

def require_success(ids):
    # 必须来自本候选真实attempt-1；失败不在此启动器内重试，更不能拼接旧轮绿色。
    for item in ids:
        receipt = json.loads((bundle / 'receipts' / (item + '-attempt-1') / 'receipt.json').read_text())
        assert receipt['success'] is True and receipt['base'] == base, item
        assert receipt['id'] == item and receipt['attempt'] == 1, item
        assert receipt['manifestSha256'] == manifest_sha, item

if lane == 'tooling-after-parallel':
    require_success([item for items in parallel.values() for item in items])
    ids = ['tooling-tests']
elif lane == 'serial-tail':
    require_success([item for items in parallel.values() for item in items] + ['tooling-tests'])
    ids = tail
else:
    ids = parallel[lane]
for item in ids:
    command = by_id[item]
    argv = ['/usr/bin/python3', helper, 'run', '--bundle', str(bundle), '--command', item,
            '--lane', lane, '--timeout', str(command['timeoutSecondsSuggested']), '--execute']
    print(json.dumps({'launching': item, 'argv': argv}), flush=True)
    code = subprocess.run(argv, env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'TZ': 'UTC', 'TMPDIR': '/tmp'}).returncode
    print(json.dumps({'finished': item, 'helperExitCode': code}), flush=True)
    if code:
        sys.exit(code)
print(json.dumps({'lane': lane, 'commandsCompleted': len(ids)}), flush=True)
