"""原冻结 helper 的单次受限运行入口；只缩短浏览器类命令的独占 TMPDIR。"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os

BUNDLE = Path('/var/tmp/awa-refactor-20261015/c47-60fdbfbc')
HERE = Path(__file__).parent
HELPER = Path('/tmp/awa-c47-public-snapshot/c47-public-snapshot.py')
ALLOWED = {'chromium-e2e': 2, 'render-png-zh-CN': 1, 'render-png-en': 1, 'render-mp4-en': 1}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
parser = argparse.ArgumentParser()
parser.add_argument('command', choices=ALLOWED)
args = parser.parse_args()
cid = args.command
attempt = ALLOWED[cid]
assert sha(HELPER) == '632d87e1024ac0c7a4be32a2c2d454e17a5e44030056dff05d4fbd6d3f47a87d'
assert sha(BUNDLE/'snapshot-manifest.json') == '08cb4b2ba9640566b28b9610ea22c1602d40eee811c47be282128ca8618b591e'
assert sha(BUNDLE/'execution-plan.json') == '18a92451981ea503702198ab61a2dc9436b8d2dc2a2b538fa0e804cf24fcd957'
assert json.loads((BUNDLE/'snapshot-manifest.json').read_text())['baseCommit'] == '60fdbfbc57122eeb1d4e9204b66d4daec1eb0157'
failed = BUNDLE/'receipts/chromium-e2e-attempt-1'
first = json.loads((failed/'receipt.json').read_text())
assert first['success'] is False and first['exitCode'] == 1 and first['preparationOrFenceError'] is None
report = json.loads((failed/'stdout.raw').read_text())
assert report['stats']['expected'] == 0 and report['stats']['unexpected'] == 362
def failures(suites):
    for suite in suites:
        for spec in suite.get('specs', []):
            for test in spec.get('tests', []):
                for result in test.get('results', []):
                    if result['status'] == 'failed':
                        yield result
        yield from failures(suite.get('suites', []))
rows = list(failures(report['suites']))
assert len(rows) == 362 and all(any('Socket path too long:' in e.get('message', '') for e in r['errors']) for r in rows)
for prior in json.loads((BUNDLE/'execution-plan.json').read_text())['commands']:
    if prior['id'] in ALLOWED:
        continue
    r = json.loads((BUNDLE/'receipts'/(prior['id']+'-attempt-1')/'receipt.json').read_text())
    assert r['success'] is True
if cid != 'chromium-e2e':
    assert json.loads((BUNDLE/'receipts/chromium-e2e-attempt-2/receipt.json').read_text())['success'] is True
short = Path('/tmp')/('awa47-'+{'chromium-e2e':'pw2','render-png-zh-CN':'zh1','render-png-en':'en1','render-mp4-en':'mp1'}[cid])
assert not short.exists() and not short.is_symlink()
short.mkdir(mode=0o700)
assert short.resolve() == short and (short.stat().st_mode & 0o777) == 0o700 and short.stat().st_uid == os.getuid()
spec = importlib.util.spec_from_file_location('frozen_c47_helper', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
original = helper.planned_env
def environment(command, runtime):
    assert command['id'] == cid
    before = original(command, runtime)
    after = {**before, 'TMPDIR': str(short)}
    assert {k for k in before if before[k] != after[k]} == {'TMPDIR'}
    record = {'kind': 'explicit short temporary path execution protocol supplement',
              'base': first['base'], 'manifestSHA256': first['manifestSha256'],
              'command': cid, 'attempt': attempt, 'helperSHA256': sha(HELPER),
              'wrapperSHA256': sha(__file__), 'failedReceiptSHA256': sha(failed/'receipt.json'),
              'failedReportSHA256': sha(failed/'stdout.raw'), 'all362FailuresAtBrowserLaunchSocketPath': True,
              'environmentBefore': before, 'environmentAfter': after, 'onlyChangedKey': 'TMPDIR',
              'shortDirectory': {'path': str(short), 'uid': short.stat().st_uid, 'mode': '0700', 'initiallyEmpty': not any(short.iterdir())},
              'limits': 'Same product/plan/helper/tool bytes and argv; execution TMPDIR placement differs explicitly. No old attempt reclassified; no retry of green.'}
    target = HERE/(cid+'-attempt-'+str(attempt)+'-supplement.json')
    with target.open('x') as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
        f.write('\n')
    return after
helper.planned_env = environment
command = next(r for r in json.loads((BUNDLE/'execution-plan.json').read_text())['commands'] if r['id'] == cid)
reason = 'Manual retry after all362 browser launch failures: Unix SingletonSocket path exceeds platform length. Only TMPDIR placement shortened to a fresh private0700 directory; source, plan, argv, tools and original failed attempt retained.' if attempt == 2 else None
helper.run_one(argparse.Namespace(bundle=str(BUNDLE), command=cid, attempt=attempt, reason=reason, lane='serial-tail-short-tmp-supplement', timeout=command['timeoutSecondsSuggested'], execute=True))
