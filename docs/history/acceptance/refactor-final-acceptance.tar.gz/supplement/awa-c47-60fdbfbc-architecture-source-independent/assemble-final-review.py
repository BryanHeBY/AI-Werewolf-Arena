"""只组装已有收据与字节身份的末审记录，不执行任何产品或项目检查。"""
from pathlib import Path
import json,hashlib,stat
B=Path('/var/tmp/awa-refactor-20261015/c47-60fdbfbc'); O=Path('/tmp/awa-c47-60fdbfbc-architecture-source-independent')
S='60fdbfbc57122eeb1d4e9204b66d4daec1eb0157'; M='08cb4b2ba9640566b28b9610ea22c1602d40eee811c47be282128ca8618b591e'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def identity(p):
 p=Path(p);raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
errors=[]
def note(ok,label):
 if not ok:errors.append(label)
def bind(row,label,root=None):
 p=Path(row['path']);p=(root/p) if root is not None and not p.is_absolute() else p
 actual=identity(p); note(actual['sha256']==row['sha256'],label+':sha');note(actual['bytes']==row['bytes'],label+':bytes')
 if 'gitMode' in row:note(row['gitMode']==('100755' if p.stat().st_mode&0o100 else '100644'),label+':mode')
 return actual
manifest=read(B/'snapshot-manifest.json');plan=read(B/'execution-plan.json');commands={x['id']:x for x in plan['commands']}; prior=read(O/'terminal-38-receipts-review.json')
summary=read(B/'summary-final.json');collector=read('/tmp/awa-c47-60fdbfbc-collected-first.json');supp=read('/tmp/awa-c47-short-tmp-protocol/actual-environment-verification.json');media_root=Path('/tmp/awa-c47-60fdbfbc-media-inspection');media=read(media_root/'receipt.json');visual=read(media_root/'root-visual-review.json')
note(identity(B/'snapshot-manifest.json')['sha256']==M,'manifest actualsha');note(manifest['baseCommit']==S,'manifest base');note(identity(B/'execution-plan.json')['sha256']==manifest['planSha256'],'plan fixedsha')
for name,d in [('summary',summary),('collector',collector),('supplement',supp),('media',media),('visual',visual)]:
 note(d['base']==S,name+':base');note(d.get('manifestSHA256',d.get('manifestSha256'))==M,name+':manifest')
note(not collector['errors'] and not collector['pending'],'collector empty errors/pending');note(len(collector['attempts'])==43 and set(collector['commandIDs'])==set(commands) and set(collector['successfulIDs'])==set(commands),'collector 43 attempts/42 known successfulIDs')
note(summary['status']=='COMMAND_RECEIPTS_COMPLETE_PENDING_SEMANTIC_REVIEW' and not summary['missingCommandIDs'],'helper summary complete bounded inventory')
# 既有38份只末绑其收据SHA，沿用先前对raw及fence的完整阅读，不再扫源码或依赖。
for previous in prior['terminalReceipts']:
 note(identity(previous['receiptPath'])['sha256']==previous['receiptSHA256'],'prior38 unchanged '+previous['id'])
summary_refs={(r['id'],r['attempt']):r for r in summary['receipts']};collector_refs={(r['id'],r['attempt']):r for r in collector['attempts']}
for key,r in summary_refs.items():
 note(identity(r['path'])['sha256']==r['sha256'],'summary actual receipt '+str(key));note(collector_refs[key]['receipt']['sha256']==r['sha256'],'collector summary receipt agrees '+str(key))
core=prior['terminalReceipts'][0]['fences']['preInputFence']['dependencyCoreDigest'];tail=[];raws=[]
for cid,attempt in [('chromium-e2e',1),('chromium-e2e',2),('render-png-zh-CN',1),('render-png-en',1),('render-mp4-en',1)]:
 folder=B/'receipts'/f'{cid}-attempt-{attempt}';r=read(folder/'receipt.json');command=commands[cid]
 expected_argv=[v.replace('<RUN_ARTIFACT_DIR>',str(B/'artifacts')) for v in command['argv']]
 note(r['base']==S and r['manifestSha256']==M and r['id']==cid and r['attempt']==attempt,'tail identity '+cid+str(attempt))
 note(r['argv']==expected_argv and r['cwd']==str(B/'snapshot'/command['cwd']),'tail plan argv/cwd '+cid+str(attempt))
 note(r['signal'] is None and not r['timedOut'] and r['preparationOrFenceError'] is None and r['resourceGroupStillExistsAfterWait'] is False,'tail terminal/fence '+cid+str(attempt))
 for raw in r['raw']:raws.append(bind(raw,cid+str(attempt)+':'+Path(raw['path']).name))
 fences={}
 for f in ['preInputFence','postInputFence']:
  x=r[f];note(x['inputDigest']==manifest['inputDigest'] and x['gitDigest']==manifest['gitFilesDigest'] and x['dependencyCoreDigest']==core,'tail source/git/core '+cid+str(attempt)+f)
  note(all(any(c['path']==p or c['path'].startswith(p+'/') for p in plan['dependencyCachePrefixes']) for c in x['explicitCacheRows']),'recorded caches bounded '+cid+str(attempt)+f)
  fences[f]={k:x[k] for k in ['checkedAt','inputDigest','gitDigest','dependencyCoreDigest','actualDependencyDigest']};fences[f]['explicitCacheRows']=len(x['explicitCacheRows'])
 raw_pw=None
 if cid=='chromium-e2e':
  raw_pw=read(folder/'stdout.raw');leaves=[];files=set()
  def walk(suites):
   for suite in suites:
    for spec in suite.get('specs',[]):
     files.add(spec.get('file') or suite.get('file'))
     for test in spec.get('tests',[]):leaves.extend(test.get('results',[]))
    walk(suite.get('suites',[]))
  walk(raw_pw['suites']);note(len(leaves)==362 and len(files)==23 and not raw_pw.get('errors',[]),'PW actual expanded results '+str(attempt))
  if attempt==1:
   note(r['success'] is False and r['exitCode']==1 and raw_pw['stats']['unexpected']==362,'PW first actualred')
   note(all(x['status']=='failed' and any('Socket path too long:' in e.get('message','') for e in x.get('errors',[])) for x in leaves),'PW first all362 launchsocket errors')
  else:note(r['success'] is True and r['exitCode']==0 and all(x['status']=='passed' for x in leaves) and raw_pw['stats']['expected']==362 and raw_pw['stats']['unexpected']==0 and raw_pw['stats']['skipped']==0 and raw_pw['stats']['flaky']==0,'PW2 actual362pass')
 else:note(r['success'] is True and r['exitCode']==0,'render success '+cid)
 tail.append({'id':cid,'attempt':attempt,'receipt':identity(folder/'receipt.json'),'exitCode':r['exitCode'],'success':r['success'],'startedAt':r['startedAt'],'endedAt':r['endedAt'],'argv':r['argv'],'fences':fences,'raw':r['raw'],'playwrightStats':raw_pw['stats'] if raw_pw else None})
# 已prepared独审过的纯数据补充验证器由Root实际执行0；本次只读其实际输出与附件。
note(supp['status']=='ENVIRONMENT_SUPPLEMENTS_COMPLETE' and not supp['errors'] and not supp['pending'] and len(supp['attempts'])==4,'actual supplement complete')
note(supp['script']['sha256']=='a20e7b5749fec408d75d16cf18ebc25b1b16510b729eadc91eda478933c8348e','supplement reviewed script')
for i,row in enumerate(supp['bindings']):bind(row,'supplement binding'+str(i))
for i,row in enumerate(supp['firstPWRed']):bind(row,'original PW file'+str(i))
for a in supp['attempts']:
 for key in ['supplement','launch','process','receipt']:bind(a[key],a['id']+':'+key)
 for i,row in enumerate(a['raw']):bind(row,a['id']+':raw'+str(i))
 note(a['terminalSuccess'] is True and a['resourceGroupStillExistsAfterWait'] is False,'actual supplemented terminal '+a['id'])
 note(list(a['environmentDifference'])==['TMPDIR'],'actual supplementary delta '+a['id'])
# 只读媒体身份/已执行probe、decode与Root真实view收据，不再运行媒体命令。
note(media['firstError'] is None and media['mediaBytesPrePostSame'] is True,'media actual successful probe/decode');note(media['status']=='ACTUAL_METADATA_AND_DECODE_PASSED_VISUAL_REVIEW_PENDING','media inspector stage accurately retained')
note(visual['status']=='VISUALLY_INSPECTED_WITH_NO_FINDING' and not visual['findings'] and visual['reviewer']=='/root','actual Root visual nofinding')
for cmd in media['commands']:
 note(cmd['exitCode']==0 and cmd['error'] is None,'actual media command '+cmd['label'])
 for i,row in enumerate(cmd['raw']):bind(row,'actual media raw '+cmd['label']+str(i),media_root)
for r in media['renderReceipts']:note(identity(r['path'])['sha256']==r['sha256'],'media actual render receipt '+r['id'])
for a in summary['artifacts']:
 actual=bind(a,'actual artifact '+a['path'],B);basename=Path(a['path']).name
 note(media['artifactsSHA256Before'][basename]==actual['sha256']==media['artifactsSHA256After'][basename],'media before/after '+basename)
for frame in media['decodedFrames']:bind(frame,'actual decoded frame')
for image in visual['images']:note(identity(image['path'])['sha256']==image['sha256'],'actual viewed bytes '+image['path'])
for name in ['replay-zh-CN.png','replay-en.png']:
 stream=media['metadata'][name]['streams'][0];note(stream['codec_name']=='png' and stream['width']==1280 and stream['height']==720,'actual PNG shape '+name)
v=media['metadata']['replay-en.mp4']['streams'][0];note(v['codec_name']=='h264' and v['width']==1280 and v['height']==720 and v['avg_frame_rate']=='30/1' and v['nb_frames']=='180' and v['duration']=='6.000000','actual MP4 shape/timing')
ff=summary['finalFence'];note(ff['inputDigest']==manifest['inputDigest'] and ff['gitDigest']==manifest['gitFilesDigest'] and ff['dependencyCoreDigest']==core,'final input/git/corefence')
refs=[O/'static-source-review.json',O/'terminal-38-receipts-review.json',Path('/tmp/awa-c47-short-tmp-verifier-independent/prepared-review.json'),B/'snapshot-manifest.json',B/'execution-plan.json',B/'summary-final.json',Path('/tmp/awa-c47-60fdbfbc-collected-first.json'),Path('/tmp/awa-c47-short-tmp-protocol/actual-environment-verification.json'),Path('/tmp/awa-c47-short-tmp-protocol/first-red-classification.json'),media_root/'receipt.json',media_root/'root-visual-review.json']
final={
 'reviewer':'/root/native_final_architecture_review','role':'architecture_source_and_final_C47_receipt_peer','decision':'approved_for_C47_evidence_publication' if not errors else 'blocked_by_actual_identity_difference','base':S,'manifestSHA256':M,'c47PublicationApproved':not errors,'sourceStaticPortionApproved':True,'errors':errors,
 'reviewedEvidence':[identity(p) for p in refs],
 'actualCommandScope':{'knownPlannedIDs':42,'successfulIDs':42,'actualAttempts':43,'firstFailedAttemptsPreserved':1,'remainingUnrunIDs':0,'collectionErrors':collector['errors'],'collectionPending':collector['pending'],'prior38ReceiptSHAsUnchanged':True,'tailActualReceipts':tail,'aggregateProductsNotRerunByReviewer':True},
 'explicitEnvironmentSupplement':{'onlyChangedKey':'TMPDIR','commands':['chromium-e2e#2','render-png-zh-CN#1','render-png-en#1','render-mp4-en#1'],'shortPaths':['/tmp/awa47-pw2','/tmp/awa47-zh1','/tmp/awa47-en1','/tmp/awa47-mp1'],'approvalMeaning':'Explicit private0700 placement correction after the actual Unix SingletonSocket path-length infrastructure failure; not identical environment wording. Original source/helper/plan/argv/tools remain fixed.','actualVerifierStatus':supp['status'],'firstPW':{'pass':0,'unexpected':362,'flaky':0,'classification':'All362 actual result errors contain Chromium Socket path too long; assertions were not reached.'},'secondPW':{'pass':362,'skip':0,'unexpected':0,'flaky':0,'actualSpecFiles':23}},
 'sourceAndDependencyFence':{'testedSource':S,'sourceInputDigest':manifest['inputDigest'],'gitFilesDigest':manifest['gitFilesDigest'],'dependencyCoreDigest':core,'initialFullDependencyDigest':manifest['dependencyDigest'],'finalFullDependencyDigest':ff['actualDependencyDigest'],'fullDependencyDifferenceMeaning':'Explicit recorded Vite/webpack caches changed under the exact frozen plan cache prefixes. Installed dependency core, public source inputs and Git object/metadata identities did not drift; final helper performs actual system-tool identity comparison. Do not claim the full cache-inclusive digest was unchanged.','finalFenceReadAt':ff['checkedAt'],'noReviewerRehashOf9045PublicInputsOrInstalledClosure':True},
 'actualMedia':{'artifacts':summary['artifacts'],'pngs':{'count':2,'width':1280,'height':720,'locales':['zh-CN','en']},'mp4':{'locale':'en','codec':'h264','width':1280,'height':720,'fps':'30/1','frames':180,'durationSeconds':6},'metadataAndDecode':'Root actual five commands succeeded; metadata/decoded frame/raw bytes bound in this review.','visualReview':{'reviewer':'/root','actualImages':4,'findingCount':0,'receiptSHA256':identity(media_root/'root-visual-review.json')['sha256'],'reviewerDidNotRepeatPixelViewing':True},'boundedPort4173Observation':media['port4173ListenerAbsentAtRead'],'sampleLimit':'The registered sample has2players/2events;4 images are not visual coverage of all frames,55roles or every possible board.'},
 'architectureAcceptanceBoundary':{'requirementsAndChannels':'Reuse existing31 requirements,11 extension-channel andN01–20/R01–18 static/source review plus actual strict3364/0violations/0remainingDebt/1779cleared receipt; no renewed full-tree audit.','finiteMechanismScope':'55 finite Role support,91mechanisms and51slices retain their explicit support/N/A/independent replay boundaries. All42 gates are evidence for this tested source; not proof of arbitrary callback/partial/Proxy/failure combinations.','authorIndependenceDisclosure':'Earlier adapters/chooser/lowerX06 authored by this reviewer rely on the existing published nonauthor peer scopes; this report does not relabel those algorithms as newly independently authored review.','testSkipFact':'Backend scenarios actually3345pass/1skip/0fail/934103expect/264files; the manual finalized Mist fixture skip remains visible.'},
 'notApprovedByThisReport':{'E220AlreadyPublished':False,'C48AlreadyPublished':False,'acceptedCellsChanged':False,'allProjectGoalsUnconditionallyComplete':False,'arbitraryEscapedResourceClosure':False},
 'finalAcceptanceApproved':False,'futurePublicationBoundary':'Root may publish actual C47 E220 evidence from this fixed tested source. Actual E220 commit and later C48 matrix/docs metadata identity remain separate; no future metadata commit or843 acceptance is invented here.',
 'execution':{'productChecksByReviewer':False,'projectParserCompilerTestsMediaByReviewer':False,'repositoryWritten':False,'method':'Incremental existing JSON/raw/media file byte identity reading only, with previous actual source/static and38receipt reviews retained. Report written only to TMP.'}
}
(O/'final-review.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
md=f'''# C47 最终架构与同源收据独审\n\n结论：**{'批准发布 C47 实际证据' if not errors else '有实际差异阻塞'}**，`c47PublicationApproved: {str(not errors).lower()}`。受测源码 `{S}`；manifest `{M}`。\n\n原源码／静态要求审和38项真实收据审继续有效；末增量读取PW首红、PW#2、三个render#1、短TMP实际验证结果、helper final summary、collector及媒体／Root视觉收据。42个命令ID均有实际成功终态，共43次attempt；首PW362个浏览器Socket路径过长启动失败完整保留，未重分类成pass。唯一环境修正为四个短私有TMPDIR，argv／helper／plan／源码不变。PW#2实际362pass、0skip、0unexpected、0flaky，23个spec文件。\n\n源码／Git／依赖核心fence同源；显式Vite/webpack缓存有记录变化，不称缓存在内全依赖digest相同。2张PNG均1280×720；英文MP4 H.264／1280×720／30fps／180帧／6秒。实际probe/decode成功，Root实看2图+2解码帧无finding；本审只末核这些事实与身份，没有重复渲染或查看所有帧。所有资源结论保留process-group及端口观察的有界性质。\n\n实际身份差异：{len(errors)}。本审0项目／测试／类型／parser／媒体执行、0仓库写。该批准仅允许发布真实C47证据；E220与C48尚未发布，不预改843适用格、67理由N/A或未来metadataGit。\n'''
(O/'final-report.md').write_text(md)
arts=[identity(O/'final-review.json'),identity(O/'final-report.md'),identity(O/'assemble-final-review.py')]
h={'reviewer':final['reviewer'],'decision':final['decision'],'base':S,'manifestSHA256':M,'c47PublicationApproved':not errors,'finalAcceptanceApproved':False,'artifacts':arts,'actualCommandIDs':42,'actualAttempts':43,'errors':errors,'execution':final['execution']}
(O/'final-HANDOFF.json').write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'approved':not errors,'errors':errors,'artifacts':arts,'handoffSHA256':identity(O/'final-HANDOFF.json')['sha256']},ensure_ascii=False,indent=2))
