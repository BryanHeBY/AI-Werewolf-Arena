# C47 短 TMPDIR 纯数据补充核验

状态：prepared，作者未执行。固定源码60fdbfbc与manifest08cb；原helper、plan、collector和history文件均不修改。

Root在四份实际supplement及其launch/process/receipt都落盘后运行一次：

```sh
/usr/bin/python3 /tmp/awa-c47-short-tmp-verifier/verify.py --output /tmp/awa-c47-short-tmp-protocol/actual-environment-verification.json
```

输出必须不存在。未齐exit2/INCOMPLETE，差分或失败终态exit1/BLOCKED，四项实际完整且成功才exit0/ENVIRONMENT_SUPPLEMENTS_COMPLETE。该status仍不是最终C47批准。

## 精确范围

- 唯一允许PW#2、中文PNG#1、英文PNG#1、英文MP4#1；不运行它们，不自动retry。
- 固定wrapper/helper/plan/manifest/base及原history-index摘要；原PW#1五个证据文件逐字节核原摘要，保362浏览器启动失败，不把它们算领域失败或成功。
- 不导入原helper。按已静读的fixed_env数据模板逐键构造before，保原PLAYWRIGHT_HEADLESS政策；after完整等于before仅将TMPDIR改为四个精确短路径。
- 实际launch.env、env-i进程argv/PID、receipt身份/argv/cwd/timeout/prerequisites/retryReason、raw摘要/mode和记录的source/Git前后fence均核。
- 真实短目录当前必须原path、无symlink、uid匹配、0700。初始空是冻结wrapper在独占mkdir后、产品启动前记录的观察，不冒称浏览器使用后目录仍空。请在核验前保留四短目录，勿提前清理。
- render必须在PW#2成功终态之后启动；不把其晚时间当所有可能逃逸进程或监听器全闭的证明。

## 与原collector/发布边界

此脚本只读现有JSON、字节与stat，不扫描完整依赖，不运行产品/门禁/parser/compiler/测试/媒体/子进程。原collector仍核42IDs、连续attempt、retryReason、完整依赖缓存及tools相关记录、真实Bun/PW/media结果。

Root最终additionalEvidence收入：本目录脚本/README/HANDOFF、冻结run.py、协议prepared报告、实际四supplement、本脚本实际输出、PW首红分类及原raw、真实媒体/独审。不得只保TMP路径；四首red文件本已在receipt归档中时可引用同一成员避免重复。历史index保持原字节。

当前只有PW#2启动信息，尚未读取其terminal，也未执行本验证器。所有未来成功与实际attempt总数必须由真实结果决定；报告c47PublicationApproved始终false，最终人工独审另行批准。
