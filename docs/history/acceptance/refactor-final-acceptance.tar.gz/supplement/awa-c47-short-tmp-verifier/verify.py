"""只读核对四个浏览器临时目录补充；不导入 helper，不运行任何产品或门禁。"""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import os
import stat
import sys

BASE = "60fdbfbc57122eeb1d4e9204b66d4daec1eb0157"
BUNDLE = Path("/var/tmp/awa-refactor-20261015/c47-60fdbfbc")
PROTOCOL = Path("/tmp/awa-c47-short-tmp-protocol")
MANIFEST = "08cb4b2ba9640566b28b9610ea22c1602d40eee811c47be282128ca8618b591e"
PLAN = "18a92451981ea503702198ab61a2dc9436b8d2dc2a2b538fa0e804cf24fcd957"
HELPER = "632d87e1024ac0c7a4be32a2c2d454e17a5e44030056dff05d4fbd6d3f47a87d"
WRAPPER = "28adc5cfe8c3f6216ec1f70e17dcc7003d52544c96bd99f90b33117ca488c60f"
HISTORY = "341b76be1328ac32ead4a9dbe82535708e4fb0f3761470e24ccf0467797347fe"
ALLOWED = [("chromium-e2e", 2, "pw2"), ("render-png-zh-CN", 1, "zh1"),
           ("render-png-en", 1, "en1"), ("render-mp4-en", 1, "mp1")]
FIRST = {"receipt.json": "41167e5008e98e4c6dcebc560f5a338ede5d848876bcc3dfda753639e0724a2d",
         "launch.json": "8addd98f8815aa377e80b085d62660c551549ae313640c616e771da6b5265137",
         "process.json": "0e44e53c2bc30773bfed3db0c0f1dee508d9879951382fa76ce634192d118924",
         "stdout.raw": "32e8afabdd23c5f238107c75dbc24847765c3940093d0de832d7bb273c323437",
         "stderr.raw": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def file_row(path):
    path = Path(path)
    st = path.lstat()
    if not stat.S_ISREG(st.st_mode) or path.is_symlink():
        raise ValueError("not a real regular evidence file: " + str(path))
    raw = path.read_bytes()
    return {"path": str(path), "kind": "file", "bytes": len(raw), "sha256": sha(raw),
            "gitMode": "100755" if st.st_mode & 0o100 else "100644",
            "posixMode": format(stat.S_IMODE(st.st_mode), "04o")}


def original_environment(command, runtime):
    # 手工逐键抄录冻结 fixed_env 的数据模板，不导入它或触发 mkdir。
    paths = {"HOME": "home", "XDG_CONFIG_HOME": "xdg/config", "XDG_CACHE_HOME": "xdg/cache",
             "XDG_DATA_HOME": "xdg/data", "TMPDIR": "tmp", "BUN_INSTALL_CACHE_DIR": "cache/bun",
             "BUN_RUNTIME_TRANSPILER_CACHE_PATH": "cache/transpiler", "GIT_TEMPLATE_DIR": "git-empty-template"}
    env = {key: str(runtime / value) for key, value in paths.items()}
    env.update({"PATH": "/usr/bin:/bin", "CI": "1", "TZ": "UTC", "LANG": "C.UTF-8",
                "LC_ALL": "C.UTF-8", "TERM": "dumb", "BUN_RUNTIME_EXECUTABLE": "/usr/bin/bun",
                "PLAYWRIGHT_CHROMIUM_EXECUTABLE": "/usr/bin/chromium", "PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD": "1",
                "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_NOSYSTEM": "1", "GIT_TERMINAL_PROMPT": "0",
                "GIT_OPTIONAL_LOCKS": "0"})
    additions = command.get("environmentAdditions", {})
    if additions and (command["id"] != "chromium-e2e" or additions != {"PLAYWRIGHT_HEADLESS": "true"}):
        raise ValueError("unexpected original environment additions")
    return {**env, **additions}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    requested = Path(args.output).absolute()
    output = requested.parent.resolve(strict=True) / requested.name
    if not (str(output).startswith("/tmp/") or str(output).startswith("/var/tmp/")):
        raise ValueError("output must be a fresh TMP file")
    if output.exists() or output.is_symlink() or str(output).startswith(str(BUNDLE) + "/"):
        raise ValueError("output exists or is inside the frozen bundle")
    errors, pending, attempts, bindings = [], [], [], []

    def require(ok, message):
        if not ok:
            raise ValueError(message)

    for path, expected in [(BUNDLE / "snapshot-manifest.json", MANIFEST),
                           (BUNDLE / "execution-plan.json", PLAN),
                           (Path("/tmp/awa-c47-public-snapshot/c47-public-snapshot.py"), HELPER),
                           (PROTOCOL / "run.py", WRAPPER),
                           (Path("/tmp/awa-c47-pure-data-collector-60fdbfbc/history-index.json"), HISTORY)]:
        row = file_row(path)
        require(row["sha256"] == expected, "frozen identity changed: " + str(path))
        bindings.append(row)
    manifest, plan = read(BUNDLE / "snapshot-manifest.json"), read(BUNDLE / "execution-plan.json")
    require(manifest["baseCommit"] == BASE, "base mismatch")
    commands = {row["id"]: row for row in plan["commands"]}
    first_directory = BUNDLE / "receipts/chromium-e2e-attempt-1"
    first_files = []
    for name, expected in FIRST.items():
        row = file_row(first_directory / name)
        require(row["sha256"] == expected, "original PW red changed: " + name)
        first_files.append(row)
    first = read(first_directory / "receipt.json")
    require(first["base"] == BASE and first["manifestSha256"] == MANIFEST and first["success"] is False
            and first["exitCode"] == 1 and first["timedOut"] is False, "original PW red identity/status")

    for cid, attempt, suffix in ALLOWED:
        folder = BUNDLE / "receipts" / (cid + "-attempt-" + str(attempt))
        supplement_path = PROTOCOL / (cid + "-attempt-" + str(attempt) + "-supplement.json")
        needed = [supplement_path, folder / "launch.json", folder / "process.json", folder / "receipt.json"]
        missing = [str(path) for path in needed if not path.is_file()]
        if missing:
            pending.append({"id": cid, "attempt": attempt, "missing": missing})
            continue
        try:
            for path in needed:
                file_row(path)
            supp, launch, process, receipt = [read(path) for path in needed]
            command = commands[cid]
            before = original_environment(command, folder / "runtime")
            short = Path("/tmp/awa47-" + suffix)
            after = {**before, "TMPDIR": str(short)}
            require(supp["base"] == BASE and supp["manifestSHA256"] == MANIFEST
                    and supp["command"] == cid and supp["attempt"] == attempt, cid + ": supplement identity")
            require(supp["helperSHA256"] == HELPER and supp["wrapperSHA256"] == WRAPPER,
                    cid + ": supplement program hashes")
            require(supp["failedReceiptSHA256"] == FIRST["receipt.json"]
                    and supp["failedReportSHA256"] == FIRST["stdout.raw"]
                    and supp["all362FailuresAtBrowserLaunchSocketPath"] is True, cid + ": original red binding")
            require(supp["environmentBefore"] == before and supp["environmentAfter"] == after
                    and supp["onlyChangedKey"] == "TMPDIR", cid + ": full environment mismatch")
            require(set(before) == set(after) and [k for k in before if before[k] != after[k]] == ["TMPDIR"],
                    cid + ": change is not exactly TMPDIR")
            sd = supp["shortDirectory"]
            require(sd["path"] == str(short) and sd["mode"] == "0700" and sd["initiallyEmpty"] is True,
                    cid + ": fresh launch observation missing")
            require(short.is_dir() and not short.is_symlink() and short.resolve() == short,
                    cid + ": short directory is not a real exact path")
            st = short.stat()
            require(stat.S_IMODE(st.st_mode) == 0o700 and st.st_uid == sd["uid"] == os.getuid(),
                    cid + ": short directory mode/owner mismatch")
            argv = [v.replace("<RUN_ARTIFACT_DIR>", str(BUNDLE / "artifacts")) for v in command["argv"]]
            cwd = str(BUNDLE / "snapshot" / command["cwd"])
            for value in [launch, receipt]:
                require(value["base"] == BASE and value["manifestSha256"] == MANIFEST
                        and value["attempt"] == attempt and value["argv"] == argv and value["cwd"] == cwd,
                        cid + ": actual command identity")
            require(launch["environment"] == after and launch["timeoutSeconds"] == command["timeoutSecondsSuggested"],
                    cid + ": launch environment/timeout")
            require(launch["commandPrerequisites"] == command.get("commandPrerequisites", []), cid + ": prerequisites")
            require((isinstance(launch["retryReason"], str) and bool(launch["retryReason"])) if attempt == 2
                    else launch["retryReason"] is None, cid + ": explicit retry reason")
            require(process["argv"] == ["/usr/bin/env", "-i", *[k + "=" + v for k, v in sorted(after.items())], *argv]
                    and process["pid"] == receipt["pid"], cid + ": actual process environment/PID")
            require(receipt["id"] == cid and receipt["startedAt"] == launch["startedAt"], cid + ": receipt identity/time")
            raw = [file_row(folder / "stdout.raw"), file_row(folder / "stderr.raw")]
            require(raw == receipt["raw"], cid + ": actual raw bytes/modes/hash")
            terminal_success = (type(receipt["exitCode"]) is int and receipt["exitCode"] == 0 and receipt["timedOut"] is False
                                and receipt["preparationOrFenceError"] is None)
            require(receipt["success"] is terminal_success, cid + ": success flag mismatch")
            for phase in ["preInputFence", "postInputFence"]:
                fence = receipt.get(phase) or {}
                require(fence.get("inputDigest") == manifest["inputDigest"]
                        and fence.get("gitDigest") == manifest["gitFilesDigest"], cid + ": recorded source/Git fence")
            if cid != "chromium-e2e":
                pw = read(BUNDLE / "receipts/chromium-e2e-attempt-2/receipt.json")
                require(pw["success"] is True and pw["endedAt"] <= launch["startedAt"], cid + ": PW2 prerequisite")
            attempts.append({"id": cid, "attempt": attempt, "environmentDifference": {"TMPDIR": {
                "before": before["TMPDIR"], "after": after["TMPDIR"]}},
                "supplement": file_row(supplement_path), "launch": file_row(folder / "launch.json"),
                "process": file_row(folder / "process.json"), "receipt": file_row(folder / "receipt.json"), "raw": raw,
                "actualShortDirectory": {"path": str(short), "uid": st.st_uid, "mode": "0700", "realPath": str(short.resolve())},
                "initiallyEmptyAtLaunch": True, "freshnessMeaning": "Bound wrapper records exclusive absent-before-mkdir and initially empty; verifier does not claim the now-used directory is empty.",
                "terminalSuccess": terminal_success, "resourceGroupStillExistsAfterWait": receipt.get("resourceGroupStillExistsAfterWait")})
            if not terminal_success:
                errors.append(cid + ": actual terminal unsuccessful; not eligible for final acceptance")
        except (KeyError, ValueError, TypeError, OSError) as error:
            errors.append(cid + ": " + str(error))

    result = {"schemaVersion": 1, "status": "BLOCKED_DATA_OR_TERMINAL" if errors else "INCOMPLETE" if pending else "ENVIRONMENT_SUPPLEMENTS_COMPLETE",
              "base": BASE, "manifestSHA256": MANIFEST, "reviewer": "pure_data_supplement_verifier",
              "readAt": dt.datetime.now(dt.timezone.utc).isoformat(), "c47PublicationApproved": False,
              "bindings": bindings, "firstPWRed": first_files, "attempts": attempts, "pending": pending, "errors": errors,
              "script": file_row(__file__), "limits": [
                  "Reads only existing JSON/text/file bytes/stat; imports no helper and runs no product/parser/compiler/test/media or subprocess.",
                  "Original source/helper/plan/manifest/collector/history remain unchanged. This is an explicit TMPDIR placement supplement, not identical environment wording.",
                  "Historical index is byte-bound, not all historical raw revalidated here; first PW red is independently bound and never erased.",
                  "Recorded source/Git fences are compared; full dependency/core/cache/tool checks and actual PW/media outcomes remain the collector and independent reviewers' responsibility.",
                  "Directory owner/mode/realpath are current observations; initial freshness is the fixed wrapper's before-launch observation, not a later re-creation of it.",
                  "A complete supplement report does not approve final C47 publication, every browser input, escaped process closure or media visuals."]}
    with output.open("x") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({"status": result["status"], "output": str(output), "errors": len(errors), "pending": len(pending)}))
    return 1 if errors else 2 if pending else 0


if __name__ == "__main__":
    sys.exit(main())
