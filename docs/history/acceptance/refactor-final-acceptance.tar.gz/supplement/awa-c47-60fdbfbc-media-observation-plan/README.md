# 最终三媒体的手工观察计划

只读源码预期，尚未运行渲染、解码、解析器或检查，也未观察实际媒体。固定输入为60fdbfbc／manifest08cb4b2b。全部17引用与snapshot字节相同。

实际输入是两席位、两事件的小型公开fixture，board标签虽为six_player_mvp，不能据此称完整六人／十二人对局。两个事件均未被presentation筛掉，因此视频应为180帧、30fps、6秒，画幅1280×720；英文H264 MP4一次，中英frame0 PNG各一次。

| 帧 | 时间 | 必看内容 |
| --- | --- | --- |
| 0 | 0秒 | 两席位1/2、中文预言家／狼人或英文Seer／Werewolf，均亮；第1天夜晚／Day1Night；字幕opacity0属于原动画，不能报缺字幕。 |
| 15 | 0.5秒 | MP4英文首事件字幕全显：Phase transition、2026-07-29 00:00:00 [UTC]、Night 1: close your eyes。两人仍亮。 |
| 105 | 3.5秒 | MP4英文第二事件字幕全显：Exile result、2026-07-29 00:01:00 [UTC]、Player 2 is exiled；Day 1 · Day；2号变灰0.35，1号仍亮。 |

两个PNG只承诺frame0：并没有额外中文MP4或额外15/105中文渲染。fixture无昵称，画面不应凭空生成name行；两语共同英文品牌不是漏翻译。result.good不是终局事件，投影无decision，不要求赢家徽记／终局横幅。

实际Root三render成功后，按JSON所列ffprobe命令保存真实元数据及媒体SHA；解码已有英文MP4的15/105帧再观察，不产生第四媒体任务或重渲染。图像须真实可读、无方块缺字／裁切／覆盖；不得把文件存在当视觉通过。最终签字仍待Root真实媒体与视觉记录、PW实际统计。
