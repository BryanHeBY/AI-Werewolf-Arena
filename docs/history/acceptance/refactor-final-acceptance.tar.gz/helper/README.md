# C47 新公开固定快照与验收执行准备

**状态：TMP-only，helper 未执行；没有运行解析器、语法检查、类型、测试、构建、浏览器或产品。** 当前只读 HEAD 为 `d7b5f51b770d1b5713ffe8b62fd671cac36e92eb`。最终 C43 尚未发布，不能用此 HEAD 冒充验收基线。

## 1. 相对旧提案的必要变化

- 原 41 项保留，并新增独立 history guard，共 42 个原子操作，不再运行根 `check/lint/test`、package check/test 聚合或 backend/frontend 聚合以重复统计。14 个类型项目单列：tooling 1、backend 2、frontend 1、五包各 2。
- smoke 改真实 `backend/src/app/cli/run-game-smoke.ts`；两个 backend checker 改 kebab；frontend render／replay CLI 和 replay-contract 内部路由按已提交 basename9，不把 `isLocale` 回写到旧 catalog。
- 原 formatter immutable evidence 政策已先独立实施；C43 将旧证据逐字节归档后改精确历史 ignore，C47 必须捕其**实际最终配置与历史全文**，不能拿旧计划的 `.prettierignore` 状态作现行事实。
- `freezeBuild()` 只解决双构建生产输入，不包含完整前端／测试／文档／Git，本工具不复用它冒充 C47 完整快照。
- 旧计划的静态文件数量不沿用成展开用例数。prepare 从未来基线重新列真实 tracked test/spec 文件；Playwright 原 23 spec 整体一次执行，增加 JSON reporter 只为保存真实展开结果，不另执行 discovery。

## 2. Root 唯一执行，必须等 C43 后 clean Git

下面只是命令文本，作者没有调用。变量的实际值由 Root 决定；`C47_BASE` 必须手填最终完整 40 位 SHA，不能传 `HEAD`、短 SHA 或默认未来值。

```sh
C47_REPO=/home/hby/dev/AI-Werewolf-Arena
C47_BASE=<ROOT选定的最终完整40位SHA>
C47_BUNDLE=/tmp/awa-c47-<独占新运行名>
C47_HELPER=/tmp/awa-c47-public-snapshot/c47-public-snapshot.py
C47_PLAN=/tmp/awa-c47-public-snapshot/execution-plan.json

/usr/bin/python3 "$C47_HELPER" prepare \
  --repo "$C47_REPO" --base "$C47_BASE" \
  --destination "$C47_BUNDLE" --plan "$C47_PLAN"

/usr/bin/python3 "$C47_HELPER" git-probe --bundle "$C47_BUNDLE"
```

prepare 拒绝 dirty Git、与实际 HEAD 不同的 base、已存在目的地、原仓内目的地、符号链接祖先、执行祖先的 `.env*` 名称和未分类 tracked 私有路径。失败保留已生成目录供 Root 阅读，不自动恢复或覆盖。

当前未发布的 C43 路径是硬前置：34 个 current 页、39 张规则卡、`docs/history/origin-paths.json`、历史 debt／fixture／source-hash、当前 i18n policy 都必须已 tracked。旧 docs/refactor、docs/expansion 及已退休 source 根必须没有 tracked 文件。清单来自已审 C43 候选，不猜最后 Git 或固定历史文件数。

### 完整公开内容和 Git

逐项从实际 Git blob 导出公开源码、所有 tests/support/fixtures、五包、tooling、scripts、配置、全部当前 docs 和历史证据；每项记录 path／mode／blob／bytes／SHA。原 current 同 Git 的字节及 Git owner executable 位也先核对。不会复制私有 configs、auth、`.env`、`.aws`、`.codex`、`.agents`、record/data 或原 `.git` 配置。

实际需要的 Git 输入：最终 base、原 `27a97cb…` 架构／fixture 基线、`442703…` 历史 source contract、`eb4f026…` Seer 探针，以及真实 C43 origin index／fixture manifest 中的额外 origin commits。它们以**原 commit/tree/blob 对象、原 SHA 和完整树载荷**保存到独立 Git；每个选择的 commit 标为 shallow boundary。不是原仓 `.git` symlink，不复制 remote、config、hooks、alternates 或 worktree 权限。任意祖先 log／未列历史并不保证存在，必要时 Root 可额外传完整 `--history-commit`。

Root 已明确批准一个窄例外：公开历史 `.env.example` 的 blob 可在 Git 对象中存在，以支持原 tree 的 `read-tree/write-tree`，**工作树绝不 materialize 任何 `.env*`**。当前索引对该原公开模板记 skip-worktree，不能把这个例外扩大成私有配置准入或其他任意缺文件忽略。

`git-probe` 在 snapshot 自身上真实创建临时 clone，再做 read-tree、write-tree、commit-tree，验证 fixture-source-relocations 用例所需原生 Git 输入。它是准备输入协议，不是游戏案例或另一轮测试；首次失败／raw 保留。不会 stub Git 或通过断言数据伪装成功。此真实协议也尚未执行。

### 依赖与环境

原工作树 bun.lock 必须逐字节同 base。离线复制已装物理 `node_modules/.bun` 及各 owner 的实际 node_modules，保普通文件的 bytes／完整 POSIX mode；复制前后原物理清单相同，快照文件逐项相同。绝对内部链接只可转换成同 repo-relative 目标的快照相对链接，转换单列；所有 workspace/依赖 realpath 都必须留在快照，绝不 resolve 回原仓。直依赖 name/version 与原 lock 的具名 resolution 核对；不声称重新验证远端 tar/SRI，不 install/download。

每个受控顶层命令真实使用 `/usr/bin/env -i ...`；Bun 入口明确带 `--no-env-file`，新增 history 原子入口直接调用 `/usr/bin/python3 tooling/refactor/history-integrity.py --repo . --base 14e7951787f4464573407a7bcc270303a3975856 --manifest docs/history/origin-paths.json`，不重复根 aggregate。HOME、XDG、TMPDIR、Bun cache 与 Git template 都是各 command/attempt 独占的空／合成目录，不承接前一命令的合成配置；只给 PATH、CI、UTC/locale、真实 Bun/browser 路径和无凭据 Git 设置。无 API keys、代理、NODE_OPTIONS 或用户认证环境。**外层 Bun flag 不自动传给子进程**；这里依靠真实无私密 cwd／祖先和净环境。测试自己建立的合成 key、端口和本机通信仍按原程序执行。

固定输入不是 OS sandbox。没有宣称从文件策略就能禁止网络、冻结 kernel/shared libraries 或阻止所有恶意反射。系统 Bun/Node/Git/Chromium wrapper、browser ELF、ffmpeg/ffprobe/python/env 逐字节及 realpath 绑定，首末核同；浏览器必须用实际 `/usr/bin/chromium`，不下载。

## 3. 单命令与 lane

```sh
/usr/bin/python3 "$C47_HELPER" run --bundle "$C47_BUNDLE" \
  --command architecture-strict --lane root-static --timeout 1800 --execute

/usr/bin/python3 "$C47_HELPER" run --bundle "$C47_BUNDLE" \
  --command backend-scenarios --lane root-heavy --timeout 7200 --execute
```

`execution-plan.json` 有全部 42 项真实 cwd／完整 argv／建议 timeout／lane。helper 没有自动 scheduler：Root 决定实际资源与顺序。建议一条重 scenarios、一条 backend unit/integration、一条轻任务；大 TS 项目一次一项，十个 package 项目在轻 type lane。浏览器与三次真实渲染串行、独占 4173；Playwright 2 workers、0 retries、CI=1 拒复用旧 server。其 Vite webServer 原命令已显式 `--no-env-file`，不经会嵌套 bunx 的 replay-dev 开发 wrapper。

固定覆盖：strict 架构＋固定原始归档基线的 history guard＋fixtures；14 项 types；backend ESLint/boundaries/i18n、frontend ESLint、根 Prettier；tooling＋五包；backend architecture/unit/integration/scenarios 四互斥目录；frontend unit/integration/architecture 三互斥目录；backend build、frontend build、原 smoke；完整 Playwright；同一公开 six-player fixture 的中英 frame0 PNG、英文 H264 MP4。build 与 noEmit 有编译工作重叠，但产出检查不同；不把 build 当成新的 gameplay 样本。

每个 command ID 有独占 lock 和 attempt 目录。没有 `--execute` 不运行；不会自动 retry。history 原子入口必须有同一快照实际 strict 成功收据作为先决条件；其固定 `14e795…` 是 C43 原始归档捕获提交，并非猜定 C47 最终 Git。只有实际前一个失败的同 ID 才允许 `--attempt 2 --reason ...`，拒绝重跑已绿。若改了源／依赖／helper／plan，fence 停止，不能把不同输入拼成一次同构建绿；Root 应另立新 Git/快照并明确后继证据范围。

## 4. 收据和输出

- `snapshot-manifest.json`：完整 source/dependency/Git/executable 输入、文档历史、链接转换、真实 static discovery、helper/plan hash。
- `receipts/<id>-attempt-N/launch.json`、`process.json`：实际 argv/cwd/env keys 与合成值、Root lane、PID／时间／timeout。Root 另附真实 API launch/session/terminal ID，helper 不伪造外部工具 handle。
- `stdout.raw`／`stderr.raw`／`receipt.json`：原输出和 SHA、真实 exit/signal/timeout、首末完整输入／依赖／Git／可执行体 fence、具体 cache delta。没有从静态标题推算 Bun pass/assert/case 数。
- 原 tracked 输入全部首末保持；新文件只能落明确 dist/report/coverage/record 输出目录。依赖 `.vite/.vite-temp/.cache` 在 plan 明列为输出，变化完整记录，不悄悄从声明“同一依赖”的统计里删去；不可变依赖 core 必须完全相同。
- timeout 会终止本次 process group 并保留首错误；正常退出后也记录该 group 是否仍存在。group 不存在仍不能证明所有 escaped 子进程、listener 或 browser 已关闭，Root 结合实际测试原始收据检查。

```sh
/usr/bin/python3 "$C47_HELPER" finalize --bundle "$C47_BUNDLE" --output summary-first.json
```

finalize 先逐收据绑定当前 full base／frozen manifest SHA、已知 command ID、attempt 目录、原 planned argv／cwd 与实际 raw SHA，成功项还要求首末 input/Git digest；不同快照的同 ID 绿不能被汇入。随后只汇合现有收据和末 fence，不触发遗漏命令，不将“文件存在”变成视觉／玩法验收。Root 需读真实 Bun raw／Playwright JSON 的展开案例与 skip，保留首红及分类，再对三产物实际看图／看视频。媒体参数可使用单列 `artifact-inspection-plan.json` 的 ffprobe 命令；这不是第二次渲染。不得用旧轮数量或 all55 标签补缺。

## 5. 当前疑点和交接条件

1. 最终 C43 Git 未定；现在 prepare 会因未发布路径停止，属准备态，不是假执行红。
2. 已报 C43 第七真实读点：`fixture-source-relocations.test.ts` 用 `document.baseline.inventoryPath` 实际 copy 冻结文件，需要新 history 物理落点；协议 origin 字符串保持。NativeFinal 正按 Root 授权准备 v3，Pref 静态审后再执行。本工具不修改它。
3. Git-probe、快照创建、42 项命令、loopback bind、browser、媒体 probe 均尚未执行。真实沙箱 EACCES、端口冲突、OOM、超时、assertion 红须分别记录，不以跳过通信或改 golden 求绿。
4. 完整命令绿也不自动证明全部 55 角色、所有任意外部 API 或 P9 已完成；仍需与计划机制证据、明确 F01–F05/Q2/Q3 政策、有限支持和独立审查汇合。

## 首稿保留与后继静态精度

原 41 项的五份完整文件原字节保留在 `/tmp/awa-c47-public-snapshot-first-41-snapshot.json`（SHA `a87bfda2c59a54acda0553f86ce12a44645e01553d294104532bef91e5fccb0e`）。本版新增 Root 指定的独立 Python history 入口，并按非作者静态意见闭合 Python argv 接纳、Playwright 唯一 command 的 `PLAYWRIGHT_HEADLESS=true` 实际合入及逐 receipt 输入绑定。没有执行过首／末 helper、变体、解析器、检查或测试，不能称静态 finding 为实际运行红。

## Root 对最终矩阵前置的裁定

`docs/architecture/migration-matrix.json` 是未来 current owner，不因路径已定就制造尚无真实同源收据的空壳。prepare 不硬要求这个尚未产出的文件：若 future base 已 tracked，则同其他公开文件完整捕获；若未 tracked，manifest 的 `documentationState` 明列原工作树／快照是否真实存在、tracked 状态与 captured input（缺席时 null）。现有 role 规则资料、feature/module ownership、delivery 与 guard 工具仍必须 present。

这是输入边界，不跳过任何已有 public tracked 文件。finalize 只可报告 42 项真实运行集合，保留最终矩阵／C48对账依赖；后继新增 metadata 和新 HEAD 必须与受测 candidate 分开，不能倒称 metadata 提交已通过整轮验收。

## 命令依赖与环境标签分义

计划用 `commandPrerequisites` 只登记真实命令 ID（本版只有 history→architecture-strict），由当前 base/manifest 的成功收据确认。`environmentPrerequisites` 中的 private-free snapshot、Chromium 已装、4173 独占与新输出路径是 Root 的真实准备／资源约束和原脚本检查，不是命令，不会查找或伪造同名绿色 receipt。运行 launch 会将两者分列。此静态精度前的实际42稿完整保 `/tmp/awa-c47-public-snapshot-first-42-snapshot.json`（SHA `34516ac138833737f6e8286f485423c8f07823c963ace7fcc714af7d7000a54b`），它是ff58/5eb6阶段，不冒每个早先中间稿都已保存。
