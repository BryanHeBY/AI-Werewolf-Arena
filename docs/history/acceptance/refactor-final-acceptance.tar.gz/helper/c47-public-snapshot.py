#!/usr/bin/env python3
"""Root 显式使用的离线验收输入与单命令收据工具；本文件只准备，作者未执行。

prepare 不调用产品/编译器/测试；git-probe 只核真实 Git 对象协议。
run 每次只执行一个已封存命令，不 install、不自动 retry、不修改原仓库。
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import zlib

FULL = re.compile(r"^[a-f0-9]{40}$")
PUBLIC_ROOTS = {"backend", "frontend", "packages", "tooling", "tools", "docs", "configs.example", ".github"}
PUBLIC_ROOT_FILES = {"package.json", "bun.lock", "bunfig.toml", "tsconfig.json", ".gitignore", ".gitattributes", ".prettierignore", ".prettierrc.json", ".editorconfig"}
BANNED_PARTS = {".git", ".codex", ".agents", ".aws", "auth.json", ".npmrc", ".netrc", "node_modules"}
SYSTEM_TOOLS = ["/usr/bin/bun", "/usr/bin/node", "/usr/bin/git", "/usr/bin/chromium", "/usr/bin/ffmpeg", "/usr/bin/ffprobe", "/usr/bin/python3", "/usr/bin/env"]
DISCOVERY_ROOTS = ["tooling/refactor", "backend/tests/architecture", "backend/tests/unit", "backend/tests/integration", "backend/tests/scenarios", "frontend/tests/unit", "frontend/tests/integration", "frontend/tests/architecture", "frontend/tests/e2e"]

def fail(message):
    raise RuntimeError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()

def save(path, value):
    with Path(path).open("xb") as handle:
        handle.write(encoded(value))

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def safe(name):
    p = PurePosixPath(name)
    if not name or p.is_absolute() or any(x in ("", ".", "..") for x in p.parts) or "\\" in name or any(x in name for x in ("\0", "\r", "\n")):
        fail("unsafe relative input: " + repr(name))
    return p

def public(name):
    parts = safe(name).parts
    if any(p in BANNED_PARTS or p.startswith(".env") for p in parts):
        return False
    if parts[0] in {"configs", "record", "data", "coverage", "dist"}:
        return False
    if parts[0] in PUBLIC_ROOTS:
        if len(parts) > 1 and parts[:2] in (("backend", "data"), ("backend", "dist"), ("frontend", "dist"), ("frontend", "playwright-report"), ("frontend", "test-results")):
            return False
        return True
    return len(parts) == 1 and (name in PUBLIC_ROOT_FILES or name.endswith(".md"))

def no_symlink_chain(path):
    p = Path(path).absolute()
    for part in [*reversed(p.parents), p]:
        if part.is_symlink():
            fail("symlink ancestor: " + str(part))

def no_env_ancestors(path):
    p = Path(path).absolute()
    for directory in [p, *p.parents]:
        if not directory.exists():
            continue
        if directory.is_symlink():
            fail("symlink execution ancestor: " + str(directory))
        for entry in directory.iterdir():
            if entry.name.startswith(".env"):
                fail("env file/name at execution ancestor: " + str(entry))

def fixed_env(bundle):
    # 不复制调用进程的任何环境值；测试内部合成 key/port 由其真实代码另行建立。
    b = Path(bundle)
    paths = {"HOME": b / "home", "XDG_CONFIG_HOME": b / "xdg/config", "XDG_CACHE_HOME": b / "xdg/cache", "XDG_DATA_HOME": b / "xdg/data", "TMPDIR": b / "tmp", "BUN_INSTALL_CACHE_DIR": b / "cache/bun", "BUN_RUNTIME_TRANSPILER_CACHE_PATH": b / "cache/transpiler", "GIT_TEMPLATE_DIR": b / "git-empty-template"}
    for p in paths.values():
        p.mkdir(parents=True, exist_ok=True)
    return {**{k: str(v) for k, v in paths.items()}, "PATH": "/usr/bin:/bin", "CI": "1", "TZ": "UTC", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TERM": "dumb", "BUN_RUNTIME_EXECUTABLE": "/usr/bin/bun", "PLAYWRIGHT_CHROMIUM_EXECUTABLE": "/usr/bin/chromium", "PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD": "1", "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_NOSYSTEM": "1", "GIT_TERMINAL_PROMPT": "0", "GIT_OPTIONAL_LOCKS": "0"}

def git(repo, *args, data=None, env=None):
    return subprocess.check_output(["/usr/bin/git", "-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false", *args], cwd=repo, input=data, env=env, stderr=subprocess.PIPE)

def tree(repo, commit, env):
    result = []
    for row in git(repo, "ls-tree", "-r", "-z", commit, env=env).split(b"\0"):
        if not row:
            continue
        meta, path = row.split(b"\t", 1)
        mode, kind, blob = meta.decode("ascii").split()
        name = path.decode("utf-8", "strict")
        safe(name)
        if kind != "blob" or mode not in {"100644", "100755", "120000"}:
            fail("non-blob/submodule public input: " + name)
        result.append({"path": name, "mode": mode, "blob": blob})
    return sorted(result, key=lambda r: r["path"])

class Objects:
    def __init__(self, repo, env):
        self.proc = subprocess.Popen(["/usr/bin/git", "cat-file", "--batch"], cwd=repo, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def get(self, oid):
        if not FULL.fullmatch(oid):
            fail("object ID must be full SHA1")
        self.proc.stdin.write((oid + "\n").encode()); self.proc.stdin.flush()
        header = self.proc.stdout.readline().rstrip(b"\n").decode()
        fields = header.split()
        if len(fields) != 3 or fields[0] != oid:
            fail("missing/malformed Git object: " + header)
        kind, length = fields[1], int(fields[2])
        data = self.proc.stdout.read(length)
        if len(data) != length or self.proc.stdout.read(1) != b"\n":
            fail("short Git object")
        raw = kind.encode() + b" " + str(length).encode() + b"\0" + data
        if hashlib.sha1(raw).hexdigest() != oid:
            fail("Git object identity mismatch")
        return kind, data, raw

    def close(self):
        self.proc.stdin.close()
        code = self.proc.wait()
        error = self.proc.stderr.read()
        if code:
            fail("cat-file failed: " + error.decode(errors="replace"))

def record_file(path, name=None):
    p = Path(path)
    info = p.lstat()
    row = {"path": name if name is not None else str(p), "gitMode": "100755" if info.st_mode & 0o100 else "100644", "posixMode": format(stat.S_IMODE(info.st_mode), "04o")}
    if stat.S_ISLNK(info.st_mode):
        row.update(kind="symlink", target=os.readlink(p))
    elif stat.S_ISREG(info.st_mode):
        data = p.read_bytes()
        row.update(kind="file", bytes=len(data), sha256=sha(data))
    else:
        fail("nonfile input: " + str(p))
    return row

def closure(root, prefixes):
    rows = []
    for prefix in prefixes:
        base = root / prefix
        if not base.exists() and not base.is_symlink():
            continue
        for directory, dirs, files in os.walk(base, followlinks=False):
            dirs.sort(); files.sort()
            for name in list(dirs):
                p = Path(directory) / name
                if p.is_symlink():
                    rows.append(record_file(p, p.relative_to(root).as_posix())); dirs.remove(name)
            for name in files:
                p = Path(directory) / name
                rows.append(record_file(p, p.relative_to(root).as_posix()))
    return sorted(rows, key=lambda r: r["path"])

def in_prefix(name, prefix):
    return name == prefix or name.startswith(prefix + "/")

def dependencies(snapshot, owners):
    rows = closure(snapshot, [o + "/node_modules" if o else "node_modules" for o in owners])
    # Root store属于根 node_modules，不再从每个符号链接跟入，物理 bytes 只计一次。
    for row in rows:
        if row["kind"] == "symlink":
            destination = (snapshot / row["path"]).resolve(strict=True)
            if destination != snapshot and snapshot not in destination.parents:
                fail("dependency link escapes snapshot: " + row["path"])
    return rows

def history_commits(plan, snapshot, base, extras):
    values = {base, *extras, *(r["commit"] for r in plan["requiredHistoryCommits"])}
    origin = json.loads((snapshot / "docs/history/origin-paths.json").read_text())
    if origin.get("schema") != "awa-history-origin-index-v1":
        fail("C43 origin index schema missing")
    values.add(origin["originCommit"])
    manifest = json.loads((snapshot / "tooling/refactor/fixtures/manifest.json").read_text())
    values.add(manifest["baseline"]["commit"])
    def walk(value):
        if isinstance(value, dict):
            for k, v in value.items():
                if k == "originCommit":
                    values.add(v)
                else:
                    walk(v)
        elif isinstance(value, list):
            for v in value: walk(v)
    walk(manifest)
    if any(not isinstance(v, str) or not FULL.fullmatch(v) for v in values):
        fail("history requires explicit full commit IDs")
    return sorted(values), origin

def copy_git_objects(repo, snapshot, commits, objects, env):
    # 原 .git/config/remote/hooks/alternates/worktree 不复制。保原 commit/tree/blob 身份，
    # 各选定 commit 作为真实 shallow boundary，不能冒成完整祖先历史或对象共享回原工作树。
    git(snapshot, "init", "-q", "--template", env["GIT_TEMPLATE_DIR"], env=env)
    gitdir = snapshot / ".git"
    stored, commit_rows = set(), []
    def store(oid):
        if oid in stored: return
        kind, content, raw = objects.get(oid)
        target = gitdir / "objects" / oid[:2] / oid[2:]
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists(): target.write_bytes(zlib.compress(raw))
        stored.add(oid)
        return kind, content
    for commit in commits:
        kind, contents, _ = objects.get(commit)
        if kind != "commit": fail("history ref is not commit")
        store(commit)
        root_tree = contents.split(b"\n", 1)[0].decode().removeprefix("tree ")
        store(root_tree)
        for row in git(repo, "ls-tree", "-r", "-t", "-z", commit, env=env).split(b"\0"):
            if not row: continue
            meta, rawpath = row.split(b"\t", 1)
            mode, kind, oid = meta.decode().split(); name = rawpath.decode("utf-8", "strict")
            safe(name)
            if kind == "tree": store(oid)
            elif kind == "blob":
                if not public(name) and name != ".env.example":
                    fail("selected history contains nonpublic path; do not read/copy its blob: " + name)
                store(oid)
            else: fail("history submodule/unknown object")
        git(snapshot, "update-ref", "refs/heads/c47-history-" + commit, commit, env=env)
        commit_rows.append({"commit": commit, "rootTree": root_tree, "boundary": "independent shallow root; original raw object IDs"})
    (gitdir / "shallow").write_text("".join(c + "\n" for c in commits))
    git(snapshot, "config", "core.hooksPath", env["GIT_TEMPLATE_DIR"], env=env)
    git(snapshot, "config", "core.logAllRefUpdates", "false", env=env)
    return {"commits": commit_rows, "objectCount": len(stored), "objectOnlyPublicTemplate": ".env.example", "originalGitConfigCopied": False, "originalObjectAlternates": False}

def copy_dependencies(repo, snapshot, owners):
    for owner in owners:
        source = repo / owner / "node_modules"
        dest = snapshot / owner / "node_modules"
        no_symlink_chain(source)
        if not source.is_dir(): fail("installed dependencies absent: " + str(source))
        shutil.copytree(source, dest, symlinks=True)
    # 绝对链接只允许其原目标属于原repo；改成指向快照同位置的相对链接。
    for owner in owners:
        start = snapshot / owner / "node_modules"
        for directory, dirs, files in os.walk(start, followlinks=False):
            for name in [*dirs, *files]:
                item = Path(directory) / name
                if not item.is_symlink(): continue
                old_link = os.readlink(item)
                original = repo / item.relative_to(snapshot)
                real = original.resolve(strict=True)
                if repo not in real.parents:
                    fail("installed dependency outside original repo: " + str(original))
                if os.path.isabs(old_link):
                    target = snapshot / real.relative_to(repo)
                    item.unlink(); item.symlink_to(os.path.relpath(target, item.parent))
    # 仅验证已安装直依赖的真实包身份，不声称从锁文件重新安装或验证远端tar完整性。
    names = {}
    for owner in owners:
        data = json.loads((snapshot / owner / "package.json").read_text())
        names[data["name"]] = owner
    resolutions = []
    lock_text = (snapshot / "bun.lock").read_text()
    for owner in owners:
        manifest = json.loads((snapshot / owner / "package.json").read_text())
        for name, declared in sorted({**manifest.get("dependencies", {}), **manifest.get("devDependencies", {})}.items()):
            leaf = (snapshot / owner / "node_modules" / name).resolve(strict=True)
            if snapshot not in leaf.parents: fail("dependency escaped")
            installed = json.loads((leaf / "package.json").read_text())
            if installed.get("name") != name: fail("installed dependency name mismatch: " + name)
            if name in names and leaf != snapshot / names[name]: fail("workspace points to foreign tree: " + name)
            if name not in names:
                # Bun lock 是带 trailing commas 的 JSONC；只取此具名直依赖原 resolution 字符串，
                # 不用不完整的通用 JSONC parser，也不据此声称重验了远端 tar/SRI。
                match = re.search(re.escape(json.dumps(name)) + r'\s*:\s*\[\s*"([^"\n]+)"', lock_text)
                if not match or match.group(1) != name + "@" + str(installed.get("version")):
                    fail("installed direct resolution differs from frozen lock: " + name)
            resolutions.append({"owner": owner, "name": name, "declared": declared, "installedVersion": installed.get("version"), "physicalPath": leaf.relative_to(snapshot).as_posix(), "workspace": name in names})
    return resolutions

def frozen_inputs(snapshot, records):
    current = []
    for row in records:
        p = snapshot / row["path"]
        no_symlink_chain(p)
        if not p.is_file(): fail("snapshot input missing: " + row["path"])
        actual = record_file(p, row["path"])
        if actual["kind"] != "file" or actual["gitMode"] != row["mode"] or actual["sha256"] != row["sha256"]:
            fail("snapshot input drift: " + row["path"])
        current.append(actual)
    return sha(encoded(current))

def system_tools():
    result = []
    for name in SYSTEM_TOOLS:
        p = Path(name); target = p.resolve(strict=True)
        row = record_file(target)
        row.update(requested=name, realpath=str(target))
        result.append(row)
    # /usr/bin/chromium 在此平台是 wrapper；真实已装 browser ELF 另列，绝不自动下载。
    browser = Path("/usr/lib/chromium/chromium")
    if browser.is_file(): result.append(record_file(browser))
    return result

def prepare(args):
    if not FULL.fullmatch(args.base): fail("--base must be explicit full Git commit, not HEAD")
    repo, bundle = Path(args.repo).resolve(strict=True), Path(args.destination).absolute()
    no_symlink_chain(bundle.parent); no_env_ancestors(bundle.parent)
    if bundle.exists() or bundle == repo or repo in bundle.parents: fail("new external destination required")
    bundle.mkdir(); env = fixed_env(bundle)
    plan_path = Path(args.plan).resolve(strict=True); plan_raw = plan_path.read_bytes(); plan = json.loads(plan_raw)
    if len(plan["commands"]) != 42 or plan["expectedCommandCount"] != 42: fail("unexpected command scope")
    if len({r["id"] for r in plan["commands"]}) != 42: fail("command IDs must be unique")
    if git(repo, "rev-parse", "HEAD", env=env).decode().strip() != args.base: fail("base is not actual HEAD")
    if git(repo, "status", "--porcelain=v1", "--untracked-files=all", env=env): fail("source Git must be clean before snapshot")
    snapshot = bundle / "snapshot"; snapshot.mkdir()
    entries = tree(repo, args.base, env)
    forbidden = [r["path"] for r in entries if not public(r["path"]) and r["path"] != ".env.example"]
    if forbidden: fail("unclassified/private tracked paths; do not export: " + repr(forbidden))
    objects = Objects(repo, env); inputs = []
    try:
        for r in entries:
            if r["path"] == ".env.example": continue
            if r["mode"] == "120000": fail("current public symlink rejected: " + r["path"])
            p = repo / r["path"]; no_symlink_chain(p)
            _, data, _ = objects.get(r["blob"])
            actual = record_file(p)
            if actual["kind"] != "file" or actual["gitMode"] != r["mode"] or p.read_bytes() != data: fail("current/Git source mismatch: " + r["path"])
            dest = snapshot / r["path"]; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data)
            dest.chmod(0o755 if r["mode"] == "100755" else 0o644)
            inputs.append({**r, "bytes": len(data), "sha256": sha(data)})
        paths = {r["path"] for r in inputs}
        for name in [*plan["requiredPublishedPaths"], *plan["currentC43RequiredPages"], *plan["currentRuleCardPaths"]]:
            if name not in paths: fail("final C43/public layout not published: " + name)
        for prefix in plan["requiredAbsentPrefixes"]:
            if any(in_prefix(p, prefix) for p in paths): fail("retired root still contains tracked files: " + prefix)
        commits, origins = history_commits(plan, snapshot, args.base, args.history_commit)
        guard = plan["historyGuard"]
        scripts = json.loads((snapshot / "package.json").read_text())["scripts"]
        expected_history_script = "python3 tooling/refactor/history-integrity.py --repo . --base " + guard["originBase"] + " --manifest docs/history/origin-paths.json"
        if origins["originCommit"] != guard["originBase"] or scripts.get("check:history") != expected_history_script:
            fail("actual root history script / original C43 capture identity differs from approved policy")
        check_steps = scripts.get("check", "").split(" && ")
        if check_steps[:2] != ["bun run lint:architecture", "bun --no-env-file run check:history"] or check_steps.count("bun --no-env-file run check:history") != 1:
            fail("actual root check must run history once immediately after strict")
        origin_trees = {}
        seen_origins, seen_targets = set(), set()
        for r in origins["files"]:
            original_name = r["originPath"]; safe(original_name); safe(r["currentPath"])
            if original_name in seen_origins or r["currentPath"] in seen_targets:
                fail("duplicate C43 history mapping")
            seen_origins.add(original_name); seen_targets.add(r["currentPath"])
            if r["currentPath"] != original_name.replace("docs/", "docs/history/", 1):
                fail("C43 origin/current path relation differs")
            commit = r["originCommit"]
            if commit not in origin_trees:
                origin_trees[commit] = {row["path"]: row for row in tree(repo, commit, env)}
            original_row = origin_trees[commit].get(original_name)
            if original_row is None or original_row["blob"] != r["originalGitBlob"] or original_row["mode"] != r["mode"]:
                fail("history source path/blob/mode differs from exact original Git")
            name = r["currentPath"]; b = snapshot / name
            if not b.is_file() or b.stat().st_size != r["bytes"] or sha(b.read_bytes()) != r["sha256"] or record_file(b)["gitMode"] != r["mode"]: fail("C43 historical input identity mismatch: " + name)
            kind, old, _ = objects.get(r["originalGitBlob"])
            if kind != "blob" or old != b.read_bytes(): fail("history/original Git byte mismatch")
        git_history = copy_git_objects(repo, snapshot, commits, objects, env)
    finally:
        objects.close()
    git(snapshot, "update-ref", "refs/heads/c47-fixed", args.base, env=env)
    git(snapshot, "symbolic-ref", "HEAD", "refs/heads/c47-fixed", env=env)
    git(snapshot, "read-tree", args.base, env=env)
    omitted = [r["path"] for r in entries if r["path"] == ".env.example"]
    if omitted: git(snapshot, "update-index", "--skip-worktree", "--", *omitted, env=env)
    if git(snapshot, "status", "--porcelain=v1", "--untracked-files=all", env=env): fail("snapshot public working tree not clean")
    owners = ["", "backend", "frontend", *sorted({str(PurePosixPath(r["path"]).parent) for r in inputs if re.fullmatch(r"packages/[^/]+/package\.json", r["path"])})]
    dependency_prefixes = [o + "/node_modules" if o else "node_modules" for o in owners]
    source_dependencies = closure(repo, dependency_prefixes)
    resolutions = copy_dependencies(repo, snapshot, owners)
    deps = dependencies(snapshot, owners)
    if closure(repo, dependency_prefixes) != source_dependencies:
        fail("installed dependency source changed while copying")
    destination_by_path = {row["path"]: row for row in deps}
    if set(destination_by_path) != {row["path"] for row in source_dependencies}:
        fail("dependency physical membership differs after copy")
    link_rewrites = []
    for row in source_dependencies:
        after = destination_by_path[row["path"]]
        if row["kind"] == "file":
            if row != after: fail("dependency physical bytes/mode differ: " + row["path"])
        else:
            original_target = (repo / row["path"]).resolve(strict=True).relative_to(repo)
            copied_target = (snapshot / row["path"]).resolve(strict=True).relative_to(snapshot)
            if original_target != copied_target: fail("dependency target changed: " + row["path"])
            if row["target"] != after["target"]:
                link_rewrites.append({"path": row["path"], "before": row["target"], "after": after["target"], "sameRepositoryRelativeTarget": str(original_target)})
    discovery = {prefix: [r["path"] for r in inputs if in_prefix(r["path"], prefix) and re.search(r"\.(?:test|spec)\.[cm]?[jt]sx?$", r["path"])] for prefix in DISCOVERY_ROOTS}
    plan_copy = bundle / "execution-plan.json"; plan_copy.write_bytes(plan_raw)
    git_files = closure(snapshot, [".git"])
    manifest = {"schema": "awa-c47-full-public-snapshot-v1", "createdAt": utc(), "sourceRepo": str(repo), "baseCommit": args.base, "snapshot": str(snapshot), "planSha256": sha(plan_raw), "helperSha256": sha(Path(__file__).read_bytes()), "inputs": inputs, "inputDigest": sha(encoded(inputs)), "omittedWorktreePublicTemplate": omitted, "dependencies": deps, "dependencyDigest": sha(encoded(deps)), "sourceDependencyCopyFence": {"sourceInventoryDigestBeforeAndAfter": sha(encoded(source_dependencies)), "physicalEntryCount": len(source_dependencies), "allPhysicalFileBytesModesEqual": True, "linkRewrites": link_rewrites}, "dependencyResolutions": resolutions, "dependencyOwners": owners, "gitHistory": git_history, "gitFiles": git_files, "gitFilesDigest": sha(encoded(git_files)), "tools": system_tools(), "discoveryFiles": discovery, "discoveryMeaning": "Tracked filenames only, not executed/expanded case IDs", "environmentKeys": sorted(env), "environment": env, "commandsRun": [], "limits": ["No original Git config/remotes/alternates copied", "Required exact selected commits are shallow roots; arbitrary ancestor traversal not promised", "Public .env.example is Git-object-only; never a cwd or ancestor env file", "Local installed dependency bytes captured; not a fresh offline install or remote integrity revalidation", "No OS-level egress or dynamic-library/image sandbox is claimed"]}
    matrix_path = plan["futureMatrixOwner"]
    matrix_input = next((row for row in inputs if row["path"] == matrix_path), None)
    manifest["documentationState"] = {
        "currentProgressOwner": "docs/architecture/delivery-status.md",
        "futureMatrixOwner": matrix_path,
        "matrixTrackedAtBase": matrix_input is not None,
        "matrixPresentInOriginalWorktreeAtCapture": (repo / matrix_path).is_file(),
        "matrixPresentInSnapshot": (snapshot / matrix_path).is_file(),
        "matrixCapturedInput": matrix_input,
        "matrixAbsenceIsNotASkipOfTrackedInputs": "All public tracked files were captured. An absent future metadata owner is recorded, never created as a stub to run gates.",
        "finalGoalBoundary": "Actual C47 command receipts can precede the final matrix. C48 must reconcile real receipts; new metadata/HEAD is not retroactively the tested candidate.",
    }
    frozen_inputs(snapshot, inputs)
    if git(repo, "rev-parse", "HEAD", env=env).decode().strip() != args.base or git(repo, "status", "--porcelain=v1", "--untracked-files=all", env=env): fail("original repo changed during capture")
    save(bundle / "snapshot-manifest.json", manifest)
    (bundle / "receipts").mkdir(); (bundle / "artifacts").mkdir(); (bundle / "locks").mkdir()
    print(json.dumps({"status": "SNAPSHOT_CAPTURED_NO_GATE_EXECUTED", "base": args.base, "inputs": len(inputs), "dependencies": len(deps), "manifestSha256": sha((bundle / "snapshot-manifest.json").read_bytes()), "root": str(bundle)}))

def load(bundle):
    bundle = Path(bundle).resolve(strict=True)
    raw = (bundle / "snapshot-manifest.json").read_bytes(); manifest = json.loads(raw)
    plan_raw = (bundle / "execution-plan.json").read_bytes()
    if sha(plan_raw) != manifest["planSha256"]: fail("frozen command plan changed")
    if sha(Path(__file__).read_bytes()) != manifest["helperSha256"]: fail("helper changed after snapshot")
    return bundle, manifest, json.loads(plan_raw), sha(raw)

def fence(bundle, manifest, plan):
    root = Path(manifest["snapshot"])
    env = fixed_env(bundle)
    no_env_ancestors(root)
    frozen_inputs(root, manifest["inputs"])
    if git(root, "rev-parse", "HEAD", env=env).decode().strip() != manifest["baseCommit"]: fail("snapshot Git HEAD changed")
    if closure(root, [".git"]) != manifest["gitFiles"]: fail("snapshot Git metadata/object drift")
    current_tools = system_tools()
    if current_tools != manifest["tools"]: fail("system executable identity drift")
    actual_deps = dependencies(root, manifest["dependencyOwners"])
    caches = plan["dependencyCachePrefixes"]
    old_core = [r for r in manifest["dependencies"] if not any(in_prefix(r["path"], p) for p in caches)]
    core = [r for r in actual_deps if not any(in_prefix(r["path"], p) for p in caches)]
    if core != old_core: fail("installed dependency input changed")
    # 新输出必须属于明确输出/缓存目录；不以 gitignore 为笼统输入豁免。
    expected = {r["path"] for r in manifest["inputs"]}
    output_prefixes = [*plan["runtimeOutputPrefixes"], *caches]
    installed_roots = {o + "/node_modules" if o else "node_modules" for o in manifest["dependencyOwners"]}
    for directory, dirs, files in os.walk(root, followlinks=False):
        for d in list(dirs):
            child = Path(directory) / d; name = child.relative_to(root).as_posix()
            if name == ".git" or name in installed_roots:
                dirs.remove(d)
            elif child.is_symlink():
                fail("new symlink in snapshot source/output tree: " + name)
        dirs.sort()
        for name in files:
            p = Path(directory) / name; rel = p.relative_to(root).as_posix()
            if rel not in expected and not any(in_prefix(rel, prefix) for prefix in output_prefixes): fail("unexpected snapshot file: " + rel)
    return {"checkedAt": utc(), "inputDigest": manifest["inputDigest"], "dependencyCoreDigest": sha(encoded(core)), "actualDependencyDigest": sha(encoded(actual_deps)), "explicitCacheRows": [r for r in actual_deps if any(in_prefix(r["path"], p) for p in caches)], "gitDigest": manifest["gitFilesDigest"]}

def git_probe(args):
    bundle, manifest, plan, manifest_sha = load(args.bundle)
    before = fence(bundle, manifest, plan); env = fixed_env(bundle)
    scratch = bundle / "tmp/git-object-contract-probe"
    if scratch.exists() or (bundle / "git-contract-receipt.json").exists(): fail("Git input probe already attempted")
    started = utc(); steps = []
    try:
        for argv, cwd, data in [(["clone", "--quiet", "--shared", "--no-checkout", manifest["snapshot"], str(scratch)], bundle, None), (["read-tree", plan["requiredHistoryCommits"][0]["commit"]], scratch, None), (["write-tree"], scratch, None)]:
            value = git(cwd, *argv, data=data, env=env); steps.append({"argv": ["/usr/bin/git", *argv], "cwd": str(cwd), "stdoutSha256": sha(value)})
        tree_id = value.decode().strip()
        result = git(scratch, "-c", "user.name=C47 public input probe", "-c", "user.email=c47@example.invalid", "commit-tree", tree_id, "-p", plan["requiredHistoryCommits"][0]["commit"], data=b"C47 object-only protocol probe\n", env=env)
        steps.append({"operation": "actual commit-tree", "newSyntheticCommit": result.decode().strip()})
        save(bundle / "git-contract-receipt.json", {"status": "INPUT_PROTOCOL_READY_NOT_GAMEPLAY_GATE", "startedAt": started, "endedAt": utc(), "manifestSha256": manifest_sha, "steps": steps, "before": before, "after": fence(bundle, manifest, plan)})
    except BaseException as error:
        if isinstance(error, subprocess.CalledProcessError):
            (bundle / "git-contract-failure-stdout.raw").write_bytes(error.output or b"")
            (bundle / "git-contract-failure-stderr.raw").write_bytes(error.stderr or b"")
        save(bundle / "git-contract-first-failure.json", {"startedAt": started, "endedAt": utc(), "steps": steps, "error": str(error), "classification": "snapshot Git input preparation failure; no product tests run"})
        raise
    finally:
        if scratch.exists(): shutil.rmtree(scratch)
    print("Real offline clone/read-tree/write-tree/commit-tree input protocol ready; no product gate executed.")

def planned_argv(command, bundle):
    argv = [value.replace("<RUN_ARTIFACT_DIR>", str(bundle / "artifacts")) for value in command["argv"]]
    if command["id"] == "history-integrity":
        if argv != ["/usr/bin/python3", "tooling/refactor/history-integrity.py", "--repo", ".", "--base", "14e7951787f4464573407a7bcc270303a3975856", "--manifest", "docs/history/origin-paths.json"]:
            fail("history entry must use the exact approved Python command/origin base")
    elif argv[:2] != ["/usr/bin/bun", "--no-env-file"]:
        fail("controlled Bun entry flag absent")
    return argv

def planned_env(command, runtime):
    env = fixed_env(runtime)
    additions = command.get("environmentAdditions", {})
    if additions and (command["id"] != "chromium-e2e" or additions != {"PLAYWRIGHT_HEADLESS": "true"}):
        fail("unapproved command-specific environment")
    env.update(additions)
    return env

def run_one(args):
    if not args.execute: fail("run requires explicit --execute")
    bundle, manifest, plan, manifest_sha = load(args.bundle)
    if not (bundle / "git-contract-receipt.json").is_file(): fail("complete real Git input probe before first gate")
    matches = [r for r in plan["commands"] if r["id"] == args.command]
    if len(matches) != 1: fail("unknown command ID")
    command = matches[0]; attempt = args.attempt
    if attempt < 1 or (attempt > 1 and not args.reason): fail("explicit retry reason required")
    if attempt > 1:
        previous = bundle / "receipts" / (command["id"] + "-attempt-" + str(attempt - 1)) / "receipt.json"
        if not previous.is_file() or json.loads(previous.read_text())["success"]:
            fail("retry requires an actual preceding failed attempt; do not rerun green")
    name = command["id"] + "-attempt-" + str(attempt)
    destination = bundle / "receipts" / name; destination.mkdir()
    lock = bundle / "locks" / command["id"]
    lock.mkdir()
    started = utc(); start = time.monotonic(); child = None; code = None; timeout = False
    pre = None; post = None; error = None
    # 各命令使用独占空 HOME/XDG/TMP/cache；不让前一个测试的合成配置成为下一命令的输入。
    env = planned_env(command, destination / "runtime"); root = Path(manifest["snapshot"])
    argv = planned_argv(command, bundle)
    cwd = root / command["cwd"]
    try:
        for prerequisite in command.get("commandPrerequisites", []):
            if prerequisite not in {r["id"] for r in plan["commands"]}:
                fail("unknown command prerequisite; environment/resource labels are not receipts")
            found = False
            for path in (bundle / "receipts").glob(prerequisite + "-attempt-*/receipt.json"):
                value = json.loads(path.read_text())
                if value.get("id") == prerequisite and value.get("base") == manifest["baseCommit"] and value.get("manifestSha256") == manifest_sha and value.get("success") is True:
                    found = True
            if not found: fail("required prior same-input command not successful: " + prerequisite)
        pre = fence(bundle, manifest, plan)
        save(destination / "launch.json", {"startedAt": started, "base": manifest["baseCommit"], "manifestSha256": manifest_sha, "cwd": str(cwd), "argv": argv, "rootAssignedLane": args.lane, "plannedLane": command["lane"], "environment": env, "commandPrerequisites": command.get("commandPrerequisites", []), "rootEnvironmentResourcePrerequisites": command.get("environmentPrerequisites", []), "timeoutSeconds": args.timeout, "attempt": attempt, "retryReason": args.reason, "parentToolLaunchSessionTerminal": "Root adds actual external tool receipt linkage; helper does not invent IDs"})
        with (destination / "stdout.raw").open("xb") as stdout, (destination / "stderr.raw").open("xb") as stderr:
            # env -i 是真实命令，不依赖外层 Bun flag 向测试子进程传播。
            env_argv = ["/usr/bin/env", "-i", *[k + "=" + v for k, v in sorted(env.items())], *argv]
            child = subprocess.Popen(env_argv, cwd=cwd, stdout=stdout, stderr=stderr, start_new_session=True, env={})
            save(destination / "process.json", {"pid": child.pid, "argv": env_argv, "startedAt": utc()})
            try: code = child.wait(timeout=args.timeout)
            except subprocess.TimeoutExpired:
                timeout = True; os.killpg(child.pid, signal.SIGTERM)
                try: code = child.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL); code = child.wait()
        post = fence(bundle, manifest, plan)
    except BaseException as thrown:
        error = str(thrown)
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL); code = child.wait()
    finally:
        group_still_exists = None
        if child is not None:
            try:
                os.killpg(child.pid, 0)
                group_still_exists = True
            except ProcessLookupError:
                group_still_exists = False
            except PermissionError:
                group_still_exists = "unobservable_permission_error"
        raw = []
        for p in [destination / "stdout.raw", destination / "stderr.raw"]:
            if p.exists(): raw.append(record_file(p))
        receipt = {"id": command["id"], "attempt": attempt, "base": manifest["baseCommit"], "manifestSha256": manifest_sha, "cwd": str(cwd), "argv": argv, "startedAt": started, "endedAt": utc(), "elapsedSeconds": time.monotonic() - start, "pid": child.pid if child else None, "exitCode": code, "signal": -code if code is not None and code < 0 else None, "timedOut": timeout, "preInputFence": pre, "postInputFence": post, "preparationOrFenceError": error, "raw": raw, "success": code == 0 and not timeout and error is None, "testCounts": "Read actual raw / Playwright JSON; no historical or static expanded counts inferred", "resourceGroupStillExistsAfterWait": group_still_exists, "resourceCleanup": "Process group killed on wrapper timeout; group absence is a bounded observation, not proof of every escaped descendant/browser/listener closure"}
        save(destination / "receipt.json", receipt)
        lock.rmdir()
    print(json.dumps({k: receipt[k] for k in ("id", "attempt", "exitCode", "timedOut", "success", "preparationOrFenceError")}))
    if not receipt["success"]: sys.exit(code if code is not None and 0 < code < 126 else 1)

def finalize(args):
    if len(safe(args.output).parts) != 1:
        fail("summary output must be a fresh basename within this bundle")
    bundle, manifest, plan, manifest_sha = load(args.bundle)
    current = fence(bundle, manifest, plan)
    receipts = []
    by_id = {row["id"]: row for row in plan["commands"]}
    for p in sorted((bundle / "receipts").glob("*/receipt.json")):
        raw = p.read_bytes(); value = json.loads(raw)
        command = by_id.get(value.get("id"))
        attempt = value.get("attempt")
        if command is None or type(attempt) is not int or attempt < 1:
            fail("unknown receipt ID/attempt: " + str(p))
        if p.parent.name != command["id"] + "-attempt-" + str(attempt):
            fail("receipt path/identity mismatch: " + str(p))
        if value.get("base") != manifest["baseCommit"] or value.get("manifestSha256") != manifest_sha:
            fail("receipt belongs to a different frozen input: " + str(p))
        if value.get("argv") != planned_argv(command, bundle) or value.get("cwd") != str(Path(manifest["snapshot"]) / command["cwd"]):
            fail("receipt command/cwd differs from frozen plan: " + str(p))
        actual_raw_paths = set()
        for original in value.get("raw", []):
            expected = p.parent / Path(original["path"]).name
            if expected.name not in {"stdout.raw", "stderr.raw"} or Path(original["path"]) != expected:
                fail("raw receipt path escapes its attempt: " + str(p))
            if original != record_file(expected):
                fail("raw bytes/mode/SHA differ from receipt: " + str(expected))
            actual_raw_paths.add(expected.name)
        if value.get("success") is True:
            if value.get("exitCode") != 0 or value.get("timedOut") is not False or value.get("preparationOrFenceError") is not None or actual_raw_paths != {"stdout.raw", "stderr.raw"}:
                fail("success receipt lacks actual successful execution: " + str(p))
            for phase in ("preInputFence", "postInputFence"):
                seen = value.get(phase) or {}
                if seen.get("inputDigest") != manifest["inputDigest"] or seen.get("gitDigest") != manifest["gitFilesDigest"]:
                    fail("success receipt fence belongs to other inputs: " + str(p))
        receipts.append({"path": str(p), "sha256": sha(raw), "id": value["id"], "attempt": value["attempt"], "success": value["success"], "exitCode": value["exitCode"]})
    done = {r["id"] for r in receipts if r["success"]}
    all_ids = {r["id"] for r in plan["commands"]}
    missing = sorted(all_ids - done)
    artifacts = closure(bundle, ["artifacts"])
    summary = {"status": "COMMAND_RECEIPTS_COMPLETE_PENDING_SEMANTIC_REVIEW" if not missing else "INCOMPLETE", "base": manifest["baseCommit"], "manifestSha256": manifest_sha, "finalFence": current, "receipts": receipts, "missingCommandIDs": missing, "artifacts": artifacts, "firstFailuresPreserved": [r for r in receipts if not r["success"]], "notClaimed": ["all55 gameplay or P9 complete", "PNG/MP4 visual acceptance from file existence", "all dynamic test case IDs from static paths", "no resources left merely because parent exit was zero"]}
    summary["documentationStateAtCapture"] = manifest["documentationState"]
    summary["finalMatrixAndC48Reconciliation"] = "Required separately from this 42-command receipt inventory; neither file existence nor all command IDs imply P9/C48 objective completion."
    save(bundle / args.output, summary)
    print(json.dumps({"status": summary["status"], "missingCommandIDs": missing, "summary": str(bundle / args.output)}))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="operation", required=True)
    p = sub.add_parser("prepare"); p.add_argument("--repo", required=True); p.add_argument("--base", required=True); p.add_argument("--destination", required=True); p.add_argument("--plan", required=True); p.add_argument("--history-commit", action="append", default=[]); p.set_defaults(call=prepare)
    p = sub.add_parser("git-probe"); p.add_argument("--bundle", required=True); p.set_defaults(call=git_probe)
    p = sub.add_parser("run"); p.add_argument("--bundle", required=True); p.add_argument("--command", required=True); p.add_argument("--lane", required=True); p.add_argument("--timeout", type=int, required=True); p.add_argument("--attempt", type=int, default=1); p.add_argument("--reason"); p.add_argument("--execute", action="store_true"); p.set_defaults(call=run_one)
    p = sub.add_parser("finalize"); p.add_argument("--bundle", required=True); p.add_argument("--output", default="summary-first.json"); p.set_defaults(call=finalize)
    args = parser.parse_args(); args.call(args)

if __name__ == "__main__":
    main()
