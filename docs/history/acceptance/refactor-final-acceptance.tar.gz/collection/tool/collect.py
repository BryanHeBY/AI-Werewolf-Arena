#!/usr/bin/env python3
"""只汇总现存 C47 数据；不运行 helper、Git、测试、编译、浏览器或媒体工具。

输出为待独立审读的数据报告，不是验收批准。所有输入只读，输出必须是新的 TMP 文件。
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import stat
import sys

BASE = "60fdbfbc57122eeb1d4e9204b66d4daec1eb0157"
MANIFEST = "08cb4b2ba9640566b28b9610ea22c1602d40eee811c47be282128ca8618b591e"
IDS = """architecture-strict history-integrity fixtures tooling-types
package-game-catalog-types package-game-catalog-test-types
package-game-contract-types package-game-contract-test-types
package-game-presentation-types package-game-presentation-test-types
package-game-text-types package-game-text-test-types
package-replay-contract-types package-replay-contract-test-types
backend-types backend-test-types frontend-types backend-eslint backend-boundaries
backend-i18n frontend-eslint format tooling-tests package-game-catalog-tests
package-game-contract-tests package-game-presentation-tests package-game-text-tests
package-replay-contract-tests backend-architecture backend-unit backend-integration
backend-scenarios frontend-unit frontend-integration frontend-architecture
backend-build frontend-build backend-smoke chromium-e2e render-png-zh-CN
render-png-en render-mp4-en""".split()
BUN_SUITES = {x for x in IDS if x.endswith("-tests")} | {
    "backend-architecture", "backend-unit", "backend-integration", "backend-scenarios",
    "frontend-unit", "frontend-integration", "frontend-architecture",
}
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
FOOTER = re.compile(r"^Ran (\d+) tests? across (\d+) files?\.\s*(.*)$")
COUNTER = re.compile(r"^\s*(\d+) (pass|fail|skip|todo|filtered out|expect\(\) calls)\s*$")


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def file_row(path):
    p = Path(path)
    s = p.lstat()
    if not stat.S_ISREG(s.st_mode):
        raise ValueError("not a regular data file: " + str(p))
    b = p.read_bytes()
    return {"path": str(p), "kind": "file", "bytes": len(b), "sha256": digest(b),
            "gitMode": "100755" if s.st_mode & 0o100 else "100644",
            "posixMode": format(stat.S_IMODE(s.st_mode), "04o")}


def inside(name, prefix):
    return name == prefix or name.startswith(prefix + "/")


def bun_counts(raws):
    """仅取唯一输出流的最后一个 Bun footer；不数逐条 fail 的重复摘要。"""
    candidates = []
    for name, text in raws.items():
        lines = ANSI.sub("", text).splitlines()
        ends = [(i, FOOTER.fullmatch(line.strip())) for i, line in enumerate(lines)]
        ends = [(i, match) for i, match in ends if match]
        if not ends:
            continue
        index, footer = ends[-1]
        counts, at = {}, index - 1
        while at >= 0:
            if not lines[at].strip():
                at -= 1
                continue
            match = COUNTER.fullmatch(lines[at])
            if not match:
                break
            if match[2] in counts:
                raise ValueError("duplicate final Bun counter: " + match[2])
            counts[match[2]] = int(match[1])
            at -= 1
        if "pass" not in counts or "fail" not in counts:
            raise ValueError("final Bun footer lacks actual pass/fail counters")
        candidates.append({"stream": name, "countsActuallyPrinted": counts,
                           "testsActuallyReported": int(footer[1]),
                           "filesActuallyReported": int(footer[2]), "footer": footer[0],
                           "earlierFootersNotSummed": len(ends) - 1,
                           "outputAfterFooter": {"lines": len(lines[index + 1:]),
                               "sha256": digest("\n".join(lines[index + 1:]).encode())},
                           "absentCountersAreNotInferred": [x for x in
                               ["skip", "todo", "filtered out", "expect() calls"] if x not in counts]})
    if len(candidates) != 1:
        raise ValueError("expected one unambiguous Bun final-summary stream")
    return candidates[0]


def playwright_counts(text):
    """stdout 必须是完整 JSON；不从混杂输出任取一个看似合法的 JSON 片段。"""
    data = json.loads(text)
    stats = data["stats"]
    for key in ["expected", "unexpected", "flaky", "skipped"]:
        if type(stats.get(key)) is not int or stats[key] < 0:
            raise ValueError("missing/invalid Playwright stat: " + key)
    tests = []

    def walk(suite, parents):
        titles = [*parents, suite.get("title", "")]
        for spec in suite.get("specs", []):
            for test in spec.get("tests", []):
                tests.append({"titlePath": [*titles, spec.get("title", "")],
                              "file": spec.get("file"), "project": test.get("projectName"),
                              "expectedStatus": test.get("expectedStatus"),
                              "status": test.get("status"), "annotations": test.get("annotations", []),
                              "actualResults": [{"status": r.get("status"),
                                                 "retry": r.get("retry"),
                                                 "duration": r.get("duration")}
                                                for r in test.get("results", [])]})
        for child in suite.get("suites", []):
            walk(child, titles)

    for suite in data.get("suites", []):
        walk(suite, [])
    if sum(stats[k] for k in ["expected", "unexpected", "flaky", "skipped"]) != len(tests):
        raise ValueError("Playwright actual expanded tests disagree with its stats")
    return {"stats": stats, "expandedTests": tests, "topLevelErrors": data.get("errors", []),
            "meaning": "expectedStatus may be failed; do not confuse expected negative tests with unexpected failures"}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--summary", default="summary-final.json")
    ap.add_argument("--helper", default="/tmp/awa-c47-public-snapshot/c47-public-snapshot.py")
    ap.add_argument("--history-index", default=str(Path(__file__).with_name("history-index.json")))
    args = ap.parse_args()
    bundle = Path(args.bundle).resolve(strict=True)
    requested_output = Path(args.output).absolute()
    output = requested_output.parent.resolve(strict=True) / requested_output.name
    if not any(inside(str(output), p) for p in ["/tmp", "/var/tmp"]):
        raise ValueError("collector output must be a fresh TMP path")
    if output.exists() or output.is_symlink() or not output.parent.is_dir():
        raise ValueError("output must be absent and its parent must already exist")
    manifest_path = bundle / "snapshot-manifest.json"
    manifest_raw = manifest_path.read_bytes()
    manifest, plan = json.loads(manifest_raw), read(bundle / "execution-plan.json")
    if manifest["baseCommit"] != BASE or digest(manifest_raw) != MANIFEST:
        raise ValueError("not the explicitly approved60fdbfbc manifest/base")
    snapshot = Path(manifest["snapshot"])
    if snapshot != bundle / "snapshot" or inside(str(output), str(snapshot)):
        raise ValueError("snapshot/output path mismatch")
    if inside(str(output), manifest["sourceRepo"]):
        raise ValueError("repository output forbidden")
    errors, pending, observations, attempts = [], [], [], []

    def require(ok, message):
        if not ok:
            errors.append(message)

    require(digest((bundle / "execution-plan.json").read_bytes()) == manifest["planSha256"], "plan SHA mismatch")
    require(file_row(args.helper)["sha256"] == manifest["helperSha256"], "helper SHA mismatch")
    for key, rows in [("inputDigest", "inputs"), ("dependencyDigest", "dependencies"), ("gitFilesDigest", "gitFiles")]:
        require(digest(encoded(manifest[rows])) == manifest[key], "manifest inventory digest: " + key)
    commands = {r["id"]: r for r in plan["commands"]}
    require(len(commands) == len(plan["commands"]) == 42 and set(commands) == set(IDS), "42 actual command IDs mismatch")
    caches = plan["dependencyCachePrefixes"]
    core = [r for r in manifest["dependencies"] if not any(inside(r["path"], p) for p in caches)]
    core_digest = digest(encoded(core))

    def check_fence(value, context):
        for key, expected in [("inputDigest", manifest["inputDigest"]),
                              ("gitDigest", manifest["gitFilesDigest"]),
                              ("dependencyCoreDigest", core_digest)]:
            require(value.get(key) == expected, context + ": " + key)
        cache_rows = value.get("explicitCacheRows", [])
        require(all(any(inside(r["path"], p) for p in caches) for r in cache_rows), context + ": unapproved cache row")
        require(len({r["path"] for r in cache_rows}) == len(cache_rows), context + ": duplicate cache rows")
        combined = sorted([*core, *cache_rows], key=lambda r: r["path"])
        require(digest(encoded(combined)) == value.get("actualDependencyDigest"), context + ": actual dependency digest")

    for folder in sorted((bundle / "receipts").iterdir()):
        match = re.fullmatch(r"(.+)-attempt-(\d+)", folder.name)
        if folder.is_symlink() or not folder.is_dir() or not match or match[1] not in commands:
            errors.append("unknown receipt directory: " + str(folder)); continue
        receipt_path = folder / "receipt.json"
        if not receipt_path.is_file():
            pending.append("terminal_receipt_missing:" + folder.name); continue
        try:
            receipt = read(receipt_path)
            launch = read(folder / "launch.json") if (folder / "launch.json").is_file() else None
            process = read(folder / "process.json") if (folder / "process.json").is_file() else None
            cid, attempt = match[1], int(match[2]); command = commands[cid]
            argv = [s.replace("<RUN_ARTIFACT_DIR>", str(bundle / "artifacts")) for s in command["argv"]]
            cwd = str(snapshot / command["cwd"])
            good = type(receipt.get("exitCode")) is int and receipt["exitCode"] == 0 and receipt.get("timedOut") is False and receipt.get("preparationOrFenceError") is None
            for item, label in [(receipt, "receipt"), (launch, "launch")]:
                if item is None:
                    require(not good and receipt.get("pid") is None, folder.name + ": launched attempt lacks " + label)
                    continue
                require(item.get("base") == BASE and item.get("manifestSha256") == MANIFEST, folder.name + ": " + label + " identity")
                require(item.get("attempt") == attempt and item.get("argv") == argv and item.get("cwd") == cwd, folder.name + ": " + label + " command")
            require(receipt.get("id") == cid, folder.name + ": command ID")
            if process is not None and launch is not None:
                env_argv = ["/usr/bin/env", "-i", *[k + "=" + v for k, v in sorted(launch["environment"].items())], *argv]
                require(process.get("argv") == env_argv and process.get("pid") == receipt.get("pid"), folder.name + ": process argv/PID")
                require(launch.get("commandPrerequisites") == command.get("commandPrerequisites", []), folder.name + ": command prerequisites")
            else:
                require(not good and receipt.get("pid") is None, folder.name + ": missing launched process")
            require(cid == "history-integrity" or argv[:2] == ["/usr/bin/bun", "--no-env-file"], folder.name + ": Bun entry flag")
            raw_rows, texts = {}, {}
            for row in receipt.get("raw", []):
                name = Path(row["path"]).name
                if name not in {"stdout.raw", "stderr.raw"} or Path(row["path"]) != folder / name or name in raw_rows:
                    raise ValueError("raw path or duplicate entry")
                actual = file_row(folder / name)
                require(actual == row, folder.name + ": raw bytes/mode/SHA " + name)
                raw_rows[name] = actual
                texts[name] = (folder / name).read_bytes().decode("utf-8", "replace")
            if good or receipt.get("pid") is not None:
                require(set(raw_rows) == {"stdout.raw", "stderr.raw"}, folder.name + ": both raw streams required")
            require(receipt.get("success") is good, folder.name + ": success flag mismatch")
            if good:
                check_fence(receipt.get("preInputFence") or {}, folder.name + " pre")
                check_fence(receipt.get("postInputFence") or {}, folder.name + " post")
            row = {"id": cid, "attempt": attempt, "success": good, "receipt": file_row(receipt_path),
                   "launch": file_row(folder / "launch.json") if launch is not None else None,
                   "process": file_row(folder / "process.json") if process is not None else None,
                   "raw": list(raw_rows.values()), "exitCode": receipt.get("exitCode"), "signal": receipt.get("signal"),
                   "timedOut": receipt.get("timedOut"), "resourceGroupStillExistsAfterWait": receipt.get("resourceGroupStillExistsAfterWait")}
            try:
                if cid in BUN_SUITES:
                    row["bun"] = bun_counts(texts)
                    if good: require(row["bun"]["countsActuallyPrinted"]["fail"] == 0, folder.name + ": successful Bun reports failures")
                elif cid == "chromium-e2e":
                    row["playwright"] = playwright_counts(texts["stdout.raw"])
                    if good:
                        require(row["playwright"]["stats"]["unexpected"] == 0 and not row["playwright"]["topLevelErrors"], folder.name + ": unexpected PW tests/errors")
            except (ValueError, KeyError, TypeError) as error:
                row["countsUnavailable"] = str(error)
                # 真实早抛／wrapper停止可没有最终footer；仍保首红，绝不补零或丢掉该attempt。
                if good: errors.append(folder.name + ": successful test counts unavailable: " + str(error))
            if row["resourceGroupStillExistsAfterWait"] is not False:
                observations.append({"attempt": folder.name, "resourceReviewNeeded": row["resourceGroupStillExistsAfterWait"]})
            attempts.append(row)
        except (OSError, ValueError, KeyError, TypeError) as error:
            errors.append(folder.name + ": " + str(error))

    successes = {r["id"] for r in attempts if r["success"]}
    pending += ["successful_terminal_missing:" + cid for cid in IDS if cid not in successes]
    for cid in IDS:
        group = sorted([r for r in attempts if r["id"] == cid], key=lambda r: r["attempt"])
        require([r["attempt"] for r in group] == list(range(1, len(group) + 1)), cid + ": attempt gap")
        for previous, current in zip(group, group[1:]):
            require(not previous["success"], cid + ": rerun of green")
            require(bool(current["launch"] and read(Path(current["launch"]["path"])).get("retryReason")), cid + ": retry reason missing")

    summary_path = bundle / args.summary
    if summary_path.parent != bundle:
        raise ValueError("summary must be a bundle-root basename")
    summary = None
    if not summary_path.is_file():
        pending.append("final_helper_summary_missing:" + args.summary)
    else:
        summary = read(summary_path)
        require(summary.get("base") == BASE and summary.get("manifestSha256") == MANIFEST, "summary identity")
        check_fence(summary.get("finalFence") or {}, "final recorded helper fence")
        require(set(summary.get("missingCommandIDs", [])) == set(IDS) - successes, "summary success-ID inventory")
        expected_status = "COMMAND_RECEIPTS_COMPLETE_PENDING_SEMANTIC_REVIEW" if successes == set(IDS) else "INCOMPLETE"
        require(summary.get("status") == expected_status, "summary completion status")
        summary_rows = {r["path"]: r for r in summary.get("receipts", [])}
        require(len(summary_rows) == len(attempts), "summary attempt inventory")
        for row in attempts:
            got = summary_rows.get(row["receipt"]["path"], {})
            require(got.get("sha256") == row["receipt"]["sha256"] and got.get("success") == row["success"], "summary receipt hash/status")

    media = []
    for name in ["replay-zh-CN.png", "replay-en.png", "replay-en.mp4"]:
        path = bundle / "artifacts" / name
        if not path.is_file():
            pending.append("media_missing:" + name); continue
        row = file_row(path); require(row["bytes"] > 0, "empty media: " + name)
        if summary:
            declared = next((r for r in summary.get("artifacts", []) if r.get("path") == "artifacts/" + name), None)
            require({**row, "path": "artifacts/" + name} == declared, "media differs from final helper artifact capture: " + name)
        media.append({**row, "meaning": "presence and byte identity only; probe and actual visual review remain required"})
    history = read(args.history_index)
    history_evidence = []
    for row in history["evidence"]:
        try:
            actual = file_row(row["path"])
            require(actual["sha256"] == row["sha256"], "historical index changed: " + row["path"])
            history_evidence.append({**row, "actual": actual})
        except OSError as error:
            errors.append("historical evidence missing: " + str(error))
    result = {"status": "BLOCKED_DATA_MISMATCH" if errors else "INCOMPLETE" if pending else "COLLECTED_PENDING_INDEPENDENT_REVIEW",
              "base": BASE, "manifestSha256": MANIFEST, "collectedAt": dt.datetime.now(dt.timezone.utc).isoformat(),
              "manifest": file_row(manifest_path), "plan": file_row(bundle / "execution-plan.json"),
              "helper": file_row(args.helper), "commandIDs": IDS, "attempts": attempts,
              "successfulIDs": sorted(successes), "pending": pending, "errors": errors,
              "finalSummary": file_row(summary_path) if summary else None,
              "media": media, "resourceObservations": observations,
              "historyIndex": file_row(args.history_index), "historyEvidence": history_evidence,
              "historicalClassificationsAtPreparation": history.get("classifications", []),
              "independentReviewStillRequired": ["Read actual raw/skip/filter/PW expected-status and test input scope",
                  "Read source/dependency/Git/tools final fence and actual media metadata/visual observations",
                  "Process-group absence is not all escaped descendants/listeners closed",
                  "No all55/910/P9 completion from42 command IDs; C48 separately reconciles evidence"],
              "collectorLimit": "Only parses existing data and hashes files. Does not run helpers, Git, compilers, tests, probes or media; does not rehash1GB installed dependencies or claim new live fences."}
    with output.open("xb") as handle:
        handle.write(encoded(result))
    print(json.dumps({"status": result["status"], "output": str(output), "errors": len(errors), "pending": len(pending)}))
    return 1 if errors else 2 if pending else 0


if __name__ == "__main__":
    sys.exit(main())
