# 60fdbfbc 最终轮纯数据 collector

TMP 已冻结，未执行脚本／语法检查／产品 parser／类型／测试／probe；无仓库写入。新 snapshot prepare 已由 Root 实际完成，本脚本尚未运行，gitprobe／42命令结果不得由准备态推断。

## Root 实际入口

```sh
/usr/bin/python3 /tmp/awa-c47-pure-data-collector-60fdbfbc/collect.py \
  --bundle /var/tmp/awa-refactor-20261015/c47-60fdbfbc \
  --summary summary-final.json \
  --output /tmp/awa-c47-60fdbfbc-collected-first.json
```

显式 base `60fdbfbc57122eeb1d4e9204b66d4daec1eb0157`；实际 manifest SHA `08cb4b2ba9640566b28b9610ea22c1602d40eee811c47be282128ca8618b591e`。manifest 源来自已经写成的 `/var/tmp/awa-refactor-20261015/c47-60fdbfbc/snapshot-manifest.json`，不是猜测未来 hash。输出必须全新 TMP 文件；若 Root 的 finalize 文件名不同，仅将 `--summary` 换成真实 bundle 根 basename，不代跑任何 helper。缺实际终态/媒体时应输出 INCOMPLETE。

## 仅身份后继

从 `/tmp/awa-c47-pure-data-collector-f2bdc983/collect.py` 逐字复制，只更新 BASE／MANIFEST 两常量及对应拒绝 label 三个字面；`binding-only.diff` 是完整差量，逆回原脚本字节相同。bundle 仍通过原必填 CLI 传入，并由新固定 manifest 中的 snapshot 路径约束。42 IDs、Bun真实footer/PW JSON/media、argv/cwd/env-i、raw路径/bytes/mode/hash、pre/post fence、summary集合、retry和资源观测逻辑全保。

原 f2 collector/HISTORY 与最初07ef版本均未修改。新history保前25 evidence与7 classifications对象，继承的 `successorCurrentIdentity` 只描述 f2当时准备态；本次 `currentCollectorIdentity` 明确是60。仅追加 f2真实summary/terminalparse与两个首红 receipt/四raw（9对象）：20终态=18绿+2红，22项未启动，A场景未启动。strict原JSON为3364files/9comment诊断/0remainingDebt；integration原footer349/1/4169、350tests/78files。后继五头修复和词典准入有限绿不回填 f2，也不给60补成功。

## 结论边界

保原输出状态：数据矛盾 BLOCKED_DATA_MISMATCH/1；收据或媒体不足 INCOMPLETE/2；纯数据齐 COLLECTED_PENDING_INDEPENDENT_REVIEW/0。exit0不是验收批准；三媒体仍需实际probe和看图/视频审查，资源group不存在不冒全部逃逸后代/监听已关闭。旧红原raw、07ef7200timeout和12无footer行、旧cb/2a4等分类身份均保，不拼绿。42入口不是910格/所有玩法的形式证明。

工具只读既有JSON/日志/媒体字节，不启动产品／解析器／Git／测试／编译器／媒体工具，不复制依赖或runtime；最终Root实际执行后再独立读审。
