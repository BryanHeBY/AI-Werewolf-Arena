/**
 * 负责双语文件系统集成测试，消费实际 PlayerRoundRecorder、录制 scope 与玩家文件。
 * 输入为字面有界请求和原 prompt／thought，输出由原内层 v2 阶段／schema 及保存原文断言核对。
 * 临时目录与终结顺序由每例拥有，新外层封装仅在实际读取处解包，不改变预期。
 */
import { readReplayPlayerView } from "@ai-werewolf-arena/replay-contract";
import { expect, test } from "bun:test";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { assertReplayPlayerView } from "@ai-werewolf-arena/replay-contract";
import { bootstrapGame } from "../../../src/app/bootstrap";
import { sixPlayerMvpConfig } from "../../../src/rulesets/presets/six-player-mvp";
import { PlayerRoundRecorder } from "../../../src/app/player-round-recorder";
import { SessionRecordManager } from "../../../src/recording/session/recorder";
import { runWithSessionRecorder } from "../../../src/recording/session/context";
import { Phase, Role } from "../../../src/domain";
import { createTestTempDirectory } from "../../support/drivers/temp-directories";

for (const locale of ["zh-CN", "en"] as const)
  test(`actual player round writes v2 ${locale} machine phase/stage and original text`, async () => {
    const root = await createTestTempDirectory("awa-private-v2-");
    const { world } = bootstrapGame(sixPlayerMvpConfig, {
      locale,
      fixedRoles: [Role.Wolf, Role.Seer, Role.Villager, Role.Wolf, Role.Guard, Role.Villager],
    });
    const manager = await SessionRecordManager.create(
      {
        sessionId: "private-v2",
        locale,
        board: "synthetic",
        startedAtIso: "2026-10-08T00:00:00.000Z",
      },
      root,
    );
    await runWithSessionRecorder(manager, async () => {
      new PlayerRoundRecorder(world).record(
        {
          actorId: 1,
          phase: Phase.Night,
          allowedTools: ["speak_to_wolves"],
          context: {
            day: 1,
            stage: "wolf_discussion",
            visible_events: [],
            turn_constraints: {
              min_valid_actions: 1,
              max_valid_actions: 1,
              summary_message: { key: "request.summary.night_action" },
            },
          },
        },
        {
          systemPrompt: "Original 系统",
          userPrompt: "Original 当前提示",
          messages: [],
          isInitialRound: true,
          eventCursorBefore: 0,
          eventCursorAfter: 0,
          contextWindowStart: 0,
          contextWindowEnd: 0,
          contextWindowTotal: 0,
          turnId: "t1",
        },
        { actionMode: "none", toolCalls: [], thinkingText: "Original 思考" },
      );
      await manager.finalize({
        endedAtIso: "2026-10-08T00:01:00.000Z",
        winner: null,
        finishReason: "completed",
        players: [],
      });
    });
    const view = readReplayPlayerView(
      JSON.parse(await readFile(path.join(root, "private-v2/players/player_1.json"), "utf8")),
    );
    assertReplayPlayerView(view);
    expect(view.schemaVersion).toBe(2);
    expect(view.locale).toBe(locale);
    expect(view.initial_prompt!.phase).toBe("night");
    expect(view.initial_prompt!.stage).toBe("wolf_discussion");
    expect(view.timeline[0].phase).toBe("night");
    expect(view.timeline[0].stage).toBe("wolf_discussion");
    expect(view.timeline[0].request_id).toBe("1-night-1-1");
    expect(view.initial_prompt!.prompt_system).toBe("Original 系统");
    expect(JSON.stringify(view)).toContain("Original 思考");
    expect(JSON.stringify(view)).toContain("Original 当前提示");
  });
