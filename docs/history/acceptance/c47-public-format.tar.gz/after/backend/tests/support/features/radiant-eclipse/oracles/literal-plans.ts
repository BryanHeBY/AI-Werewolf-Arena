/**
 * 持有本模块手写测试预期和有界契约断言；输入为提供的计划或观察元组，输出保留字面库存、身份、标记及错误预期。不从生产结算重新生成预期游戏结果，也不运行游戏、模型或传输。
 */

export const radiantFullPlans = [
  {
    name: "last-wolf-borrow-backlash",
    sheriff: null,
    nights: [
      {
        swallow: null,
        shelter: null,
        dream: 6,
        knife: 10,
        exile: 11,
      },
      {
        swallow: null,
        shelter: null,
        dream: 7,
        knife: 12,
        exile: null,
      },
      {
        swallow: 2,
        shelter: 7,
        dream: 8,
        knife: 6,
        exile: null,
      },
    ],
    nightDeaths: [[10], [12], [1, 6]],
    alive: [
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 12],
      [1, 2, 3, 4, 5, 6, 7, 8, 9],
      [2, 3, 4, 5, 7, 8, 9],
    ],
    winner: "good",
    phase: "day",
    lastWords: [10, 11],
    dreamDeaths: [],
    sources: [
      {
        "10": ["wolf_kill"],
      },
      {
        "12": ["wolf_kill"],
      },
      {
        "1": ["radiant_backlash"],
        "6": ["wolf_kill"],
      },
    ],
  },
  {
    name: "last-villager-saved-then-double-cause",
    sheriff: null,
    nights: [
      {
        swallow: null,
        shelter: null,
        dream: 1,
        knife: 6,
        exile: 7,
      },
      {
        swallow: 4,
        shelter: 8,
        dream: 2,
        knife: 8,
        exile: 8,
        potion: ["heal", 8],
      },
      {
        swallow: 3,
        shelter: 9,
        dream: 1,
        knife: 9,
        exile: 10,
      },
      {
        swallow: 4,
        shelter: null,
        dream: 2,
        knife: 9,
        exile: null,
        potion: ["poison", 9],
      },
    ],
    nightDeaths: [[6], [], [], [9]],
    alive: [
      [1, 2, 3, 4, 5, 8, 9, 10, 11, 12],
      [1, 2, 3, 4, 5, 9, 10, 11, 12],
      [1, 2, 3, 4, 5, 9, 11, 12],
      [1, 2, 3, 4, 5, 11, 12],
    ],
    winner: "wolf",
    phase: "day",
    lastWords: [6, 7, 8, 10],
    dreamDeaths: [],
    sources: [
      {
        "6": ["wolf_kill"],
      },
      {},
      {},
      {
        "9": ["wolf_kill", "poison"],
      },
    ],
  },
  {
    name: "last-god-restored-dream-gap",
    sheriff: null,
    nights: [
      {
        swallow: null,
        shelter: null,
        dream: 6,
        knife: 3,
        exile: 4,
      },
      {
        swallow: 5,
        shelter: 6,
        dream: 6,
        knife: 2,
        exile: 10,
      },
      {
        swallow: 6,
        shelter: null,
        dream: 6,
        knife: 5,
        exile: null,
      },
    ],
    nightDeaths: [[3], [2], [5, 6]],
    alive: [
      [1, 2, 5, 6, 7, 8, 9, 10, 11, 12],
      [1, 5, 6, 7, 8, 9, 11, 12],
      [1, 7, 8, 9, 11, 12],
    ],
    winner: "wolf",
    phase: "day",
    lastWords: [3, 4, 10],
    dreamDeaths: [
      {
        actorId: 5,
        targetId: 6,
        day: 3,
        reason: "linked",
      },
    ],
    sources: [
      {
        "3": ["wolf_kill"],
      },
      {
        "2": ["wolf_kill"],
      },
      {
        "5": ["wolf_kill"],
        "6": ["dream"],
      },
    ],
  },
  {
    name: "borrowed-dream-death-badge-words",
    sheriff: 1,
    nights: [
      {
        swallow: null,
        shelter: null,
        dream: 6,
        knife: 10,
        exile: 11,
      },
      {
        swallow: 5,
        shelter: 9,
        dream: 7,
        knife: 8,
        exile: 12,
        potion: ["poison", 1],
      },
    ],
    nightDeaths: [[10], [1, 8, 7]],
    alive: [
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 12],
      [2, 3, 4, 5, 6, 9],
    ],
    winner: "good",
    phase: "voting",
    lastWords: [10, 11, 12],
    dreamDeaths: [
      {
        actorId: 1,
        targetId: 7,
        day: 2,
        reason: "linked",
        abilityId: "copy:eclipse:night:2",
      },
    ],
    sources: [
      {
        "10": ["wolf_kill"],
      },
      {
        "1": ["poison"],
        "7": ["dream"],
        "8": ["wolf_kill"],
      },
    ],
  },
  {
    name: "independent-stock-card16-card17",
    sheriff: 5,
    nights: [
      {
        swallow: null,
        shelter: null,
        dream: 6,
        knife: 10,
        exile: 11,
      },
      {
        swallow: 4,
        shelter: 12,
        dream: 7,
        knife: 8,
        exile: 9,
        potion: ["poison", 12],
      },
      {
        swallow: 2,
        shelter: 5,
        dream: 1,
        knife: 5,
        exile: 12,
        potion: ["poison", 1],
      },
      {
        swallow: 3,
        shelter: 5,
        dream: 6,
        knife: 5,
        exile: 1,
        potion: ["heal", 5],
        seer: 2,
      },
    ],
    nightDeaths: [[10], [8], [], []],
    alive: [
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 12],
      [1, 2, 3, 4, 5, 6, 7, 12],
      [1, 2, 3, 4, 5, 6, 7],
      [2, 3, 4, 5, 6, 7],
    ],
    winner: "good",
    phase: "voting",
    lastWords: [10, 11, 9, 12, 1],
    dreamDeaths: [],
    sources: [
      {
        "10": ["wolf_kill"],
      },
      {
        "8": ["wolf_kill"],
      },
      {},
      {},
    ],
  },
  {
    name: "zero-one-then-empty",
    nights: [
      {
        swallow: null,
        shelter: null,
        dream: 6,
        knife: 10,
        potion: ["heal", 10],
        exile: 10,
      },
      {
        swallow: 4,
        shelter: 6,
        dream: 8,
        knife: 8,
        potion: ["poison", 6],
        exile: 11,
      },
      {
        swallow: 2,
        shelter: 5,
        dream: 1,
        knife: 5,
        potion: ["poison", 1],
        exile: 12,
      },
      {
        swallow: 4,
        shelter: 7,
        dream: 7,
        knife: 7,
        exile: 1,
      },
    ],
    nightDeaths: [[], [], [], []],
    alive: [
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12],
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 12],
      [1, 2, 3, 4, 5, 6, 7, 8, 9],
      [2, 3, 4, 5, 6, 7, 8, 9],
    ],
    lastWords: [10, 11, 12, 1],
    dreamDeaths: [],
    winner: "good",
    sheriff: null,
    phase: "voting",
    sources: [{}, {}, {}, {}],
  },
  {
    name: "one-zero-borrow-heal",
    nights: [
      {
        swallow: null,
        shelter: null,
        dream: 6,
        knife: 10,
        potion: ["poison", 6],
        exile: 11,
      },
      {
        swallow: 4,
        shelter: 6,
        dream: 8,
        knife: 12,
        potion: ["heal", 12],
        exile: 12,
      },
      {
        swallow: 6,
        shelter: 7,
        dream: 9,
        knife: 7,
        exile: 1,
      },
    ],
    nightDeaths: [[10], [], []],
    alive: [
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 12],
      [1, 2, 3, 4, 5, 6, 7, 8, 9],
      [2, 3, 4, 5, 6, 7, 8, 9],
    ],
    lastWords: [10, 11, 12, 1],
    dreamDeaths: [],
    winner: "good",
    sheriff: null,
    phase: "voting",
    sources: [
      {
        "10": ["wolf_kill"],
      },
      {},
      {},
    ],
  },
] as const;

export type RadiantFullPlanName = (typeof radiantFullPlans)[number]["name"];
