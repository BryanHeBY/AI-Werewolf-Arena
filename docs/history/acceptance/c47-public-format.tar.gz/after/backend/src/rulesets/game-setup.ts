/**
 * 负责开局馥郁双生权威安装及首夜设置的确定序列：盗贼／千面人、野孩子、孤独少女、鬼魂新娘。
 * 输入为原配置与现场读取 World、事件、网关的查询；首夜序列另接原 provider、日期和唯一当前性回调；
 * 开局输出为安装完成或原异常；首夜输出为全部准备通过，或在首个未完成／失效步骤之后返回 false。
 * 组合装配原窗口及其惰性请求构造依赖，串行交还原执行 Promise；
 * 选择、库存、接受权限和 finally 关闭仍由各机制拥有，不把构造器或阶段标签当许可。
 * 开局安装只在原配置为真时按原World／事件／两角色查询顺序执行，首异常阻止后续构造，不发布事实或退款。
 * 不缓存 World 或提前读取构造参数；首夜序列成功末尾没有额外当前性查询，也不推进阶段或生成快照。
 */
import type { GameEvent, ReadonlyBoardConfig } from "@ai-werewolf-arena/game-contract";
import type { ActionProvider } from "../domain/actions";
import type { World } from "../domain/world";
import type { ToolGateway } from "../engine/actions/tool-gateway";
import { GameActionRequestFactory } from "../engine/actions/action-request-factory";
import { Role } from "../domain/identity";
import { installFragrantPairAuthority } from "../features/fragrant-pair-seer/setup-ports";
import {
  InitialIdentitySetupWindow,
  initialIdentitySetupReady,
  initialIdentityKind,
} from "../features/initial-identity/ports";
import { wildChildReady } from "../features/wild-child/ports";
import { WildChildSetupWindow } from "../features/wild-child/setup-ports";
import { LonelyGirlSetupWindow, lonelyGirlReady } from "../features/lonely-girl/ports";
import { GhostBrideSetupWindow, ghostBrideReady } from "../features/ghost-bride/ports";

/** 查询只读取原调用点；事件数组与板子引用交给窗口，不产生新授权或状态镜像。 */
export interface GameSetupRuntime {
  world(): World;
  toolGateway(): ToolGateway;
  events(): GameEvent[];
  config(): ReadonlyBoardConfig;
}

export function* prepareGameSetup(
  runtime: GameSetupRuntime,
  actionProvider: ActionProvider,
  nightDay: number,
  nightIsCurrent: () => boolean,
): Generator<Promise<boolean>, boolean, boolean> {
  // 没有待设置窗口时同步结束；只在原 execute 的 Promise 处暂停，不增加 helper 完成等待。
  // 每个 new 先查找原类，再按原顺序读取参数；execute 仍使用该实例作为 receiver。
  if (!initialIdentitySetupReady(runtime.world())) {
    const ready = yield new InitialIdentitySetupWindow(
      runtime.world(),
      runtime.toolGateway(),
      runtime.events(),
      initialIdentityKind(runtime.world())!,
      {
        // 装配只交付 getter；共享窗口到原 new 点才读取真实类，不在开局检查时捕获。
        get requestFactory() {
          return GameActionRequestFactory;
        },
      },
    ).execute(runtime.config(), actionProvider, nightDay, nightIsCurrent);
    // false 先短路，不再查询当前性或推进其它设置；窗口的失败关闭仍由自己的 finally 完成。
    if (!ready || !nightIsCurrent()) return false;
  }
  if (!wildChildReady(runtime.world())) {
    const ready = yield new WildChildSetupWindow(
      runtime.world(),
      runtime.toolGateway(),
      runtime.events(),
      {
        get requestFactory() {
          return GameActionRequestFactory;
        },
      },
    ).execute(runtime.config(), actionProvider, nightDay, nightIsCurrent);
    if (!ready || !nightIsCurrent()) return false;
  }
  if (!lonelyGirlReady(runtime.world())) {
    const ready = yield new LonelyGirlSetupWindow(
      runtime.world(),
      runtime.toolGateway(),
      runtime.events(),
      {
        get requestFactory() {
          return GameActionRequestFactory;
        },
      },
    ).execute(runtime.config(), actionProvider, nightDay, nightIsCurrent);
    if (!ready || !nightIsCurrent()) return false;
  }
  if (!ghostBrideReady(runtime.world())) {
    const ready = yield new GhostBrideSetupWindow(
      runtime.world(),
      runtime.toolGateway(),
      runtime.events(),
      {
        get requestFactory() {
          return GameActionRequestFactory;
        },
      },
    ).execute(runtime.config(), actionProvider, nightDay, nightIsCurrent);
    if (!ready || !nightIsCurrent()) return false;
  }
  return true;
}

/** 开局安装在原config门控后才读World／事件与两角色；本贡献不建立第二权威或新的许可。 */
export function installFragrantGameSetup(
  config: Pick<ReadonlyBoardConfig, "fragrantPairSeer">,
  runtime: Pick<GameSetupRuntime, "world" | "events">,
): void {
  if (config.fragrantPairSeer)
    installFragrantPairAuthority(
      runtime.world(),
      runtime.events(),
      runtime.world().getEntityIdsByRole(Role.FragrantPhantom)[0]!,
      runtime.world().getEntityIdsByRole(Role.AwakenedSeer)[0]!,
    );
}
