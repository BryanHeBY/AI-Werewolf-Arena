/**
 * 负责录制输入、时间线与调试快照的数据契约；输入为原事件／行动和会话元数据，输出为记录器消费的结构。
 * manifest 的档案形状由共享契约唯一维护，本叶保留原领域 enum／RNG 收窄，不创造第二份结构。
 * 私有 seed 只属于 manifest／Tape，协议身份或玩家内容不授予资源写权；此处不执行 IO、规则或阶段。
 */
import type { ErrorDiagnostic } from "@ai-werewolf-arena/replay-contract";
import type { Locale } from "@ai-werewolf-arena/game-contract";
import { Camp, PlayerVisibleEvent, ToolCall, type GameResult } from "../domain/model";
import type { RandomMetadata } from "../domain/random";

/** 玩家回合行动模式。 */
export type ReplayActionMode = "tool_call" | "text_action" | "none";

/** manifest 结构由纯归档契约单独维护；领域枚举、判胜与 RNG 类型在本入口保持原收窄。 */
export type ReplayManifestPlayer =
  import("@ai-werewolf-arena/replay-contract").ReplayManifestPlayerData;
export type ReplayManifest = Omit<
  import("@ai-werewolf-arena/replay-contract").ReplayManifestData,
  "winner" | "game_result" | "random"
> & {
  winner: Camp | null;
  game_result?: GameResult;
  random?: RandomMetadata;
};

/** 公共时间线事件记录。 */
export interface ReplayPublicEvent {
  seq: number;
  timestamp: string;
  phase: string;
  day: number;
  stage?: string;
  type: string;
  payload: Record<string, unknown>;
}

/** 阶段内子阶段窗口。 */
export interface ReplayPhaseStageWindow {
  stage: string;
  start_seq: number;
  end_seq: number;
}

/** 阶段窗口。 */
export interface ReplayPhaseWindow {
  phase_id: string;
  day: number;
  phase: string;
  start_seq: number;
  end_seq: number;
  stages: ReplayPhaseStageWindow[];
}

/** phase_windows.json 结构。 */
export interface ReplayPhaseWindowsFile {
  session_id: string;
  windows: ReplayPhaseWindow[];
}

/** timeline_index.json 结构。 */
export interface ReplayTimelineIndexFile {
  session_id: string;
  public: {
    min_seq: number;
    max_seq: number;
    count: number;
  };
  players: Record<
    string,
    {
      count: number;
    }
  >;
  phases: {
    count: number;
  };
}

/** 逻辑操作审计记录。 */
export interface ReplayLogicOp {
  seq: number;
  timestamp: string;
  scope: "phase_pipeline" | "gateway" | "registry" | "resolution" | "llm_action_provider";
  op: string;
  actor_id?: number;
  event_count?: number;
  phase?: string;
  input?: Record<string, unknown>;
  output?: Record<string, unknown>;
  status: "ok" | "rejected" | "fallback" | "error";
  reason?: string;
}

/** 工具调用追踪记录。 */
export interface ReplayToolCallTrace {
  id?: string;
  name: string;
  args: Record<string, unknown>;
  accepted?: boolean;
  result?: Record<string, unknown> | string;
}

/** LLM 请求消息结构。 */
export interface ReplayLlmRequestMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  tool_call_id?: string;
}

/** LLM 请求载荷结构。 */
export interface ReplayLlmRequestPayload {
  messages: ReplayLlmRequestMessage[];
}

export type {
  ReplayPlayerDeltaMessage,
  ReplayPlayerEventEntry,
  ReplayPlayerTurnEntry,
  ReplayPlayerTimelineEntry,
  ReplayPlayerView,
} from "@ai-werewolf-arena/replay-contract";
import type {
  ReplayPlayerDeltaMessage,
  ReplayPlayerView,
} from "@ai-werewolf-arena/replay-contract";

/** 对局会话元信息。 */
export interface ReplaySessionMeta {
  locale?: Locale;
  random?: RandomMetadata;
  sessionId: string;
  board: string;
  startedAtIso: string;
}

/** 结束写盘元信息。 */
export interface ReplayFinalizeMeta {
  endedAtIso: string;
  winner: Camp | null;
  finishReason: string;
  gameResult?: GameResult;
  players: ReplayManifestPlayer[];
}

/** 记录公共事件输入结构。 */
export interface ReplayRecordPublicEventInput {
  type: string;
  timestampMs: number;
  phase: string;
  day: number;
  stage?: string;
  payload: Record<string, unknown>;
}

/** 记录逻辑操作输入结构。 */
export interface ReplayRecordLogicOpInput {
  eventCount?: number;
  scope: ReplayLogicOp["scope"];
  op: string;
  actorId?: number;
  phase?: string;
  input?: Record<string, unknown>;
  output?: Record<string, unknown>;
  status: ReplayLogicOp["status"];
  reason?: string;
}

/** 记录玩家回合输入结构。 */
export interface ReplayRecordPlayerRoundInput {
  playerId: number;
  role: string;
  camp: string;
  day: number;
  phase: string;
  stage: string;
  requestId: string;
  timestampMs?: number;
  llmRequestMessages?: ReplayLlmRequestMessage[];
  deltaMessages?: ReplayPlayerDeltaMessage[];
  promptSystem?: string;
  initialPromptSystem?: string;
  initialBoardInfo?: string;
  promptUserDelta?: string[];
  retryTrace?: Array<{
    attempt: number;
    status: "request_error" | "no_valid_action";
    reason?: string;
    diagnostic?: ErrorDiagnostic;
    retryPrompt?: string;
    assistantText?: string;
  }>;
  thinkingText?: string;
  actionMode: ReplayActionMode;
  toolCalls: ReplayToolCallTrace[];
  finalAction?: ToolCall | null;
  fallback?: {
    used: boolean;
    reason?: string;
    action?: {
      name: string;
      args: Record<string, unknown>;
    };
  };
}

/** 记录玩家可见结构化事件输入。 */
export interface ReplayRecordPlayerEventInput {
  playerId: number;
  role: string;
  camp: string;
  day: number;
  phase: string;
  stage: string;
  requestId: string;
  timestampMs?: number;
  /** 领域事件流中的全局序号，仅写入复盘，不得发送给玩家 Agent。 */
  sourceEventSeq?: number;
  event: PlayerVisibleEvent;
}

/** 调试上报记录。 */
export interface ReplayDebugReport {
  report_id: string;
  timestamp: string;
  day: number;
  phase: string;
  stage: string;
  actor_id: number;
  actor_role: string;
  actor_camp: string;
  category: "flow" | "rule" | "state" | "logging" | "other";
  severity: "low" | "medium" | "high" | "critical";
  message: string;
  evidence_event_seq: number[];
  status: "open";
}

/** 调试上报写入输入。 */
export interface ReplayRecordDebugReportInput {
  timestampMs?: number;
  day: number;
  phase: string;
  stage: string;
  actorId: number;
  actorRole: string;
  actorCamp: string;
  category: "flow" | "rule" | "state" | "logging" | "other";
  severity: "low" | "medium" | "high" | "critical";
  message: string;
  evidenceEventSeq?: number[];
}

/** 已完成录制的快照，供可选调试摘要构造器消费。 */
export interface DebugSummaryInput {
  manifest: ReplayManifest;
  reports: ReplayDebugReport[];
  publicEvents: ReplayPublicEvent[];
  logicOps: ReplayLogicOp[];
  playerViews: ReplayPlayerView[];
  sessionDir: string;
}
