/**
 * 负责鬼魂新娘婚礼回合、原参与者授权与有序提交，拥有婚约、回合和绑定别名的写权。
 * 输入保留原 World 及封存请求；输出为原校验后已接受的选择、消息与结算记录。
 * 原参与者阵营只取真实 Camp，仍核同组件／own-data与Victory；婚约历史阵营不改为晚查询。
 * 资源及参与者私态数据写入归 state；身体／身份复验、Victory 与回执仍在这里按原顺序处理。
 * 不变量：提交必须匹配原参与者和绑定回合，别名不能替代本地校验。未付原信封、领域或最早期限
 * 被正确观察为失效后永久撤回该 turn；别名自己的失配只退该别名，不读取或毒化原请求。
 * 第一见证同意保留的原 proof 仍在第二次同意前复验，失效不能靠恢复字段完成婚礼。
 * 已付聊天／刀口与关系的纯当前性保持原政策；取消、关闭或失败保原结算及写前缀，不修复库存。
 */
import type { ReadonlyBoardConfig } from "@ai-werewolf-arena/game-contract";
import type { WeddingActorView } from "@ai-werewolf-arena/game-contract/facts/ghost-bride";
import { registerRequestAliasPropagation } from "../../domain/request-delivery";
import { types } from "node:util";
import {
  GHOST_BRIDE_POLICY,
  GHOST_BRIDE_ROLE,
  type GhostBrideState,
  type WeddingPair,
  type WeddingGroup,
  type WeddingSetup,
  type WeddingKnifeCapture,
  type WeddingTool,
  readWeddingTool,
} from "@ai-werewolf-arena/game-contract/facts/ghost-bride";
import {
  bindRequestDeliveryGuard,
  settleRequestDelivery,
  DeathCause,
  type DeathSources,
  COMPONENT,
  Camp,
  Role,
  Phase,
  createVictoryComponent,
  type World,
  type RoleComponent,
  type CampComponent,
  type VictoryComponent,
} from "../../domain";
import {
  aliveLifeVersion,
  aliveLifeDescriptor,
  type AliveComponent,
} from "../../domain/components/alive";
import { assertGhostBridePreset } from "./preset";
import {
  readGhostBrideState,
  ghostBrideStateWritable,
  captureGhostBrideParticipantData,
  ghostBridePrivateFields,
  ghostBridePrivateRefsCurrent,
  acceptGhostBrideParticipantAudit,
  closeGhostBrideResource,
  consumeGhostBrideChoice,
  updateGhostBrideExpectedData,
  refreshGhostBrideParticipantAudit,
  projectGhostBrideFailedPrivateData,
  type GhostBrideParticipantData,
} from "./state";

/** 只读 own data；拒绝或审计期间不执行被替换的 getter。 */
function data(value: unknown, key: string): unknown {
  if (!value || typeof value !== "object" || types.isProxy(value)) return undefined;
  const d = Object.getOwnPropertyDescriptor(value, key);
  return d && Object.hasOwn(d, "value") ? d.value : undefined;
}
function snapshot(value: unknown, depth = 0, arrayLimit = 128): unknown {
  if (
    value === null ||
    ["string", "boolean"].includes(typeof value) ||
    (typeof value === "number" && Number.isFinite(value))
  )
    return value;
  if (
    !value ||
    typeof value !== "object" ||
    types.isProxy(value) ||
    depth > 12 ||
    Object.getOwnPropertySymbols(value).length
  )
    throw new Error("ghost_bride_authority_not_data");
  const array = Array.isArray(value),
    proto = Object.getPrototypeOf(value);
  if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
    throw new Error("ghost_bride_authority_not_plain");
  const fields = Object.getOwnPropertyDescriptors(value),
    result: Record<string, unknown> = {};
  for (const [key, d] of Object.entries(fields)) {
    if (array && key === "length") continue;
    if (!d.enumerable || !Object.hasOwn(d, "value"))
      throw new Error("ghost_bride_authority_accessor");
    Object.defineProperty(result, key, {
      value: snapshot(d.value, depth + 1, arrayLimit),
      enumerable: true,
    });
  }
  if (!array) return result;
  const length = fields.length?.value;
  if (
    !Number.isSafeInteger(length) ||
    length > arrayLimit ||
    Object.keys(result).length !== length ||
    !Array.from({ length }, (_, i) => Object.hasOwn(result, i)).every(Boolean)
  )
    throw new Error("ghost_bride_authority_array");
  return Array.from({ length }, (_, i) => result[i]);
}
function json(value: unknown): string | null {
  try {
    return JSON.stringify(snapshot(value));
  } catch {
    return null;
  }
}
interface Participant extends GhostBrideParticipantData {
  id: number;
  role: RoleComponent;
  kind: Role;
  camp: Camp;
  campComponent: CampComponent;
  life: AliveComponent;
  version: number;
  aliveDescriptor: PropertyDescriptor;
  victory: VictoryComponent;
  affiliations: VictoryComponent["affiliations"];
  victoryJson: string;
}
type TurnKind = "bridegroom" | "chat" | "witness" | "knife";
interface Binding {
  world: World;
  config: ReadonlyBoardConfig;
  configJson: string;
  actorId: number;
  participants: Map<number, Participant>;
  state: GhostBrideState;
  status: WeddingSetup["status"];
  pair: Readonly<WeddingPair> | null;
  group: Readonly<WeddingGroup> | null;
  votes: WeddingSetup["witnessVotes"];
  consent: Turn | null;
  chats: number;
  setupCurrent: (() => boolean) | null;
  turn: Turn | null;
  pendingChat: Turn | null;
  assignments: ReadonlyMap<number, Camp> | null;
  nights: Map<number, Night>;
  activeNight: Night | null;
}
interface Turn {
  binding: Binding;
  kind: TurnKind;
  actorId: number;
  day: number;
  tool: WeddingTool["name"];
  scope: object;
  isCurrent: () => boolean;
  privateJson: Map<number, string>;
  targetVersions: Map<number, number>;
  request: WeddingRequest | null;
  requestJson: string | null;
  deadline: number | null;
  chat: Readonly<{ actorId: number; recipientId: number; day: number; text: string }> | null;
  delivered: boolean;
}
interface Night {
  binding: Binding;
  day: number;
  capture: Readonly<WeddingKnifeCapture>;
  isCurrent: () => boolean;
  actorVersions: Map<number, number>;
  targetVersions: Map<number, number>;
  votes: Array<{ actorId: number; targetId: number | null; abstain: boolean }>;
  chats: number;
  requiredChats: number;
  closed: boolean;
  knifeCommitted: boolean;
  targetId: number | null;
}
export interface WeddingRequest {
  phase: Phase;
  actorId: number;
  allowedTools: readonly string[];
  context: { day: number; stage: string };
  deadlineAtMs?: number;
}
const bindings = new WeakMap<World, Binding>(),
  turns = new WeakMap<object, Turn>(),
  requests = new WeakMap<
    object,
    {
      turn: Turn;
      context: object;
      json: string;
      fields: PropertyDescriptorMap;
      deadline: number | null;
    }
  >();
/** 只记录运行请求撤权，不复制库存／JSON或改绑定字段；原 turn 与合法别名共享前者，别名独退用后者。 */
const revokedRequestTurns = new WeakSet<Turn>(),
  retiredRequestAliases = new WeakSet<object>();
function capture(world: World, id: number): Participant {
  const role = world.getComponent(id, COMPONENT.Role),
    campComponent = world.getComponent(id, COMPONENT.Camp),
    life = world.getComponent(id, COMPONENT.Alive),
    victory = world.getComponent(id, COMPONENT.Victory);
  const kind = data(role, "role"),
    camp = data(campComponent, "camp"),
    state = data(role, "privateState"),
    affiliations = data(victory, "affiliations"),
    version = life && aliveLifeVersion(life),
    aliveDescriptor = life && aliveLifeDescriptor(life),
    actualDescriptor = life && Object.getOwnPropertyDescriptor(life, "alive"),
    privateJson = json(state),
    victoryJson = json(affiliations);
  if (
    !role ||
    !campComponent ||
    !life ||
    !victory ||
    !aliveDescriptor ||
    !actualDescriptor ||
    actualDescriptor.get !== aliveDescriptor.get ||
    actualDescriptor.set !== aliveDescriptor.set ||
    version === undefined ||
    !life.alive ||
    typeof kind !== "string" ||
    !Object.values(Camp).includes(camp as Camp) ||
    data(campComponent, "camp") !== camp ||
    !state ||
    typeof state !== "object" ||
    !Array.isArray(affiliations) ||
    !privateJson ||
    !victoryJson ||
    victoryJson !== json([{ kind: "faction", faction: camp }])
  )
    throw new Error("ghost_bride_initial_roster_invalid");
  return {
    id,
    role,
    kind: kind as Role,
    camp: camp as Camp,
    campComponent,
    life,
    victory,
    ...captureGhostBrideParticipantData(state, privateJson, snapshot),
    affiliations,
    victoryJson,
    version,
    aliveDescriptor,
  };
}
function sameBody(b: Binding, p: Participant, mustLive = false): boolean {
  const d = Object.getOwnPropertyDescriptor(p.life, "alive");
  if (
    b.world.getComponent(p.id, COMPONENT.Alive) !== p.life ||
    !d ||
    d.get !== p.aliveDescriptor.get ||
    d.set !== p.aliveDescriptor.set ||
    (!d.get && d.value !== p.aliveDescriptor.value)
  )
    return false;
  // 验证 descriptor 后，只执行最初捕获的 accessor。
  const alive = p.aliveDescriptor.get
    ? p.aliveDescriptor.get.call(p.life) === true
    : d.value === true;
  return (!mustLive || alive) && aliveLifeVersion(p.life) === p.version + (alive ? 0 : 1);
}
function sameIdentity(b: Binding, p: Participant): boolean {
  const fields = ghostBridePrivateFields(p);
  if (fields === null) return false;
  return (
    b.world.getComponent(p.id, COMPONENT.Role) === p.role &&
    data(p.role, "role") === p.kind &&
    data(p.campComponent, "camp") === p.camp &&
    data(p.role, "privateState") === p.state &&
    ghostBridePrivateRefsCurrent(p, fields) &&
    b.world.getComponent(p.id, COMPONENT.Camp) === p.campComponent &&
    data(p.campComponent, "camp") === p.camp &&
    b.world.getComponent(p.id, COMPONENT.Victory) === p.victory &&
    data(p.victory, "affiliations") === p.affiliations &&
    json(p.affiliations) === p.victoryJson
  );
}
function validBinding(b: Binding, setup = false): boolean {
  const s = readGhostBrideState(b.state),
    expectedGroom = b.pair?.groomId ?? null,
    expectedRemaining = b.status === "pending" || b.status === "active" ? 1 : 0;
  return (
    bindings.get(b.world) === b &&
    b.world.entityIds().length === b.participants.size &&
    json(b.config) === b.configJson &&
    !!s &&
    s.groomId === expectedGroom &&
    s.remaining === expectedRemaining &&
    data(b.participants.get(b.actorId)?.state, "ghostBride") === b.state &&
    [...b.participants.values()].every((p) => {
      const encoded = json(p.state);
      if (!sameBody(b, p, setup) || !sameIdentity(b, p)) return false;
      return acceptGhostBrideParticipantAudit(p, encoded, setup);
    })
  );
}
function third(b: Binding, id: number): void {
  const p = b.participants.get(id)!,
    victory = createVictoryComponent([{ kind: "faction", faction: Camp.ThirdParty }]);
  b.world.addComponent(id, COMPONENT.Victory, victory);
  p.victory = victory;
  p.affiliations = victory.affiliations;
  p.victoryJson = json(victory.affiliations)!;
}
/** 安装与 catalog 激活、runtime setup 各自独立。 */
export function installGhostBride(world: World, config: ReadonlyBoardConfig): void {
  if (bindings.has(world)) throw new Error("ghost_bride_already_installed");
  assertGhostBridePreset(config);
  const participants = new Map(world.entityIds().map((id) => [id, capture(world, id)])),
    brides = [...participants.values()].filter((p) => String(p.kind) === GHOST_BRIDE_ROLE),
    actor = brides[0],
    state = data(actor?.state, "ghostBride"),
    parsed = readGhostBrideState(state),
    configJson = json(config);
  const counts: Record<string, number> = {};
  for (const p of participants.values()) counts[p.kind] = (counts[p.kind] ?? 0) + 1;
  const deck = new Map(config.roleSetups.map((r) => [String(r.role), r.count]));
  if (
    participants.size !== 12 ||
    brides.length !== 1 ||
    !actor ||
    actor.camp !== Camp.ThirdParty ||
    !parsed ||
    parsed.remaining !== 1 ||
    parsed.groomId !== null ||
    !configJson ||
    Object.entries(counts).some(([r, n]) => deck.get(r) !== n) ||
    deck.size !== Object.keys(counts).length ||
    [...participants.values()].some(
      (p) => p.id !== actor.id && p.camp !== (p.kind === Role.Wolf ? Camp.Wolf : Camp.Good),
    ) ||
    !ghostBrideStateWritable(state as object, "remaining") ||
    !ghostBrideStateWritable(state as object, "groomId")
  )
    throw new Error("ghost_bride_initial_state_invalid");
  bindings.set(world, {
    world,
    config,
    configJson,
    actorId: actor.id,
    participants,
    state: state as GhostBrideState,
    status: "pending",
    pair: null,
    group: null,
    votes: [],
    consent: null,
    chats: 0,
    setupCurrent: null,
    turn: null,
    pendingChat: null,
    assignments: null,
    nights: new Map(),
    activeNight: null,
  });
}
export function beginWeddingSetup(
  world: World,
  config: ReadonlyBoardConfig,
  isCurrent: () => boolean,
): void {
  const b = bindings.get(world);
  if (!b || b.config !== config || b.status !== "pending" || !validBinding(b, true) || !isCurrent())
    throw new Error("ghost_bride_setup_unavailable");
  b.status = "active";
  b.setupCurrent = isCurrent;
}
export function weddingSetup(world: World): WeddingSetup | null {
  const b = bindings.get(world);
  return b
    ? {
        policy: GHOST_BRIDE_POLICY,
        status: b.status,
        actorId: b.actorId,
        groomId: b.pair?.groomId ?? null,
        witnessId: b.group?.witnessId ?? null,
        witnessVotes: b.votes.map((v) => ({ ...v })),
      }
    : null;
}
export function weddingPair(world: World): Readonly<WeddingPair> | null {
  return bindings.get(world)?.pair ?? null;
}
export function weddingGroup(world: World): Readonly<WeddingGroup> | null {
  return bindings.get(world)?.group ?? null;
}
export function ghostBrideReady(world: World): boolean {
  const b = bindings.get(world);
  return b
    ? b.status === "complete" && validBinding(b)
    : !world
        .entityIds()
        .some((id) => data(world.getComponent(id, COMPONENT.Role), "role") === GHOST_BRIDE_ROLE);
}
export function hasActiveGhostBride(world: World): boolean {
  const b = bindings.get(world);
  return !!b && (b.status === "active" || b.status === "paired" || !!b.activeNight);
}
export function hasGhostBrideNightCommit(world: World, day: number): boolean {
  return bindings.get(world)?.nights.has(day) ?? false;
}
function expectedTurn(b: Binding, kind: TurnKind, actorId: number, day: number): boolean {
  if (kind === "bridegroom")
    return b.status === "active" && !b.pair && actorId === b.actorId && day === 1;
  if (!b.pair) return false;
  const members = [b.actorId, b.pair.groomId];
  if (b.status === "paired" && day === 1) {
    if (kind === "chat") return b.chats < 2 && actorId === members[b.chats];
    if (kind === "witness")
      return b.chats === 2 && b.votes.length < 2 && actorId === members[b.votes.length];
  }
  const n = b.activeNight;
  if (b.status !== "complete" || !n || n.day !== day || n.closed) return false;
  if (kind === "chat")
    return (
      day > 1 &&
      n.chats < 2 &&
      actorId === members[n.chats] &&
      members.every((id) => sameBody(b, b.participants.get(id)!, true))
    );
  return (
    kind === "knife" &&
    !n.knifeCommitted &&
    n.chats === n.requiredChats &&
    n.votes.length < n.capture.actorIds.length &&
    actorId === n.capture.actorIds[n.votes.length] &&
    validKnifeOwner(n)
  );
}
export function openWeddingTurn(
  world: World,
  kind: TurnKind,
  actorId: number,
  day: number,
  isCurrent: () => boolean,
): object {
  const b = bindings.get(world),
    setup = b?.status !== "complete";
  if (
    !b ||
    b.turn ||
    b.pendingChat ||
    !isCurrent() ||
    (setup && !b.setupCurrent?.()) ||
    !expectedTurn(b, kind, actorId, day) ||
    !validBinding(b, setup) ||
    !sameBody(b, b.participants.get(actorId)!, true)
  )
    throw new Error("ghost_bride_turn_unavailable");
  const tool: WeddingTool["name"] =
    kind === "bridegroom"
      ? "choose_bridegroom"
      : kind === "witness"
        ? "choose_wedding_witness"
        : kind === "chat"
          ? "speak_to_partner"
          : b.activeNight!.capture.owner === "ordinary_pack"
            ? "kill_vote"
            : "wedding_kill_vote";
  const scope = Object.freeze({}),
    turn: Turn = {
      binding: b,
      kind,
      actorId,
      day,
      tool,
      scope,
      isCurrent,
      privateJson: new Map([...b.participants].map(([id, p]) => [id, json(p.state)!])),
      request: null,
      requestJson: null,
      deadline: null,
      chat: null,
      delivered: false,
      targetVersions: new Map(
        [...b.participants].map(([id, p]) => [id, aliveLifeVersion(p.life)!]),
      ),
    };
  b.turn = turn;
  turns.set(scope, turn);
  return scope;
}
function validWindow(t: Turn): boolean {
  const b = t.binding,
    setup = b.status !== "complete";
  return (
    b.turn === t &&
    t.isCurrent() &&
    (!setup || b.setupCurrent?.() === true) &&
    expectedTurn(b, t.kind, t.actorId, t.day) &&
    validBinding(b, setup) &&
    sameBody(b, b.participants.get(t.actorId)!, true) &&
    [...b.participants].every(([id, p]) => json(p.state) === t.privateJson.get(id))
  );
}
function validDeadline(t: Turn): boolean {
  return t.deadline === null || t.deadline > Date.now();
}
function validRequestProof(t: Turn): boolean {
  const r = t.request,
    a = r && requests.get(r);
  return (
    !!r &&
    !!a &&
    a.turn === t &&
    data(r, "context") === a.context &&
    requestData(r) === t.requestJson &&
    validDeadline(t) &&
    (data(r, "deadlineAtMs") ?? null) === a.deadline
  );
}
/**
 * 只服务未付请求和仍等待第二同意的 retained proof；已付 takeWeddingChat 继续用上方纯 reader。
 * 原 proof 的重复读取、deadline 时钟及错误位置保留；观察失败先落撤权，再返回／抛同一错误。
 */
function currentUnpaidRequestProof(t: Turn): boolean {
  if (revokedRequestTurns.has(t)) return false;
  try {
    const current = validRequestProof(t);
    if (!current && t.request) revokedRequestTurns.add(t);
    return current;
  } catch (error) {
    if (t.request) revokedRequestTurns.add(t);
    throw error;
  }
}
/** 只有尚在等待第二票的共同领域失效才撤旧第一同意；第二请求自己的壳／期限坏不连带撤它。 */
function revokeRetainedConsentForSharedFailure(t: Turn): void {
  const b = t.binding,
    consent = b.consent;
  if (
    t.kind === "witness" &&
    b.status === "paired" &&
    b.votes.length === 1 &&
    consent &&
    consent !== t
  )
    revokedRequestTurns.add(consent);
}
function validTurn(t: Turn): boolean {
  // 正常已关闭的第一同意不因旧 scope 被查询就失去 retained proof；它不能再作为活跃请求使用。
  if (revokedRequestTurns.has(t) || t.binding.turn !== t) return false;
  let observingSharedWindow = true;
  try {
    const windowCurrent = validWindow(t);
    observingSharedWindow = false;
    if (!windowCurrent) {
      revokeRetainedConsentForSharedFailure(t);
      revokedRequestTurns.add(t);
      return false;
    }
    const current =
      currentUnpaidRequestProof(t) &&
      (t.kind !== "witness" || t.binding.votes.length !== 1 || validConsent(t.binding, t));
    // 上述领域回调可同步重入并撤权；最后只查私有位，不重读 World 或已付数据。
    if (!current || revokedRequestTurns.has(t)) {
      revokedRequestTurns.add(t);
      return false;
    }
    return true;
  } catch (error) {
    if (observingSharedWindow) revokeRetainedConsentForSharedFailure(t);
    revokedRequestTurns.add(t);
    throw error;
  }
}
function validConsent(b: Binding, second: Turn): boolean {
  const t = b.consent;
  if (!t) return false;
  let observingShared = true;
  try {
    // 保原 shared 前段的重复 current／World 读取顺序；这次观察失败不能靠另开第二请求复用旧第一票。
    if (!(
      t.binding === b &&
      t.kind === "witness" &&
      t.actorId === b.actorId &&
      t.day === 1 &&
      b.setupCurrent?.() === true &&
      t.isCurrent() &&
      second.isCurrent() &&
      b.turn === second &&
      expectedTurn(b, second.kind, second.actorId, second.day) &&
      validBinding(b, true)
    )) {
      revokedRequestTurns.add(t);
      return false;
    }
    // 两份各自 proof 按原次序查询；second 自己的正文／期限错误只撤 second，不能毒化有效 first。
    observingShared = false;
    if (!currentUnpaidRequestProof(t) || !currentUnpaidRequestProof(second)) return false;
    observingShared = true;
    const current =
      [...b.participants].every(([id, p]) => json(p.state) === second.privateJson.get(id)) &&
      [...b.participants].every(([id, p]) => json(p.state) === t.privateJson.get(id)) &&
      targetCurrent(t, b.votes[0]!.targetId);
    if (!current) revokedRequestTurns.add(t);
    return current && !revokedRequestTurns.has(t);
  } catch (error) {
    if (observingShared) revokedRequestTurns.add(t);
    throw error;
  }
}
export function authorizedWeddingTurn(
  world: World,
  actorId: number,
  phase: Phase,
  day: number,
  scope: object | undefined,
): boolean {
  const t = scope && turns.get(scope);
  return (
    !!t &&
    t.binding.world === world &&
    t.actorId === actorId &&
    phase === Phase.Night &&
    day === t.day &&
    validTurn(t)
  );
}
export function closeWeddingTurn(scope: object): void {
  const t = turns.get(scope);
  if (t && t.binding.turn === t) t.binding.turn = null;
  // 不把已提交的第一同意标为失败；其 proof 可被下一位见证人读取，活动请求仍由 b.turn 身份关闭。
  if (!t || t.binding.pendingChat !== t) settleRequestDelivery(scope, false);
}
export function closeWeddingSetup(world: World, status: "failed" | "cancelled"): void {
  const b = bindings.get(world);
  if (!b || b.status === "complete" || b.status === "failed" || b.status === "cancelled") return;
  if (b.turn) settleRequestDelivery(b.turn.scope, false);
  if (b.pendingChat) settleRequestDelivery(b.pendingChat.scope, false);
  b.status = status;
  b.turn = null;
  b.pendingChat = null;
  b.setupCurrent = null;
  closeGhostBrideResource(b);
  // 仅保留实际提交的 pair，不消耗或修复替换状态。
}
const stages: Record<TurnKind, string> = {
  bridegroom: "ghost_bride_groom",
  chat: "ghost_bride_chat",
  witness: "ghost_bride_witness",
  knife: "ghost_bride_knife",
};
function requestData(request: WeddingRequest): string | null {
  try {
    const { deadlineAtMs: _deadline, ...rest } = snapshot(request, 0, 16384) as Record<
      string,
      unknown
    >;
    return JSON.stringify(rest);
  } catch {
    return null;
  }
}
export function bindGhostBrideRequest(world: World, request: WeddingRequest): void {
  const t = bindings.get(world)?.turn;
  if (!t) return;
  let p: WeddingRequest & { context: Record<string, unknown> };
  try {
    p = snapshot(request, 0, 16384) as WeddingRequest & { context: Record<string, unknown> };
  } catch {
    return;
  }
  const constraints = data(p.context, "turn_constraints") as Record<string, unknown> | undefined,
    encoded = requestData(request);
  if (
    t &&
    !t.request &&
    validWindow(t) &&
    p.actorId === t.actorId &&
    p.phase === Phase.Night &&
    p.context.day === t.day &&
    p.context.stage ===
      (t.kind === "knife" && t.binding.activeNight?.capture.owner === "ordinary_pack"
        ? "wolf_vote"
        : stages[t.kind]) &&
    p.allowedTools.length === 1 &&
    p.allowedTools[0] === t.tool &&
    data(p.context, "allow_fallback") === false &&
    data(p.context, "action_failure_policy") === "error" &&
    constraints?.min_valid_actions === 1 &&
    constraints.max_valid_actions === 1 &&
    json(constraints.required_any_tools) === json([t.tool]) &&
    encoded &&
    requestData(request) === encoded &&
    data(request, "deadlineAtMs") === p.deadlineAtMs &&
    (p.deadlineAtMs === undefined ||
      (Number.isFinite(p.deadlineAtMs) && p.deadlineAtMs > Date.now()))
  ) {
    t.request = request;
    t.requestJson = encoded;
    t.deadline = p.deadlineAtMs ?? null;
    requests.set(request, {
      turn: t,
      context: data(request, "context") as object,
      json: encoded,
      fields: Object.getOwnPropertyDescriptors(request),
      deadline: p.deadlineAtMs ?? null,
    });
    bindRequestDeliveryGuard(
      request,
      () => ghostBrideRequestScope(world, request) !== undefined,
      t.scope,
    );
    registerRequestAliasPropagation(request, 50, inheritGhostBrideDeadlineRequest);
  }
}
export function ghostBrideRequestScope(world: World, request: WeddingRequest): object | undefined {
  const a = requests.get(request);
  // 外来对象／World不观察本地权限；已退别名也不再读取原请求或领域 current。
  if (!a || a.turn.binding.world !== world || retiredRequestAliases.has(request)) return undefined;
  const original = request === a.turn.request;
  try {
    // 保原 context→完整正文→自身 deadline 的短路；别名先自检，不能因自己换壳伤及 original。
    if (
      data(request, "context") !== a.context ||
      requestData(request) !== a.json ||
      (data(request, "deadlineAtMs") ?? null) !== a.deadline
    ) {
      if (original) revokedRequestTurns.add(a.turn);
      else retiredRequestAliases.add(request);
      return undefined;
    }
  } catch (error) {
    if (original) revokedRequestTurns.add(a.turn);
    else retiredRequestAliases.add(request);
    throw error;
  }
  return validTurn(a.turn) ? a.turn.scope : undefined;
}
export function inheritGhostBrideDeadlineRequest(
  source: WeddingRequest,
  target: WeddingRequest,
): void {
  const a = requests.get(source);
  if (requests.has(target)) return;
  if (!a || !ghostBrideRequestScope(a.turn.binding.world, source)) return;
  const fields = Object.getOwnPropertyDescriptors(target),
    keys = Object.keys(a.fields).filter((k) => k !== "deadlineAtMs"),
    others = Object.keys(fields).filter((k) => k !== "deadlineAtMs");
  const deadline = data(target, "deadlineAtMs"),
    effective = a.turn.deadline;
  if (
    (deadline !== undefined &&
      (typeof deadline !== "number" || !Number.isFinite(deadline) || deadline <= Date.now())) ||
    (effective !== null && (typeof deadline !== "number" || deadline > effective))
  )
    return;
  if (
    keys.length === others.length &&
    keys.every(
      (k) =>
        others.includes(k) &&
        fields[k] &&
        Object.hasOwn(fields[k], "value") &&
        fields[k]!.value === a.fields[k]!.value,
    ) &&
    requestData(target) === a.json
  ) {
    a.turn.deadline = typeof deadline === "number" ? deadline : null;
    requests.set(target, { ...a, deadline: typeof deadline === "number" ? deadline : null });
    bindRequestDeliveryGuard(
      target,
      () => ghostBrideRequestScope(a.turn.binding.world, target) !== undefined,
      a.turn.scope,
    );
    registerRequestAliasPropagation(target, 50, inheritGhostBrideDeadlineRequest);
  }
}
function targetCurrent(t: Turn, id: number): boolean {
  const p = t.binding.participants.get(id);
  return (
    !!p && sameBody(t.binding, p, true) && aliveLifeVersion(p.life) === t.targetVersions.get(id)
  );
}
export function commitWeddingTool(scope: object, value: unknown): boolean {
  const t = turns.get(scope);
  const accepted = commitWeddingToolInternal(scope, value);
  if (!accepted) settleRequestDelivery(scope, false);
  else if (t?.kind !== "chat") settleRequestDelivery(scope, true);
  return accepted;
}
function commitWeddingToolInternal(scope: object, value: unknown): boolean {
  const t = turns.get(scope),
    call = readWeddingTool(value);
  if (!t || !call || call.name !== t.tool || !validTurn(t)) return false;
  const b = t.binding;
  if (call.name === "choose_bridegroom") {
    const id = call.args.target_id;
    if (
      id === b.actorId ||
      !targetCurrent(t, id) ||
      !ghostBrideStateWritable(b.state, "remaining") ||
      !ghostBrideStateWritable(b.state, "groomId")
    )
      return false;
    const pair = Object.freeze({
      policy: GHOST_BRIDE_POLICY,
      groupId: `ghost-bride:1:${b.actorId}`,
      brideId: b.actorId,
      groomId: id,
      day: 1 as const,
    });
    consumeGhostBrideChoice(b, id);
    b.pair = pair;
    third(b, b.actorId);
    third(b, id);
    b.status = "paired";
    updateGhostBrideExpectedData(b, json);
  } else if (call.name === "speak_to_partner") {
    const partner = t.actorId === b.actorId ? b.pair!.groomId : b.actorId;
    if (!targetCurrent(t, partner)) return false;
    t.chat = Object.freeze({
      actorId: t.actorId,
      recipientId: partner,
      day: t.day,
      text: call.args.text,
    });
    b.pendingChat = t;
  } else if (call.name === "choose_wedding_witness") {
    const id = call.args.target_id;
    if (id === b.actorId || id === b.pair!.groomId || !targetCurrent(t, id)) return false;
    if (b.votes.length === 1 && !validConsent(b, t)) return false;
    b.votes.push(Object.freeze({ actorId: t.actorId, targetId: id }));
    if (b.votes.length === 1) b.consent = t;
    if (b.votes.length === 2) {
      if (b.votes[0]!.targetId !== id) {
        // 两个合法但相互矛盾的票均已实际提交，复盘必须保留该行动。
        settleRequestDelivery(scope, true);
        closeWeddingSetup(b.world, "failed");
        return false;
      }
      const group = Object.freeze({ ...b.pair!, witnessId: id });
      third(b, id);
      b.group = group;
      b.assignments = new Map(
        [...b.participants].map(([pid, p]) => [
          pid,
          [group.brideId, group.groomId, group.witnessId].includes(pid) ? Camp.ThirdParty : p.camp,
        ]),
      );
      b.status = "complete";
      b.setupCurrent = null;
    }
  } else {
    const n = b.activeNight!,
      id = call.args.target_id;
    if (
      id !== null &&
      (!targetCurrent(t, id) ||
        (n.capture.owner === "pair" && [b.actorId, b.pair!.groomId].includes(id)) ||
        (n.capture.owner === "witness" && id === t.actorId))
    )
      return false;
    n.votes.push(Object.freeze({ actorId: t.actorId, targetId: id, abstain: call.args.abstain }));
  }
  if (t.kind !== "chat") settleRequestDelivery(scope, true);
  closeWeddingTurn(scope);
  return true;
}
function validKnifeOwner(n: Night): boolean {
  const b = n.binding;
  return (
    b.activeNight === n &&
    !n.closed &&
    n.isCurrent() &&
    b.status === "complete" &&
    validBinding(b) &&
    n.capture.actorIds.every((id) => {
      const p = b.participants.get(id)!;
      return sameBody(b, p, true) && aliveLifeVersion(p.life) === n.actorVersions.get(id);
    })
  );
}
export function captureWeddingKnife(
  world: World,
  day: number,
  isCurrent: () => boolean,
): Readonly<WeddingKnifeCapture> {
  const b = bindings.get(world);
  if (
    !b ||
    b.status !== "complete" ||
    !b.group ||
    b.activeNight ||
    b.nights.has(day) ||
    !Number.isSafeInteger(day) ||
    day < 1 ||
    !isCurrent() ||
    !validBinding(b)
  )
    throw new Error("ghost_bride_night_unavailable");
  const groupIds = [b.actorId, b.group.groomId, b.group.witnessId],
    singles = [...b.participants.values()]
      .filter((p) => p.kind === Role.Wolf && !groupIds.includes(p.id) && sameBody(b, p, true))
      .map((p) => p.id),
    pairIds = [b.actorId, b.group.groomId],
    pairAlive = pairIds.every((id) => sameBody(b, b.participants.get(id)!, true)),
    pairDead = pairIds.every((id) => !b.participants.get(id)!.life.alive),
    witnessAlive = sameBody(b, b.participants.get(b.group.witnessId)!, true);
  const owner = singles.length
      ? "ordinary_pack"
      : pairAlive
        ? "pair"
        : pairDead && witnessAlive
          ? "witness"
          : "none",
    actorIds = singles.length
      ? singles
      : owner === "pair"
        ? pairIds
        : owner === "witness"
          ? [b.group.witnessId]
          : [];
  const capture = Object.freeze({
    policy: GHOST_BRIDE_POLICY,
    groupId: b.group.groupId,
    day,
    owner,
    actorIds: Object.freeze(actorIds) as unknown as number[],
  });
  const n: Night = {
    binding: b,
    day,
    capture,
    isCurrent,
    actorVersions: new Map(
      actorIds.map((id) => [id, aliveLifeVersion(b.participants.get(id)!.life)!]),
    ),
    targetVersions: new Map([...b.participants].map(([id, p]) => [id, aliveLifeVersion(p.life)!])),
    votes: [],
    chats: 0,
    requiredChats: day > 1 && pairAlive ? 2 : 0,
    closed: false,
    knifeCommitted: false,
    targetId: null,
  };
  b.nights.set(day, n);
  b.activeNight = n;
  return capture;
}
export function resolveWeddingKnife(world: World, day: number): number | null {
  const n = bindings.get(world)?.activeNight;
  if (!n || n.day !== day || n.knifeCommitted) throw new Error("ghost_bride_knife_unavailable");
  n.knifeCommitted = true;
  if (!validKnifeOwner(n)) {
    n.targetId = null;
    return null;
  }
  if (n.votes.length !== n.capture.actorIds.length || n.chats !== n.requiredChats)
    throw new Error("ghost_bride_required_knife_missing");
  const counts = new Map<number, number>();
  for (const v of n.votes)
    if (!v.abstain && v.targetId !== null)
      counts.set(v.targetId, (counts.get(v.targetId) ?? 0) + 1);
  const target = [...counts].sort((a, b) => b[1] - a[1] || a[0] - b[0])[0]?.[0] ?? null;
  const p = target === null ? undefined : n.binding.participants.get(target);
  n.targetId =
    p && sameBody(n.binding, p, true) && aliveLifeVersion(p.life) === n.targetVersions.get(p.id)
      ? p.id
      : null;
  return n.targetId;
}
export function weddingKnifeCurrent(world: World, day: number, targetId: number): boolean {
  const n = bindings.get(world)?.activeNight,
    p = n?.binding.participants.get(targetId);
  return (
    !!n &&
    n.day === day &&
    n.knifeCommitted &&
    n.targetId === targetId &&
    validKnifeOwner(n) &&
    !!p &&
    sameBody(n.binding, p, true) &&
    aliveLifeVersion(p.life) === n.targetVersions.get(targetId)
  );
}
export function closeWeddingNight(world: World): void {
  const b = bindings.get(world);
  if (!b?.activeNight) return;
  if (b.turn) settleRequestDelivery(b.turn.scope, false);
  if (b.pendingChat) settleRequestDelivery(b.pendingChat.scope, false);
  b.activeNight.closed = true;
  b.activeNight = null;
  b.turn = null;
  b.pendingChat = null;
}
export function weddingMember(world: World, role: RoleComponent): boolean {
  const b = bindings.get(world);
  if (!b?.pair) return false;
  if (!validBinding(b)) throw new Error("ghost_bride_authority_invalid");
  return [b.actorId, b.pair.groomId, b.group?.witnessId].some(
    (id) => id !== undefined && b.participants.get(id)?.role === role,
  );
}
export function weddingAssignment(world: World): ReadonlyArray<readonly [number, Camp]> | null {
  const b = bindings.get(world);
  if (!b) return null;
  if (b.status !== "complete" || !b.assignments || !validBinding(b))
    throw new Error("ghost_bride_victory_unavailable");
  return Object.freeze([...b.assignments].map(([id, camp]) => Object.freeze([id, camp] as const)));
}
export function weddingFactionResult(
  world: World,
): { faction: Camp | null; winningPlayerIds: number[] } | null {
  const b = bindings.get(world),
    assignment = weddingAssignment(world);
  if (!b || !assignment) return null;
  const alive = new Set(
    assignment.filter(([id]) => sameBody(b, b.participants.get(id)!, true)).map(([, camp]) => camp),
  );
  if (alive.size > 1) return null;
  const faction = [...alive][0] ?? null;
  return {
    faction,
    winningPlayerIds: faction
      ? assignment.filter(([, camp]) => camp === faction).map(([id]) => id)
      : [],
  };
}
export function weddingAuditPlayer(world: World, id: number, failedCycle = false) {
  const b = bindings.get(world),
    p = b?.participants.get(id);
  if (!b || !p || (!failedCycle && b.status !== "failed" && b.status !== "cancelled")) return null;
  // 分别刷新仍归原 owner 的 plain 库存；其他参与者可能已经失败。
  // json 仅读 descriptor，foreign getter／Proxy 因而保留最近安全快照。
  if (sameBody(b, p) && sameIdentity(b, p)) {
    refreshGhostBrideParticipantAudit(p, json);
  }
  const alive = p.aliveDescriptor.get
    ? p.aliveDescriptor.get.call(p.life) === true
    : p.aliveDescriptor.value === true;
  return {
    role: p.kind,
    camp: p.camp,
    alive,
    privateState: projectGhostBrideFailedPrivateData(b, p, id),
    victory: JSON.parse(p.victoryJson) as VictoryComponent["affiliations"],
  };
}

const deathEdges = new WeakMap<World, Set<string>>();
/** 原生枪资格检查前关闭独立 roots；派生情侣关系不建立反向边。 */
export function expandWeddingDeaths(
  world: World,
  ids: number[],
  sources: DeathSources,
  eligibleDead: ReadonlySet<number>,
  nightOrigin?: Set<number>,
): Array<{ actorId: number; targetId: number }> {
  const b = bindings.get(world);
  if (!b) return [];
  if (b.status !== "complete" || !b.group || !validBinding(b))
    throw new Error("ghost_bride_relation_unavailable");
  const pairIds = [b.actorId, b.group.groomId],
    members = new Set(ids),
    roots = new Set(ids.filter((id) => (sources[id] ?? []).some((c) => c !== DeathCause.Lovers))),
    edges: Array<{ actorId: number; targetId: number }> = [],
    emitted = deathEdges.get(world) ?? new Set<string>();
  for (const root of pairIds) {
    if (!roots.has(root)) continue;
    const target = pairIds.find((id) => id !== root)!,
      p = b.participants.get(target)!;
    if (!sameBody(b, p, true) && !members.has(target) && !eligibleDead.has(target)) continue;
    if (!members.has(target)) {
      members.add(target);
      ids.push(target);
    }
    if (!(sources[target] ?? []).includes(DeathCause.Lovers))
      sources[target] = [...(sources[target] ?? []), DeathCause.Lovers];
    if (nightOrigin?.has(root)) nightOrigin.add(target);
    const key = `${root}:${target}`;
    if (!emitted.has(key)) {
      emitted.add(key);
      edges.push({ actorId: root, targetId: target });
    }
  }
  deathEdges.set(world, emitted);
  return edges;
}

export function weddingNightCapture(
  world: World,
  day: number,
): Readonly<WeddingKnifeCapture> | null {
  return bindings.get(world)?.nights.get(day)?.capture ?? null;
}

/** 重检双方原生命及原请求后，仅消耗一次已提交消息。 */
export function takeWeddingChat(
  scope: object,
): { actorId: number; recipientId: number; day: number; text: string } | null {
  const t = turns.get(scope),
    message = t?.chat;
  if (!t || !message || t.delivered) return null;
  const b = t.binding,
    setup = b.status !== "complete";
  if (
    b.pendingChat !== t ||
    !t.isCurrent() ||
    (setup && b.setupCurrent?.() !== true) ||
    !validBinding(b, setup) ||
    !validRequestProof(t) ||
    !targetCurrent(t, message.actorId) ||
    !targetCurrent(t, message.recipientId) ||
    (!setup && (!b.activeNight || b.activeNight.day !== t.day || b.activeNight.closed)) ||
    [...b.participants].some(([id, p]) => json(p.state) !== t.privateJson.get(id))
  ) {
    if (b.pendingChat === t) settleRequestDelivery(scope, false);
    return null;
  }
  t.delivered = true;
  b.pendingChat = null;
  if (setup) b.chats++;
  else b.activeNight!.chats++;
  settleRequestDelivery(scope, true);
  return { ...message };
}
/** 与原身份无关的最小关系投影；先复验绑定，canKnife 仍只是此时知识，见证人不接收聊天、票型或原生库存。 */
export function weddingActorView(world: World, actorId: number): WeddingActorView | null {
  const b = bindings.get(world);
  if (!b?.pair || b.status === "failed" || b.status === "cancelled") return null;
  if (!validBinding(b)) throw new Error("ghost_bride_authority_invalid");
  const n = b.activeNight,
    canKnife = !!n && n.capture.actorIds.includes(actorId) && validKnifeOwner(n);
  if (actorId === b.actorId || actorId === b.pair.groomId)
    return {
      policy: GHOST_BRIDE_POLICY,
      member: actorId === b.actorId ? "bride" : "groom",
      faction: Camp.ThirdParty,
      partnerId: actorId === b.actorId ? b.pair.groomId : b.actorId,
      witnessId: b.group?.witnessId ?? null,
      ...(actorId === b.pair.groomId && b.votes.length === 1
        ? { proposedWitnessId: b.votes[0]!.targetId }
        : {}),
      canKnife,
    };
  return actorId === b.group?.witnessId
    ? {
        policy: GHOST_BRIDE_POLICY,
        member: "witness",
        faction: Camp.ThirdParty,
        brideId: b.actorId,
        groomId: b.pair.groomId,
        canKnife,
      }
    : null;
}

/** 纯 preflight 与提交使用同一原体／请求目标证明。 */
export function canSubmitWeddingTool(
  world: World,
  actorId: number,
  phase: Phase,
  day: number,
  scope: object | undefined,
  value: unknown,
): boolean {
  const t = scope && turns.get(scope),
    call = readWeddingTool(value);
  if (
    !t ||
    !call ||
    call.name !== t.tool ||
    !authorizedWeddingTurn(world, actorId, phase, day, scope)
  )
    return false;
  if (call.name === "speak_to_partner")
    return targetCurrent(
      t,
      t.actorId === t.binding.actorId ? t.binding.pair!.groomId : t.binding.actorId,
    );
  const id = call.args.target_id;
  if (id === null) return call.name === "kill_vote" || call.name === "wedding_kill_vote";
  if (!targetCurrent(t, id)) return false;
  if (call.name === "choose_bridegroom") return id !== t.binding.actorId;
  if (call.name === "choose_wedding_witness")
    return id !== t.binding.actorId && id !== t.binding.pair!.groomId;
  const owner = t.binding.activeNight!.capture.owner;
  return owner === "pair"
    ? ![t.binding.actorId, t.binding.pair!.groomId].includes(id)
    : owner !== "witness" || id !== actorId;
}
export function weddingBrideState(world: World, actorId: number): GhostBrideState | null {
  const b = bindings.get(world);
  if (!b || actorId !== b.actorId) return null;
  if (!validBinding(b)) throw new Error("ghost_bride_authority_invalid");
  return readGhostBrideState(b.state);
}

const swallowedBadges = new WeakSet<World>();
export function weddingBadgeSwallowed(world: World): boolean {
  return swallowedBadges.has(world);
}
export function swallowWeddingBadges(
  world: World,
  events: import("../../domain").GameEvent[],
): void {
  const b = bindings.get(world);
  if (!b || !ghostBrideReady(world)) throw new Error("ghost_bride_badge_authority_invalid");
  swallowedBadges.add(world);
  for (const id of world.entityIds()) {
    const badge = world.getComponent(id, COMPONENT.Badge);
    const vote = world.getComponent(id, COMPONENT.VotingRight);
    if (badge) {
      if (badge.isSheriff && !badge.destroyed)
        events.push({
          timestamp: Date.now(),
          type: "sheriff_badge_destroyed",
          payload: { targetId: id, reason: "ghost_bride_single_wolf_blast" },
        });
      badge.isSheriff = false;
      badge.destroyed = true;
      badge.voteWeight = 1;
      delete badge.handoffPolicy;
    }
    if (vote) vote.weight = vote.canVote ? 1 : 0;
  }
}
