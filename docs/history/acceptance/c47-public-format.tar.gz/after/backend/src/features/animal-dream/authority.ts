/**
 * 负责动物梦境原 roster、子狐租约和白猫／河豚死亡、放逐单元的实际授权与结算。
 * 输入为原玩家生命、票、受作用域约束的选择；仅在匹配单元仍有效时形成效果和权威快照。
 * 三族状态捕获／唯一替换／JSON 由 state-slot 拥有，已接受票与封票归唯一 ballot-ledger；
 * 此处仍拥有生命、当前性、河豚租约建立、付款及关闭顺序。
 * 关闭、失败和中止永久撤销原窗口，不允许替换身体恢复，不退还已提交的效果或记录前缀。
 */
import type { World } from "../../domain/world";
import { Camp } from "../../domain/identity";
import { snapshotPlainData } from "../../domain/plain-data";
import { aliveLifeVersion } from "../../domain/components/alive";
import { COMPONENT } from "../../domain/components/names";
import { bindCharm } from "../wolf-beauty/charm-ports";
import {
  animalRequestEnvelopeHeader,
  animalRequestEnvelopeCurrent,
  animalRequestEnvelopeDeadline,
  animalRequestEnvelopeMatchesWorld,
} from "./request-envelope";
import {
  installAnimalRoster,
  animalRosterCurrent,
  animalOriginalPlayer,
  animalOriginalRolePlayer,
  animalRosterPolicies,
  type AnimalOriginalPlayer,
} from "./roster";
import type { AnimalDeathUnit } from "./state";
import { AnimalBallotLedger, type AcceptedBallot } from "./ballot-ledger";
import {
  FOX_STATE_SLOT,
  PUFFER_STATE_SLOT,
  CAT_STATE_SLOT,
  captureResource,
  descriptor,
  plainJson,
  type Resource,
} from "./state-slot";

interface FoxLease {
  opened: boolean;
  paid: boolean;
  closed: boolean;
  checking: boolean;
  readonly requests: Set<object>;
  readonly beauty: object;
  readonly beautyJson: string;
}
interface AnimalNight {
  readonly day: number;
  readonly current: () => boolean;
  status: "starting" | "open" | "closing" | "normal" | "aborted";
  readonly requiresFox: boolean;
  readonly pufferWasAlive: boolean;
  readonly pufferVersion: number;
  readonly fox: FoxLease;
}
interface FoxEffect {
  day: number;
  targetId: number;
  knifeBlocked: boolean;
  beautyBlocked: boolean;
}
interface Owner {
  readonly fox: Resource<ReturnType<typeof FOX_STATE_SLOT.create>>;
  readonly puffer: Resource<ReturnType<typeof PUFFER_STATE_SLOT.create>>;
  readonly cat: Resource<ReturnType<typeof CAT_STATE_SLOT.create>>;
  stopped: boolean;
  night: AnimalNight | null;
  effect: FoxEffect | null;
  checkingDeath: boolean;
  completedUnits: number;
  lastUnitDay: number;
  unit: OwnedUnit | null;
  beautyLinkBlockedDay: number | null;
}
interface PufferLease {
  readonly targets: readonly AnimalOriginalPlayer[];
  readonly requests: Set<object>;
  paid: boolean;
  closed: boolean;
  activated: boolean;
}
interface OwnedUnit {
  readonly token: object;
  readonly value: Readonly<AnimalDeathUnit>;
  readonly current: () => boolean;
  status: "starting" | "open" | "closing" | "closed" | "aborted";
  expiryPrepared: boolean;
  expiryCatId: number | null;
  readonly ballots: AnimalBallotLedger;
  puffer: PufferLease | null;
}
const owners = new WeakMap<World, Owner>();
interface FoxRequest {
  readonly world: World;
  readonly night: AnimalNight;
  readonly deadlineAtMs: number | null;
  revoked: boolean;
  readonly envelope: object | null;
}
const foxRequests = new WeakMap<object, FoxRequest>();
const pufferRequests = new WeakMap<
  object,
  {
    world: World;
    unit: OwnedUnit;
    deadlineAtMs: number | null;
    revoked: boolean;
    envelope: object | null;
  }
>();
const now = Date.now.bind(Date);
function permitDeadlineCurrent(requests: ReadonlySet<object>, kind: "fox" | "puffer"): boolean {
  let earliest = Infinity;
  for (const token of requests) {
    const r = kind === "fox" ? foxRequests.get(token) : pufferRequests.get(token);
    if (!r || r.revoked) return false;
    if (r.deadlineAtMs !== null) earliest = Math.min(earliest, r.deadlineAtMs);
    const deadline = r.envelope === null ? null : animalRequestEnvelopeDeadline(r.envelope);
    if (deadline !== null) earliest = Math.min(earliest, deadline);
  }
  return now() < earliest;
}
function stop(owner: Owner): void {
  owner.stopped = true;
  if (owner.night) {
    owner.night.status = "aborted";
    owner.night.fox.closed = true;
  }
  if (owner.unit && owner.unit.status !== "closed") owner.unit.status = "aborted";
  if (owner.unit?.puffer) owner.unit.puffer.closed = true;
}
function rejectDeathReentry(owner: Owner): void {
  if (!owner.checkingDeath) return;
  stop(owner);
  throw Error("animal_death_scope_reentry");
}
function currentOwner(world: World): Owner | null {
  const owner = owners.get(world);
  if (!owner || owner.stopped) return null;
  if (
    !animalRosterCurrent(world) ||
    !FOX_STATE_SLOT.invalidations.current(owner.fox) ||
    !PUFFER_STATE_SLOT.invalidations.current(owner.puffer) ||
    !CAT_STATE_SLOT.invalidations.current(owner.cat)
  ) {
    stop(owner);
    return null;
  }
  return owner;
}
function beautyState(world: World): { value: object; json: string } | null {
  const actor = animalOriginalRolePlayer(world, "wolf_beauty"),
    d = actor && descriptor(actor.privateState, "wolf_beauty"),
    value = d?.value,
    json = plainJson(value),
    target = descriptor(value, "targetId");
  if (!value || typeof value !== "object" || !target?.writable || json === null) return null;
  return { value, json };
}
/** 捕获三个原生资源的唯一 authority；原 roster 安装不能重复，不初始化替代库存。 */
export function installAnimalAuthority(world: World, config: unknown): void {
  if (owners.has(world)) throw Error("animal_authority_already_installed");
  installAnimalRoster(world, config);
  const fox = captureResource(
      world,
      "fox_cub",
      "foxCub",
      FOX_STATE_SLOT.schema,
      FOX_STATE_SLOT.create(),
    ),
    puffer = captureResource(
      world,
      "pufferfish",
      "pufferfish",
      PUFFER_STATE_SLOT.schema,
      PUFFER_STATE_SLOT.create(),
    ),
    cat = captureResource(
      world,
      "white_cat",
      "whiteCat",
      CAT_STATE_SLOT.schema,
      CAT_STATE_SLOT.create(),
    );
  if (!beautyState(world)) throw Error("animal_initial_resource_invalid");
  owners.set(world, {
    fox,
    puffer,
    cat,
    stopped: false,
    night: null,
    effect: null,
    checkingDeath: false,
    completedUnits: 0,
    lastUnitDay: 0,
    unit: null,
    beautyLinkBlockedDay: null,
  });
}
/** 先保留本夜再调用阶段回调；重入或回调失败不能重新开启同一个夜间。 */
export function beginAnimalNight(world: World, day: number, isCurrent: () => boolean): void {
  const owner = currentOwner(world);
  if (owner) rejectDeathReentry(owner);
  if (
    !owner ||
    !Number.isSafeInteger(day) ||
    day !== (owner.night?.day ?? 0) + 1 ||
    (owner.night && owner.night.status !== "normal") ||
    (owner.unit && owner.unit.status !== "closed") ||
    typeof isCurrent !== "function"
  )
    throw Error("animal_night_unavailable");
  const beauty = beautyState(world);
  if (!beauty) {
    stop(owner);
    throw Error("animal_resource_revoked");
  }
  const state = FOX_STATE_SLOT.schema(FOX_STATE_SLOT.checkpoint.decode(() => owner.fox.json));
  const lives = world.entityIds().map((id) => {
    const player = animalOriginalPlayer(world, id, false)!;
    return { player, version: aliveLifeVersion(player.scope.life) };
  });
  const night: AnimalNight = {
    day,
    current: isCurrent,
    status: "starting",
    requiresFox: day >= 2 && state.usedNight === null && owner.fox.actor.scope.life.alive,
    pufferWasAlive: owner.puffer.actor.scope.life.alive,
    pufferVersion: aliveLifeVersion(owner.puffer.actor.scope.life)!,
    fox: {
      opened: false,
      paid: false,
      closed: false,
      checking: false,
      requests: new Set(),
      beauty: beauty.value,
      beautyJson: beauty.json,
    },
  };
  owner.night = night;
  try {
    if (
      isCurrent() !== true ||
      currentOwner(world) !== owner ||
      night.status !== "starting" ||
      lives.some(({ player, version }) => aliveLifeVersion(player.scope.life) !== version)
    )
      throw Error("animal_night_revoked");
    owner.effect = null;
    owner.beautyLinkBlockedDay = null;
    night.status = "open";
  } catch (error) {
    stop(owner);
    throw error;
  }
}
function foxCurrent(world: World, owner: Owner, night: AnimalNight): boolean {
  const lease = night.fox;
  if (
    lease.checking ||
    lease.closed ||
    lease.paid ||
    !lease.opened ||
    night.status !== "open" ||
    owner.night !== night ||
    currentOwner(world) !== owner ||
    !night.requiresFox ||
    !animalOriginalPlayer(world, owner.fox.actor.scope.id)
  )
    return false;
  lease.checking = true;
  try {
    if (night.current() !== true) throw Error("animal_fox_lease_revoked");
    const beauty = beautyState(world);
    if (
      currentOwner(world) !== owner ||
      night.status !== "open" ||
      lease.closed ||
      lease.paid ||
      !animalOriginalPlayer(world, owner.fox.actor.scope.id) ||
      !beauty ||
      beauty.value !== lease.beauty ||
      beauty.json !== lease.beautyJson
    )
      throw Error("animal_fox_lease_revoked");
    // 唯一外部回调已结束；之后只读私有数据，不再调用可能撤销旧期限或请求样本的别名回调。
    const checkedAt = now();
    for (const token of lease.requests) {
      const request = foxRequests.get(token);
      if (
        !request ||
        request.world !== world ||
        request.night !== night ||
        request.revoked ||
        (request.envelope !== null && !animalRequestEnvelopeCurrent(request.envelope)) ||
        (request.deadlineAtMs !== null && request.deadlineAtMs <= checkedAt)
      )
        throw Error("animal_fox_lease_revoked");
    }
    if (!permitDeadlineCurrent(lease.requests, "fox")) throw Error("animal_fox_lease_revoked");
    return true;
  } catch {
    lease.closed = true;
    return false;
  } finally {
    lease.checking = false;
  }
}
export function openAnimalFoxChoice(world: World, day: number, requestToken?: object) {
  const owner = currentOwner(world),
    night = owner?.night;
  if (owner) rejectDeathReentry(owner);
  if (night?.fox.checking) {
    night.fox.closed = true;
    throw Error("animal_fox_choice_unavailable");
  }
  const request = requestToken === undefined ? undefined : foxRequests.get(requestToken);
  if (
    !owner ||
    !night ||
    night.day !== day ||
    night.status !== "open" ||
    !night.requiresFox ||
    night.fox.closed ||
    night.fox.paid ||
    (requestToken !== undefined &&
      (!request || request.world !== world || request.night !== night || request.revoked))
  )
    throw Error("animal_fox_choice_unavailable");
  if (requestToken !== undefined) night.fox.requests.add(requestToken);
  night.fox.opened = true;
  return Object.freeze({
    actorId: owner.fox.actor.scope.id,
    isCurrent: () => foxCurrent(world, owner, night),
    close: () => {
      night.fox.closed = true;
    },
    commit: (targetId: number | null) => {
      if (!foxCurrent(world, owner, night)) throw Error("animal_fox_choice_unavailable");
      const target = targetId === null ? null : animalOriginalPlayer(world, targetId),
        next = FOX_STATE_SLOT.allowedWrites.choose(
          FOX_STATE_SLOT.schema(FOX_STATE_SLOT.checkpoint.decode(() => owner.fox.json)),
          day,
          targetId,
        ),
        encoded = FOX_STATE_SLOT.checkpoint.encode(next);
      if (targetId !== null && !target) throw Error("animal_fox_target_unavailable");
      if (
        !foxCurrent(world, owner, night) ||
        (target && animalOriginalPlayer(world, targetId!) !== target)
      )
        throw Error("animal_fox_choice_unavailable");
      const effect = target && {
        day,
        targetId: target.scope.id,
        knifeBlocked: target.scope.campValue === Camp.Wolf,
        beautyBlocked: target.scope.roleId === "wolf_beauty",
      };
      const beauty = effect?.beautyBlocked ? animalOriginalRolePlayer(world, "wolf_beauty") : null;
      if ((effect?.beautyBlocked && !beauty) || !permitDeadlineCurrent(night.fox.requests, "fox")) {
        night.fox.closed = true;
        throw Error("animal_fox_choice_unavailable");
      }
      // 原狐狸复验之后先清目标与旧绑定，再提交狐狸库存；绑定或后续写入失败保留此前前缀，不补付款。
      if (beauty) {
        (night.fox.beauty as { targetId: number | null }).targetId = null;
        bindCharm(world, beauty.scope.id, null);
      }
      FOX_STATE_SLOT.allowedWrites.commit(owner.fox, next, encoded);
      owner.effect = effect;
      night.fox.paid = true;
      return Object.freeze({ day, targetId });
    },
  });
}
/** 请求层只持有固定绝对期限和终态取消；opaque token 绑定实际本夜，不接任意回调。 */
export function createAnimalFoxRequest(
  world: World,
  day: number,
  deadlineAtMs?: number,
  envelope?: object,
) {
  const owner = currentOwner(world),
    night = owner?.night;
  if (owner) rejectDeathReentry(owner);
  if (night?.fox.checking) {
    night.fox.closed = true;
    throw Error("animal_fox_request_unavailable");
  }
  if (
    !night ||
    night.day !== day ||
    night.status !== "open" ||
    !night.requiresFox ||
    night.fox.closed ||
    night.fox.paid ||
    (deadlineAtMs !== undefined && (!Number.isFinite(deadlineAtMs) || deadlineAtMs <= now()))
  )
    throw Error("animal_fox_request_unavailable");
  if (envelope !== undefined) {
    const h = animalRequestEnvelopeHeader(envelope),
      candidates = world
        .entityIds()
        .filter((id) => animalOriginalPlayer(world, id))
        .sort((a, b) => a - b);
    if (
      !h ||
      !animalRequestEnvelopeMatchesWorld(envelope, world) ||
      h.kind !== "fox" ||
      h.actorId !== owner!.fox.actor.scope.id ||
      h.day !== day ||
      JSON.stringify(h.candidates) !== JSON.stringify(candidates) ||
      !animalRequestEnvelopeCurrent(envelope)
    )
      throw Error("animal_fox_request_unavailable");
  }
  const token = Object.freeze({}),
    request: FoxRequest = {
      world,
      night,
      deadlineAtMs: deadlineAtMs ?? null,
      revoked: false,
      envelope: envelope ?? null,
    };
  foxRequests.set(token, request);
  return Object.freeze({
    token,
    revoke: () => {
      request.revoked = true;
      night.fox.closed = true;
    },
  });
}
export function closeAnimalNight(world: World, day: number, status: "normal" | "aborted"): void {
  const owner = owners.get(world),
    night = owner?.night;
  if (owner) rejectDeathReentry(owner);
  if (!owner || !night || night.day !== day) throw Error("animal_night_unavailable");
  if (status === "aborted") {
    stop(owner);
    return;
  }
  if (
    status !== "normal" ||
    currentOwner(world) !== owner ||
    night.status !== "open" ||
    (night.requiresFox && !night.fox.paid)
  )
    throw Error("animal_night_not_complete");
  night.status = "closing";
  try {
    if (night.current() !== true || currentOwner(world) !== owner || night.status !== "closing")
      throw Error("animal_night_revoked");
    night.status = "normal";
    night.fox.closed = true;
  } catch (error) {
    stop(owner);
    throw error;
  }
}
function checkDeathScope(world: World, owner: Owner, isCurrent: () => boolean): void {
  rejectDeathReentry(owner);
  if (typeof isCurrent !== "function") throw Error("animal_death_scope_unavailable");
  owner.checkingDeath = true;
  try {
    if (isCurrent() !== true || currentOwner(world) !== owner)
      throw Error("animal_death_scope_revoked");
  } catch (error) {
    stop(owner);
    throw error;
  } finally {
    owner.checkingDeath = false;
  }
}
/** manager 签发实际放逐／跳过单元；PK 属于同一 token，不额外开启另一个单元。 */
export function beginAnimalExileUnit(
  world: World,
  day: number,
  kind: AnimalDeathUnit["kind"],
  isCurrent: () => boolean,
): object {
  const owner = currentOwner(world);
  if (owner) rejectDeathReentry(owner);
  if (
    !owner ||
    owner.night?.day !== day ||
    owner.night.status !== "normal" ||
    day <= owner.lastUnitDay ||
    (owner.unit && owner.unit.status !== "closed") ||
    !["exile", "skipped_day"].includes(kind) ||
    typeof isCurrent !== "function"
  )
    throw Error("animal_exile_unit_unavailable");
  const token = Object.freeze({}),
    unit: OwnedUnit = {
      token,
      value: Object.freeze({ number: owner.completedUnits + 1, day, kind }),
      current: isCurrent,
      status: "starting",
      expiryPrepared: false,
      expiryCatId: null,
      ballots: new AnimalBallotLedger(),
      puffer: null,
    };
  const lives = world.entityIds().map((id) => {
    const player = animalOriginalPlayer(world, id, false)!;
    return { player, version: aliveLifeVersion(player.scope.life) };
  });
  owner.unit = unit;
  try {
    checkDeathScope(world, owner, isCurrent);
    if (
      unit.status !== "starting" ||
      lives.some(({ player, version }) => aliveLifeVersion(player.scope.life) !== version)
    )
      throw Error("animal_exile_unit_revoked");
    unit.status = "open";
    return token;
  } catch (error) {
    stop(owner);
    throw error;
  }
}
function ownedUnit(world: World, token: object): { owner: Owner; unit: OwnedUnit } {
  const owner = currentOwner(world),
    unit = owner?.unit;
  if (owner) rejectDeathReentry(owner);
  if (!owner || !unit || unit.token !== token || unit.status !== "open")
    throw Error("animal_exile_unit_unavailable");
  checkDeathScope(world, owner, unit.current);
  if (unit.status !== "open") throw Error("animal_exile_unit_revoked");
  return { owner, unit };
}
/** 在实际致死提交边界过滤，早于 seen、Alive、遗言、警徽和死亡钩子。
 * 返回编号仍只是提议；生命写入始终归 DeathResolution，本函数不授予死亡或遗言资格。 */
export function filterAnimalLethalWave(
  world: World,
  day: number,
  phase: "night" | "day" | "voting",
  rawIds: readonly number[],
  rawSources: Readonly<Record<number, readonly string[]>>,
  scope: object | (() => boolean),
) {
  const owner = currentOwner(world);
  if (owner) rejectDeathReentry(owner);
  if (
    !owner ||
    owner.night?.day !== day ||
    owner.night.status !== "normal" ||
    !["night", "day", "voting"].includes(phase) ||
    (owner.unit?.value.day === day && owner.unit.status !== "open") ||
    (phase === "voting" &&
      (!owner.unit || owner.unit.value.day !== day || owner.unit.status !== "open"))
  )
    throw Error("animal_death_scope_unavailable");
  const ids = snapshotPlainData(rawIds) as number[],
    sources = snapshotPlainData(rawSources) as Record<number, string[]>;
  if (
    owner.unit?.value.day === day &&
    owner.unit.value.kind === "skipped_day" &&
    Object.values(sources).some((causes) =>
      causes.some((c) => c === "exile" || c === "puffer_retaliation"),
    )
  )
    throw Error("animal_death_scope_unavailable");
  if (
    !Array.isArray(ids) ||
    new Set(ids).size !== ids.length ||
    ids.some((id) => !animalOriginalPlayer(world, id))
  )
    throw Error("animal_death_proposals_invalid");
  const catId = owner.cat.actor.scope.id,
    before = CAT_STATE_SLOT.schema(CAT_STATE_SLOT.checkpoint.decode(() => owner.cat.json)),
    hasCat = ids.includes(catId),
    unit = owner.unit?.status === "open" && owner.unit.value.day === day ? owner.unit : null,
    countedUnit =
      unit &&
      (unit.value.kind === "exile" ||
        animalRosterPolicies(world)!.skippedVotePolicy === "awa_expire_on_skipped_day_v1")
        ? unit
        : null,
    next =
      hasCat && before.form.kind === "veiled"
        ? CAT_STATE_SLOT.allowedWrites.defer(
            before,
            day,
            phase,
            sources[catId] ?? [],
            owner.completedUnits,
            countedUnit?.value ?? null,
          )
        : before,
    encoded = CAT_STATE_SLOT.checkpoint.encode(next);
  if (unit ? scope !== unit.token : typeof scope !== "function")
    throw Error("animal_death_scope_unavailable");
  checkDeathScope(world, owner, unit ? unit.current : (scope as () => boolean));
  // 回调可能合法改变生命而保留原身体；回调结束后仍须重新检查提议目标的生命。
  if (ids.some((id) => !animalOriginalPlayer(world, id))) {
    stop(owner);
    throw Error("animal_death_scope_revoked");
  }
  const blocked = hasCat && next.form.kind !== "expired";
  if (encoded !== owner.cat.json) {
    CAT_STATE_SLOT.allowedWrites.commit(owner.cat, next, encoded);
    if (unit) {
      // 先前空准备不能结算后来死亡波新创建的时钟，实际写入后撤销旧准备回执。
      unit.expiryPrepared = false;
      unit.expiryCatId = null;
    }
  }
  return Object.freeze({
    deaths: Object.freeze(blocked ? ids.filter((id) => id !== catId) : [...ids]),
    revealedCatId: hasCat && before.form.kind === "veiled" ? catId : null,
    blockedCatId: blocked ? catId : null,
  });
}
/** 在本单元最终死亡波前准备时钟；历史死因不会授予死亡提交或遗言资格。 */
export function prepareAnimalCatExpiry(world: World, token: object): number | null {
  const { owner, unit } = ownedUnit(world, token);
  if (
    unit.value.kind === "exile" &&
    (unit.ballots.finalRound === null || (unit.puffer && !unit.puffer.paid))
  )
    throw Error("animal_exile_unit_not_complete");
  if (unit.expiryPrepared) throw Error("animal_cat_expiry_already_prepared");
  const before = CAT_STATE_SLOT.schema(CAT_STATE_SLOT.checkpoint.decode(() => owner.cat.json)),
    policy = animalRosterPolicies(world)!.skippedVotePolicy,
    next = CAT_STATE_SLOT.allowedWrites.expire(before, unit.value, policy),
    encoded = CAT_STATE_SLOT.checkpoint.encode(next);
  const expires = before.form.kind === "deferred" && next.form.kind === "expired";
  if (expires && !animalOriginalPlayer(world, owner.cat.actor.scope.id)) {
    stop(owner);
    throw Error("animal_death_scope_revoked");
  }
  if (encoded !== owner.cat.json) CAT_STATE_SLOT.allowedWrites.commit(owner.cat, next, encoded);
  unit.expiryPrepared = true;
  unit.expiryCatId = expires ? owner.cat.actor.scope.id : null;
  return expires ? owner.cat.actor.scope.id : null;
}
export function closeAnimalExileUnit(world: World, token: object): void {
  const { owner, unit } = ownedUnit(world, token);
  if (!unit.expiryPrepared) throw Error("animal_exile_unit_not_complete");
  if (unit.value.kind === "exile" && unit.ballots.finalRound === null)
    throw Error("animal_exile_unit_not_complete");
  if (unit.puffer && !unit.puffer.paid) throw Error("animal_exile_unit_not_complete");
  if (unit.puffer?.activated) {
    const catState = CAT_STATE_SLOT.schema(CAT_STATE_SLOT.checkpoint.decode(() => owner.cat.json));
    for (const target of unit.puffer.targets) {
      const original = animalOriginalPlayer(world, target.scope.id, false);
      if (
        !original ||
        (original.scope.life.alive &&
          !(original === owner.cat.actor && catState.form.kind === "deferred"))
      )
        throw Error("animal_exile_unit_not_complete");
    }
  }
  if (unit.expiryCatId !== null) {
    const cat = animalOriginalPlayer(world, unit.expiryCatId, false);
    if (!cat || cat.scope.life.alive) throw Error("animal_exile_unit_not_complete");
  }
  unit.status = "closing";
  const policy = animalRosterPolicies(world)!.skippedVotePolicy;
  if (unit.value.kind === "exile" || policy === "awa_expire_on_skipped_day_v1")
    owner.completedUnits = unit.value.number;
  owner.lastUnitDay = unit.value.day;
  unit.status = "closed";
  if (unit.puffer) unit.puffer.closed = true;
}
/** 封票后在原点建立河豚原目标租约；先读票再解库存，失败不撤销已写 finalRound。 */
export function installAnimalPufferBallotChoice(
  world: World,
  owner: Owner,
  unit: OwnedUnit,
  selected: readonly AcceptedBallot[],
): void {
  const targets = selected
      .filter((v) => !v.abstain && v.target?.scope.id === owner.puffer.actor.scope.id)
      .map((v) => v.voter)
      .sort((a, b) => a.scope.id - b.scope.id),
    stock = PUFFER_STATE_SLOT.schema(PUFFER_STATE_SLOT.checkpoint.decode(() => owner.puffer.json));
  if (
    targets.length &&
    stock.usedDay === null &&
    stock.knifeDeathDay === null &&
    animalOriginalPlayer(world, owner.puffer.actor.scope.id)
  )
    unit.puffer = {
      targets: Object.freeze(targets),
      requests: new Set(),
      paid: false,
      closed: false,
      activated: false,
    };
}
// 同族接受票流程复用这三个实际权威函数；这些对象引用不代表额外授权，原 guard／停止仍生效。
export {
  ownedUnit as animalAcceptedBallotUnit,
  checkDeathScope as assertAnimalAcceptedBallotScope,
  stop as stopAnimalAcceptedBallotUnit,
};
export function animalPufferChoiceActor(world: World, token: object): number | null {
  const { owner, unit } = ownedUnit(world, token);
  return unit.puffer && !unit.puffer.paid && !unit.puffer.closed
    ? owner.puffer.actor.scope.id
    : null;
}
function pufferCurrent(
  world: World,
  token: object,
): { owner: Owner; unit: OwnedUnit; lease: PufferLease } {
  const { owner, unit } = ownedUnit(world, token),
    lease = unit.puffer;
  if (
    !lease ||
    lease.paid ||
    lease.closed ||
    !animalOriginalPlayer(world, owner.puffer.actor.scope.id) ||
    lease.targets.some((v) => animalOriginalPlayer(world, v.scope.id) !== v)
  )
    throw Error("animal_puffer_choice_unavailable");
  const checkedAt = now();
  for (const permit of lease.requests) {
    const r = pufferRequests.get(permit);
    if (
      !r ||
      r.world !== world ||
      r.unit !== unit ||
      r.revoked ||
      (r.envelope !== null && !animalRequestEnvelopeCurrent(r.envelope)) ||
      (r.deadlineAtMs !== null && r.deadlineAtMs <= checkedAt)
    ) {
      lease.closed = true;
      throw Error("animal_puffer_choice_unavailable");
    }
  }
  if (!permitDeadlineCurrent(lease.requests, "puffer")) {
    lease.closed = true;
    throw Error("animal_puffer_choice_unavailable");
  }
  return { owner, unit, lease };
}
export function createAnimalPufferRequest(
  world: World,
  token: object,
  deadlineAtMs?: number,
  envelope?: object,
) {
  const { owner, unit, lease } = pufferCurrent(world, token);
  if (deadlineAtMs !== undefined && (!Number.isFinite(deadlineAtMs) || deadlineAtMs <= now()))
    throw Error("animal_puffer_request_unavailable");
  if (envelope !== undefined) {
    const h = animalRequestEnvelopeHeader(envelope);
    if (
      !h ||
      !animalRequestEnvelopeMatchesWorld(envelope, world) ||
      h.kind !== "puffer" ||
      h.actorId !== owner.puffer.actor.scope.id ||
      h.day !== unit.value.day ||
      !animalRequestEnvelopeCurrent(envelope)
    )
      throw Error("animal_puffer_request_unavailable");
  }
  const permit = Object.freeze({}),
    r = {
      world,
      unit,
      deadlineAtMs: deadlineAtMs ?? null,
      revoked: false,
      envelope: envelope ?? null,
    };
  pufferRequests.set(permit, r);
  return Object.freeze({
    token: permit,
    revoke: () => {
      r.revoked = true;
      lease.closed = true;
    },
  });
}
export function openAnimalPufferChoice(world: World, token: object, requestToken?: object) {
  const { owner, unit, lease } = pufferCurrent(world, token),
    r = requestToken === undefined ? undefined : pufferRequests.get(requestToken);
  if (requestToken !== undefined && (!r || r.world !== world || r.unit !== unit || r.revoked))
    throw Error("animal_puffer_request_unavailable");
  if (requestToken !== undefined) lease.requests.add(requestToken);
  return Object.freeze({
    actorId: owner.puffer.actor.scope.id,
    isCurrent: () => {
      try {
        pufferCurrent(world, token);
        return true;
      } catch {
        lease.closed = true;
        return false;
      }
    },
    close: () => {
      lease.closed = true;
    },
    commit: (activate: boolean) => {
      pufferCurrent(world, token);
      const targetIds = lease.targets.map((v) => v.scope.id),
        next = PUFFER_STATE_SLOT.allowedWrites.choose(
          PUFFER_STATE_SLOT.schema(PUFFER_STATE_SLOT.checkpoint.decode(() => owner.puffer.json)),
          unit.value.day,
          activate,
          targetIds,
        ),
        encoded = PUFFER_STATE_SLOT.checkpoint.encode(next);
      pufferCurrent(world, token);
      PUFFER_STATE_SLOT.allowedWrites.commit(owner.puffer, next, encoded);
      lease.paid = true;
      lease.activated = activate;
      return Object.freeze({ day: unit.value.day, activate });
    },
  });
}
/** 仅供 God／引擎结算的回执；已付效果保留原首次死亡，玩家提示不消费此权限入口。 */
export function animalPufferReaction(world: World, token: object): readonly number[] {
  const { unit } = ownedUnit(world, token),
    lease = unit.puffer;
  return Object.freeze(lease?.paid && lease.activated ? lease.targets.map((v) => v.scope.id) : []);
}
/** 只接原生命已实际提交的狼刀死亡；待处理标记或未提交提议不能触发河豚被动。 */
export function commitAnimalPufferKnifeDeath(
  world: World,
  day: number,
  rawSources: readonly string[],
  scope: object | (() => boolean),
): void {
  const owner = currentOwner(world);
  if (owner) rejectDeathReentry(owner);
  const puffer = owner && animalOriginalPlayer(world, owner.puffer.actor.scope.id, false),
    sources = snapshotPlainData(rawSources) as string[],
    unit = owner?.unit?.status === "open" && owner.unit.value.day === day ? owner.unit : null;
  if (
    !owner ||
    owner.night?.day !== day ||
    owner.night.status !== "normal" ||
    !owner.night.pufferWasAlive ||
    !puffer ||
    puffer.scope.life.alive ||
    aliveLifeVersion(puffer.scope.life) !== owner.night.pufferVersion + 1 ||
    !Array.isArray(sources) ||
    !sources.includes("wolf_kill") ||
    (unit ? scope !== unit.token : typeof scope !== "function")
  )
    throw Error("animal_puffer_knife_death_unavailable");
  const next = PUFFER_STATE_SLOT.allowedWrites.knifeDeath(
      PUFFER_STATE_SLOT.schema(PUFFER_STATE_SLOT.checkpoint.decode(() => owner.puffer.json)),
      day,
    ),
    encoded = PUFFER_STATE_SLOT.checkpoint.encode(next);
  checkDeathScope(world, owner, unit ? unit.current : (scope as () => boolean));
  if (animalOriginalPlayer(world, puffer.scope.id, false) !== puffer || puffer.scope.life.alive)
    throw Error("animal_puffer_knife_death_unavailable");
  PUFFER_STATE_SLOT.allowedWrites.commit(owner.puffer, next, encoded);
  owner.beautyLinkBlockedDay = day;
}
export function animalBeautyLinkBlocked(world: World, day: number): boolean {
  const owner = currentOwner(world);
  return owners.has(world) && (!owner || owner.beautyLinkBlockedDay === day);
}
export function isAnimalDreamBoard(world: World): boolean {
  return owners.has(world);
}
export function abortAnimalGame(world: World): void {
  const owner = owners.get(world);
  if (owner) stop(owner);
}
export function animalFoxChoiceActor(world: World, day: number): number | null {
  const owner = currentOwner(world),
    night = owner?.night;
  return owner &&
    night?.day === day &&
    night.status === "open" &&
    night.requiresFox &&
    !night.fox.closed &&
    !night.fox.paid &&
    animalOriginalPlayer(world, owner.fox.actor.scope.id)
    ? owner.fox.actor.scope.id
    : null;
}
export function animalFoxChoiceCandidates(world: World, day: number): readonly number[] {
  if (animalFoxChoiceActor(world, day) === null) return Object.freeze([]);
  return Object.freeze(
    world
      .entityIds()
      .filter((id) => animalOriginalPlayer(world, id))
      .sort((a, b) => a - b),
  );
}
/** 只查询当前运行许可；不代表玩家已公布知识，也不是命中效果回执。 */
export function animalPackKnifeBlocked(world: World): boolean {
  if (!owners.has(world)) return false;
  const owner = currentOwner(world);
  return !owner || owner.night?.status !== "open" || owner.effect?.knifeBlocked === true;
}
export function animalBeautyCharmAllowed(world: World, day: number): boolean {
  if (!owners.has(world)) return true;
  const owner = currentOwner(world);
  return (
    !!owner &&
    owner.night?.day === day &&
    owner.night.status === "open" &&
    owner.effect?.beautyBlocked !== true
  );
}
/** 已付效果仅向 God 暴露；玩家提示使用独立的按公告披露知识投影。 */
export function animalFoxEffect(world: World): Readonly<FoxEffect> | null {
  const owner = currentOwner(world);
  return owner?.effect ? { ...owner.effect } : null;
}
export function animalAuthoritySnapshot(world: World, complete = true) {
  const owner = complete ? currentOwner(world) : owners.get(world);
  if (!owner) return null;
  return {
    policies: animalRosterPolicies(world),
    foxId: owner.fox.actor.scope.id,
    pufferId: owner.puffer.actor.scope.id,
    catId: owner.cat.actor.scope.id,
    fox: FOX_STATE_SLOT.checkpoint.decode(() => owner.fox.json),
    puffer: PUFFER_STATE_SLOT.checkpoint.decode(() => owner.puffer.json),
    cat: CAT_STATE_SLOT.checkpoint.decode(() => owner.cat.json),
    stopped: owner.stopped,
    night: owner.night && {
      day: owner.night.day,
      status: owner.night.status,
      requiresFox: owner.night.requiresFox,
      foxPaid: owner.night.fox.paid,
    },
    effect: owner.effect && { ...owner.effect },
    completedUnits: owner.completedUnits,
    beautyLinkBlockedDay: owner.beautyLinkBlockedDay,
    unit: owner.unit && {
      ...owner.unit.value,
      status: owner.unit.status,
      expiryPrepared: owner.unit.expiryPrepared,
      expiryCatId: owner.unit.expiryCatId,
      finalRound: owner.unit.ballots.finalRound,
      ballots: owner.unit.ballots.snapshotVotes(),
      puffer: owner.unit.puffer && {
        targetIds: owner.unit.puffer.targets.map((v) => v.scope.id),
        paid: owner.unit.puffer.paid,
        activated: owner.unit.puffer.activated,
        closed: owner.unit.puffer.closed,
      },
    },
  };
}
