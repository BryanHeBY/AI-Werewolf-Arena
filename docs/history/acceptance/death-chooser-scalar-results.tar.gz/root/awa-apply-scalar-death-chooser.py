"""仅在全部九份前态匹配后应用选枪输出边界；狼王只改局部死亡钩子。"""
from pathlib import Path
import hashlib, json, subprocess
repo = Path('/home/hby/dev/AI-Werewolf-Arena')
prepared = Path('/tmp/awa-h02-death-effect-implementation/successor-scalar-death-chooser')
sha = lambda b: hashlib.sha256(b).hexdigest()
ready = json.loads((prepared / 'source-ready.json').read_text())
local = json.loads((prepared / 'wolf-king-local-delta.json').read_text())[0]
updates = []
for row in ready['source']:
    path = repo / row['path']
    before = path.read_bytes()
    candidate = Path(row['candidate']).read_bytes()
    assert sha(before) == row['beforeSHA256'], row['path']
    assert sha(candidate) == row['afterSHA256'], row['path']
    if row['path'] == local['path']:
        text = before.decode()
        for edit in sorted(local['edits'], key=lambda edit: edit['start'], reverse=True):
            assert text[edit['start']:edit['end']] == edit['before']
            text = text[:edit['start']] + edit['after'] + text[edit['end']:]
        after = text.encode()
        assert after == candidate
    else:
        after = candidate
    updates.append((path, after, row))
for path, after, row in updates:
    path.write_bytes(after)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
result = {'base': base, 'source': [{**row, 'appliedSHA256': sha(after)} for path, after, row in updates]}
Path('/tmp/awa-scalar-death-chooser-applied.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
env = {'PATH': '/usr/bin:/bin', 'HOME': '/tmp', 'LANG': 'C.UTF-8', 'CI': '1'}
subprocess.run(['/usr/bin/bun', '--no-env-file', 'node_modules/prettier/bin/prettier.cjs', '--write', *[row['path'] for path, after, row in updates]], cwd=repo, env=env, check=True)
for row in result['source']:
    row['finalSHA256'] = sha((repo / row['path']).read_bytes())
Path('/tmp/awa-scalar-death-chooser-final-source.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'paths': len(updates), 'base': base}))
