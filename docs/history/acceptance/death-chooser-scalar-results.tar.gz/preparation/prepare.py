"""仅TMP，实际Root formatted WIP为前态；不执行产品/检查/parser。"""
from pathlib import Path
import json,hashlib,subprocess,difflib,stat
R=Path('/home/hby/dev/AI-Werewolf-Arena');D=Path('/tmp/awa-h02-death-effect-implementation/successor-scalar-death-chooser');C=D/'candidates'
def h(b):return hashlib.sha256(b).hexdigest()
def js(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
ps=['backend/src/engine/hooks/owned-bindings.ts','backend/src/engine/hooks/registry.ts','backend/src/features/hunter/death-hook.ts','backend/src/features/mechanical-wolf/death-hook.ts','backend/src/features/awakened-hidden-wolf/death-hook.ts','backend/src/features/death-actions/gift-gun-death-hook.ts','backend/src/features/wolf-beauty/death-hook.ts','backend/src/features/wolf-king/profile.ts','backend/tests/unit/engine/death/narrow-hook-capabilities.test.ts']
headStart=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip();before={}
for p in ps:
 f=R/p;b=f.read_bytes();st=f.lstat();assert stat.S_ISREG(st.st_mode)
 g=subprocess.run(['git','-C',str(R),'show',headStart+':'+p],capture_output=True);t=subprocess.run(['git','-C',str(R),'ls-tree',headStart,'--',p],capture_output=True,text=True)
 fields=t.stdout.split('\t')[0].split() if t.stdout else []
 before[p]={'text':b.decode(),'sha256':h(b),'bytes':len(b),'mode':'100755' if st.st_mode&stat.S_IXUSR else '100644','gitAtCapture':{'commit':headStart,'existed':g.returncode==0,'sha256':h(g.stdout) if g.returncode==0 else None,'mode':fields[0] if fields else None,'blob':fields[2] if fields else None,'currentSameGit':g.returncode==0 and g.stdout==b}}
 f=C/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
rows=[]
def update(p,fn,label):
 f=C/p;a=f.read_text();z=fn(a);assert z!=a,p;f.write_text(z);rows.append({'path':p,'label':label,'before':a,'after':z,'beforeSHA256':h(a.encode()),'afterSHA256':h(z.encode())})
def bindings(s):
 s=s.replace('import type { EntityId, GameEvent, Role, Camp }','import type { EntityId, GameEvent, Role, Camp, DeathShotSelection }')
 key='export interface HookQueries {';assert key in s
 s=s.replace(key,'''/** 完整选择只在本次可信资源绑定中传递；不进入公开callback参数。 */
export type OwnedDeathShotChooser = (actorId: EntityId, abilityId?: string) => Promise<DeathShotSelection>;
export interface OwnedDeathHookBindingSource extends OwnedHookBindingSource {
  readonly chooseDeathShot: OwnedDeathShotChooser;
}
'''+key)
 s=s.replace('const deathBindings = new WeakMap<object, Binder>();','const deathBindings = new WeakMap<object, (source: OwnedDeathHookBindingSource) => object>();')
 a='binder: (source: OwnedHookBindingSource) => Ports,\n): DeathHook<Ports>';z='binder: (source: OwnedDeathHookBindingSource) => Ports,\n): DeathHook<Ports>';assert a in s;s=s.replace(a,z)
 a='''  const binder = (
    kind === "death" ? deathBindings : kind === "voted" ? votedBindings : committedBindings
  ).get(hook);
  return binder ? binder(source) : {};'''
 z='''  if (kind === "death") {
    const binder = deathBindings.get(hook);
    // 仅invokeDeathHook的可信装配进入此分支，完整chooser在该处作为必填字段构造。
    return binder ? binder(source as OwnedDeathHookBindingSource) : {};
  }
  const binder = (kind === "voted" ? votedBindings : committedBindings).get(hook);
  return binder ? binder(source) : {};''';assert a in s;s=s.replace(a,z)
 a='''    choose: Parameters<DeathHook>[3],
    context: Parameters<DeathHook>[4],''';assert a in s;s=s.replace(a,'''    context: Parameters<DeathHook>[4],''')
 return s
update(ps[0],bindings,'private per-invocation full chooser in death binding only; command resolve no public chooser argument')
def registry(s):
 s=s.replace('  type OwnedHookBindingSource,','  type OwnedHookBindingSource,\n  type OwnedDeathHookBindingSource,')
 a='/** 死亡钩子函数签名。 */';assert a in s
 z='''/** 公共扩展只能观察选择标量；该副本不是目标生命、映射回调、许可或付款回执。 */
export type DeathHookChoice =
  | { kind: "shot"; targetId: EntityId; deathActionId: number; mappedMiss?: true }
  | { kind: "pass"; deathActionId: number }
  | { kind: "invalid" };
export type DeathHookChooser = (actorId: EntityId, abilityId?: string) => Promise<DeathHookChoice>;

'''+a;s=s.replace(a,z)
 # 只公开callback签名变化；可信引擎invoker/registry本身仍接受原完整selection。
 a='''    chooseDeathShot: (actorId: EntityId, abilityId?: string) => Promise<DeathShotSelection>,
    context?: DeathHookContext,
  ): Promise<DeathHookResult>;
}["invoke"];''';z='''    chooseDeathShot: DeathHookChooser,
    context?: DeathHookContext,
  ): Promise<DeathHookResult>;
}["invoke"];''';assert a in s;s=s.replace(a,z)
 a='''  return hook(
    hookRuntime("death", hook, bindingSource(world, events, preparation)),
    ids,
    sources,
    choose,
    context,
  );'''
 z='''  const source: OwnedDeathHookBindingSource = {
    ...bindingSource(world, events, preparation),
    chooseDeathShot: choose,
  };
  // 未知扩展实际取得新标量对象，不透传原targetScope/life或mappingCurrent。
  // 内建资源command不调用此adapter，仍私用同一原chooser及其完整原体／映射结果。
  const publicChoose: DeathHookChooser = async (...args) => {
    const selection = await choose(...args);
    if (selection.kind === "shot")
      return {
        kind: "shot",
        targetId: selection.targetId,
        deathActionId: selection.deathActionId,
        ...(selection.mappedMiss ? { mappedMiss: true as const } : {}),
      };
    if (selection.kind === "pass")
      return { kind: "pass", deathActionId: selection.deathActionId };
    return { kind: "invalid" };
  };
  return hook(hookRuntime("death", hook, source), ids, sources, publicChoose, context);''';assert a in s;s=s.replace(a,z)
 return s
update(ps[1],registry,'public chooser DTO copied explicitly; raw chooser private source retains original function identity/arguments')
for p in ps[2:7]:
 def f(s):
  s=s.replace('  type OwnedHookBindingSource,','  type OwnedHookBindingSource,\n  type OwnedDeathShotChooser,')
  # private original body receives same complete chooser; public binder resolve drops caller chooser argument.
  assert s.count('  choose: Parameters<DeathHook>[3],')==2,p
  s=s.replace('  choose: Parameters<DeathHook>[3],','  choose: OwnedDeathShotChooser,',1)
  s=s.replace('  (runtime, ids, sources, choose, context) => runtime.ports.resolve(ids, sources, choose, context),','  (runtime, ids, sources, _choose, context) => runtime.ports.resolve(ids, sources, context),')
  s=s.replace('''      choose: Parameters<DeathHook>[3],
      context: Parameters<DeathHook>[4],''','''      context: Parameters<DeathHook>[4],''')
  name='resolveOwnedBeauty' if '/wolf-beauty/' in p else 'resolveOwnedDeath'
  a=f') => {name}(source, ids, sources, choose, context),';z=f') => {name}(source, ids, sources, source.chooseDeathShot, context),';assert a in s,p;s=s.replace(a,z)
  return s
 update(p,f,'native complete resource body unchanged; original chooser from trusted per-call source, not public adapter')
p=ps[7]
def wolfking(s):
 a='''      (runtime, ids, sources, choose, context) =>
        runtime.ports.resolve(ids, sources, choose, context),''';z='''      (runtime, ids, sources, _choose, context) =>
        runtime.ports.resolve(ids, sources, context),''';assert a in s;s=s.replace(a,z)
 a='''          choose: Parameters<import("../../engine/hooks/registry").DeathHook>[3],
''';assert a in s;s=s.replace(a,'')
 a='''            choose,
            events,''';z='''            source.chooseDeathShot,
            events,''';assert a in s;s=s.replace(a,z)
 return s
update(p,wolfking,'WolfKing only deathHook local delta; preserve concurrent H03 validation/import')
p=ps[8]
def risk(s):
 a='import { setHunterState } from "../../../../src/features/hunter/ports";';assert a in s
 s=s.replace(a,a+'''\nimport { captureNightLife } from "../../../../src/domain/night-effects";
import { DeathResolution } from "../../../../src/engine/death-resolution";
import { EventRegistry } from "../../../../src/engine/events/event-registry";
import { ToolGateway } from "../../../../src/engine/actions/tool-gateway";''')
 return s+'''

// 真实死亡结算提供chooser；custom只观察候选，不借观察结果消费枪或改写目标生命。
test("narrow death chooser: actual collection returns scalar DTO to custom while native keeps original mapped scope", async () => {
  const f = fixture(), events: GameEvent[] = [];
  f.world.getComponent(f.actor, COMPONENT.Alive)!.alive = true;
  const targetLife = f.world.getComponent(f.target, COMPONENT.Alive)!;
  let asks = 0, customCalls = 0;
  const custom: DeathHook = async (_runtime, ids, _sources, choose) => {
    customCalls++;
    expect(ids).toEqual([1]);
    const selected = await choose(f.actor);
    expect(selected.kind).toBe("shot");
    expect(Object.keys(selected).sort()).toEqual(["deathActionId", "kind", "targetId"]);
    expect("targetScope" in selected).toBe(false);
    expect("mappingCurrent" in selected).toBe(false);
    expect("life" in selected).toBe(false);
    if (selected.kind !== "shot") throw new Error("literal_expected_shot");
    expect(selected.targetId).toBe(2);
    expect(Number.isSafeInteger(selected.deathActionId)).toBe(true);
    selected.targetId = 999;
    expect(f.world.getComponent(f.target, COMPONENT.Alive)).toBe(targetLife);
    expect(targetLife.alive).toBe(true);
    return { extraDeaths: [], extraDeathSources: {} };
  };
  await new DeathResolution(f.world, events, new ToolGateway(), new EventRegistry(new HookRegistry([], [custom])), { day: 1, phase: Phase.Day, gameOver: false, result: null }).resolve(
    [f.actor], { [f.actor]: [DeathCause.Shot] }, {
      async getAction(request) {
        asks++;
        expect(request.allowedTools).toEqual(["shoot"]);
        return { name: "shoot", args: { target_id: f.target } };
      },
    }, Phase.Day, Phase.Day,
  );
  expect(asks).toBe(1);
  expect(customCalls).toBe(1);
  expect(f.stock.canShoot).toBe(true);
  expect(targetLife.alive).toBe(true);
  expect(events.some(event => event.type === "hunter_shot")).toBe(false);
  expect(f.world.activeDeathActionCount).toBe(0);

  // 内建command必须继续消费同一完整selection，不能由公共DTO重捕目标或丢失映射当前性。
  const native = fixture(), originalScope = captureNightLife(native.world, native.target)!;
  const permit = native.world.openDeathAction(native.actor, "shoot", Phase.Day, 1);
  let mappingChecks = 0;
  try {
    const result = await invokeDeathHook(hunterDeathHook, native.world, [native.actor], { [native.actor]: [DeathCause.Exile] }, async () => ({
      kind: "shot", targetId: native.target, deathActionId: permit.id, targetScope: originalScope,
      mappingCurrent: () => { mappingChecks++; return true; },
    }), [], { day: 1, deathOriginPhase: Phase.Day, deferShotCommit: true, nightEffect: false, blocksNightShot: () => false });
    expect(mappingChecks).toBe(1);
    expect(result.pendingShots).toHaveLength(1);
    expect(result.pendingShots![0]!.targetScope).toBe(originalScope);
    expect(native.stock.canShoot).toBe(false);
    expect(native.world.getComponent(native.target, COMPONENT.Alive)).toBe(originalScope.life);
    expect(originalScope.life.alive).toBe(true);
  } finally { permit.close(); }
});
'''
update(p,risk,'append real DR/factory/collect chooser custom boundary plus original native raw mapped scope control; original3 declarations intact')
# 精确局部行差分，真实当前WIP前态不冒完整Git同态。
source=[];edits=[];patch=[]
for row in rows:
 p=row['path'];a=row['before'];z=row['after'];al=a.splitlines(True);zl=z.splitlines(True);ao=[0];zo=[0]
 for t in al:ao.append(ao[-1]+len(t))
 for t in zl:zo.append(zo[-1]+len(t))
 es=[]
 for tag,a0,a1,z0,z1 in difflib.SequenceMatcher(None,al,zl,autojunk=False).get_opcodes():
  if tag!='equal':es.append({'start':ao[a0],'end':ao[a1],'before':a[ao[a0]:ao[a1]],'after':z[zo[z0]:zo[z1]]})
 s=a
 for e in reversed(es):assert s[e['start']:e['end']]==e['before'];s=s[:e['start']]+e['after']+s[e['end']:]
 assert s==z
 source.append({'path':p,'mode':before[p]['mode'],'beforeSHA256':row['beforeSHA256'],'afterSHA256':row['afterSHA256'],'bytes':len(z.encode()),'candidate':str(C/p),'apply':'exact chooser local deltas only' if p.endswith('/wolf-king/profile.ts') else 'whole file only if exact WIP beforeSHA matches'})
 edits.append({'path':p,'label':row['label'],'beforeSHA256':row['beforeSHA256'],'afterSHA256':row['afterSHA256'],'edits':es})
 patch.extend(difflib.unified_diff(al,zl,fromfile=p,tofile=p,n=4))
js(D/'before.json',{'kind':'actual Root formatted+typed D/E currentWIP complete before','headAtCaptureStart':headStart,'headAtCaptureEnd':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'files':before,'limits':'currentSHA is authoritative; earlierGit source identity stored separately, not all-current-Git claim'})
js(D/'edits.json',edits);(D/'candidate.patch').write_text(''.join(patch));js(D/'wolf-king-local-delta.json',[x for x in edits if x['path'].endswith('/wolf-king/profile.ts')])
js(D/'source-ready.json',{'status':'TMP source-ready, no checks executed','source':source,'deleted':[],'sourceCount':9,'newPaths':[],'retirement':'Public DeathHook chooser scalar DTO; targetScope/life/mappingCurrent now private native input','privateChooser':'OwnedDeathHookBindingSource per actual invocation stores same original chooser; no global or World chooser cache','originalRiskDeclarationsPreserved':3,'newRiskDeclarations':1,'checksExecuted':[],'repoWrites':False})
(D/'README.md').write_text('''# H02 死亡chooser标量边界后继

九完整前态来自Root当前实际formatted/typed D/E工作树，包含Root补的getter返回类型注解；before.json逐源保存当前完整字节及同时Git来源，绝不回放早期50稿。Root若已合H03，WolfKing只能用本批局部deathHook差分，不能whole覆盖validation/import。

公开DeathHookChooser现在返回新DeathHookChoice对象，只显式复制kind/targetId/deathActionId/mappedMiss标量；targetScope/life/mappingCurrent代码API明确退出，未知custom不能由一次合法choose取得原生命组件或映射回调。新DTO不是许可或付款，也不把选择当成已杀死目标。

原完整DeathShotSelection/chooser仍由每次invokeDeathHook可信构造的OwnedDeathHookBindingSource私持，静态binder表仅函数→coldbinder，不存World或chooser。内建具体command不再接public chooser参数，直接将本次原chooser交原资源程序；没有重捕目标、JSON化权限、改生命版本、丢映射或更改await/receiver/错误。World/events/prepare原私源不变。

新增public adapter存在一次await及明确标量字段读取，这是custom API收窄的观察面；内建根本不调用adapter，不替其原异步路径。未知custom本来可选择不consume，仍可返回原DeathHookResult；没有给所有custom强加付款或状态机。自定义wrapper若需原生命令，调用方显式拥有的可信invoker仍负责其本来资源，不能从新公共DTO推回原targetScope。

仅追加第4unit声明：真实DeathResolution→factory→collectDeathShot→custom合法await，断言返回字段及改DTO不改目标生命／枪库存；同声明另fresh原Hunter command检mappingCurrent调用和pending targetScope同一引用，禁止以重新捕获目标替代。原3声明体和全部原Stock/Ghost/Beauty/default算法保持。

本作者只准备TMP/读取源和Git对象，0产品/parser/type/test/formatter/gate执行，0repo写。Root唯一执行后继必要风险和实际变根类型；不重复原318unit/34scenario/完整types既有绿。
''')
js(D/'prepared-checks.json',{'newRiskOnly':['bun','--no-env-file','test','--preload','./backend/tests/setup.ts','backend/tests/unit/engine/death/narrow-hook-capabilities.test.ts','--test-name-pattern','^narrow death chooser:'],'types':'Root finite changed9roots after own H03 merge; no author execution','heads':'Root choose actual changed header roots only; important maintenance comments added locally','proof':'exact9WIP before/deltas; preserve full original native/gift body except private chooser type/binder argument; original3 test declarations unchanged; author no parser execution'})
refs=[]
for p in ['prepare.py','before.json','edits.json','candidate.patch','wolf-king-local-delta.json','source-ready.json','README.md','prepared-checks.json']:
 b=(D/p).read_bytes();refs.append({'path':p,'sha256':h(b),'bytes':len(b)})
js(D/'HANDOFF.json',{'status':'prepared source-ready successor; no checks','sourceCount':9,'newSourceCount':0,'deleted':[],'sourceReadySHA256':h((D/'source-ready.json').read_bytes()),'inputKind':'actual Root current formatted WIP, not old50 and not all-current-Git','wolfKingApply':'exact chooser deltas only','artifacts':refs,'checksExecuted':[],'repoWrites':False})
print(json.dumps({'HANDOFF':h((D/'HANDOFF.json').read_bytes()),'ready':h((D/'source-ready.json').read_bytes()),'HEADatCapture':headStart,'sourceCount':len(source),'exactDeltas':sum(len(x['edits']) for x in edits)}))
