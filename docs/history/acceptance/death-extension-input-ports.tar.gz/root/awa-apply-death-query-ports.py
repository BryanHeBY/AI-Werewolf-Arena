"""整合D/E完整候选；唯一交叉夹具只合hook调用，保Root目标提示改动。"""
from pathlib import Path
import json,hashlib,subprocess
repo=Path('/home/hby/dev/AI-Werewolf-Arena');root=Path('/tmp/awa-h02-death-effect-implementation/successor-bool-life-queries');d=json.loads((root/'source-ready.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();special='backend/tests/unit/mechanisms/configured-inspection-and-death-policy-instances.test.ts';rows=[];base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b''
for r in d['source']:
 p=repo/r['path'];candidate=Path(r['candidatePath']).read_bytes();assert sha(candidate)==r['afterSHA256'],r['path'];old=p.read_bytes() if p.exists() else None
 if r['path']==special:
  s=old.decode();a='import { bindTargetHintContext }';assert s.count(a)==1;s=s.replace(a,'import { invokeDeathHook } from "../../../src/engine/hooks/registry";\n'+a,1)
  for before,after in [('await hook(','await invokeDeathHook(hook, '),('await hunterDeathHook(','await invokeDeathHook(hunterDeathHook, ')]:assert s.count(before)==1;s=s.replace(before,after,1)
  result=s.encode();mode='local hook delta preserving Root bindTargetHintContext and its original object arguments'
 else:
  assert (old is None if r['expectedAbsent'] else sha(old)==r['beforeSHA256']),r['path'];result=candidate;mode='whole prepared candidate'
 rows.append({'path':r['path'],'beforeSHA256':sha(old) if old is not None else None,'preparedSHA256':r['afterSHA256'],'appliedSHA256':sha(result),'mode':mode});p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(result)
Path('/tmp/awa-death-query-ports-applied.json').write_text(json.dumps({'base':base,'preparedBase':d['baseCommit'],'source':rows,'formatPending':True},ensure_ascii=False,indent=2)+'\n');print('applied',len(rows),'at',base)
