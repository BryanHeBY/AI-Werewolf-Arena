"""首ready后静态补齐真实Dream callback消费者；只TMP。"""
from pathlib import Path
import subprocess,json,hashlib,shutil
D=Path('/tmp/awa-h02-death-effect-implementation');C=D/'candidates';R=Path('/home/hby/dev/AI-Werewolf-Arena')
for p in ['HANDOFF.json','source-ready.json','exact-edits-final.json','candidate.patch','cross-owner-deltas-final.json']:
 shutil.copy2(D/p,D/('first-'+p.replace('.json','-snapshot.json').replace('.patch','-snapshot.patch')))
B=json.loads((D/'before.json').read_text());p='backend/tests/unit/rulesets/additional-death-relations.test.ts';base=B['baseCommit']
b=subprocess.check_output(['git','-C',str(R),'show',base+':'+p]);v=subprocess.check_output(['git','-C',str(R),'ls-tree',base,'--',p],text=True).split('\t')[0].split();a=b.decode()
B['files'][p]={'text':a,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'mode':v[0],'blob':v[2]}
s=a.replace('import type { DreamNightEffects }','import type { DreamNightEffects, DreamLifeQueries }').replace('current: World,','current: DreamLifeQueries,')
assert s.count('expect(current).toBe(world);')==2
s=s.replace('expect(current).toBe(world);','''// 扩展只收真实生命query；同原组件引用仍可读，World本体不再进入回调。
        expect(Object.keys(current)).toEqual(["alive"]);
        expect(current.alive(1)).toBe(world.getComponent(1, COMPONENT.Alive));''',1)
s=s.replace('expect(current).toBe(world);','''expect(Object.keys(current)).toEqual(["alive"]);
    expect(current.alive(1)).toBe(world.getComponent(1, COMPONENT.Alive));''',1)
f=C/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
(D/'before.json').write_text(json.dumps(B,ensure_ascii=False,indent=2)+'\n')
(D/'dream-custom-consumer-successor.json').write_text(json.dumps({'reason':'首49 SourceReady后静态发现真实callback输入身份API消费者；非执行红','path':p,'before':a,'after':s,'firstReadySHA256':hashlib.sha256((D/'first-source-ready-snapshot.json').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
print('one extra existing actual callback test; no product execution')
