"""纯数据后继绑定；首49完整候选/前样均保，未运行产品。"""
from pathlib import Path
import json,hashlib,difflib,subprocess
D=Path('/tmp/awa-h02-death-effect-implementation');C=D/'candidates';R=Path('/home/hby/dev/AI-Werewolf-Arena')
def h(b):return hashlib.sha256(b).hexdigest()
def js(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
a=json.loads((D/'first-exact-edits-final-snapshot.json').read_text());B=json.loads((D/'before.json').read_text());p='backend/tests/unit/rulesets/additional-death-relations.test.ts';old=B['files'][p];before=old['text'];after=(C/p).read_text()
linesA=before.splitlines(True);linesZ=after.splitlines(True);offsetA=[0];offsetZ=[0]
for t in linesA:offsetA.append(offsetA[-1]+len(t))
for t in linesZ:offsetZ.append(offsetZ[-1]+len(t))
es=[]
for tag,b0,b1,z0,z1 in difflib.SequenceMatcher(None,linesA,linesZ,autojunk=False).get_opcodes():
 if tag!='equal':es.append({'start':offsetA[b0],'end':offsetA[b1],'before':before[offsetA[b0]:offsetA[b1]],'after':after[offsetZ[z0]:offsetZ[z1]]})
a.append({'path':p,'mode':old['mode'],'beforeSHA256':old['sha256'],'afterSHA256':h(after.encode()),'beforeBytes':len(before.encode()),'afterBytes':len(after.encode()),'expectedAbsent':False,'candidatePath':str(C/p),'mergeOwner':None,'edits':es});a.sort(key=lambda x:x['path'])
for x in a:assert h(Path(x['candidatePath']).read_bytes())==x['afterSHA256']
js(D/'exact-edits-final.json',a)
ready=json.loads((D/'first-source-ready-snapshot.json').read_text());ready['currentHEADAtSampling']=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip();ready['source']=[{k:v for k,v in x.items() if k!='edits'} for x in a];ready['successor']={'firstSourceReadySHA256':h((D/'first-source-ready-snapshot.json').read_bytes()),'reason':'one actual custom Dream callback input migration omitted by method-call inventory; no execution failure','changedAfterFirstReady':[p],'programChecksExecuted':[]}
js(D/'source-ready.json',ready)
patch=[]
for x in a:
 old=B['files'][x['path']].get('text','');new=Path(x['candidatePath']).read_text();patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=x['path'],tofile=x['path'],n=4))
(D/'candidate.patch').write_text(''.join(patch))
js(D/'cross-owner-deltas-final.json',[x for x in a if x['mergeOwner']])
readme=(D/'README.md').read_text();readme+='\n## 首ready静态后继\n\n首49源ready和完整文本差分均原样保存为first-*-snapshot。后继只增加实际additional-death-relations测试的两处Dream callback首参身份断言适配，旧trace/容器/事件/receiver字面断言保。新50源不宣称额外检查已运行。\n';(D/'README.md').write_text(readme)
js(D/'prepared-checks.json',{'status':'commands prepared only; Root decides joint fence/actual execution','newRiskCommand':['bun','--no-env-file','test','--preload','./backend/tests/setup.ts','backend/tests/unit/engine/death/narrow-hook-capabilities.test.ts'],'necessaryOldAPICases':['backend/tests/unit/features/wolf-beauty/death-wave-publication.test.ts','backend/tests/unit/features/ghost-bride/death-wave-publication.test.ts','backend/tests/unit/rulesets/additional-death-relations.test.ts'],'types':'Root joint H02/H03 finite strict source roots after merge; author did not compile','proof':'Root may use full exact before+final edits and protected original body mapping; no claim full raw emission equality across intentional API change','heads':'Root finite changed roots only; no author execution'})
files=['before.json','source-ready.json','exact-edits-final.json','candidate.patch','cross-owner-deltas-final.json','README.md','prepare-first-failed.py','prepare.py','first-draft-snapshot.json','refine.py','refinements.json','adapt-tests.py','test-api-edits.json','finalize-source.py','final-source-refinements.json','trim-unused-supply.py','unused-supply-trim.json','first-HANDOFF-snapshot.json','first-source-ready-snapshot.json','first-exact-edits-final-snapshot.json','first-candidate-snapshot.patch','first-cross-owner-deltas-final-snapshot.json','dream-custom-consumer-successor.py','dream-custom-consumer-successor.json','package-source-ready.py','package-successor.py','prepared-checks.json']
refs=[]
for p in files:
 f=D/p;b=f.read_bytes();refs.append({'path':p,'sha256':h(b),'bytes':len(b)})
hand={'status':'source-ready successor; prepared TMP only; no checks executed','baseCommit':B['baseCommit'],'sourceReadySHA256':h((D/'source-ready.json').read_bytes()),'sourceCount':len(a),'newSourceCount':sum(x['expectedAbsent'] for x in a),'deleted':[],'controls':len(ready['controls']),'crossOwnerMergePaths':ready['crossOwnerMergePaths'],'newRiskTest':'backend/tests/unit/engine/death/narrow-hook-capabilities.test.ts','newRiskDeclarations':2,'firstSourceReadySHA256':ready['successor']['firstSourceReadySHA256'],'artifacts':refs,'noRepositoryWrites':True,'noProductParserOrCheckExecution':True}
js(D/'HANDOFF.json',hand)
print(json.dumps({'sourceCount':len(a),'new':hand['newSourceCount'],'HANDOFF':h((D/'HANDOFF.json').read_bytes()),'sourceReady':hand['sourceReadySHA256']}))
