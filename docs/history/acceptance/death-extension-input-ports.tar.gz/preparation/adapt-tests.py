"""仅TMP旧API实际消费者适配；原标题/字面规则预期保留。"""
from pathlib import Path
import subprocess,json,hashlib,re,os
O=Path('/tmp/awa-h02-death-effect-implementation');C=O/'candidates';R=Path('/home/hby/dev/AI-Werewolf-Arena');B='8dd28e93ded9eeb04fdd49d1a1e6d369f8649f3b'
bef=json.loads((O/'before.json').read_text())['files'];ed=[]
def source(p):
 if p not in bef:
  b=subprocess.check_output(['git','-C',str(R),'show',B+':'+p]);h=subprocess.check_output(['git','-C',str(R),'ls-tree',B,'--',p],text=True).split('\t')[0].split();bef[p]={'text':b.decode(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'mode':h[0],'blob':h[2]}
 return (C/p).read_text() if (C/p).exists() else bef[p]['text']
def save(p,s,label):
 a=source(p)
 if a==s:return
 t=C/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(s);ed.append({'path':p,'label':label,'before':a,'after':s})
def imp(s,p,names,target='backend/src/engine/hooks/registry'):
 rel=os.path.relpath(target,str(Path(p).parent)).replace('\\','/');rel=rel if rel.startswith('.') else './'+rel
 line='import { '+names+' } from "'+rel+'";'
 at=s.find('\nimport ');assert at>=0
 return s[:at+1]+line+'\n'+s[at+1:]
# 直接调用不再把World交callback，而走相同可信引擎invocation。
namesD=['hunterDeathHook','mechanicalDeathHook','awakenedDeathHook','giftGunDeathHook','wolfBeautyDeathHook']
namesV=['redMoonVotedOutHook','idiotVotedOutHook']
ps=set()
for l in (O/'all-hook-test-sites.txt').read_text().splitlines():ps.add(l.split(':',1)[0])
for p in sorted(ps):
 s=source(p);n=s;uses=set()
 for name in namesD:
  n,count=re.subn(r'\b'+name+r'\((?!\.\.\.args)', 'invokeDeathHook('+name+', ',n)
  if count:uses.add('invokeDeathHook')
 for name in namesV:
  n,count=re.subn(r'\b'+name+r'\(', 'invokeVotedOutHook('+name+', ',n)
  if count:uses.add('invokeVotedOutHook')
 for name in namesV:
  old='Parameters<typeof '+name+'>[2]'
  if old in n:n=n.replace(old,'import("@ai-werewolf-arena/game-contract").GameEvent[]')
 if p.endswith('native-shot-authority.test.ts'):
  n=n.replace('await hook(','await invokeDeathHook(hook, ');uses.add('invokeDeathHook')
  n=n.replace('getDefaultRoleCatalog().requireRuntime(Role.WolfKing).deathHook!(','invokeDeathHook(getDefaultRoleCatalog().requireRuntime(Role.WolfKing).deathHook!, ')
 if p.endswith('configured-inspection-and-death-policy-instances.test.ts'):
  n=n.replace('await hook(','await invokeDeathHook(hook, ');uses.add('invokeDeathHook')
 if p.endswith('day-origin-policy.test.ts'):
  n=n.replace('WOLF_KING_ROLE_PROFILE.runtime.deathHook!(\n','invokeDeathHook(WOLF_KING_ROLE_PROFILE.runtime.deathHook!, \n');uses.add('invokeDeathHook')
 if n!=s:
  n=imp(n,p,', '.join(sorted(uses))) if uses else n
  save(p,n,'direct API uses trusted invoker; original args/oracles remain')
# 已有包装明确使用fixture本来持有的World/events，不从新ctx读World或自动继承binding。
wrappers={
 'backend/tests/unit/engine/death/target-life-scope.test.ts': [('hunterDeathHook','game.world','events')],
 'backend/tests/unit/mechanisms/gifted-gun-resource-boundaries.test.ts':[('giftGunDeathHook','game.world','game.events')],
 'backend/tests/scenarios/features/wolf-beauty/charm-chain-and-victory.test.ts':[('wolfBeautyDeathHook','game.world','events')],
 'backend/tests/unit/features/wolf-king/day-origin-policy.test.ts':[('WOLF_KING_ROLE_PROFILE.runtime.deathHook!','f.world','f.events')],
}
for p,items in wrappers.items():
 s=source(p);n=s
 for name,w,e in items:
  n=n.replace(name+'(...args)',f'invokeDeathHook({name}, {w}, args[1], args[2], args[3], {e}, args[4])')
 # fixture f由callback实际执行前建立；使用原已拥有World，不从runtime回门。
 if p.endswith('day-origin-policy.test.ts'):
  n=n.replace('const [world, , sources] = args;','const [, , sources] = args;\n              const world = f.world;')
  n=n.replace('context = args[5];','context = args[4];')
 if n!=s:
  if 'import { invokeDeathHook }' not in n and 'invokeDeathHook,' not in n:n=imp(n,p,'invokeDeathHook')
  save(p,n,'explicit fixture-owned wrapper command; no same-id/clone capability grant')
# Ghost三旧constructor消费改真实owner binding，原getter/trace/预期保持。
p='backend/tests/unit/features/ghost-bride/death-wave-publication.test.ts';s=source(p);n=s.replace('new WeddingDeathWavePublication(','bindWeddingDeathWavePublication(')
n=n.replace('import { WeddingDeathWavePublication }','import { bindWeddingDeathWavePublication }')
save(p,n,'Ghost original runtime supplied only to trusted owner factory')
# Beauty单元完整三场景：移相同lategetter到私有资源binding，动态prepare运行对象不再含World。
p='backend/tests/unit/features/wolf-beauty/death-wave-publication.test.ts';s=source(p)
s=s.replace('  createWolfBeautyDeathContribution,','  createWolfBeautyDeathContribution,\n  bindWolfBeautyDeathCommands,\n  type WolfBeautyDeathCommands,')
old='''  const owner = createWolfBeautyDeathContribution([{ binding: f.binding, nightEffect: true }], {
    attemptCharmTrigger,
    commitCharmDeath,
  });'''
new='''  const owner = createWolfBeautyDeathContribution([{ binding: f.binding, nightEffect: true }], bindWolfBeautyDeathCommands({
    world: f.world, events: [],
    prepareWorld() { throw new Error("world_must_not_read"); },
    prepareEvents() { throw new Error("events_must_not_read"); },
  }));'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('''      get world(): World {
        throw new Error("world_must_not_read");
      },
      get events(): GameEvent[] {
        throw new Error("events_must_not_read");
      },
''','')
# 梦回调新真实view仍核同原目标引用；其余收集轨迹和业务断言保持。
s=s.replace('expect(world).toBe(f.world);','expect(world.alive(f.target)).toBe(f.targetLife);')
a=s.index('  const owner = createWolfBeautyDeathContribution',s.index('test("blocked publication'))
z=s.index('  const nightEffects =',a)
s=s[:a]+'''  const privateSource = {
    get world() { trace.push("world"); return f.world; },
    get events(): GameEvent[] { trace.push("events"); throw failure; },
  };
  const bound = bindWolfBeautyDeathCommands({ world: f.world, events: [], prepareWorld: () => privateSource.world, prepareEvents: () => privateSource.events });
  const owner = createWolfBeautyDeathContribution([{ binding: f.binding, nightEffect: true }], {
    get attempt() {
      trace.push("attempt");
      const attempt = bound.attempt;
      return function (this: unknown, ...args: Parameters<WolfBeautyDeathCommands["attempt"]>) {
        expect(this).toBeUndefined();
        return attempt(...args);
      };
    },
    get commit() { return bound.commit; },
    blocked: (binding) => bound.blocked(binding),
    applied: (binding) => bound.applied(binding),
  });
'''+s[z:]
s=s.replace('''        get world() {
          trace.push("world");
          return f.world;
        },
        get events(): GameEvent[] {
          trace.push("events");
          throw failure;
        },
''','')
s=s.replace('bindDreamLifeQueries(this.world)','bindDreamLifeQueries(privateSource.world)')
old='''  const owner = createWolfBeautyDeathContribution([{ binding: f.binding, nightEffect: false }], {
    attemptCharmTrigger,
    commitCharmDeath,
  });'''
new='''  const owner = createWolfBeautyDeathContribution([{ binding: f.binding, nightEffect: false }], bindWolfBeautyDeathCommands({
    world: f.world, events: [], prepareWorld: () => f.world, prepareEvents() { throw failure; },
  }));''';assert old in s;s=s.replace(old,new)
s=s.replace('''      get world() {
        return f.world;
      },
      get events(): GameEvent[] {
        throw failure;
      },
''','')
save(p,s,'Beauty exact original late inputs moved into private owner binding; original trace and state oracles')
# 动态custom贡献仍可持真实owner事先绑定的command；不把raw runtime传回prepare。
p='backend/tests/unit/mechanisms/death-wave-contributions.test.ts';s=source(p).replace('  createWolfBeautyDeathContribution,','  createWolfBeautyDeathContribution,\n  bindWolfBeautyDeathCommands,')
old='''  real = createWolfBeautyDeathContribution([{ binding: f.binding, nightEffect: false }], {
    attemptCharmTrigger,
    commitCharmDeath,
  });'''
new='''  real = createWolfBeautyDeathContribution([{ binding: f.binding, nightEffect: false }], bindWolfBeautyDeathCommands({
    world: f.world, events: f.events, prepareWorld: () => f.world, prepareEvents: () => f.events,
  }));''';assert old in s;s=s.replace(old,new)
save(p,s,'custom contribution explicitly owns bounded real relation command')
(O/'test-api-edits.json').write_text(json.dumps(ed,ensure_ascii=False,indent=2)+'\n')
(O/'before.json').write_text(json.dumps({'baseCommit':B,'files':bef},ensure_ascii=False,indent=2)+'\n')
print('test input changed stages',len(ed),'captured',len(bef))
