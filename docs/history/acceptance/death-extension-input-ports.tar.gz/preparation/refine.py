"""TMP静态精度/类型形状修订；不调用产品或TS parser。"""
from pathlib import Path
import json,hashlib,re
O=Path('/tmp/awa-h02-death-effect-implementation');C=O/'candidates'
# 保首组装候选原样，以后继精确差分记录类型/文义修订。
files=[p for p in C.rglob('*') if p.is_file()]
snap={str(p.relative_to(C)):p.read_text() for p in files}
(O/'first-draft-snapshot.json').write_text(json.dumps(snap,ensure_ascii=False,indent=2)+'\n')
extra=[]
def update(rel,fn,label):
 p=C/rel;s=p.read_text();n=fn(s);assert n!=s,(rel,label);p.write_text(n);extra.append({'path':rel,'label':label,'before':s,'after':n})
p='backend/src/engine/hooks/owned-bindings.ts'
def f(s):
 s=s.replace('import type { World } from "../../domain/world";','import type { World } from "../../domain/world";\nimport type { DeathHook, VotedOutHook, CommittedDeathWaveHook } from "./registry";')
 s=s.replace('export function ownDeathHook<T extends Function>(hook: T, binder: Binder): T {','export function ownDeathHook<Ports extends object>(hook: DeathHook<Ports>, binder: (source: OwnedHookBindingSource) => Ports): DeathHook<Ports> {')
 s=s.replace('export function ownVotedOutHook<T extends Function>(hook: T, binder: Binder): T {','export function ownVotedOutHook<Ports extends object>(hook: VotedOutHook<Ports>, binder: (source: OwnedHookBindingSource) => Ports): VotedOutHook<Ports> {')
 s=s.replace('export function ownCommittedDeathHook<T extends Function>(hook: T, binder: Binder): T {','export function ownCommittedDeathHook<Ports extends object>(hook: CommittedDeathWaveHook<Ports>, binder: (source: OwnedHookBindingSource) => Ports): CommittedDeathWaveHook<Ports> {')
 return s+'''\n/** 三个实际提交形状，资源及政策仍由各owner的闭包持有。 */
export interface OwnedDeathCommands {
  resolve(ids: Parameters<DeathHook>[1], sources: Parameters<DeathHook>[2], choose: Parameters<DeathHook>[3], context: Parameters<DeathHook>[4]): ReturnType<DeathHook>;
}
export interface OwnedVotedOutCommands {
  resolve(targetId: number): ReturnType<VotedOutHook>;
}
export interface OwnedCommittedCommands {
  resolve(ids: readonly EntityId[], sources: Parameters<CommittedDeathWaveHook>[2], day: number, phase: Parameters<CommittedDeathWaveHook>[4]): void;
}
'''
update(p,f,'explicit actual command types; no public any-port default')
p='backend/src/engine/hooks/registry.ts'
def f(s):
 s=s.replace('type OwnedHookBindingSource }','type OwnedHookBindingSource, type OwnedCommittedCommands }')
 # method-indexed callable keeps dispatch able to retain concrete port subtypes without arbitrary any in public ctx.
 s=s.replace('export type CommittedDeathWaveHook<Ports extends object = any> = (','export type CommittedDeathWaveHook<Ports extends object = Record<never, never>> = { invoke(')
 s=s.replace('\n) => void;','\n): void; }["invoke"];',1)
 s=s.replace('export type VotedOutHook<Ports extends object = any> = (','export type VotedOutHook<Ports extends object = Record<never, never>> = { invoke(')
 s=s.replace('\n) => VotedOutResult | null;','\n): VotedOutResult | null; }["invoke"];')
 s=s.replace('export type DeathHook<Ports extends object = any> = (','export type DeathHook<Ports extends object = Record<never, never>> = { invoke(')
 s=s.replace('\n) => Promise<DeathHookResult>;','\n): Promise<DeathHookResult>; }["invoke"];')
 s=s.replace('return [ownCommittedDeathHook(','return [ownCommittedDeathHook<OwnedCommittedCommands>(')
 return s
update(p,f,'public custom ctx defaults no command; actual hooks concrete command contract')
for rel in ['backend/src/features/hunter/death-hook.ts','backend/src/features/mechanical-wolf/death-hook.ts','backend/src/features/awakened-hidden-wolf/death-hook.ts','backend/src/features/death-actions/gift-gun-death-hook.ts','backend/src/features/wolf-beauty/death-hook.ts','backend/src/features/wolf-king/profile.ts']:
 def f(s):
  s=s.replace('ownDeathHook, type OwnedHookBindingSource','ownDeathHook, type OwnedHookBindingSource, type OwnedDeathCommands')
  s=s.replace('import { ownDeathHook }','import { ownDeathHook, type OwnedDeathCommands }')
  s=s.replace('ownDeathHook(','ownDeathHook<OwnedDeathCommands>(')
  s=s.replace('runtime.ports.collect(','runtime.ports.resolve(').replace('(source) => ({ collect:','(source) => ({ resolve:')
  if rel.endswith('/wolf-beauty/death-hook.ts'):
   s=s.replace('activeCharm, permitsCharm, attemptCharmTrigger, commitCharmDeath','activeCharm, permitsCharm')
  return s
 update(rel,f,'explicit narrow native death command type')
for rel in ['backend/src/features/red-moon/voted-out-hook.ts','backend/src/rulesets/idiot-exile-outcome.ts']:
 def f(s):
  return s.replace('ownVotedOutHook, type OwnedHookBindingSource','ownVotedOutHook, type OwnedHookBindingSource, type OwnedVotedOutCommands').replace('ownVotedOutHook(','ownVotedOutHook<OwnedVotedOutCommands>(')
 update(rel,f,'explicit narrow native exile command type')
update('backend/src/domain/dream-night-effects.ts',lambda s:s.replace('定义一夜梦关系效果的运行接口；输入为原 World、原死亡集合','定义一夜梦关系效果的运行接口；输入为实际窄生命查询、原死亡集合'),'Dream actual input responsibility')
update('backend/src/engine/death-wave-contribution.ts',lambda s:s.replace('  GameEvent,\n',''),'remove now-unused old event type binding')
(O/'refinements.json').write_text(json.dumps(extra,ensure_ascii=False,indent=2)+'\n')
print('prepared refinements',len(extra))
