"""纯TMP缩窄未使用的新API；custom可闭包显式已有command，不加通用注入容器。"""
from pathlib import Path
import json
D=Path('/tmp/awa-h02-death-effect-implementation');C=D/'candidates';ed=[]
for p in ['backend/src/engine/hooks/owned-bindings.ts','backend/src/engine/hooks/registry.ts']:
 f=C/p;a=f.read_text();s=a
 if p.endswith('owned-bindings.ts'):
  s=s.replace('自定义扩展只能由调用方显式提供其已持有的窄port。','自定义扩展可在闭包显式持有调用方本来拥有的窄command，不隐式继承内建绑定。')
  s=s.replace('  supplied?: object,\n','').replace('return binder ? binder(source) : supplied ?? {};','return binder ? binder(source) : {};')
 else:
  s=s.replace(', supplied?: object): HookRuntime<any>','): HookRuntime<any>')
  s=s.replace('ownedHookPorts(kind, hook, source, supplied)','ownedHookPorts(kind, hook, source)')
  s=s.replace('未知custom只有query和调用方已拥有的supplied窄命令。','未知custom只有query；需要具体command的调用方在自有闭包中显式绑定，不收通用World容器。')
  s=s.replace(', supplied?: object): Promise<DeathHookResult>','): Promise<DeathHookResult>')
  s=s.replace('bindingSource(world, events, preparation), supplied)','bindingSource(world, events, preparation))')
  s=s.replace(', supplied?: object): VotedOutResult | null','): VotedOutResult | null')
  s=s.replace('bindingSource(world, events), supplied)','bindingSource(world, events))')
  s=s.replace('    private readonly suppliedPorts: ReadonlyMap<object, object> = new Map(),\n','')
  s=s.replace('invokeVotedOutHook(hook, world, targetId, events, this.suppliedPorts.get(hook))','invokeVotedOutHook(hook, world, targetId, events)')
  s=s.replace('context, preparation, this.suppliedPorts.get(hook))','context, preparation)')
 assert s!=a;f.write_text(s);ed.append({'path':p,'label':'do not add unused arbitrary object command injection; explicit custom lexical ports only','before':a,'after':s})
(D/'unused-supply-trim.json').write_text(json.dumps(ed,ensure_ascii=False,indent=2)+'\n')
print('TMP narrow API stages',len(ed))
