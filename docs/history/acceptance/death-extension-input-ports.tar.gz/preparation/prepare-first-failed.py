"""仅组装TMP完整候选和精确文本增量；不运行产品/TS解析器/检查。"""
from pathlib import Path
import subprocess,json,hashlib,re
R=Path('/home/hby/dev/AI-Werewolf-Arena'); O=Path('/tmp/awa-h02-death-effect-implementation'); B='8dd28e93ded9eeb04fdd49d1a1e6d369f8649f3b'
C=O/'candidates'; C.mkdir(exist_ok=True)
before={};after={};changes=[];cross=[]
def get(p):
 if p not in before:
  try:
   b=subprocess.check_output(['git','-C',str(R),'show',B+':'+p],stderr=subprocess.DEVNULL);h=subprocess.check_output(['git','-C',str(R),'ls-tree',B,'--',p],text=True).strip().split('\t')[0].split()
   before[p]={'text':b.decode(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':h[0],'blob':h[2]}
  except subprocess.CalledProcessError:before[p]={'expectedAbsent':True}
  after[p]=before[p].get('text','')
 return after[p]
def edit(p,old,new,label):
 s=get(p);assert s.count(old)==1,(p,label,s.count(old));pos=s.index(old);after[p]=s[:pos]+new+s[pos+len(old):];changes.append({'path':p,'label':label,'before':old,'after':new,'offsetAtStage':pos})
def whole(p,s,label):
 old=get(p);after[p]=s;changes.append({'path':p,'label':label,'before':old,'after':s,'offsetAtStage':0})
def addimport(p,text):
 s=get(p);at=s.find('\nimport ');assert at>=0,p;edit(p,s[at:at+1], '\n'+text+'\n','import '+text)
# 支持实际hook的可信静态绑定；映射只持函数引用和cold binder，从不缓存World。
whole('backend/src/engine/hooks/owned-bindings.ts','''/**
 * 负责内建死亡／放逐贡献的静态函数引用与私有资源绑定。
 * 这里只登记受信资源owner的cold binder；映射不保存World或每局端口，克隆/同id函数不继承绑定。
 * 引擎在实际调用时给binder原参数及晚prepare读取源，扩展只收到新建query/具体command对象。
 * 本内部装配叶不经公共barrel导出；自定义扩展只能由调用方显式提供其已持有的窄port。
 */
import type { EntityId, GameEvent, Role, Camp } from "../../domain/model";
import type { World } from "../../domain/world";

/** 仅引擎与可信资源owner间的私有构造输入，不进入hook运行上下文。 */
export interface OwnedHookBindingSource {
  readonly world: World;
  readonly events: GameEvent[];
  prepareWorld(): World;
  prepareEvents(): GameEvent[];
}
export interface HookQueries {
  role(id: EntityId): Role | undefined;
  camp(id: EntityId): Camp | undefined;
  alive(id: EntityId): boolean;
  entityIds(): EntityId[];
}
export interface HookRuntime<Ports extends object = Record<never, never>> {
  readonly queries: HookQueries;
  readonly ports: Ports;
}
type Binder = (source: OwnedHookBindingSource) => object;
const deathBindings = new WeakMap<Function, Binder>();
const votedBindings = new WeakMap<Function, Binder>();
const committedBindings = new WeakMap<Function, Binder>();
/** 内部静态登记不执行binder；默认Registry仍只持同一函数名单。 */
export function ownDeathHook<T extends Function>(hook: T, binder: Binder): T {
  deathBindings.set(hook, binder);
  return hook;
}
export function ownVotedOutHook<T extends Function>(hook: T, binder: Binder): T {
  votedBindings.set(hook, binder);
  return hook;
}
export function ownCommittedDeathHook<T extends Function>(hook: T, binder: Binder): T {
  committedBindings.set(hook, binder);
  return hook;
}
export function ownedHookPorts(
  kind: "death" | "voted" | "committed",
  hook: Function,
  source: OwnedHookBindingSource,
  supplied?: object,
): object {
  const binder = (kind === "death" ? deathBindings : kind === "voted" ? votedBindings : committedBindings).get(hook);
  return binder ? binder(source) : supplied ?? {};
}
''','new private static binding owner')
# Narrow runtime查询在registry真实构造，只有标量/编号副本。
p='backend/src/engine/hooks/registry.ts';s=get(p)
s=s.replace('import { World } from "../../domain/world";','import { World } from "../../domain/world";\nimport { COMPONENT } from "../../domain/components/names";\nimport { ownedHookPorts, ownCommittedDeathHook, type HookRuntime, type OwnedHookBindingSource } from "./owned-bindings";')
s=s.replace('export type CommittedDeathWaveHook = (\n  world: World,','export type CommittedDeathWaveHook<Ports extends object = any> = (\n  runtime: HookRuntime<Ports>,')
s=s.replace('  events: GameEvent[],\n) => void;','\n) => void;',1)
s=s.replace('  return [resolveWildChildDeathWave];','''  return [ownCommittedDeathHook(
    (runtime, deadIds, deathSources, day, phase) => runtime.ports.resolve(deadIds, deathSources, day, phase),
    (source) => ({
      resolve: (deadIds: readonly EntityId[], deathSources: DeathSources, day: number, phase: Phase) =>
        resolveWildChildDeathWave(source.world, deadIds, deathSources, day, phase, source.events),
    }),
  )];''')
s=s.replace('export type VotedOutHook = (\n  world: World,','export type VotedOutHook<Ports extends object = any> = (\n  runtime: HookRuntime<Ports>,')
s=s.replace('  targetId: EntityId,\n  events: GameEvent[],\n) => VotedOutResult | null;','  targetId: EntityId,\n) => VotedOutResult | null;')
s=s.replace('export type DeathHook = (\n  world: World,','export type DeathHook<Ports extends object = any> = (\n  runtime: HookRuntime<Ports>,')
s=s.replace('  chooseDeathShot: (actorId: EntityId, abilityId?: string) => Promise<DeathShotSelection>,\n  events: GameEvent[],\n  context?: DeathHookContext,\n) => Promise<DeathHookResult>;','  chooseDeathShot: (actorId: EntityId, abilityId?: string) => Promise<DeathShotSelection>,\n  context?: DeathHookContext,\n) => Promise<DeathHookResult>;')
anchor='function buildDefaultVotedOutHooks(): VotedOutHook[] {'
helpers='''/** 回调实际获得新query对象；原World只留本调用的私有闭包，不从返回值取回。 */
function hookRuntime(kind: "death" | "voted" | "committed", hook: Function, source: OwnedHookBindingSource, supplied?: object): HookRuntime<any> {
  return {
    queries: {
      role: (id) => source.world.getComponent(id, COMPONENT.Role)?.role,
      camp: (id) => source.world.getComponent(id, COMPONENT.Camp)?.camp,
      alive: (id) => source.world.getComponent(id, COMPONENT.Alive)?.alive === true,
      entityIds: () => source.world.entityIds(),
    },
    ports: ownedHookPorts(kind, hook, source, supplied),
  };
}
/** 可信调用方才提供原World/事件；晚prepare源不传给动态hook或其返回对象。 */
export interface DeathHookPreparationSource {
  world(): World;
  events(): GameEvent[];
}
function bindingSource(world: World, events: GameEvent[], preparation?: DeathHookPreparationSource): OwnedHookBindingSource {
  return { world, events, prepareWorld: () => preparation ? preparation.world() : world, prepareEvents: () => preparation ? preparation.events() : events };
}
/** 真实一次调用端口，也供显式owner测试；未知custom只有query和调用方已拥有的supplied窄命令。 */
export function invokeDeathHook(hook: DeathHook, world: World, ids: EntityId[], sources: DeathSources, choose: (actorId: EntityId, abilityId?: string) => Promise<DeathShotSelection>, events: GameEvent[], context?: DeathHookContext, preparation?: DeathHookPreparationSource, supplied?: object): Promise<DeathHookResult> {
  return hook(hookRuntime("death", hook, bindingSource(world, events, preparation), supplied), ids, sources, choose, context);
}
export function invokeVotedOutHook(hook: VotedOutHook, world: World, targetId: EntityId, events: GameEvent[], supplied?: object): VotedOutResult | null {
  return hook(hookRuntime("voted", hook, bindingSource(world, events), supplied), targetId);
}
export function invokeCommittedDeathWaveHook(hook: CommittedDeathWaveHook, world: World, ids: readonly EntityId[], sources: DeathSources, day: number, phase: Phase, events: GameEvent[]): void {
  hook(hookRuntime("committed", hook, bindingSource(world, events)), ids, sources, day, phase);
}

'''
s=s.replace(anchor,helpers+anchor)
s=s.replace('    private readonly deathHooks: DeathHook[] = buildDefaultDeathHooks(),\n  ) {}','    private readonly deathHooks: DeathHook[] = buildDefaultDeathHooks(),\n    private readonly suppliedPorts: ReadonlyMap<Function, object> = new Map(),\n  ) {}')
s=s.replace('const result = hook(world, targetId, events);','const result = invokeVotedOutHook(hook, world, targetId, events, this.suppliedPorts.get(hook));')
s=s.replace('    context?: DeathHookContext,\n  ): Promise<DeathHookResult> {','    context?: DeathHookContext,\n    preparation?: DeathHookPreparationSource,\n  ): Promise<DeathHookResult> {')
s=s.replace('const result = await hook(world, deadIds, deathSources, chooseDeathShot, events, context);','const result = await invokeDeathHook(hook, world, deadIds, deathSources, chooseDeathShot, events, context, preparation, this.suppliedPorts.get(hook));')
whole(p,s,'worldless hook runtime and trusted per-invocation binding')
# 保持owner原完整body，World仅在owner私有闭包，不在hook收到的运行对象内。
def owned_death(p,name):
 s=get(p); s=s.replace('import type { DeathHook } from "../../engine/hooks/registry";','import type { DeathHook } from "../../engine/hooks/registry";\nimport { ownDeathHook, type OwnedHookBindingSource } from "../../engine/hooks/owned-bindings";')
 pat=re.search(r'export const '+name+r': DeathHook = ',s);assert pat,p
 head=s[:pat.start()];body=s[pat.end():]
 # 原算法变为private resolver，接受原World与事件；public callback只可执行本族命令。
 oldsig='async (world, ids, sources, choose, events, context) =>' if body.startswith('async ') else '(world, ids, sources, choose, events, context) =>'
 assert body.startswith(oldsig),(p,body[:100])
 impl=body[len(oldsig):]
 # 由原DeathHook参数类型派生plain typed body；新增私有resolver不是另一份算法。
 sig='''function resolveOwnedDeath(source: OwnedHookBindingSource, ids: Parameters<DeathHook>[1], sources: Parameters<DeathHook>[2], choose: Parameters<DeathHook>[3], context: Parameters<DeathHook>[4]): ReturnType<DeathHook>'''
 # 不能在原body中给world/events新getter；source字段是原传入值，读取不会触及外部World getter。
 if oldsig.startswith('async'):sig='async '+sig.replace('ReturnType<DeathHook>','ReturnType<DeathHook>')
 if impl.lstrip().startswith('{'):
  impl=impl.lstrip();impl=impl.replace('{','{\n  const world = source.world, events = source.events;',1)
  impl=impl.rstrip();assert impl.endswith(';');impl=impl[:-1]
  resolver=sig+' '+impl+'\n'
 else:
  expr=impl.strip();assert expr.endswith(';');expr=expr[:-1]
  resolver=sig+' {\n  const world = source.world, events = source.events;\n  return '+expr+';\n}\n'
 public='''\n/** 本族运行hook只得到具体结算命令；cold绑定不查询名单、库存或World。 */
export const NAME: DeathHook = ownDeathHook(
  (runtime, ids, sources, choose, context) => runtime.ports.resolve(ids, sources, choose, context),
  (source) => ({ resolve: (ids: Parameters<DeathHook>[1], sources: Parameters<DeathHook>[2], choose: Parameters<DeathHook>[3], context: Parameters<DeathHook>[4]) => resolveOwnedDeath(source, ids, sources, choose, context) }),
);
'''.replace('NAME',name)
 whole(p,head+resolver+public,'owned '+name+' retains complete resolver body')
for p,n in [('backend/src/features/hunter/death-hook.ts','hunterDeathHook'),('backend/src/features/mechanical-wolf/death-hook.ts','mechanicalDeathHook'),('backend/src/features/awakened-hidden-wolf/death-hook.ts','awakenedDeathHook'),('backend/src/features/death-actions/gift-gun-death-hook.ts','giftGunDeathHook')]:owned_death(p,n)
# VotedOut两个完整owner的原body私留；publichook仅run命令。
for p,name,importpath in [('backend/src/features/red-moon/voted-out-hook.ts','redMoonVotedOutHook','../../engine/hooks/owned-bindings'),('backend/src/rulesets/idiot-exile-outcome.ts','idiotVotedOutHook','../engine/hooks/owned-bindings')]:
 s=get(p)
 if name=='redMoonVotedOutHook':
  start=s.index('export const '+name);body=s[start:].split('=>',1)[1].strip();assert body.endswith(';');body=body[:-1]
  h=s[:start]+f'import {{ ownVotedOutHook, type OwnedHookBindingSource }} from "{importpath}";\n'
  body=body.replace('{','{\n  const world = source.world, events = source.events;',1)
  r='function resolveOwnedExile(source: OwnedHookBindingSource, actorId: number): ReturnType<VotedOutHook> '+body+'\n'
 else:
  h=s[:s.index('export function '+name)]+f'import {{ ownVotedOutHook, type OwnedHookBindingSource }} from "{importpath}";\nimport type {{ VotedOutHook }} from "../engine/hooks/registry";\n'
  body=s[s.index('): VotedOutResult | null {')+len('): VotedOutResult | null '):]
  body=body.replace('{','{\n  const world = source.world, events = source.events;',1)
  r='function resolveOwnedExile(source: OwnedHookBindingSource, targetId: EntityId): VotedOutResult | null '+body+'\n'
 public=f'''\n/** 运行回调只取得本族完整免死command，不接通用World或事件数组。 */
export const {name}: VotedOutHook = ownVotedOutHook(
  (runtime, targetId) => runtime.ports.resolve(targetId),
  (source) => ({{ resolve: (targetId: number) => resolveOwnedExile(source, targetId) }}),
);\n'''
 whole(p,h+r+public,'owned exile '+name)
# EventRegistry只把真实root输入给可信invoker，不把World直接传扩展。
p='backend/src/engine/events/event-registry.ts';s=get(p).replace('  type CommittedDeathWaveHook,','  type CommittedDeathWaveHook,\n  invokeCommittedDeathWaveHook,\n  type DeathHookPreparationSource,')
s=s.replace('hook(world, deadIds, deathSources, day, phase, events);','invokeCommittedDeathWaveHook(hook, world, deadIds, deathSources, day, phase, events);')
s=s.replace('    context?: import("../hooks/registry").DeathHookContext,\n  ): Promise<DeathHookResult> {','    context?: import("../hooks/registry").DeathHookContext,\n    preparation?: DeathHookPreparationSource,\n  ): Promise<DeathHookResult> {')
s=s.replace('      context,\n    );','      context,\n      preparation,\n    );')
whole(p,s,'event dispatch uses actual narrow invocation')
# Dream的实际新query只含alive；原World参数点capture一次，保组件引用。
p='backend/src/domain/dream-night-effects.ts';s=get(p).replace('import type { World } from "./world";','import type { World } from "./world";\nimport type { AliveComponent } from "./components/alive";\nimport { COMPONENT } from "./components/names";')
s=s.replace('export interface DreamNightEffects {','''/** 运行查询对象只有原生命读取；实际对象不是World或Readonly<World>。 */
export interface DreamLifeQueries {
  alive(id: EntityId): Readonly<AliveComponent> | undefined;
}
/** 可信调用方在原World参数位置绑定；不读组件、不缓存生命或World状态。 */
export function bindDreamLifeQueries(world: World): DreamLifeQueries {
  return { alive: (id) => world.getComponent(id, COMPONENT.Alive) };
}

export interface DreamNightEffects {''').replace('world: World','queries: DreamLifeQueries')
# restore binder World signature changed by global exact text
s=s.replace('bindDreamLifeQueries(queries: DreamLifeQueries)','bindDreamLifeQueries(world: World)')
whole(p,s,'Dream methods take actual single-purpose life query')
p='backend/src/features/dreamer/night-frame.ts';s=get(p).replace('import type { DreamNightEffects }','import type { DreamNightEffects, DreamLifeQueries }')
# replace only after class; committed World WeakMap remains actual owner
at=s.index('export class DreamNightFrame');h=s[:at];b=s[at:].replace('world: World','queries: DreamLifeQueries')
b=re.sub(r'world\.getComponent\(([^,\n]+), COMPONENT\.Alive\)',r'queries.alive(\1)',b)
b=re.sub(r'\bworld\b','queries',b)
whole(p,h+b,'complete Dream frame algorithm uses narrow life query')
# all actual Dream call sites: finite known argument text, no parser/tool execution.
world_exprs=['runtime.world()','this.world','f.world','game.world','world','new World()']
method_names=['protectedTargets','immuneNightTargets','blocksNightShot','blocksNightCharm','consecutiveDeaths','linkedDeaths','expandInitialDamage']
callpaths=subprocess.check_output(['rg','-l',r'\.(protectedTargets|immuneNightTargets|blocksNightShot|blocksNightCharm|consecutiveDeaths|linkedDeaths|expandInitialDamage)\(','backend/src','backend/tests','-g','*.ts'],cwd=R,text=True).splitlines()
for p in callpaths:
 if p in ['backend/src/features/dreamer/night-frame.ts','backend/src/features/death-actions/gift-gun-death-hook.ts','backend/src/features/death-actions/native-death-shot-settlement.ts']:continue
 s=get(p);n=s
 for method in method_names:
  for arg in world_exprs:
   old='.'+method+'('+arg
   # exact expression must end in comma or close-paren, not prefix of another expression
   n=re.sub(re.escape(old)+r'(?=\s*[,\)])','.'+method+'(bindDreamLifeQueries('+arg+')',n)
 # Cupid multiline first World arg
 n=n.replace('.linkedDeaths(\n        world,','.linkedDeaths(\n        bindDreamLifeQueries(world),')
 if n==s:continue
 # derive relative path from current physical p; no module parser.
 import os
 rel=os.path.relpath('backend/src/domain/dream-night-effects',str(Path(p).parent)).replace('\\','/')
 if not rel.startswith('.'):rel='./'+rel
 pos=n.find('\nimport ');n=n[:pos+1]+f'import {{ bindDreamLifeQueries }} from "{rel}";\n'+n[pos+1:]
 whole(p,n,'Dream caller binds real single-purpose query at original arg point')
# Ghost真实窄ports对象；绑定层归本完整owner，World绝不进执行ports。
p='backend/src/features/ghost-bride/death-wave-publication.ts';s=get(p)
a=s.index('interface WeddingDeathWaveRuntime');z=s.index('export class WeddingDeathWavePublication')
s=s[:a]+'''interface WeddingDeathWaveRuntime {
  readonly world: World;
  readonly events: GameEvent[];
  readonly day: number;
  readonly phase: Phase;
}
/** 执行体只拿本族扩张、逐边婚约查询与专用事实命令；没有World或通用写回门。 */
export interface WeddingDeathWavePorts {
  expandDeaths(ids: number[], sources: DeathSources, seen: ReadonlySet<number>, nightOrigin: Set<number>): ReturnType<typeof expandWeddingDeaths>;
  currentGroup(): ReturnType<typeof weddingGroup>;
  appendPartnerDeath(group: NonNullable<ReturnType<typeof weddingGroup>>, edge: ReturnType<typeof expandWeddingDeaths>[number]): void;
}
/** 可信DR构造完整owner；只建立闭包，World/events/day/phase均在原表达式位置读取。 */
export function bindWeddingDeathWavePublication(runtime: WeddingDeathWaveRuntime): WeddingDeathWavePublication {
  return new WeddingDeathWavePublication({
    get expandDeaths() {
      const expand = expandWeddingDeaths;
      return (ids, sources, seen, nightOrigin) => expand(runtime.world, ids, sources, seen, nightOrigin);
    },
    get currentGroup() {
      const current = weddingGroup;
      return () => current(runtime.world);
    },
    appendPartnerDeath(group, edge) {
      runtime.events.push({
        timestamp: Date.now(),
        type: "ghost_bride_partner_death",
        payload: { policy: GHOST_BRIDE_POLICY, groupId: group.groupId, day: runtime.day, phase: runtime.phase, ...edge },
        audience: Object.freeze([]),
      });
    },
  });
}

'''+s[z:]
s=s.replace('constructor(private readonly runtime: WeddingDeathWaveRuntime) {}','constructor(private readonly ports: WeddingDeathWavePorts) {}')
s=s.replace('expandWeddingDeaths(this.runtime.world, ids, sources, seen, nightOrigin)','this.ports.expandDeaths(ids, sources, seen, nightOrigin)')
s=s.replace('const group = weddingGroup(this.runtime.world)!;','const group = this.ports.currentGroup()!;')
start=s.index('      this.runtime.events.push({');end=s.index('\n      });',start)+len('\n      });');s=s[:start]+'      this.ports.appendPartnerDeath(group, edge);'+s[end:]
whole(p,s,'Ghost complete publication runtime has only actual three ports')
p='backend/src/features/ghost-bride/ports.ts';edit(p,'export { WeddingDeathWavePublication } from "./death-wave-publication";','export { WeddingDeathWavePublication, bindWeddingDeathWavePublication } from "./death-wave-publication";\nexport type { WeddingDeathWavePorts } from "./death-wave-publication";','Ghost public named actual port factory')
p='backend/src/engine/death-resolution.ts';s=get(p).replace('import { WeddingDeathWavePublication }','import { bindWeddingDeathWavePublication }').replace('return new WeddingDeathWavePublication({','return bindWeddingDeathWavePublication({')
# Cold private preparation source is final arg; extensions never receive it.
anchor='''                eligibleDead: seen,
                isCurrent,
              }),
            );'''
assert s.count(anchor)==1
s=s.replace(anchor,'''                eligibleDead: seen,
                isCurrent,
              }),
              { world: () => resolution.world, events: () => resolution.events },
            );''')
# remove raw World/events from generic contribution runtime
s=s.replace('''                        get world() {
                          return resolution.world;
                        },
                        get events() {
                          return resolution.events;
                        },
''','')
whole(p,s,'DR trusted Ghost binding and private late Beauty source')
p='backend/src/engine/death-wave-contribution.ts';s=get(p).replace('import type { World } from "../domain/world";\n','').replace('  readonly world: World;\n  readonly events: GameEvent[];\n','')
s=s.replace('/** 查询在原表达式位置读取；World 的原身份供具体权威核对，不复制或冻结运行对象。 */','/** 动态贡献只可查询本波夜保护；领取和事实命令已在具体资源owner私有绑定，不给World回门。 */')
whole(p,s,'generic contribution runtime actually has no World/events')
# Beauty complete old hook resolver private + bound commands preserving late prepare read.
p='backend/src/features/wolf-beauty/death-wave-publication.ts';s=get(p)
s=s.replace('''  attemptCharmTrigger,
  commitCharmDeath,
''','')
s=s.replace('} from "./relation";','} from "./relation";\nimport { attemptCharmTrigger, commitCharmDeath } from "./relation";\nimport type { OwnedHookBindingSource } from "../../engine/hooks/owned-bindings";')
a=s.index('interface WolfBeautyDeathCommands');z=s.index('/** 一次 hook')
s=s[:a]+'''export interface WolfBeautyDeathCommands {
  attempt(binding: CharmBinding, sources: import("../../domain/model").DeathSources, nativeShots: ReadonlySet<EntityId>, seen: ReadonlySet<EntityId>, blocks: () => unknown): ReturnType<typeof attemptCharmTrigger>;
  commit(receipt: CharmClaimReceipt): ReturnType<typeof commitCharmDeath>;
  blocked(binding: CharmBinding): void;
  applied(binding: CharmBinding): void;
}
/** 可信资源绑定只捕获晚读取源；动态prepare/post对象不能取得World或source本身。 */
export function bindWolfBeautyDeathCommands(source: OwnedHookBindingSource): WolfBeautyDeathCommands {
  return {
    get attempt() {
      const attempt = attemptCharmTrigger;
      return (binding, sources, nativeShots, seen, blocks) => attempt(binding, sources, nativeShots, seen, () => source.prepareWorld(), blocks);
    },
    get commit() {
      const commit = commitCharmDeath;
      return (receipt) => commit(source.prepareWorld(), receipt);
    },
    blocked(binding) {
      source.prepareEvents().push({ timestamp: Date.now(), type: "charm_blocked", payload: { actorId: binding.actorId, targetId: binding.targetId, reason: "night_protection" } });
    },
    applied(binding) {
      source.prepareEvents().push({ timestamp: Date.now(), type: "charm_death", payload: { actorId: binding.actorId, targetId: binding.targetId } });
    },
  };
}

'''+s[z:]
s=s.replace('const attemptCharmTrigger = commands.attemptCharmTrigger;','const attemptCharmTrigger = commands.attempt;').replace('          () => runtime.world,\n','')
start=s.index('          runtime.events.push({');end=s.index('\n          });',start)+len('\n          });');s=s[:start]+'          commands.blocked(binding);'+s[end:]
s=s.replace('const commitCharmDeath = commands.commitCharmDeath;','const commitCharmDeath = commands.commit;').replace('commitCharmDeath(runtime.world, receipt)','commitCharmDeath(receipt)')
start=s.index('              runtime.events.push({');end=s.index('\n              });',start)+len('\n              });');s=s[:start]+'              commands.applied(binding);'+s[end:]
whole(p,s,'Beauty private claim/apply/fact commands with late source')
p='backend/src/features/wolf-beauty/death-hook.ts';s=get(p)
s=s.replace('import type { DeathHook } from "../../engine/hooks/registry";','import type { DeathHook } from "../../engine/hooks/registry";\nimport { ownDeathHook, type OwnedHookBindingSource } from "../../engine/hooks/owned-bindings";')
s=s.replace('import { createWolfBeautyDeathContribution }','import { createWolfBeautyDeathContribution, bindWolfBeautyDeathCommands }')
start=s.index('export const wolfBeautyDeathHook: DeathHook = async (');brace=s.index(') => {',start)+len(') => ');body=s[brace:];assert body.endswith(';\n');body=body[:-2]
old='''createWolfBeautyDeathContribution(proposals, {
        get attemptCharmTrigger() {
          return attemptCharmTrigger;
        },
        get commitCharmDeath() {
          return commitCharmDeath;
        },
      })''';assert old in body;body=body.replace(old,'createWolfBeautyDeathContribution(proposals, bindWolfBeautyDeathCommands(source))')
body=body.replace('{','{\n  const world = source.world, events = source.events;',1)
new='''async function resolveOwnedBeauty(source: OwnedHookBindingSource, ids: Parameters<DeathHook>[1], sources: Parameters<DeathHook>[2], choose: Parameters<DeathHook>[3], context: Parameters<DeathHook>[4]): ReturnType<DeathHook> '''+body+'''\n
/** 运行扩展只持本族collect命令，真实World和晚prepare读取源只在resource binder闭包内。 */
export const wolfBeautyDeathHook: DeathHook = ownDeathHook(
  (runtime, ids, sources, choose, context) => runtime.ports.collect(ids, sources, choose, context),
  (source) => ({ collect: (ids: Parameters<DeathHook>[1], sources: Parameters<DeathHook>[2], choose: Parameters<DeathHook>[3], context: Parameters<DeathHook>[4]) => resolveOwnedBeauty(source, ids, sources, choose, context) }),
);
'''
whole(p,s[:start]+new,'Beauty hook actual bounded resource command')
p='backend/src/features/wolf-beauty/ports.ts';edit(p,'export { createWolfBeautyDeathContribution } from "./death-wave-publication";','export { createWolfBeautyDeathContribution, bindWolfBeautyDeathCommands } from "./death-wave-publication";\nexport type { WolfBeautyDeathCommands } from "./death-wave-publication";','Beauty public precise owner commands')
# 狼王profile只交局部片段，避免与Pref validation整源冲突。
p='backend/src/features/wolf-king/profile.ts';s=get(p)
a=s.index('    deathHook: (world, ids, sources, choose, events, context) =>');z=s.index('    baselineAction:',a)
old=s[a:z]
body=old[old.index('resolveNativeDeathShots('):].rstrip();assert body.endswith(',');body=body[:-1]
new='''    deathHook: ownDeathHook(
      (runtime, ids, sources, choose, context) => runtime.ports.resolve(ids, sources, choose, context),
      (source) => ({ resolve: (ids: number[], sources: import("../../domain/model").DeathSources, choose: Parameters<import("../../engine/hooks/registry").DeathHook>[3], context: Parameters<import("../../engine/hooks/registry").DeathHook>[4]) => {
        const world = source.world, events = source.events;
        return '''+body+''';
      } }),
    ),
'''
edit(p,old,new,'WolfKing actual owned gun hook only local profile delta');addimport(p,'import { ownDeathHook } from "../../engine/hooks/owned-bindings";')
# output complete candidates and before plus exact text edits. Cross-owner NightPipeline is delta-only.
night_paths=set(subprocess.check_output(['rg','-l','NightStageContext|NightStageHandler','backend/src/features','-g','*.ts'],cwd=R,text=True).splitlines())|{'backend/src/engine/phases/night-pipeline.ts'}
for p,s in after.items():
 if s==before[p].get('text',''):continue
 target=C/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s)
 if p in night_paths:cross.append({'path':p,'owner':'NativePresentation','edits':[e for e in changes if e['path']==p],'candidateSHA256':hashlib.sha256(s.encode()).hexdigest()})
(O/'before.json').write_text(json.dumps({'baseCommit':B,'files':before},ensure_ascii=False,indent=2)+'\n')
(O/'edits.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
(O/'cross-owner-deltas.json').write_text(json.dumps(cross,ensure_ascii=False,indent=2)+'\n')
# Explicit no checks: only counts/bytes of prepared text.
print(json.dumps({'capturedFiles':len(before),'changedFiles':sum(s!=before[p].get('text','') for p,s in after.items()),'exactEdits':len(changes),'crossOwner':len(cross),'base':B}))
