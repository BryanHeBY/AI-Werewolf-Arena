# H02 Dream 布尔原体查询后继

父目录50源首准备与HANDOFF原样保留。本目录完整50候选中只变6源，其余44逐字复制；3新unit声明中原2体保留，追加1个真实查询读取顺序／错误／跨World反例。

## 实际边界

DreamLifeQueries现在只公开matchesAlive(id, originalThunk):boolean，不由引擎返回可写AliveComponent；外部自己持有原体并传入比较不是新的泄漏。DreamFrame仍私持原life与version，原paid current/原因累加/record不变，不克隆或冻结生命，也不代替lifeVersion。

get matchesAlive先读取原World.getComponent callee，后读取席位参数。实际原getComponent以同World receiver完成后才调用原比较右侧的life thunk；第一次查询抛错不读取该原体。新Reflect.apply.bind(Reflect)查找／分配是明确新增观察面，放在参数读取前，不称恶意JavaScript沙箱或任意全局反射等价。

所有Dream方法调用处原bindDreamLifeQueries(World表达式)继续在原参数位置，不新增组件查询。只有2真实测试callback需API同步；HookQueries.alive本来返回boolean，与此次Dream更正不同，不改。owned-hook/Beauty/Ghost程序除registry一处去any外，其余44个候选的原准备保持，不把公共返回Readonly称实际只读屏障。

## 来源／检查

before-from-parent-50是这6源的父准备全文，不冒actualGit前态；父before.json仍记录actual8dd。Root按父50+此后继或完整本目录候选合并，四跨属源仍只能局部delta避免覆盖并行稿。0产品／类型／parser／测试／门禁执行；后继是真实静态finding修正，不伪运行红。

Root同时要求registry内部hookRuntime返回精确默认HookRuntime，不用any；此额外类型表达未改变runtime。第一5源后继metadata另保first-five-*，仍是未执行的准备事实。
