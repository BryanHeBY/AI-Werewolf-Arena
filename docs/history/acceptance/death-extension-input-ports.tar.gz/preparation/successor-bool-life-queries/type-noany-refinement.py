"""纯TMP：Root静态typed要求；无any、无执行检查。"""
from pathlib import Path
import json,hashlib,difflib
D=Path('/tmp/awa-h02-death-effect-implementation/successor-bool-life-queries');C=D/'candidates'
def h(b):return hashlib.sha256(b).hexdigest()
def js(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
# 保第一5源后继metadata，不改父50。
for name in ['HANDOFF.json','source-ready.json','successor-edits.json']:
 (D/('first-five-'+name)).write_bytes((D/name).read_bytes())
records=json.loads((D/'successor-edits.json').read_text());before=json.loads((D/'before-from-parent-50.json').read_text())
p='backend/src/engine/hooks/registry.ts';a=(C/p).read_text();assert a.count('HookRuntime<any>')==1;z=a.replace('HookRuntime<any>','HookRuntime')
(C/p).write_text(z);before['files'][p]={'text':a,'sha256':h(a.encode()),'bytes':len(a.encode())};records.append({'path':p,'label':'Root static typed requirement: exact object ports/default empty command runtime; no any','beforeSHA256':h(a.encode()),'afterSHA256':h(z.encode()),'before':a,'after':z})
p='backend/src/domain/dream-night-effects.ts';f=C/p;s=f.read_text();a='return (id, original) => invoke(getComponent, world, [id, COMPONENT.Alive]) === original();';z='return (id: EntityId, original: () => Readonly<AliveComponent>) => invoke(getComponent, world, [id, COMPONENT.Alive]) === original();';assert a in s;s=s.replace(a,z);f.write_text(s)
for r in records:
 if r['path']==p:r['after']=s;r['afterSHA256']=h(s.encode())
js(D/'before-from-parent-50.json',before);js(D/'successor-edits.json',records)
patch=[]
for r in records:patch.extend(difflib.unified_diff(r['before'].splitlines(True),r['after'].splitlines(True),fromfile=r['path'],tofile=r['path'],n=4))
(D/'successor.patch').write_text(''.join(patch))
ready=json.loads((D/'source-ready.json').read_text());changed={r['path'] for r in records}
for x in ready['source']:
 b=(C/x['path']).read_bytes();x['afterSHA256']=h(b);x['afterBytes']=len(b)
ready['successorBoolLifeQueries']['changedPaths']=[r['path'] for r in records];ready['successorBoolLifeQueries']['additionalStaticPrecision']='hookRuntime uses exact default empty-command/object runtime, no any; no checks executed'
js(D/'source-ready.json',ready)
s=(D/'README.md').read_text().replace('只变5源，其余45逐字复制','只变6源，其余44逐字复制').replace('与其余45个候选的原准备保持','除registry一处去any外，其余44个候选的原准备保持').replace('这5源的父准备全文','这6源的父准备全文')
s+='\nRoot同时要求registry内部hookRuntime返回精确默认HookRuntime，不用any；此额外类型表达未改变runtime。第一5源后继metadata另保first-five-*，仍是未执行的准备事实。\n';(D/'README.md').write_text(s)
hand=json.loads((D/'HANDOFF.json').read_text());hand['changedFromParent']=[r['path'] for r in records];hand['sameFromParent']=44;hand['sourceReadySHA256']=h((D/'source-ready.json').read_bytes())
refs=[]
for p in ['prepare.py','type-noany-refinement.py','before-from-parent-50.json','successor-edits.json','successor.patch','source-ready.json','README.md','first-five-HANDOFF.json','first-five-source-ready.json','first-five-successor-edits.json']:
 b=(D/p).read_bytes();refs.append({'path':p,'sha256':h(b),'bytes':len(b)})
hand['artifacts']=refs;js(D/'HANDOFF.json',hand)
print(json.dumps({'HANDOFF':h((D/'HANDOFF.json').read_bytes()),'ready':hand['sourceReadySHA256'],'changed':len(records),'unchanged':44}))
