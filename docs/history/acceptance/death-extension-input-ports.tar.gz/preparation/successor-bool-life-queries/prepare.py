"""仅TMP Root裁定后继；父50全文不改，不执行产品或解析器。"""
from pathlib import Path
import json,shutil,difflib,hashlib
P=Path('/tmp/awa-h02-death-effect-implementation');D=P/'successor-bool-life-queries';C=D/'candidates'
def h(b):return hashlib.sha256(b).hexdigest()
def js(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
assert not C.exists();shutil.copytree(P/'candidates',C)
before={};records=[]
def update(p,fn,label):
 f=C/p;a=f.read_text();z=fn(a);assert a!=z,p;before[p]={'text':a,'sha256':h(a.encode()),'bytes':len(a.encode())};f.write_text(z);records.append({'path':p,'label':label,'beforeSHA256':h(a.encode()),'afterSHA256':h(z.encode()),'before':a,'after':z})
def contract(s):
 a=s.index('/** 运行查询对象只有');z=s.index('\nexport interface DreamNightEffects',a)
 return s[:a]+'''/** 运行查询只返回原体比较结果，不主动返回可写组件；外部自持原体不因此取得World。 */
export interface DreamLifeQueries {
  matchesAlive(id: EntityId, original: () => Readonly<AliveComponent>): boolean;
}
/** 可信调用方在原World参数位置绑定；绑定时不读组件、不缓存生命或World状态。 */
export function bindDreamLifeQueries(world: World): DreamLifeQueries {
  return {
    get matchesAlive() {
      // 原getComponent callee先于席位getter读取，原组件查询完成后才读比较右侧原体。
      // 新Reflect/bind准备在参数之前完成；调用保原World receiver，不从端口返回组件。
      const getComponent = world.getComponent;
      const invoke = Reflect.apply.bind(Reflect);
      return (id, original) => invoke(getComponent, world, [id, COMPONENT.Alive]) === original();
    },
  };
}
''' + s[z:]
update('backend/src/domain/dream-night-effects.ts',contract,'actual boolean identity query, no writable component returned; original callee before id and query before ref thunk')
def frame(s):
 for a,z in [
 ('queries.alive(targetId) === target.life','queries.matchesAlive(targetId, () => target.life)'),
 ('queries.alive(link.targetId) === link.targetLife','queries.matchesAlive(link.targetId, () => link.targetLife)'),
 ('queries.alive(link.actorId) === link.actorLife','queries.matchesAlive(link.actorId, () => link.actorLife)')]:
  assert a in s;s=s.replace(a,z)
 s=s.replace('import { COMPONENT } from "../../domain/components/names";\n','')
 return s
update('backend/src/features/dreamer/night-frame.ts',frame,'private original life refs still held by Frame; compare through boolean-only port at exact expression points')
update('backend/tests/unit/features/wolf-beauty/death-wave-publication.test.ts',lambda s:s.replace('expect(world.alive(f.target)).toBe(f.targetLife);','expect(world.matchesAlive(f.target, () => f.targetLife)).toBe(true);'),'Dream callback checks same existing life only through boolean query')
def additional(s):
 s=s.replace('// 扩展只收真实生命query；同原组件引用仍可读，World本体不再进入回调。','// 扩展只收布尔原体比较query，不取得World或由引擎返回的可写生命组件。')
 assert s.count('expect(Object.keys(current)).toEqual(["alive"]);')==2;s=s.replace('expect(Object.keys(current)).toEqual(["alive"]);','expect(Object.keys(current)).toEqual(["matchesAlive"]);')
 a='expect(current.alive(1)).toBe(world.getComponent(1, COMPONENT.Alive));';assert s.count(a)==2
 s=s.replace(a,'expect(current.matchesAlive(1, () => createAliveComponent())).toBe(false);',1)
 s=s.replace(a,'expect(current.matchesAlive(1, () => world.getComponent(1, COMPONENT.Alive)!)).toBe(true);',1)
 return s
update('backend/tests/unit/rulesets/additional-death-relations.test.ts',additional,'custom callbacks no longer receive component-returning query; all former domain/trace oracles remain')
def risk(s):
 needle='import { World } from "../../../../src/domain/world";';assert needle in s
 s=s.replace(needle,needle+'\nimport { bindDreamLifeQueries } from "../../../../src/domain/dream-night-effects";')
 return s+'''

test("narrow Dream query: boolean identity preserves callee-before-id, original receiver and query-before-reference failure", () => {
  const f = fixture(), original = f.world.getComponent(f.target, COMPONENT.Alive)!;
  const queries = bindDreamLifeQueries(f.world), trace: string[] = [];
  expect(Object.keys(queries)).toEqual(["matchesAlive"]);
  expect("world" in queries).toBe(false);
  expect("getWorld" in queries).toBe(false);
  expect("alive" in queries).toBe(false);
  Object.defineProperty(f.world, "getComponent", {
    configurable: true,
    get() {
      trace.push("callee");
      return function (this: unknown, id: number, slot: unknown) {
        trace.push("call");
        expect(this).toBe(f.world);
        expect(id).toBe(f.target);
        expect(slot).toBe(COMPONENT.Alive);
        return original;
      };
    },
  });
  const input = {
    get id() {
      trace.push("id");
      // 原callee必须已捕获；席位getter替换World方法不能改变这一次的原调用。
      Object.defineProperty(f.world, "getComponent", { configurable: true, value() { throw new Error("replacement_must_not_run"); } });
      return f.target;
    },
  };
  expect(queries.matchesAlive(input.id, () => { trace.push("original"); return original; })).toBe(true);
  expect(trace).toEqual(["callee", "id", "call", "original"]);
  const failure = new Error("dream_life_query_failed");
  let referenceReads = 0;
  Object.defineProperty(f.world, "getComponent", { configurable: true, value() { throw failure; } });
  expect(() => queries.matchesAlive(f.target, () => { referenceReads++; return original; })).toThrow(failure);
  expect(referenceReads).toBe(0);
  const other = fixture();
  expect(bindDreamLifeQueries(other.world).matchesAlive(other.target, () => original)).toBe(false);
});
'''
update('backend/tests/unit/engine/death/narrow-hook-capabilities.test.ts',risk,'append one real query risk declaration; original two runtime/native declarations body preserved')
js(D/'before-from-parent-50.json',{'kind':'exact parent50 prepared source before, not a new actualGit claim','parentHandoffSHA256':h((P/'HANDOFF.json').read_bytes()),'parentReadySHA256':h((P/'source-ready.json').read_bytes()),'files':before})
js(D/'successor-edits.json',records)
patch=[]
for r in records:patch.extend(difflib.unified_diff(r['before'].splitlines(True),r['after'].splitlines(True),fromfile=r['path'],tofile=r['path'],n=4))
(D/'successor.patch').write_text(''.join(patch))
parent=json.loads((P/'source-ready.json').read_text());changes={r['path']:r for r in records}
for x in parent['source']:
 b=(C/x['path']).read_bytes();x['candidatePath']=str(C/x['path']);x['afterSHA256']=h(b);x['afterBytes']=len(b)
parent['successorBoolLifeQueries']={'reason':'Root static H02 §6.1 finding: Readonly Alive return still leaks writable original component; true boolean query required','changedPaths':list(changes),'priorSourceReadySHA256':h((P/'source-ready.json').read_bytes()),'newRiskDeclarations':3,'checksExecuted':[]}
js(D/'source-ready.json',parent)
(D/'README.md').write_text('''# H02 Dream 布尔原体查询后继

父目录50源首准备与HANDOFF原样保留。本目录完整50候选中只变5源，其余45逐字复制；3新unit声明中原2体保留，追加1个真实查询读取顺序／错误／跨World反例。

## 实际边界

DreamLifeQueries现在只公开matchesAlive(id, originalThunk):boolean，不由引擎返回可写AliveComponent；外部自己持有原体并传入比较不是新的泄漏。DreamFrame仍私持原life与version，原paid current/原因累加/record不变，不克隆或冻结生命，也不代替lifeVersion。

get matchesAlive先读取原World.getComponent callee，后读取席位参数。实际原getComponent以同World receiver完成后才调用原比较右侧的life thunk；第一次查询抛错不读取该原体。新Reflect.apply.bind(Reflect)查找／分配是明确新增观察面，放在参数读取前，不称恶意JavaScript沙箱或任意全局反射等价。

所有Dream方法调用处原bindDreamLifeQueries(World表达式)继续在原参数位置，不新增组件查询。只有2真实测试callback需API同步；HookQueries.alive本来返回boolean，与此次Dream更正不同，不改。owned-hook/Beauty/Ghost程序及其余43?模块的原准备保持（准确数量以source-ready 50和changed5为准，不把公共返回Readonly称实际只读屏障）。

## 来源／检查

before-from-parent-50是这5源的父准备全文，不冒actualGit前态；父before.json仍记录actual8dd。Root按父50+此后继或完整本目录候选合并，四跨属源仍只能局部delta避免覆盖并行稿。0产品／类型／parser／测试／门禁执行；后继是真实静态finding修正，不伪运行红。
'''.replace('及其余43?模块的原准备保持（准确数量以source-ready 50和changed5为准，不把公共返回Readonly称实际只读屏障）','与其余45个候选的原准备保持，不把公共返回Readonly称实际只读屏障'))
refs=[]
for p in ['prepare.py','before-from-parent-50.json','successor-edits.json','successor.patch','source-ready.json','README.md']:
 b=(D/p).read_bytes();refs.append({'path':p,'sha256':h(b),'bytes':len(b)})
js(D/'HANDOFF.json',{'status':'source-ready TMP successor, no checks executed','baseCommit':parent['baseCommit'],'sourceCount':50,'newSourceCount':2,'deleted':[],'changedFromParent':list(changes),'sameFromParent':45,'parentHandoffPath':str(P/'HANDOFF.json'),'parentHandoffSHA256':h((P/'HANDOFF.json').read_bytes()),'parentReadySHA256':h((P/'source-ready.json').read_bytes()),'sourceReadySHA256':h((D/'source-ready.json').read_bytes()),'newRiskDeclarations':3,'artifacts':refs,'noRepositoryWrites':True,'noProductParserOrCheckExecution':True})
print(json.dumps({'handoff':h((D/'HANDOFF.json').read_bytes()),'ready':h((D/'source-ready.json').read_bytes()),'changed':list(changes)}))
