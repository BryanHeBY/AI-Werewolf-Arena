# H02 D/E 死亡扩展与梦效果窄端口候选

本目录只含 TMP 源候选，Root 负责实际合并和全部检查。前态固定 actual 8dd28e93；后来的 H01/Query 提交不重写前态。调用 API 有意退休，不称任意 JavaScript 等价。

## 实际职责

- 动态 DeathHook/VotedOutHook/CommittedHook 的首参为新建 query/本族 command 对象；不含 World、events、getWorld、通用组件写或实体创建。内建 hook 的实际函数身份只在静态 WeakMap 登记 cold binder；每次执行才由资源 owner 私有绑定原 World/事件。未知／克隆函数不继承命令，也不按角色或 hook id 授权。
- custom 保留通用标量／编号副本查询；已有特殊 command 由调用方显式持于自己闭包，不新增通用 object 注入或 legacy World 回门。旧 rawWorld hook API 明确退出；内建默认静态名单和顺序保持。
- Beauty 仍完整拥有 claim→保护→容器准备→实际标死后 applied／事实。可信本次绑定分别保 hook 参数与 DeathResolution 晚 prepare World／events，不把 World 提前快照到 hook。阻断先 resolved，事件失败保付费前缀。
- Ghost 完整 expand 算法只拿本族 expandDeaths/currentGroup/appendPartnerDeath 三端口。原每边 group 查询、事件 callee→时钟→字段／getter顺序保在真实资源 owner；返回对象和扩展 runtime 没有 World。
- DreamNightEffects 七方法接 DreamLifeQueries（只有 alive），绑定在每个原 World 实参位置，不提前读组件；返回同一原生命组件引用，非克隆／冻结。Dream 原已付 current、原因累加、record 与失败前缀保持。

## 集成边界

source-ready.json 列全部候选；四个跨作者源只应用 cross-owner-deltas-final.json 的局部编辑，禁止 whole 覆盖他人 WIP。其余候选亦以完整 beforeSHA 为保护。
NightPipeline 唯一生产交叉是 Dream binder import＋原 expandInitialDamage 参数点。WolfKing/profile 仅 hook/import 与 Pref validation 分别合并；configured-inspection 测试也只接原 hook 调用。
Root 的 roles/contracts/defaultRole/builtin 装配无需根据 ID 新建授权表：现 DeathHook/VotedOutHook 类型别名在原路径自然承接新 runtime；实际内建 owner 静态 own* 注册保持原 runtime contribution 函数引用。Root 可补精确契约说明，不需要第二份注册名单。

## 必要新风险

新增 unit/engine/death/narrow-hook-capabilities.test.ts 两声明：真实注册表 custom／同名函数 runtime 无 World 或内建命令；真实 Hunter pass 仅消费所属原 World，同 Error 选择失败保未付库存。原实际调用测试随 API 局部迁移，原标题／机器文本／业务字面预期保；Beauty 单元用可信 owner 私有源保原 getter 轨迹，Ghost 用真实 binder 代替旧 rawWorld constructor。

## 观察面与验证计划

新 command lookup／闭包分配／query 调用是明确代码 API 变化；不是恶意 JS sandbox，不承诺任意模块反射或任意自定义 getter 的全行为等价。原 builtin 资源体、callee/receiver、重复组件查询、paid/current 和首错误须由 Root 对原体映射及真实风险核对。
本作者未执行产品、类型、业务、parser 或门禁。Root 联合其余 H02/H03 source-ready 后统一有限 types；新 unit 首跑与必要旧精准调用输入由 Root 选择，不复既有绿。

## 来源记录

prepare-first-failed.py 是首次 TMP 文本组装器 import 锚点失败，发生任何候选输出之前；它不是产品或测试红。first-draft-snapshot.json/refinements/test-api/final-source-refinements/unused-supply-trim 保存后续纯文本准备阶段。exact-edits-final.json 是固定 before→当前完整候选的精确文本重建输入，不冒 AST／类型／运行证明。

## 首ready静态后继

首49源ready和完整文本差分均原样保存为first-*-snapshot。后继只增加实际additional-death-relations测试的两处Dream callback首参身份断言适配，旧trace/容器/事件/receiver字面断言保。新50源不宣称额外检查已运行。
