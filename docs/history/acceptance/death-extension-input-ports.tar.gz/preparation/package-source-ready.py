"""仅纯数据/Git对象来源整理，不调用产品、TS/AST parser或任何检查器。"""
from pathlib import Path
import subprocess,json,hashlib,difflib,os,stat
D=Path('/tmp/awa-h02-death-effect-implementation');C=D/'candidates';R=Path('/home/hby/dev/AI-Werewolf-Arena')
B=json.loads((D/'before.json').read_text());base=B['baseCommit'];bf=B['files']
def h(v):return hashlib.sha256(v).hexdigest()
def js(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
changed=[];deltas=[];diff=[];absences=[]
cross={'backend/src/engine/phases/night-pipeline.ts':'NativePresentation NightStageContext集成', 'backend/tests/scenarios/features/radiant-eclipse/paid-dream-effects.test.ts':'NativePresentation 夜stage custom fixture集成', 'backend/src/features/wolf-king/profile.ts':'Root集中合并Pref validation，局部hook/import', 'backend/tests/unit/mechanisms/configured-inspection-and-death-policy-instances.test.ts':'Root/H03当前fixture局部delta'}
for f in sorted(C.rglob('*.ts')):
 p=str(f.relative_to(C));z=f.read_text();old=bf.get(p)
 if old and old.get('text')==z:continue
 if not old or 'text' not in old:
  q=subprocess.run(['git','-C',str(R),'cat-file','-e',base+':'+p],capture_output=True)
  assert q.returncode!=0,p
  old={'expectedAbsent':True};bf[p]=old;absences.append({'path':p,'command':['git','cat-file','-e',base+':'+p],'exitCode':q.returncode,'stdout':q.stdout.decode(),'stderr':q.stderr.decode()});a=''
 else:a=old['text']
 es=[]
 for tag,a0,a1,z0,z1 in difflib.SequenceMatcher(None,a,z,autojunk=False).get_opcodes():
  if tag!='equal':es.append({'start':a0,'end':a1,'before':a[a0:a1],'after':z[z0:z1]})
 # exact reconstruction is producer bookkeeping, not program proof.
 t=a
 for e in reversed(es):assert t[e['start']:e['end']]==e['before'];t=t[:e['start']]+e['after']+t[e['end']:]
 assert t==z
 entry={'path':p,'mode':old.get('mode','100644'),'beforeSHA256':old.get('sha256'),'afterSHA256':h(z.encode()),'beforeBytes':len(a.encode()),'afterBytes':len(z.encode()),'expectedAbsent':old.get('expectedAbsent',False),'candidatePath':str(f),'mergeOwner':cross.get(p),'edits':es}
 changed.append({k:v for k,v in entry.items() if k!='edits'});deltas.append(entry)
 diff.extend(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile=p,tofile=p,n=4))
controls=[]
for p in ['backend/src/domain/random.ts','backend/src/domain/components/alive.ts','packages/game-contract/src/role-ids.ts','packages/game-contract/src/facts/ghost-bride.ts']:
 b=subprocess.check_output(['git','-C',str(R),'show',base+':'+p]);tree=subprocess.check_output(['git','-C',str(R),'ls-tree',base,'--',p],text=True).split('\t')[0].split();cur=(R/p).read_bytes();mode='100755' if (R/p).stat().st_mode&stat.S_IXUSR else '100644';assert b==cur and tree[0]==mode,p
 controls.append({'path':p,'mode':tree[0],'blob':tree[2],'sha256':h(b),'bytes':len(b),'text':b.decode(),'currentSameAtCapture':True})
js(D/'before.json',B);js(D/'source-ready.json',{'baseCommit':base,'currentHEADAtSampling':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'kind':'prepared TMP source only; no product/check/parser execution','source':changed,'deleted':[],'controls':controls,'newAbsenceReceipts':absences,'crossOwnerMergePaths':cross,'checksExecuted':[]})
js(D/'exact-edits-final.json',deltas);(D/'candidate.patch').write_text(''.join(diff))
js(D/'cross-owner-deltas-final.json',[d for d in deltas if d['path'] in cross])
(D/'README.md').write_text('''# H02 D/E 死亡扩展与梦效果窄端口候选

本目录只含 TMP 源候选，Root 负责实际合并和全部检查。前态固定 actual 8dd28e93；后来的 H01/Query 提交不重写前态。调用 API 有意退休，不称任意 JavaScript 等价。

## 实际职责

- 动态 DeathHook/VotedOutHook/CommittedHook 的首参为新建 query/本族 command 对象；不含 World、events、getWorld、通用组件写或实体创建。内建 hook 的实际函数身份只在静态 WeakMap 登记 cold binder；每次执行才由资源 owner 私有绑定原 World/事件。未知／克隆函数不继承命令，也不按角色或 hook id 授权。
- custom 保留通用标量／编号副本查询；已有特殊 command 由调用方显式持于自己闭包，不新增通用 object 注入或 legacy World 回门。旧 rawWorld hook API 明确退出；内建默认静态名单和顺序保持。
- Beauty 仍完整拥有 claim→保护→容器准备→实际标死后 applied／事实。可信本次绑定分别保 hook 参数与 DeathResolution 晚 prepare World／events，不把 World 提前快照到 hook。阻断先 resolved，事件失败保付费前缀。
- Ghost 完整 expand 算法只拿本族 expandDeaths/currentGroup/appendPartnerDeath 三端口。原每边 group 查询、事件 callee→时钟→字段／getter顺序保在真实资源 owner；返回对象和扩展 runtime 没有 World。
- DreamNightEffects 七方法接 DreamLifeQueries（只有 alive），绑定在每个原 World 实参位置，不提前读组件；返回同一原生命组件引用，非克隆／冻结。Dream 原已付 current、原因累加、record 与失败前缀保持。

## 集成边界

source-ready.json 列全部候选；四个跨作者源只应用 cross-owner-deltas-final.json 的局部编辑，禁止 whole 覆盖他人 WIP。其余候选亦以完整 beforeSHA 为保护。
NightPipeline 唯一生产交叉是 Dream binder import＋原 expandInitialDamage 参数点。WolfKing/profile 仅 hook/import 与 Pref validation 分别合并；configured-inspection 测试也只接原 hook 调用。
Root 的 roles/contracts/defaultRole/builtin 装配无需根据 ID 新建授权表：现 DeathHook/VotedOutHook 类型别名在原路径自然承接新 runtime；实际内建 owner 静态 own* 注册保持原 runtime contribution 函数引用。Root 可补精确契约说明，不需要第二份注册名单。

## 必要新风险

新增 unit/engine/death/narrow-hook-capabilities.test.ts 两声明：真实注册表 custom／同名函数 runtime 无 World 或内建命令；真实 Hunter pass 仅消费所属原 World，同 Error 选择失败保未付库存。原实际调用测试随 API 局部迁移，原标题／机器文本／业务字面预期保；Beauty 单元用可信 owner 私有源保原 getter 轨迹，Ghost 用真实 binder 代替旧 rawWorld constructor。

## 观察面与验证计划

新 command lookup／闭包分配／query 调用是明确代码 API 变化；不是恶意 JS sandbox，不承诺任意模块反射或任意自定义 getter 的全行为等价。原 builtin 资源体、callee/receiver、重复组件查询、paid/current 和首错误须由 Root 对原体映射及真实风险核对。
本作者未执行产品、类型、业务、parser 或门禁。Root 联合其余 H02/H03 source-ready 后统一有限 types；新 unit 首跑与必要旧精准调用输入由 Root 选择，不复既有绿。

## 来源记录

prepare-first-failed.py 是首次 TMP 文本组装器 import 锚点失败，发生任何候选输出之前；它不是产品或测试红。first-draft-snapshot.json/refinements/test-api/final-source-refinements/unused-supply-trim 保存后续纯文本准备阶段。exact-edits-final.json 是固定 before→当前完整候选的精确文本重建输入，不冒 AST／类型／运行证明。
''')
refs=[]
for p in ['before.json','source-ready.json','exact-edits-final.json','candidate.patch','cross-owner-deltas-final.json','README.md','prepare-first-failed.py','prepare.py','first-draft-snapshot.json','refine.py','refinements.json','adapt-tests.py','test-api-edits.json','finalize-source.py','final-source-refinements.json','trim-unused-supply.py','unused-supply-trim.json']:
 f=D/p;b=f.read_bytes();refs.append({'path':p,'sha256':h(b),'bytes':len(b)})
js(D/'HANDOFF.json',{'status':'source-ready prepared; no checks executed','baseCommit':base,'sourceReadySHA256':h((D/'source-ready.json').read_bytes()),'sourceCount':len(changed),'newSourceCount':sum(x['expectedAbsent'] for x in changed),'deleted':[],'crossOwnerMergePaths':cross,'controls':len(controls),'newRiskTest':'backend/tests/unit/engine/death/narrow-hook-capabilities.test.ts','newRiskDeclarations':2,'artifacts':refs,'noRepositoryWrites':True,'noProductParserOrCheckExecution':True})
print(json.dumps({'sourceCount':len(changed),'new':sum(x['expectedAbsent'] for x in changed),'HANDOFF':h((D/'HANDOFF.json').read_bytes()),'sourceReady':h((D/'source-ready.json').read_bytes())}))
