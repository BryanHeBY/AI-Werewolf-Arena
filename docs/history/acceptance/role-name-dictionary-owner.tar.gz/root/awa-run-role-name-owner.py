"""Root按已封存命名源阶段执行有限包/消费者测试与类型项目，净环境且分阶段收据。"""
from pathlib import Path
import json,subprocess,hashlib,sys,time,os
repo=Path('/home/hby/dev/AI-Werewolf-Arena');work=Path('/tmp/awa-role-name-owner-execution-successor');data=json.loads((work/'formatted-source.json').read_text());task=sys.argv[1];sha=lambda b:hashlib.sha256(b).hexdigest();test='packages/game-text/tests/role-names.test.ts'
commands={
 'baseline':('packages/game-text',['/usr/bin/bun','--no-env-file','test','tests/role-names.test.ts'],120),
 'catalog-tests':('packages/game-catalog',['/usr/bin/bun','--no-env-file','test','tests'],180),
 'text-tests':('packages/game-text',['/usr/bin/bun','--no-env-file','test','tests'],180),
 'backend-consumers':('backend',['/usr/bin/bun','--no-env-file','test','--preload','./tests/setup.ts','tests/unit/mechanisms/role-catalog-contract.test.ts','tests/unit/presentation/i18n-contract.test.ts','tests/unit/presentation/bilingual-console.test.ts','tests/integration/tooling/role-rule-card-references.test.ts'],180),
 'catalog-types':('packages/game-catalog',['/usr/bin/bun','--no-env-file','node_modules/typescript/bin/tsc','-p','tsconfig.json','--noEmit'],300),
 'catalog-test-types':('packages/game-catalog',['/usr/bin/bun','--no-env-file','node_modules/typescript/bin/tsc','-p','tsconfig.tests.json','--noEmit'],300),
 'text-types':('packages/game-text',['/usr/bin/bun','--no-env-file','node_modules/typescript/bin/tsc','-p','tsconfig.json','--noEmit'],300),
 'text-test-types':('packages/game-text',['/usr/bin/bun','--no-env-file','node_modules/typescript/bin/tsc','-p','tsconfig.tests.json','--noEmit'],300),
 'backend-test-types':('backend',['/usr/bin/bun','--no-env-file','node_modules/typescript/bin/tsc','-p','tsconfig.tests.json','--noEmit'],300)}
assert task in commands
out=Path('/var/tmp/awa-refactor-20261015/role-name-owner')/task;out.mkdir(parents=True)
for x in ('home','tmp','cache'):(out/x).mkdir()
def fence():
 for r in data['source']:
  p=repo/r['path'];expected=r['sha256'] if task!='baseline' or r['path']==test else r['beforeSha256']
  if expected is None:assert not p.exists(),r['path']
  else:assert p.is_file() and sha(p.read_bytes())==expected,r['path']
 for r in data['controls']:assert sha((repo/r['path']).read_bytes())==r['sha256'],r['path']
 return {'sourcePaths':13,'controlPaths':7,'stage':'one new test over old production' if task=='baseline' else 'all13 formatted source inputs','sourceManifestSHA256':sha((work/'formatted-source.json').read_bytes())}
pre=fence();cwd,argv,timeout=commands[task];env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','CI':'1','BUN_RUNTIME_EXECUTABLE':'/usr/bin/bun','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'cache'),'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'};start=time.time()
with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:r=subprocess.run(argv,cwd=repo/cwd,env=env,stdout=a,stderr=b,timeout=timeout)
post=fence();value={'id':task,'preparedBase':data['preparedBase'],'actualIntegrationBase':data['actualIntegrationBase'],'argv':argv,'cwd':str(repo/cwd),'environment':env,'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'pre':pre,'post':post,'raw':[{'path':x,'sha256':sha((out/x).read_bytes()),'bytes':(out/x).stat().st_size} for x in ('stdout.raw','stderr.raw')]};(out/'receipt.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({'task':task,'exitCode':r.returncode,'seconds':value['elapsedSeconds'],'root':str(out)}));raise SystemExit(r.returncode)
