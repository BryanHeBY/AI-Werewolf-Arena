/** 核对新名称词典在实际引擎指纹中，保留旧固定源与当前源身份，不修改历史档案。 */
import { writeFile } from 'node:fs/promises';
import { engineFingerprintInputs, fingerprintEngine } from '/home/hby/dev/AI-Werewolf-Arena/backend/src/recording/reproduction/engine-fingerprint';
const current='/home/hby/dev/AI-Werewolf-Arena';
const before='/var/tmp/awa-refactor-20261015/c47-07ef28ef/snapshot';
const [oldNames,newNames,oldIdentity,newIdentity]=await Promise.all([engineFingerprintInputs(before),engineFingerprintInputs(current),fingerprintEngine(before),fingerprintEngine(current)]);
const added=newNames.filter(n=>!oldNames.includes(n));const removed=oldNames.filter(n=>!newNames.includes(n));
if(JSON.stringify(added)!==JSON.stringify(['packages/game-text/src/role-names.ts'])||removed.length||oldIdentity.sourceHash===newIdentity.sourceHash||oldIdentity.lockHash===newIdentity.lockHash)throw Error('fingerprint membership or identity wrong');
const report={scope:'actual engine source membership/byte hash, not C47 full-public snapshot or crossbuild compatibility',beforeFixedCommit:'07ef28ef06f2579a6e7fb7467bca588c87608348',integrationBase:'8dd28e93ded9eeb04fdd49d1a1e6d369f8649f3b',beforeRoot:before,currentRoot:current,oldIdentity,newIdentity,added,removed,oldCount:oldNames.length,newCount:newNames.length,newInputs:newNames};
await writeFile('/tmp/awa-role-name-owner-execution-successor/fingerprint-proof.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({added,removed,oldCount:oldNames.length,newCount:newNames.length,sourceChanged:true,lockChanged:true}));
