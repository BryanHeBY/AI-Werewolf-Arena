from pathlib import Path
import subprocess, hashlib, json, re, difflib
REPO=Path('/home/hby/dev/AI-Werewolf-Arena')
OUT=Path('/tmp/awa-role-name-dictionary-owner')
BASE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=[
 'packages/game-catalog/src/index.ts',
 'packages/game-text/src/index.ts',
 'packages/game-text/src/role-names.ts',
 'packages/game-text/package.json',
 'bun.lock',
 'packages/game-catalog/tests/package-contract.test.ts',
 'packages/game-catalog/tests/owner-boundary.test.ts',
 'packages/game-text/tests/package-contract.test.ts',
 'packages/game-text/tests/role-names.test.ts',
 'backend/tests/unit/mechanisms/role-catalog-contract.test.ts',
 'backend/tests/unit/presentation/i18n-contract.test.ts',
 'backend/tests/unit/presentation/bilingual-console.test.ts',
 'backend/tests/integration/tooling/role-rule-card-references.test.ts',
]
controls=[
 'packages/game-contract/src/identity.ts',
 'packages/game-contract/src/role-ids.ts',
 'packages/game-contract/src/locale.ts',
 'packages/game-text/src/messages/catalog.ts',
 'backend/src/rulesets/roles/catalog.ts',
 'backend/src/agents/presentation/text-localization-registry.ts',
 'frontend/src/replay/replay-localization.ts',
]
before=[]; originals={}
for path in paths+controls:
 entry=subprocess.check_output(['git','ls-tree',BASE,'--',path],cwd=REPO,text=True).strip()
 if not entry:
  assert not (REPO/path).exists(),path
  before.append({'path':path,'exists':False,'kind':'source' if path in paths else 'control'})
  continue
 mode,kind,rest=entry.split(' ',2);blob=rest.split('\t')[0]
 data=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=REPO)
 assert data==(REPO/path).read_bytes(),path
 originals[path]=data.decode()
 dest=OUT/'before'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 before.append({'path':path,'kind':'source' if path in paths else 'control','exists':True,'mode':mode,'blob':blob,'sha256':sha(data),'bytes':len(data),'text':data.decode()})
(OUT/'before.json').write_text(json.dumps({'base':BASE,'records':before,'limits':['Only these owned and control sources are asserted Git-identical; concurrent Root fixture WIP is not part of this scope.']},ensure_ascii=False,indent=2)+'\n')
proposal={'status':'prepared_tmp_only_not_executed','base':BASE,'plan':'docs/guides/refactoring-plan.md §12 / original user plan §12','ownedPaths':paths,'sourceCount':13,'productionAndDependencyPaths':paths[:5],'tests':paths[5:],'controls':controls,'api':{'catalogRetired':['RoleDefinition.names','ROLE_DEFINITIONS[n].names','roleName'],'catalogRetained':['ROLE_DEFINITIONS (same order and remaining metadata)','RoleDefinition (remaining metadata)','roleDefinition','RULESET'],'textRetained':['roleName(id:string,locale:Locale="zh-CN"):string','all 11 existing root runtime exports'],'newOwner':'packages/game-text/src/role-names.ts (private 64-label dictionary and the existing public operation, no World/rule/permission dependency)','names':{'total':64,'runtime':55,'planned':9,'languages':['zh-CN','en'],'literalValuesMustRemainEqual':128},'dependencies':'Remove only game-text → game-catalog in package.json and matching bun.lock workspace dependency. Catalog still only depends on game-contract; text only depends on game-contract.'},'acceptancePolicies':{'locale':'Keep isLocale check before name lookup; default zh-CN unchanged.','unknown':'Strict ID equality lookup then original id fallback, without object-key coercion, escaping, interpolation, normalization or accepting invalid locale.','custom':'RoleCatalog and TextLocalizationRegistry retain all existing late lookup, built-in equality, explicit custom/empty string override and user text policies; no production edits to them.','catalogMutation':'Retired names API is no longer a writable input to text lookup. No compatibility mirror, new catalog→text forwarding or unknown deep-import compatibility is promised.','sourceHash':'Paths/source/lexical bytes and lock change; strict current recordings require the new same-build source/lock. Raw golden/history bytes are untouched.'},'testsPlan':['Move full original 64×2 name outputs into literal package test expectations, not a second production truth.','Catalog package/namespace tests assert names and roleName retirement while retaining all stable metadata and rule references.','Existing public text and backend coverage use contract ROLE_IDS; registry tests compare the actual registry→text route, retaining all user/unknown/default assertions.','Keep existing invalid locale and custom profile tests, and add focused role-name invalid locale, unknown/prototype-like IDs, interleaving and no string coercion coverage.'],'pendingChecks':'No products, parser/AST, formatter, types, tests or gates have run. Root owns all actual application/execution.','documentation':'MIGRATION.md in this TMP bundle provides a bounded catalog API retirement and old/new import guide; do not overwrite the pending C48 guide.'}
(OUT/'proposal.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'base':BASE,'proposalSha256':sha((OUT/'proposal.json').read_bytes()),'beforeSha256':sha((OUT/'before.json').read_bytes()),'source':len(paths),'controls':len(controls)},ensure_ascii=False))
