# 角色名称唯一归属与 API 迁移（候选）

本批按计划 §12 将角色显示名称放入 `packages/game-text/src/role-names.ts`。这是完整名称查询职责迁移，不新增角色或变更规则。当前候选基于 `07ef28ef06f2579a6e7fb7467bca588c87608348` 的精确源字节，尚未应用或运行检查；不代表 C47／全目标通过。

## 调用方迁移

```ts
// 旧入口有意退出
import { roleName } from "@ai-werewolf-arena/game-catalog";

// 当前文案入口，签名和默认语言保持
import { roleName } from "@ai-werewolf-arena/game-text";
```

`RoleDefinition.names` 和 `ROLE_DEFINITIONS[n].names` 一并退出。资料仍由 catalog 提供：`id`、`status`、`targetPhase`、`ruleCardRef`、`mechanismSummary` 及原顺序不变；需要语言标签时调用 `roleName(entry.id, locale)`。规则、请求、事实、归档继续传机器 ID，不写显示名称。

catalog 不导入 game-text，不保存名称镜像，也不保留无消费者的旧转发。其根运行出口由四个减为三个：`ROLE_DEFINITIONS`、`roleDefinition`、`RULESET`。game-text 的原十一个根运行出口保持，私有词典不新增根 API。未知外部深路径、namespace key、`RoleDefinition.names` 字段和经 catalog 修改名字的旧能力有意退休，不承诺兼容。此前通过未类型化写入 catalog ID／名称再影响格式化的耦合也不保留。

## 语言与用户原文

原六十四个 ID／顺序和一百二十八个中文／英文名称逐项保留，包括九个只有资料的规划身份。`roleName` 仍默认 `zh-CN`，先检查原 `isLocale`；非法语言仍报 `i18n_locale_invalid`，不回退到另一语言。未知 ID 原样返回，不转为占位模板、不规范化或转义。查询保严格相等，避免把 `constructor`／`__proto__` 误当名称或强制转换 caller 的未知对象。

运行 `RoleCatalog.label` 与 `TextLocalizationRegistry.roleName` 不改：原显式用户 profile／注册覆盖（包括空串）、昵称、人格、原文和 built-in 相等策略继续由这些 owner 决定。名称表不授予行动、阵营、库存或注册资格。MessageKey、规则卡、机器值、请求字段和既有完整句子模板不变。

## 验证与历史

`name-literal-equality.json` 保存原固定来源与每项候选／测试字面值的相等数据；这是准备阶段文本对照，不是运行证明。新 `role-names.test.ts` 的固定测试数据来自迁移前完整名称快照，运行预期不读取新生产词典。它逐项断言六十四个 ID 的两种输出，并独立覆盖未知／原文／locale。其余测试改为真实文案路由，资料／规则卡断言保持。

只从 game-text 的 package 与 bun.lock 对应 workspace 项移除不再使用的 catalog 依赖；其余锁字节和版本保持，不安装依赖。路径、代码和 lock 的变更会改变严格复现来源指纹；当前构建按既有同构建严格合同生成／重放。此批不改 Tape 结构版本、不重写历史或 raw golden、不修改历史包桥证明，也不把旧构建成功当新来源成功。

Root 需按最终实际 source 运行共享包／必要后端路由与 custom 文本测试、有限类型和来源证明；所有运行结果当前待填写。

## 与最终文档汇合

这一小段说明供 Root 合入将发布的 `docs/guides/migration.md`，不覆盖仍待 World 后继的 C48 草稿。现行 README 第 12 行仍称 catalog 拥有中英名称，Root 发布时应同步为 catalog 稳定资料、game-text 名称词典；本包 source 仍严格为已批准十三路径。
