from pathlib import Path
import json,re,hashlib,subprocess
OUT=Path('/tmp/awa-role-name-dictionary-owner');REPO=Path('/home/hby/dev/AI-Werewolf-Arena')
sha=lambda b:hashlib.sha256(b).hexdigest()
before=json.loads((OUT/'before.json').read_text()); base=before['base']; ready=json.loads((OUT/'source-ready.json').read_text()); proposal=json.loads((OUT/'proposal.json').read_text()); original={r['path']:r for r in before['records'] if r['exists']}
queries=[('name-fields',r'\.names\b|\["names"\]|\[\x27names\x27\]'),('catalog-symbols',r'\bROLE_DEFINITIONS\b|\bRoleDefinition\b|\broleDefinition\b|game-catalog'),('role-name-consumers',r'\broleName\b')]
raws=[]
for name,pattern in queries:
 argv=['rg','-n',pattern,'backend','frontend','packages','tooling','--glob','*.ts','--glob','*.tsx','--glob','*.js','--glob','*.mjs','--glob','*.cjs','--glob','*.json','-g','!**/fixtures/**','-g','!**/node_modules/**']
 p=subprocess.run(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert p.returncode in (0,1)
 target=OUT/(name+'.txt');target.write_bytes(p.stdout)
 raws.append({'argv':argv,'output':target.name,'exit':p.returncode,'sha256':sha(p.stdout),'bytes':len(p.stdout),'lines':len(p.stdout.splitlines())})
name_fields=[
 {'path':'packages/game-catalog/src/index.ts','role':'only original production names64 data and raw catalog lookup; retired/moved'},
 {'path':'packages/game-catalog/tests/package-contract.test.ts','role':'names/nonempty/catalog lookup tests move to text owner; metadata and retirement assertions retained'},
 {'path':'packages/game-text/tests/package-contract.test.ts','role':'old wrapper-to-catalog self comparison replaced by contract-ID coverage; exact128 is new owner test'},
 {'path':'backend/tests/unit/presentation/i18n-contract.test.ts','role':'all64 names coverage moved off catalog names to ROLE_IDS; original custom profile body untouched'},
 {'path':'backend/tests/unit/presentation/bilingual-console.test.ts','role':'Registry→game-text route checked over same64 IDs; unknown/default/custom literals unchanged'},
 {'path':'backend/tests/integration/tooling/role-rule-card-references.test.ts','role':'names read from text; real filesystem ruleCardRef assertions unchanged'},
]
parsed=[]
raw=(OUT/'role-name-consumers.txt').read_text()
for line in raw.splitlines():
 path,num,content=line.split(':',2)
 parsed.append({'path':path,'line':int(num),'text':content})
files=sorted({r['path'] for r in parsed})
nav=[]
for path in files:
 data=(REPO/path).read_bytes(); text=data.decode()
 if path.startswith('packages/game-catalog/'):
  classification='retired catalog definition/test API'
 elif path=='packages/game-text/src/index.ts':
  classification='original one production catalogRoleName delegate; moved to owned module'
 elif 'import' in text and '@ai-werewolf-arena/game-text' in text:
  classification='existing game-text import route; only the four owned tests are edited, other callers keep code'
 elif path=='frontend/src/replay/replay-localization.ts':
  classification='existing sharedRoleName local presentation adapter'
 elif '/night-frame.ts' in path:
  classification='roleName field stores machine role/body snapshot, not translated name; untouched'
 elif path.endswith('/engine/agent-visible-event-feed.test.ts'):
  classification='local findRole parameter is machine identity, not name formatter; untouched'
 else:
  classification='static navigation/reference or test expectation; not automatically a name data owner'
 nav.append({'path':path,'sha256':sha(data),'bytes':len(data),'classification':classification,'matches':[x for x in parsed if x['path']==path]})
# Every retained metadata character/order is identical after deleting the original names lines.
cat='packages/game-catalog/src/index.ts';after=(OUT/'candidates'/cat).read_text();old=original[cat]['text']
old_body=old.split('export const ROLE_DEFINITIONS = [',1)[1].split('] as const satisfies readonly RoleDefinition[];',1)[0]
new_body=after.split('export const ROLE_DEFINITIONS = [',1)[1].split('] as const satisfies readonly RoleDefinition[];',1)[0]
without_names=re.sub(r'    names: \{ "zh-CN": "[^"\n]*", en: "[^"\n]*" \},\n','',old_body)
assert new_body==without_names
metadata={'status':'prepared_exact_text_data_only','base':base,'allRetainedMetadataBodySame':True,'normalizedOriginalBodySha256':sha(without_names.encode()),'candidateBodySha256':sha(new_body.encode()),'records':64,'preservedFields':['id','status','targetPhase','ruleCardRef','mechanismSummary'],'catalogPublicRuntimeNamesBefore':['ROLE_DEFINITIONS','roleDefinition','roleName','RULESET'],'catalogPublicRuntimeNamesAfter':['ROLE_DEFINITIONS','roleDefinition','RULESET'],'textRootExistingPublicNamesUnchanged':11,'privateDictionaryNotRootExported':True,'dependencyChange':{'package':'game-text','deletedDependency':'@ai-werewolf-arena/game-catalog','packageOnlyOneLineRemoved':True,'lockOnlyOneLineRemoved':True},'limits':['These are exact prepared text facts, not executed namespace/AST/type/emit or behavior proof.']}
pkg='packages/game-text/package.json';lock='bun.lock'
assert (OUT/'candidates'/pkg).read_text()==original[pkg]['text'].replace('    "@ai-werewolf-arena/game-catalog": "workspace:*",\n','',1)
# The matching lock edit remains constrained by the whole workspaces entry in edits.json.
locktext=(OUT/'candidates'/lock).read_text();assert len(original[lock]['text'].splitlines())-len(locktext.splitlines())==1
(OUT/'retained-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
consumer={'status':'static_text_inventory_not_ast','base':base,'nameFieldConsumers':name_fields,'catalogRoleNameProductionConsumer':{'path':'packages/game-text/src/index.ts','oldImport':'roleName as catalogRoleName','oldCall':'return catalogRoleName(id, locale);','newOwner':'./role-names'},'directCatalogRoleNameOtherConsumers':['packages/game-catalog/tests/package-contract.test.ts','backend/tests/unit/mechanisms/role-catalog-contract.test.ts'],'allRoleNameNavigation':nav,'queryReceipts':raws,'nonDisplayMatches':['tooling/refactor/fixture-manifest.ts route.names/packageRoute.names are module binding names, not translated role labels.','backend/src/domain/world.ts entitiesWith(...names) is component naming, not RoleDefinition.names.','night-frame roleName fields preserve machine RoleComponent.role snapshots and authority comparisons.'],'historicalBoundaries':['tooling/refactor/fixture-manifest.ts historicalSourcePackages originalFiles reads frozen Git package data for old Locale bridge; current package/old fixture bytes are not regenerated by this proposal.','No current fixture sourceAssets/moduleRelocations refer to these dictionary candidates; frozen historical package sources remain immutable.','Message templates containing a role name inside a complete sentence remain owned by existing messages modules; they are not a second role-label lookup table.'],'limits':['Read-only text searches and actual caller bodies, not a TypeScript parser run.','Unknown external code importing retired catalog roleName or reading/mutating names is intentionally unsupported after this change; no namespace reflection compatibility claim is made.','Existing direct game-text callers, custom RoleProfile and Registry implementations are not rewritten.']}
(OUT/'consumer-inventory.json').write_text(json.dumps(consumer,ensure_ascii=False,indent=2)+'\n')
migration='''# 角色名称唯一归属与 API 迁移（候选）

本批按计划 §12 将角色显示名称放入 `packages/game-text/src/role-names.ts`。这是完整名称查询职责迁移，不新增角色或变更规则。当前候选基于 `'''+base+'''` 的精确源字节，尚未应用或运行检查；不代表 C47／全目标通过。

## 调用方迁移

```ts
// 旧入口有意退出
import { roleName } from "@ai-werewolf-arena/game-catalog";

// 当前文案入口，签名和默认语言保持
import { roleName } from "@ai-werewolf-arena/game-text";
```

`RoleDefinition.names` 和 `ROLE_DEFINITIONS[n].names` 一并退出。资料仍由 catalog 提供：`id`、`status`、`targetPhase`、`ruleCardRef`、`mechanismSummary` 及原顺序不变；需要语言标签时调用 `roleName(entry.id, locale)`。规则、请求、事实、归档继续传机器 ID，不写显示名称。

catalog 不导入 game-text，不保存名称镜像，也不保留无消费者的旧转发。其根运行出口由四个减为三个：`ROLE_DEFINITIONS`、`roleDefinition`、`RULESET`。game-text 的原十一个根运行出口保持，私有词典不新增根 API。未知外部深路径、namespace key、`RoleDefinition.names` 字段和经 catalog 修改名字的旧能力有意退休，不承诺兼容。此前通过未类型化写入 catalog ID／名称再影响格式化的耦合也不保留。

## 语言与用户原文

原六十四个 ID／顺序和一百二十八个中文／英文名称逐项保留，包括九个只有资料的规划身份。`roleName` 仍默认 `zh-CN`，先检查原 `isLocale`；非法语言仍报 `i18n_locale_invalid`，不回退到另一语言。未知 ID 原样返回，不转为占位模板、不规范化或转义。查询保严格相等，避免把 `constructor`／`__proto__` 误当名称或强制转换 caller 的未知对象。

运行 `RoleCatalog.label` 与 `TextLocalizationRegistry.roleName` 不改：原显式用户 profile／注册覆盖（包括空串）、昵称、人格、原文和 built-in 相等策略继续由这些 owner 决定。名称表不授予行动、阵营、库存或注册资格。MessageKey、规则卡、机器值、请求字段和既有完整句子模板不变。

## 验证与历史

`name-literal-equality.json` 保存原固定来源与每项候选／测试字面值的相等数据；这是准备阶段文本对照，不是运行证明。新 `role-names.test.ts` 的固定测试数据来自迁移前完整名称快照，运行预期不读取新生产词典。它逐项断言六十四个 ID 的两种输出，并独立覆盖未知／原文／locale。其余测试改为真实文案路由，资料／规则卡断言保持。

只从 game-text 的 package 与 bun.lock 对应 workspace 项移除不再使用的 catalog 依赖；其余锁字节和版本保持，不安装依赖。路径、代码和 lock 的变更会改变严格复现来源指纹；当前构建按既有同构建严格合同生成／重放。此批不改 Tape 结构版本、不重写历史或 raw golden、不修改历史包桥证明，也不把旧构建成功当新来源成功。

Root 需按最终实际 source 运行共享包／必要后端路由与 custom 文本测试、有限类型和来源证明；所有运行结果当前待填写。

## 与最终文档汇合

这一小段说明供 Root 合入将发布的 `docs/guides/migration.md`，不覆盖仍待 World 后继的 C48 草稿。现行 README 第 12 行仍称 catalog 拥有中英名称，Root 发布时应同步为 catalog 稳定资料、game-text 名称词典；本包 source 仍严格为已批准十三路径。
'''
(OUT/'MIGRATION.md').write_text(migration)
review={'status':'author_static_prepared','base':base,'ownedPaths':proposal['ownedPaths'],'sourceReadySha256':sha((OUT/'source-ready.json').read_bytes()),'conclusions':['All64 id expressions, order and128 name literal values retained in the unique new text owner.','All remaining catalog metadata bytes and ordering retained. Catalog localized API retirement is explicit.','Production consumers already route through game-text; original direct catalog delegate replaced once. No catalog→text dependency.','Original isLocale-first/default-zh/strict-ID/fallback preserved in prepared code; no new World/rule/framework.','Custom profile/Registry implementations and their existing literal assertions remain unmodified.','Historical source/package inputs and raw fixture/history bytes are outside this source scope and untouched.'],'intentionalNewObservations':['Private name table construction now belongs to text, not mutable exported catalog records. Name function source path/body identity changes.','Importing game-text no longer initializes catalog metadata. There are no added clocks, callbacks, registration or process/I/O actions.','Catalog root namespace loses roleName and data records lose names. Untyped mutation of retired catalog inputs no longer affects text.'],'checksRun':[],'notClaimed':['AST/NodeArray/token/emit equality','type or runtime tests','formatter stability','full C47 acceptance','arbitrary global intrinsic monkey-patch or unknown external API compatibility']}
(OUT/'author-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
# Original sources stay a fixed identity even if Root advances unrelated fixture commits.
current=[]
for r in before['records']:
 p=REPO/r['path']
 same=(not p.exists()) if not r['exists'] else (p.is_file() and sha(p.read_bytes())==r['sha256'])
 current.append({'path':r['path'],'kind':r['kind'],'originalBeforeSameAtHandoff':same})
assert all(x['originalBeforeSameAtHandoff'] for x in current)
(OUT/'source-observation.json').write_text(json.dumps({'baseOfBefore':base,'headAtObservation':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'records':current,'claim':'Only owned/control current bytes are bound; no whole repository clean/fixed assertion.'},ensure_ascii=False,indent=2)+'\n')
artifacts=[]
for f in sorted(OUT.rglob('*')):
 if f.is_file() and f.name!='HANDOFF.json':
  b=f.read_bytes();artifacts.append({'path':str(f.relative_to(OUT)),'sha256':sha(b),'bytes':len(b)})
h={'status':'prepared_bounded_candidate_not_applied_not_executed','base':base,'sourceCount':13,'existing11New2':True,'orderedSource':ready['sources'],'deleted':[],'controls':[{'path':p,**{k:original[p][k] for k in ['sha256','bytes','mode','blob']}} for p in proposal['controls']],'proposalSha256':sha((OUT/'proposal.json').read_bytes()),'sourceReadySha256':sha((OUT/'source-ready.json').read_bytes()),'patchSha256':sha((OUT/'candidate.patch').read_bytes()),'nameLiteralEqualitySha256':sha((OUT/'name-literal-equality.json').read_bytes()),'metadataPreservationSha256':sha((OUT/'retained-metadata.json').read_bytes()),'consumerInventorySha256':sha((OUT/'consumer-inventory.json').read_bytes()),'migrationNoteSha256':sha((OUT/'MIGRATION.md').read_bytes()),'artifacts':artifacts,'execution':{'authorProductParserFormatterTypesTestsGates':0,'repoWrites':0},'limits':review['notClaimed'],'integration':'Root alone applies after checking final current SHA, formats, executes necessary focused inputs, reviews and commits. No network/install or historical file updates.'}
(OUT/'HANDOFF.json').write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'handoffSha256':sha((OUT/'HANDOFF.json').read_bytes()),'consumerInventorySha256':h['consumerInventorySha256'],'migrationNoteSha256':h['migrationNoteSha256'],'artifacts':len(artifacts),'roleNameTextNavigationFiles':len(nav)},ensure_ascii=False))
