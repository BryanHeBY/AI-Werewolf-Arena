from pathlib import Path
import json, re, hashlib, difflib
OUT=Path('/tmp/awa-role-name-dictionary-owner')
j=json.loads((OUT/'before.json').read_text()); BASE=j['base']; sha=lambda b:hashlib.sha256(b).hexdigest()
old={x['path']:x['text'] for x in j['records'] if x['exists']}
texts={p:old[p] for p in json.loads((OUT/'proposal.json').read_text())['ownedPaths'] if p in old}
edits=[]
def replace(path,before,after,n=1):
 assert texts[path].count(before)==n,(path,before,texts[path].count(before))
 for _ in range(n):
  offset=texts[path].index(before)
  edits.append({'path':path,'offsetAtApplication':offset,'before':before,'after':after})
  texts[path]=texts[path][:offset]+after+texts[path][offset+len(before):]
# This is bounded literal extraction from the already read fixed source; no TypeScript parser or product is loaded.
cat='packages/game-catalog/src/index.ts'
pattern=re.compile(r'    id: ([^\n]+),\n    names: \{ "zh-CN": "([^"\n]*)", en: "([^"\n]*)" \},\n')
labels=pattern.findall(texts[cat]); assert len(labels)==64
identity=old['packages/game-contract/src/identity.ts']; roleids=old['packages/game-contract/src/role-ids.ts']
role_body=identity.split('export enum Role {',1)[1].split('\n}',1)[0]
role_values=dict(re.findall(r'  (\w+) = "([^"\n]+)",',role_body))
planned_body=roleids.split('export const PLANNED_ROLE_IDS = {',1)[1].split('\n}',1)[0]
planned_values=dict(re.findall(r'  (\w+): "([^"\n]+)",',planned_body))
def resolve(expr):
 if expr.startswith('`${Role.') and expr.endswith('}`'):
  return role_values[expr[len('`${Role.'):-len('}`')]]
 if expr.startswith('PLANNED_ROLE_IDS.'):
  return planned_values[expr[len('PLANNED_ROLE_IDS.'):]]
 raise AssertionError(expr)
resolved=[(resolve(expr),zh,en) for expr,zh,en in labels]
assert len({x[0] for x in resolved})==64
assert sum(expr.startswith('PLANNED_ROLE_IDS.') for expr,_,_ in labels)==9
replace(cat,' * 输入为契约包的稳定 ID；输出按原顺序提供双语名称、交付状态和现行规则卡引用。\n',' * 输入为契约包的稳定 ID；输出按原顺序提供交付状态、规则来源和现行规则卡引用。\n')
replace(cat,' * 资料描述角色，不授予执行许可；机器 ID、枚举与语言的唯一所有者仍是契约包。\n',' * 资料描述角色，不授予执行许可；机器 ID 与枚举仍归契约包，双语名称由 game-text 词典提供。\n')
replace(cat,'import { Role, PLANNED_ROLE_IDS, type Locale } from "@ai-werewolf-arena/game-contract";','import { Role, PLANNED_ROLE_IDS } from "@ai-werewolf-arena/game-contract";')
replace(cat,'  readonly names: Readonly<Record<Locale, string>>;\n','')
for _,zh,en in labels:
 replace(cat,f'    names: {{ "zh-CN": "{zh}", en: "{en}" }},\n','')
replace(cat,'export function roleName(id: string, locale: Locale): string {\n  return roleDefinition(id)?.names[locale] ?? id;\n}\n','')
# Dictionary and existing public formatter operation are owned together. The array is module-private.
name_path='packages/game-text/src/role-names.ts'
name_source='''/**
 * 负责六十四个稳定角色 ID 的中文／英文名称词典及公开名称查询；包括五十五个运行身份和九个规划身份。
 * 输入为原角色 ID 与显式语言，输出原名称字面值；未知 ID 原样返回，不将用户文字当 key、占位模板或运行许可。
 * 名称只在本模块维护，资料状态与规则卡仍由 game-catalog 拥有；本模块仅依赖机器契约，不加载 Catalog、World 或规则。
 * 私有表按原目录顺序保存，不公开第二个可写名称入口；查找保严格相等，不通过对象属性索引强制转换未知输入。
 */
import { Role, PLANNED_ROLE_IDS, isLocale, type Locale } from "@ai-werewolf-arena/game-contract";

/** 双语字符串是显示资料，不是阵营、库存或身份转换的权威；规划名称不代表已注册 profile。 */
const roleNames = [
'''
for expr,zh,en in labels:
 name_source+=f'  {{ id: {expr}, names: {{ "zh-CN": "{zh}", en: "{en}" }} }},\n'
name_source+=''' ] as const satisfies readonly {
  readonly id: string;
  readonly names: Readonly<Record<Locale, string>>;
}[];

/** 先核原 locale；默认中文、未知 ID 回退与调用间语言隔离均保持，不回退到另一语言。 */
export function roleName(id: string, locale: Locale = "zh-CN"): string {
  if (!isLocale(locale)) throw new Error("i18n_locale_invalid");
  return roleNames.find((item) => item.id === id)?.names[locale] ?? id;
}
'''.replace(' ] as const','] as const')
texts[name_path]=name_source
idx='packages/game-text/src/index.ts'
replace(idx,'import { roleName as catalogRoleName } from "@ai-werewolf-arena/game-catalog";','import { roleName } from "./role-names";')
replace(idx,'export function roleName(id: string, locale: Locale = "zh-CN"): string {\n  if (!isLocale(locale)) throw new Error("i18n_locale_invalid");\n  return catalogRoleName(id, locale);\n}','export { roleName };')
pkg='packages/game-text/package.json';replace(pkg,'    "@ai-werewolf-arena/game-catalog": "workspace:*",\n','')
lock='bun.lock'
replace(lock,'    "packages/game-text": {\n      "name": "@ai-werewolf-arena/game-text",\n      "version": "0.1.0",\n      "dependencies": {\n        "@ai-werewolf-arena/game-catalog": "workspace:*",\n',
'    "packages/game-text": {\n      "name": "@ai-werewolf-arena/game-text",\n      "version": "0.1.0",\n      "dependencies": {\n')
# Catalog tests now protect the remaining metadata and actual retired API, not a compatibility text mirror.
p='packages/game-catalog/tests/package-contract.test.ts'
replace(p,' * 包单元测试负责目录公开资料及与机器契约的关系，不导入后端引擎。输入为字面覆盖、机器 ID 与双语名称，输出以原断言核对。',' * 包单元测试负责目录公开资料及与机器契约的关系，不导入后端引擎。输入为字面覆盖、机器 ID 与规则引用，输出核对完整资料及名称 API 退出。')
replace(p,'import { ROLE_DEFINITIONS, roleDefinition, roleName } from "@ai-werewolf-arena/game-catalog";','import { ROLE_DEFINITIONS, roleDefinition } from "@ai-werewolf-arena/game-catalog";')
replace(p,'test("all catalog entries have both names and delivered entries cite a rule contract",','test("all catalog entries retain metadata and delivered entries cite a rule contract",')
replace(p,'      for (const locale of LOCALES) {\n        expect(role.names[locale].trim()).not.toBeEmpty();\n        expect(roleName(role.id, locale)).toBe(role.names[locale]);\n      }','      expect(Object.hasOwn(role, "names")).toBe(false);')
replace(p,'    expect(roleName("wolf", "zh-CN")).toBe("狼人");\n    expect(roleName("wolf", "en")).toBe("Werewolf");\n','')
replace(p,'test("unknown names remain raw data and machine locale inputs are exact",','test("unknown IDs remain absent and machine locale inputs are exact",')
replace(p,'    expect(roleName("Custom {role}", "en")).toBe("Custom {role}");\n','')
p='packages/game-catalog/tests/owner-boundary.test.ts'
replace(p,' * 输出用字面四个运行出口和逐项类型拒绝核对，元数据不冒充机器契约或角色执行许可。',' * 输出用字面三个运行出口和逐项类型拒绝核对，元数据不冒充文案、机器契约或角色执行许可。')
replace(p,'export type RetiredCatalogContracts = [','// @ts-expect-error 角色名称查询已迁入 game-text，目录不保反向依赖或长期转发。\nimport type { roleName } from "@ai-werewolf-arena/game-catalog";\n\n// @ts-expect-error 双语名称字段已退出目录资料，由 game-text 的名称词典独占。\nexport type RetiredCatalogNames = catalog.RoleDefinition["names"];\n\nexport type RetiredCatalogContracts = [\n  typeof roleName,')
replace(p,'test("catalog runtime namespace contains exactly its four metadata owners",','test("catalog runtime namespace contains exactly its three metadata owners",')
replace(p,'    "roleName",\n','')
p='packages/game-text/tests/package-contract.test.ts'
replace(p,' * 独立字面输出、完整键／占位符比较核对文本格式；角色名另与实际目录元数据比较，不冒充独立角色规则预期。',' * 独立字面输出、完整键／占位符比较核对文本格式；本包覆盖六十四个机器 ID 的名称，完整双语字面预期另见 role-names 单元测试。')
replace(p,'import { ROLE_DEFINITIONS } from "@ai-werewolf-arena/game-catalog";','import { ROLE_IDS } from "@ai-werewolf-arena/game-contract";')
replace(p,'test("literal bilingual outputs and role metadata preserve the public contract",','test("literal bilingual outputs and role labels preserve the public contract",')
replace(p,'      for (const role of ROLE_DEFINITIONS)\n        expect(roleName(role.id, locale)).toBe(role.names[locale]);','      for (const id of ROLE_IDS) expect(roleName(id, locale)).not.toBe(id);')
# Independent literal snapshot belongs to tests only; original names remain unedited.
p='packages/game-text/tests/role-names.test.ts'
name_test='''/**
 * 包单元测试负责角色名称词典及原回退政策。输入为迁移前冻结的六十四组独立字面预期、未知文字与显式语言；
 * 输出逐项核对一百二十八个名称，不从本次生产表生成运行预期，也不把名称／规划身份当成规则支持证明。
 * 另外核对未知 ID 原样返回、中文默认、无共享语言状态及 locale 错误；不运行角色、World、Provider 或归档重放。
 */
import { expect, test } from "bun:test";
import { ROLE_IDS, type Locale } from "@ai-werewolf-arena/game-contract";
import { roleName } from "@ai-werewolf-arena/game-text";

// 这是原公共输出的测试快照，不是第二份生产词典；来源及逐项原／新相等记录随本批 before 包保存。
const expectedNames = [
'''
for id,zh,en in resolved:
 name_test+=f'  ["{id}", "{zh}", "{en}"],\n'
name_test+=''' ] as const;

test("all 64 names preserve both original literal locales and stable ID order", () => {
  expect(expectedNames.map(([id]) => id)).toEqual(ROLE_IDS);
  expect(new Set(expectedNames.map(([id]) => id)).size).toBe(64);
  for (const [id, chinese, english] of expectedNames) {
    expect(roleName(id, "zh-CN")).toBe(chinese);
    expect(roleName(id, "en")).toBe(english);
  }
});

test("role name fallback preserves original user text and never selects object prototype names", () => {
  for (const id of ["Custom {role}", "用户原文\\nExact label", "", "constructor", "__proto__", "toString"])
    for (const locale of ["zh-CN", "en"] as const) expect(roleName(id, locale)).toBe(id);
  const opaque = {
    toString() {
      throw new Error("must_not_coerce_role_id");
    },
  };
  // 公共类型仍为 string；保原未类型化 caller 的严格相等／原值回退，不新增隐式 String 或 schema 准入。
  expect(roleName(opaque as unknown as string, "en")).toBe(opaque as unknown as string);
});

test("role name locale validation and explicit interleaving keep the original policy", () => {
  expect(roleName("wolf")).toBe("狼人");
  expect([roleName("wolf", "en"), roleName("wolf", "zh-CN"), roleName("wolf", "en")]).toEqual([
    "Werewolf",
    "狼人",
    "Werewolf",
  ]);
  for (const locale of ["zh", "en-US", "EN", "", null, 3, {}])
    expect(() => roleName("Custom {role}", locale as Locale)).toThrow("i18n_locale_invalid");
});
'''.replace(' ] as const','] as const')
texts[p]=name_test
p='backend/tests/unit/mechanisms/role-catalog-contract.test.ts'
replace(p,'import { ROLE_DEFINITIONS, roleName } from "@ai-werewolf-arena/game-catalog";','import { ROLE_DEFINITIONS } from "@ai-werewolf-arena/game-catalog";\nimport { roleName } from "@ai-werewolf-arena/game-text";')
p='backend/tests/unit/presentation/i18n-contract.test.ts'
replace(p,' * 单元测试：验证双语词典 key、占位符、不可变性及共享角色资料。输入为原机器 ID、字面参数',' * 单元测试：验证双语词典 key、占位符、不可变性及共享角色名称覆盖。输入为原机器 ID、字面参数')
replace(p,'import { ROLE_DEFINITIONS } from "@ai-werewolf-arena/game-catalog";','import { ROLE_IDS } from "@ai-werewolf-arena/game-contract";')
replace(p,'test("supported machine IDs have shared labels and all 64 role names remain catalog owned",','test("supported machine IDs have shared labels and all 64 role names are text owned",')
replace(p,'    for (const role of ROLE_DEFINITIONS) expect(roleName(role.id, locale)).toBe(role.names[locale]);','    // 完整双语字面快照由共享名称 owner 的测试保存；本层核公开机器 ID 均走文案回退而非裸 ID。\n    for (const id of ROLE_IDS) expect(roleName(id, locale)).not.toBe(id);')
p='backend/tests/unit/presentation/bilingual-console.test.ts'
replace(p,'import { ROLE_DEFINITIONS } from "@ai-werewolf-arena/game-catalog";','import { ROLE_IDS } from "@ai-werewolf-arena/game-contract";\nimport { roleName } from "@ai-werewolf-arena/game-text";')
replace(p,'  for (const role of ROLE_DEFINITIONS) {\n    expect(registry.roleName(role.id, "en")).toBe(role.names.en);\n    expect(registry.roleName(role.id)).toBe(role.names["zh-CN"]);\n  }','  // 核实际 Registry → 文案 owner 的路由；两语全部字面值另由共享词典测试独立核对。\n  for (const id of ROLE_IDS) {\n    expect(registry.roleName(id, "en")).toBe(roleName(id, "en"));\n    expect(registry.roleName(id)).toBe(roleName(id));\n  }')
p='backend/tests/integration/tooling/role-rule-card-references.test.ts'
replace(p,' * 文件系统 catalog 集成测试以公开词典项及其引用的仓库文档为输入，核对维护的双语身份名及真实规则卡引用。非空名称和精确文件／锚点存在为预期；不执行身份规则，也不从文档推断玩法准入。',' * 文件系统 catalog 集成测试以稳定资料、文案 owner 的名称及引用的仓库文档为输入，核对名称覆盖和真实规则卡引用。非空名称和精确文件／锚点存在为预期；不执行身份规则，也不从文档推断玩法准入。')
replace(p,'import { ROLE_DEFINITIONS } from "@ai-werewolf-arena/game-catalog";','import { ROLE_DEFINITIONS } from "@ai-werewolf-arena/game-catalog";\nimport { roleName } from "@ai-werewolf-arena/game-text";')
replace(p,'    expect(entry.names["zh-CN"].trim().length).toBeGreaterThan(0);\n    expect(entry.names.en.trim().length).toBeGreaterThan(0);','    expect(roleName(entry.id, "zh-CN").trim().length).toBeGreaterThan(0);\n    expect(roleName(entry.id, "en").trim().length).toBeGreaterThan(0);')
# Save full candidates and exact byte-oriented static preparation records. No source is loaded/evaluated.
owned=json.loads((OUT/'proposal.json').read_text())['ownedPaths']
for p in owned:
 f=OUT/'candidates'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(texts[p])
for p in set(x['path'] for x in edits):
 forward=old[p]
 for e in [x for x in edits if x['path']==p]:
  at=e['offsetAtApplication']; assert forward[at:at+len(e['before'])]==e['before']
  forward=forward[:at]+e['after']+forward[at+len(e['before']):]
 assert forward==texts[p]
 reverse=texts[p]
 for e in reversed([x for x in edits if x['path']==p]):
  at=e['offsetAtApplication']; assert reverse[at:at+len(e['after'])]==e['after']
  reverse=reverse[:at]+e['before']+reverse[at+len(e['after']):]
 assert reverse==old[p]
(OUT/'edits.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
patch=''
for p in owned:
 patch+=''.join(difflib.unified_diff(old.get(p,'').splitlines(True),texts[p].splitlines(True),fromfile=('a/'+p if p in old else '/dev/null'),tofile='b/'+p))
(OUT/'candidate.patch').write_text(patch)
# Exact old/new literal data proof: unlike a runtime/AST proof this only attests prepared text.
module_labels=re.findall(r'  \{ id: ([^\n]+), names: \{ "zh-CN": "([^"\n]*)", en: "([^"\n]*)" \} \},',texts[name_path])
assert module_labels==labels
expected_labels=re.findall(r'  \["([^"\n]+)", "([^"\n]*)", "([^"\n]*)"\],',texts['packages/game-text/tests/role-names.test.ts'])
assert expected_labels==resolved
proof=[]
for index,((expr,zh,en),(id,_,_)) in enumerate(zip(labels,resolved),1):
 proof.append({'index':index,'idExpression':expr,'resolvedStableId':id,'original':{'zh-CN':zh,'en':en},'candidate':{'zh-CN':module_labels[index-1][1],'en':module_labels[index-1][2]},'literalTestExpectation':{'zh-CN':expected_labels[index-1][1],'en':expected_labels[index-1][2]},'equal':True})
(OUT/'name-literal-equality.json').write_text(json.dumps({'status':'prepared_text_data_only_not_runtime_test','base':BASE,'count':64,'runtime':55,'planned':9,'languageValues':128,'allEqual':True,'originalSourceSha256':sha(old[cat].encode()),'candidateDictionarySha256':sha(texts[name_path].encode()),'candidateLiteralTestSha256':sha(texts['packages/game-text/tests/role-names.test.ts'].encode()),'originalOrderAndIdExpressionsPreserved':True,'records':proof,'limits':['Constrained literal extraction and comparison from fixed already-read sources; no TypeScript parser, compiler, formatter, product or test was executed.','Runtime locale/fallback/lookup behavior is for Root focused validation; this text data is not such a result.']},ensure_ascii=False,indent=2)+'\n')
ready=[]
for p in owned:
 b=texts[p].encode();br=next(x for x in j['records'] if x['path']==p)
 ready.append({'path':p,'mode':br.get('mode','100644'),'beforeExists':br['exists'],'beforeSha256':br.get('sha256'),'sha256':sha(b),'bytes':len(b)})
(OUT/'source-ready.json').write_text(json.dumps({'status':'prepared_tmp_only','base':BASE,'sources':ready,'deleted':[],'edits':len(edits),'newSources':2,'repositoryApplied':False,'checksRun':[],'limits':['Root has not applied or executed these candidates. No TypeScript parsing/format/type/test/gate/product execution occurred.','Source file paths and program output will change intentionally; exact inverse and names equality are prepared text data, not full program equivalence.']},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidatePaths':len(owned),'existingExactEdits':len(edits),'literalValues':128,'sourceReadySha256':sha((OUT/'source-ready.json').read_bytes()),'patchSha256':sha((OUT/'candidate.patch').read_bytes()),'literalSha256':sha((OUT/'name-literal-equality.json').read_bytes())},ensure_ascii=False))
