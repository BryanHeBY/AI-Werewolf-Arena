# 五场景输入修复独立静态审查

结论：**approved_as_prepared_bounded_test_input_repair**，未运行任何产品、TS/parser、编译、测试或检查，也未写仓库。

固定 actual `7a85ad67ac808aab3e1d6d91078262a64382ca93` 的五完整源、mode/blob/SHA与当前源逐项核对；10精确替换记录／18实际位置正逆均同。全部原test标题行及expect行原字节保；完整inverse也约束所有非编辑区，未隐藏删减断言或付款预期。目录实际proposal材料是HANDOFF、STATIC-REVIEW、edits和patch，没有独立proposal.json；一次寻找该文件的read失败只属审查工具假设，不是产品/测试红。

## 具体结论

1. Wild13：九处正常setup输入接bootstrap已安装的同引用boardConfig。setup实际先拒raw config身份，原raw helper及DR输入不动，原五已正确canonical的死因测试不需重跑。
2. Radiant1：原强cast缺完整deck／Sheriff等政策，真实失败在BoardParameters的preset准入。现有公开12牌恰与手写World的Eclipse/Radiant/Seer/Witch/Dreamer/4Villager/3Wolf匹配。两stage与原pending/reentry字面oracle未动；新增本地公开JSON读取不是模型/网络或生产oracle。
3. Runner2：store真正收到版本envelope，故旧data.result漏掉磁盘注入。filename先短路再既有reader解包，仍抛同一个persistence并保原write.call receiver；AggregateError中四个原对象的先后与全部其它断言不变。
4. Animal2：Trace onChange是原构造保存的普通实例属性（TS private readonly不等于运行freeze）；manager回调才委托lifecycle.scheduleFlush。局部wrapper只在原paid库存已写且首次命中时throw。原commit→closed→settle顺序使Trace已落action/结算计数后通知失败，异常不回到早已返回的deferred decide try；原事实尚未发表。fired后及未命中仍按原receiver调用回调，原付款/效果/无publication/状态/严格归档和伪改拒绝均保。此处不声称是公开API或可任意注入的产品服务。
5. Wall1：原配置在bootstrap后改raw对象不会影响已clone/freeze的RulePlan。本候选只把原相同两字段移到bootstrap前，boolean默认false且仅该测试传true；真实投票前自爆入口因此接收到预期输入。原actor、动作、两周期、blasted及零补发断言全保；与另一作者Wall null/reject生产修复分开。

## 失败范围和后继

只为固定partial31-block里已观测的19个具体runtime测试名准备过滤命令：13＋1＋2＋2＋1。它不是19条源码test语句，不是A lane全suite计数/终态。Root已中断错误sandbox能力环境的原heavy场景，不能从这份静态审查推断场景全绿。五源候选没有加入付费服务、模型或外网；runner仍使用已有mock factory和synthetic-unused配置。

`failed-only19-command.json` 提供唯一19标题与完整argv；只有Root确认Wall及其他生产源已完整就绪、应用候选并核actualSHA后才执行。不要重跑原Wild已绿五死因或runner两个replayable变体。审查没有为绿放宽生产准入、归档schema、错误对象或原assert。
