from pathlib import Path
import json,hashlib,subprocess,re,collections,shlex
R=Path('/home/hby/dev/AI-Werewolf-Arena');D=Path('/tmp/awa-c47-scenario-input-repair');O=Path('/tmp/awa-c47-scenario-input-repair-independent');B='7a85ad67ac808aab3e1d6d91078262a64382ca93'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,d):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
h=json.loads((D/'HANDOFF.json').read_text());e=json.loads((D/'edits.json').read_text());assert h['baseCommit']==B and e['baseCommit']==B
bindings=[]
for a in h['artifacts']:
 b=(D/a['path']).read_bytes();assert sha(b)==a['sha256'] and len(b)==a['bytes'];bindings.append({'path':str(D/a['path']),'sha256':sha(b),'bytes':len(b)})
source=[];allOcc=0
for row in h['source']:
 p=row['path'];old=(D/row['beforePath']).read_bytes();new=(D/row['candidatePath']).read_bytes();actual=(R/p).read_bytes();g=subprocess.check_output(['git','show',B+':'+p],cwd=R)
 meta=subprocess.check_output(['git','ls-tree',B,'--',p],cwd=R).decode().strip().split('\t')[0].split()
 assert meta[0]==row['mode'] and meta[2]==row['blob'];assert old==g and sha(old)==row['beforeSha256'] and sha(new)==row['candidateSha256']
 f=old.decode();steps=[x for x in e['records'] if x['path']==p];inverseSteps=[]
 for x in steps:
  positions=[m.start() for m in re.finditer(re.escape(x['before']),f)];assert len(positions)==x['occurrences']
  afterPositions=[pos+i*(len(x['after'])-len(x['before'])) for i,pos in enumerate(positions)]
  for pos in reversed(positions):f=f[:pos]+x['after']+f[pos+len(x['before']):]
  inverseSteps.append((x,afterPositions));allOcc+=x['occurrences']
 assert f.encode()==new
 for x,positions in reversed(inverseSteps):
  for pos in reversed(positions):assert f[pos:pos+len(x['after'])]==x['after'];f=f[:pos]+x['before']+f[pos+len(x['after']):]
 assert f.encode()==old
 oldlines=old.decode().splitlines();newlines=new.decode().splitlines()
 assert [x for x in oldlines if 'expect(' in x or 'expect.' in x]==[x for x in newlines if 'expect(' in x or 'expect.' in x]
 assert [x for x in oldlines if re.search(r'\btest\(',x)]==[x for x in newlines if re.search(r'\btest\(',x)]
 assert ('100755' if (R/p).stat().st_mode&0o100 else '100644')==row['mode']
 source.append({'path':p,'mode':row['mode'],'blob':row['blob'],'beforeSha256':sha(old),'candidateSha256':sha(new),'currentSha256':sha(actual),'currentStillWholeBase':actual==old,'wholeForwardInverse':True,'exactRecordCount':len(steps),'occurrences':sum(x['occurrences'] for x in steps),'expectContainingLinesUnchanged':True,'testTitleLinesUnchanged':True})
assert allOcc==18 and len(e['records'])==10
items=json.loads((D/'diagnosis/own-selected-blocks.json').read_text())['items'];assert len(items)==19
selected=[]
for x in items:
 m=re.fullmatch(r'\(fail\) (.*) \[[^\n]*ms\]',x['title']);assert m,x['title'];selected.append({'file':x['file'],'title':m.group(1),'originalFailureBlockSHA256':sha(x['block'].encode()),'diagnosisRawLine':x['line']})
assert len({(x['file'],x['title']) for x in selected})==19
byfile=collections.defaultdict(list)
for x in selected:byfile[x['file']].append(x['title'])
assert sorted(map(len,byfile.values()))==[1,1,2,2,13]
argv=['bun','--no-env-file','test','--preload','./tests/setup.ts',*byfile.keys(),'--test-name-pattern','^(?:'+'|'.join(re.escape(x['title']) for x in selected)+')$']
commands={'kind':'prepared-only-failed-observed-runtime-test-names','executionOwner':'Root','cwd':str(R/'backend'),'selectedTests':selected,'expectedSelectedRuntimeNames':19,'sourceFiles':5,'argv':argv,'shellCommand':'cd '+shlex.quote(str(R/'backend'))+' && '+shlex.join(argv),'executionPrerequisites':['Root先完成Wall生产修复并确认可加载fence','Root按exact5候选应用且核mode/SHA','只执行19原已观测失败名，不重五个已绿Wild死因及runner两replayable变体'],'notExecuted':True,'limits':['19为实际已注册/观测runtime测试名；for loops展开不能当19个源码test语句。','原raw是固定partial31block，并非被中断scenario suite终态总数。','单个失效用例内部原循环/断言不拆成新测试，原标题保。']}
dump('failed-only19-command.json',commands)
refs=json.loads((D/'read-inputs.json').read_text())['references'];actualrefs=[]
for row in refs:
 p=row['path'];current=(R/p).read_bytes();old=subprocess.check_output(['git','show',B+':'+p],cwd=R)
 assert sha(old)==row['fixedBaseSha256']
 actualrefs.append({'path':p,'fixedBaseSha256':sha(old),'currentAtIndependentReviewSha256':sha(current),'currentSameAsFixedBase':current==old,'classification':'reference not immutable control; C46 public path/head or Root Wall repairs may be successor bytes'})
findings=[
 {'group':'WildChild','observedRuntimeNames':13,'change':'九个正常setup调用传已绑定boardConfig，不改raw fixture/helper/DR参数','realProducerConsumer':['app/bootstrap createPlayers: compile/bind BoardParameters, installWildChild(config)','features/wild-child/setup.ts execute: config !== b.config guard before choice/provider','tests same-file five death-source cases already use boardConfig'],'preserved':'原生命/引用/Camp/Victory、波次、知识/无getter访问、错误/事实/零激活断言；不是放宽setup'},
 {'group':'RadiantReentry','observedRuntimeNames':1,'change':'删强cast不完整config，使用现有公开12板经既有parseBoardDefinition','realProducerConsumer':['rulesets/board-parameters compile: boardPresetViolation before schema','engine/phases/night-pipeline execute → prepareNightPipelineLifecycle → bindBoardParameters','features/radiant-eclipse preset requires complete role deck and sheriff/policies'],'preserved':'手写World真实12牌恰匹配该preset；原两stage/getStages、pending borrowedDream/source suppression和radiant_night_reentry及零lease close断言均不变；未从生产输出生成预期'},
 {'group':'RunnerDisk','observedRuntimeNames':2,'change':'filename===replay.json后readReplayDocument(data).result.reason','realProducerConsumer':['recording/session/recorder persistFinalRecord → buildReplayArchive → writeJsonStrict replay.json','public replay-contract reader returns original payload','scenario spy throws original persistence object then original write.call receiver'],'preserved':'四原Error对象顺序(first,second,cleanup,persistence)、关闭一次/清空pending、raw不泄漏错误文字、AbortError和no gateway原断言；两replayable variants不在filter'},
 {'group':'AnimalPaidRecording','observedRuntimeNames':2,'change':'只包装本trace实际onChange；原manager.scheduleFlush已不是实际入口','realProducerConsumer':['recording/reproduction/trace constructor stores ordinary private readonly onChange; no #field/freeze','recording/session/recorder beginReproduction callback: dirtyReproduction=true → lifecycle.scheduleFlush','features/animal-dream/requests commitAnimalRequest: choice.commit → closed=true → settleRequestDelivery(true)','Trace deferred settle records action/count then invokes onChange; throw occurs outside decide try after Provider returned','animal stage publishes chosen/decided fact only after commitAnimalRequest returns'],'preserved':'fox usedNight2/puffer usedDay1首次命中才throw原文本，fired后和未命中调用original.call(this)；付款/effect保、closed/stop与零publication、rawstrict archive及伪改负例原样。局部受控private sink seam，不新增产品test hook或广拦所有lifecycle通知'},
 {'group':'WallSelfDestruct','observedRuntimeNames':1,'change':'仅该fixture boolean为true时将原hook和同值enabledWindows写在bootstrap之前','realProducerConsumer':['app/bootstrap BoardParameters.compile copies/freezes original input','engine/phase-manager constructor reuses bound parameters/RulePlan','engine/phases/voting-pipeline reads frozen config.hooks.onPreVote && isSelfDestructWindowEnabled before selfDestructWindow.execute'],'preserved':'provider actor1原同工具/动作、两周期、blasted=true、无wall补发/commit/WallNote与phase day2原断言；其它fixture defaults false。不是Wall合法null/reject生产修复'},
]
readme='''# 五场景输入修复独立静态审查

结论：**approved_as_prepared_bounded_test_input_repair**，未运行任何产品、TS/parser、编译、测试或检查，也未写仓库。

固定 actual `7a85ad67ac808aab3e1d6d91078262a64382ca93` 的五完整源、mode/blob/SHA与当前源逐项核对；10精确替换记录／18实际位置正逆均同。全部原test标题行及expect行原字节保；完整inverse也约束所有非编辑区，未隐藏删减断言或付款预期。目录实际proposal材料是HANDOFF、STATIC-REVIEW、edits和patch，没有独立proposal.json；一次寻找该文件的read失败只属审查工具假设，不是产品/测试红。

## 具体结论

1. Wild13：九处正常setup输入接bootstrap已安装的同引用boardConfig。setup实际先拒raw config身份，原raw helper及DR输入不动，原五已正确canonical的死因测试不需重跑。
2. Radiant1：原强cast缺完整deck／Sheriff等政策，真实失败在BoardParameters的preset准入。现有公开12牌恰与手写World的Eclipse/Radiant/Seer/Witch/Dreamer/4Villager/3Wolf匹配。两stage与原pending/reentry字面oracle未动；新增本地公开JSON读取不是模型/网络或生产oracle。
3. Runner2：store真正收到版本envelope，故旧data.result漏掉磁盘注入。filename先短路再既有reader解包，仍抛同一个persistence并保原write.call receiver；AggregateError中四个原对象的先后与全部其它断言不变。
4. Animal2：Trace onChange是原构造保存的普通实例属性（TS private readonly不等于运行freeze）；manager回调才委托lifecycle.scheduleFlush。局部wrapper只在原paid库存已写且首次命中时throw。原commit→closed→settle顺序使Trace已落action/结算计数后通知失败，异常不回到早已返回的deferred decide try；原事实尚未发表。fired后及未命中仍按原receiver调用回调，原付款/效果/无publication/状态/严格归档和伪改拒绝均保。此处不声称是公开API或可任意注入的产品服务。
5. Wall1：原配置在bootstrap后改raw对象不会影响已clone/freeze的RulePlan。本候选只把原相同两字段移到bootstrap前，boolean默认false且仅该测试传true；真实投票前自爆入口因此接收到预期输入。原actor、动作、两周期、blasted及零补发断言全保；与另一作者Wall null/reject生产修复分开。

## 失败范围和后继

只为固定partial31-block里已观测的19个具体runtime测试名准备过滤命令：13＋1＋2＋2＋1。它不是19条源码test语句，不是A lane全suite计数/终态。Root已中断错误sandbox能力环境的原heavy场景，不能从这份静态审查推断场景全绿。五源候选没有加入付费服务、模型或外网；runner仍使用已有mock factory和synthetic-unused配置。

`failed-only19-command.json` 提供唯一19标题与完整argv；只有Root确认Wall及其他生产源已完整就绪、应用候选并核actualSHA后才执行。不要重跑原Wild已绿五死因或runner两个replayable变体。审查没有为绿放宽生产准入、归档schema、错误对象或原assert。
'''
(O/'review.md').write_text(readme)
report={'decision':'approved_as_prepared_bounded_test_input_repair','approved':True,'role':'independent-static-peer','baseCommit':B,'proposalDirectory':str(D),'handoffSHA256':sha((D/'HANDOFF.json').read_bytes()),'source':source,'deleted':[],'artifacts':bindings,'referencePrograms':actualrefs,'groups':findings,'scope':{'sourceFiles':5,'exactRecords':10,'actualOccurrenceSites':18,'observedFailedRuntimeNames':19,'wholeGitForwardInverseMismatch':0,'newTests':0,'productionSourceChanges':0},'commands':{'path':str(O/'failed-only19-command.json'),'sha256':sha((O/'failed-only19-command.json').read_bytes())},'document':{'path':str(O/'review.md'),'sha256':sha((O/'review.md').read_bytes())},'checksExecuted':[],'repositoryWritten':False,'limits':['静态批准不冒实际failed-only19通过、类型通过或整个A场景完成。','实读当前接口的source SHA单列；不把Root其它C46/Wall WIP当wholeGit controls。','源头/raw测试标题与原资源/失败前缀assert保留，真正是否抵达目标点由Root首次执行决定。','read expected proposal.json missing是审查文件形态假设；真实材料存在，不是产品红。','审查纯数据reader首逆global-after计数误把原有canonical调用计入，首script/error原存；已仅按真实匹配坐标逆回，不是作者/产品红。']}
dump('independent-review.json',report)
print(json.dumps({'reportSHA256':sha((O/'independent-review.json').read_bytes()),'source5':len(source),'observedCases19':len(selected),'currentStillBase':sum(x['currentStillWholeBase'] for x in source),'readmeSHA256':sha((O/'review.md').read_bytes()),'commandsSHA256':sha((O/'failed-only19-command.json').read_bytes())}))
