# C47 首轮 scenarios 五组过期输入／注入点修复候选

## 状态

只在 TMP 准备，未应用、未运行 TS／parser／check／业务／模型。原5测试源取 actual Git `7a85ad67ac808aab3e1d6d91078262a64382ca93` 全文／mode／blob；捕获时各current均同该Git。Root 当前生产树有独立公共端口／六头 WIP，read-inputs单独标现源SHA，不能冒5测试候选来自完整clean新Git。

依据 Pref 固定 partial report（原report f91ce563…＋31原block）和已交付真实合同。它不是A lane终态或全失败计数，未重新poll原running raw。本组只19个原失败声明：Wild13、Radiant1、runner disk2、Animal2、Wall selfdestruct1。首13个Wild之外已green的5种死因用例不重跑；runner另2种replayable不重跑。

## 精确范围和原预期

| 分组／源 | 候选改动 | 为什么是过期输入；哪些保持 |
| --- | --- | --- |
| Wild model-death-and-pack-activation | 九处正常 `setup(g)` 改传 `{...g, config:g.boardConfig}` | Wild window明确要求config===原binding.config，bootstrap公开boardConfig是那个同引用。旧raw g.config仍保helper／DeathResolution输入，不放宽setup生产guard；13声明的生命、顺序、原Role、真实Camp／Victory、历史／知识／getter0和回执assert不变。 |
| Radiant pending-dream-reentry | 只将不完整强cast config换为既有完整公开板子实际parse；加原文件IO／parser import，退无用type BoardConfig | 同族paid-dream-effects已使用同一公开JSON+parseBoardDefinition，包含固定12牌、Sheriff与政策。手写World和资源、Stages原两项、provider借梦／嵌套pipeline和radiant_night_reentry及lease不关闭断言原样；不是用生产输出制造oracle。 |
| runner concurrent-error-prefix | 原 filename-gated replay.json磁盘spy谓词改用已import readReplayDocument解包 | 真实store收到public replay envelope，原 data.result读不到runtime_error。仍先file===判断才解包，保throw同一个persistence对象、write.call(this,file,data)及第一／第二／cleanup／disk顺序，replayable变体未改。 |
| Animal paid-effect-record-failure | 包当前trace实际onChange参数属性，替换失效manager.scheduleFlush影子属性 | Trace构造保存onChange；manager原回调写dirty并调lifecycle.scheduleFlush。真正commitAnimalRequest先领域commit、closed、settleRequestDelivery，再append事实。wrapper仅在原paid条件（fox usedNight2／puffer usedDay1）首次命中时throw原文本，后继及未命中保original.call(this)。原stocks/effects/stopped／无publication、rawschema与终档assert全部不动。 |
| Wall first-voting-and-terminal-cycles | fixture新增特定布尔参数，把原hook.onPreVote=true与同一enabledWindows值移到bootstrap之前；仅自爆用例传true | RulePlan/BoardParameters已在bootstrap捕获clone/freeze，后改raw配置不会改运行计划。actor1同一动作、两cycle、blasted=true、无catchup／commit／WallNote的oracle不变。不是Wall合法null／reject生产修复；其余投票／终局用例不改。 |

全部测试title、expect表达式、手写动作／目标／库存预期和错误文本原样。没有新增声明、换动态生产oracle、改变provider行为或删除失败断言。两个新增中文说明仅解释完整公开输入与原先后序；不用模板头扩scope。

## 原合同链与注入边界

- Wild setup.ts 原 b.config 身份检查先于开choice及所有生命／死亡断言；五个已canonical化死因用例提供同文件现用方式，不需将getter/原体政策改宽。
- Radiant支持要求固定完整政策和牌组；先过它才能实际触发原 pending/reentry。合法板子只作为输入，不从运行结果推断原literal资源与lease断言。
- `createPublicReplayArchive`新封装由既有public reader处理；不是让录制器写回旧裸格式。spy的getter／throw／返回receiver点不移动到生产owner。
- Animal只触测试中该trace的通知属性，不给SessionRecordManager补兼容scheduleFlush，也不拦全部lifecycle.scheduleFlush造成更早无关失败。TypeScript private／readonly不是运行freeze；此处仍是原测试允许的受控sink故障注入，不作为公开产品API。只承诺原测试指定可达点，首执行由Root核真。
- Wall布尔仅fixture局部输入准备，原开窗配置的赋值顺序在bootstrap前；未更改被测RulePlan不可变政策或自爆资格。

## 应用和验证边界

before/candidates五整源与candidate.patch可review；edits为10条替换记录，共18个实际片段发生位置（Wild九处）。Root若在其后格式化前应用，应核各源actual before；若另有后继字节，只按唯一exact delta合并，不能wholefile盖掉新阶段。

本目录不准备或运行重全suite命令；Root在允许后只执行这些实际failed声明及必要变更根验证。保原partial首红和真实后继，不把19目标计数说成整lane终态，不把修fixture说成玩法修复。Infra listen/ACP症状不在本组；Pref独占Wall合法null/reject真实事务问题也不在本组。
