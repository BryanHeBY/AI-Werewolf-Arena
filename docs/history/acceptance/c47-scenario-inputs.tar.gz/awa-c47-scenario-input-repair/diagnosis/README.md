# C47 场景首段只读诊断

仅分析首读的 1,032,116 字节，不是进程终态或全套结果；没有运行检查或改仓库。

## 直接端口 EPERM

Many LLM/mixed failure blocks directly contain EPERM syscall listen at Bun.serve in run-game.ts:117.

Do not change test actions, expectations or production for these blocks. Root may use the existing escalated local-port capability as a narrow diagnostic. This is not the separately proven CLI stdout failure.

## ACP 基础设施候选

nightmare/acp/en reports action_turn_failed with a decision_failed prefix. ACP factory awaits loopback control.start before spawn; control.listen also requires 127.0.0.1. Failure maps to request_error/fallback. Missing game-fixture.json and repeated fallback rounds are consistent. No underlying ACP EPERM was present in read stdout/stderr excerpt; temporary workspaces have been cleaned.

One exact unchanged ACP declaration under the required local-port permission can distinguish infrastructure before any source/oracle patch.

## Wild 规范板子输入

Nine remaining positive setup(g) callsites pass mutable raw g.config. setup requires exact bootstrap binding b.config; all fail at setup.ts:41 before death/role/life assertions. The earlier five death-source cases already use config:g.boardConfig and pass in this same read.

Only the nine positive callsites should explicitly pass {...g,config:g.boardConfig}; keep raw fixture config, helper, titles, life/death/knowledge assertions. Do not weaken production identity guard.

## Radiant 不完整配置

The custom config uses roleSetups:[], enableSheriff:false and omits required policy fields. BoardParameters.compile now enforces isRadiantEclipsePreset before pipeline opens; the actual failure is radiant_eclipse_preset_invalid, not failed pending reentry logic. The World already has the correct 12-role roster.

Use the existing complete legal Radiant twelve-player board configuration while retaining this custom two-stage registry, real World resource setup, provider/reentry flow and literal lease assertions. Do not relax production preset validation.

## runner 故障注入封装

The disk-only spy still checks data.result.reason. Real recorder writes the public replay archive envelope; the two failures contain first/second/cleanup and omit only the intended injected disk Error. This is the same already confirmed integration predicate issue.

At existing filename-gated replay.json predicate use imported readReplayDocument(data).result.reason. Keep original Error identity, write.call receiver, error order and replayable variants unchanged.

## Animal 故障注入 owner

Test casts manager to {scheduleFlush} and assigns an own property that no live producer calls. Trace callback now calls this.lifecycle.scheduleFlush(). Neither fox nor puffer injection fires; failure remains undefined before payment assertions.

Retarget only the injection to the actual Trace onChange callback (returned trace owns this callback), delegating the original callback/receiver and retaining the exact paid-state trigger, same Error, stocks/effects/publication assertions. Alternatively inspect the real lifecycle owner, but broad scheduleFlush interception could move the failure before the desired Trace settlement. No production algorithm repair inferred.

## Wall 冻结前输入

The self-destruction test bootstraps first, then mutates g.config.hooks/onPreVote and selfDestruct. Canonical RulePlan was already cloned/frozen so no self-destruct request is opened and blasted remains false.

Provide those exact hook/selfDestruct values before bootstrap through a narrow fixture parameter/callsite. Keep raw input separate, actor/action, wall/no-catchup assertions and original expected policy.

## Wall 合法空行动与精确重放

The observed game reports natural finish/no rejects/fallbacks, then strict replay rejects reproduction_recorded_decision_failed. Static source chain: conservative ObservedBot returns null for write_note; Wall window leaves legitimate null incomplete and later closes(false); Trace replaces the returned candidate with error; RecordedActions interprets any error as provider rejection. The cleanup removed original Tapes, so the exact failed error-stage cannot be proven from this raw alone.

Preserve the strict replay assertion. Obtain one bounded trace/record if Root needs final causal proof; decide how legal Wall abstention is represented without treating real cancelled/invalid/partially failed requests as success, and without globally replaying all errors as null or calling paid completion for arbitrary cases.
