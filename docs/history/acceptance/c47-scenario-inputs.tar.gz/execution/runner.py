from pathlib import Path
import json,subprocess,time,hashlib,os,sys
root=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/tmp/awa-c47-scenario-input-execution');spec=json.loads(Path('/tmp/awa-c47-scenario-input-repair-independent/failed-only19-command.json').read_text());cmd=spec['argv'];cmd[0]='/usr/bin/bun'
home=out/'runtime'
for n in ('home','cache','config','state','tmp'):(home/n).mkdir(parents=True,exist_ok=True)
env={'PATH':'/usr/bin:/bin','HOME':str(home/'home'),'XDG_CACHE_HOME':str(home/'cache'),'XDG_CONFIG_HOME':str(home/'config'),'XDG_STATE_HOME':str(home/'state'),'TMPDIR':str(home/'tmp'),'LANG':'C.UTF-8','CI':'1','NO_COLOR':'1','FORCE_COLOR':'0','TZ':'Asia/Shanghai'}
paths=['backend/'+p for p in dict.fromkeys(row['file'] for row in spec['selectedTests'])]+['backend/src/features/wall-notes/window.ts','backend/src/domain/request-lease.ts','bun.lock']
def fence():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=fence();(out/'launch.json').write_text(json.dumps({'command':cmd,'cwd':spec['cwd'],'environment':env,'expectedSelectedRuntimeNames':19,'before':before},indent=2)+'\n');start=time.time()
with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:r=subprocess.run(cmd,cwd=spec['cwd'],env=env,stdout=a,stderr=b,timeout=240)
after=fence();receipt={'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'sourcesUnchanged':before==after,'after':after};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(r.returncode)
