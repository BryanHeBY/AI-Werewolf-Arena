from pathlib import Path
p=Path('backend/src/rulesets/victory/default-specs.ts');s=p.read_text()
s=s.replace('import { WinConditionSpec } from "../../engine/victory/contracts";','import type { AliveVictoryCounts, VictoryQueries, WinConditionSpec } from "../../engine/victory/contracts";')
a=s.index('interface AliveStat {');b=s.index('\nfunction statAlive',a)
s=s[:a]+s[b:];s=s.replace('function statAlive(world: World): AliveStat {','function statAlive(world: World): AliveVictoryCounts {').replace('const stat: AliveStat = {','const stat = {')
a=s.index('function evaluateSlaughterCity(')
prefix=s[:a];tail=s[a:]
tail=tail.replace('world: World','queries: VictoryQueries').replace('(world) =>','(queries) =>').replace('cupidCityDecision(world)','queries.cupidCityDecision()').replace('statAlive(world)','queries.eliminationCounts()').replace('weddingFactionResult(world)','queries.weddingFactionResult()')
tail=tail.replace('victoryDecision(world,','queries.decision(').replace('victoryDecision(\n      world,','queries.decision(').replace('victoryDecision(\n            world,','queries.decision(')
tail=tail.replace('evaluateSlaughterCity(world','evaluateSlaughterCity(queries').replace('evaluateSlaughterSide(world','evaluateSlaughterSide(queries')
s=prefix+tail
s+='''
/**
 * 可信评估入口绑定真实所有者；构造时不读取世界，具体查询仍按原规则顺序执行。
 * 内建统计、关系判胜和成员投影的完整算法保留在各原 owner，端口不返回组件或任意回调入口。
 */
export function bindVictoryQueries(world: World): VictoryQueries {
  return {
    entityIds: () => [...world.entityIds()],
    aliveIds: () => [...world.getAliveEntityIds()],
    role: (id) => world.getComponent(id, COMPONENT.Role)?.role,
    camp: (id) => world.getComponent(id, COMPONENT.Camp)?.camp,
    eliminationCounts: () => statAlive(world),
    cupidCityDecision: () => cupidCityDecision(world),
    weddingFactionResult: () => weddingFactionResult(world),
    decision: (primary, reason, additional) => victoryDecision(world, primary, reason, additional),
  };
}
'''
p.write_text(s)
