# Cupid 场景独立静态诊断

Cupid284 的 canonical `facts.some` 与 Hybrid225 同样依赖当前 God 事实，而 cb 录制上下文未为 Cupid 提供 liveEvents。首夜已付后四条事实可先进入下一玩家请求，Trace仍用旧CP事件，异步刷盘发生误拒。建议只修有证据的源回调，不改 fixture/关系/Victory/lease 或 strict 规则。

丘比特可见性必须保：本人chosen、恋人各自recognition；隐藏relation_resolved/pairCamps/lovers_death。事实先于标死及失败CP多前缀边界保持。

Cupid文件21失败中15仅Cupid、2仅DeathHistory、4同时两根；两根不是互斥测试组。具体标题、完整现有错误块归因、源SHA与在途日志前缀见report.json。这里未执行探针；Root稍后捕获才可追加实际拒绝输入确认。

## Root 实际捕获确认

Root一次诊断保9份快照（5个不同SHA）；首5109字节/b2c33ba6…的actor3 wolf_discussion已见合法recognition3→2，global仍仅两初始事件和CP0。所有9份均无canonical Cupid事实，直接确认284 facts.some落空；它不是9个独立案例。原Trace已与固定cb逐字节相同，后继修复绿另按Root收据。详见root-capture-confirmation.json。
