from pathlib import Path
import subprocess,json,hashlib,time
root=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/tmp/awa-hybrid-live-events-execution/unit-schema-diagnostic');out.mkdir(exist_ok=True);p=root/'backend/src/recording/reproduction/format.ts';before=p.read_bytes();text=before.decode();old='if (!parsed.success) throw new Error("reproduction_record_invalid");';new='if (!parsed.success) { console.error("SYNTHETIC_SCHEMA_ISSUES", JSON.stringify(parsed.error.issues)); throw new Error("reproduction_record_invalid"); }';assert text.count(old)==1;after=text.replace(old,new).encode();(out/'format.before.ts').write_bytes(before);(out/'format.diagnostic.ts').write_bytes(after)
cmd=['/usr/bin/bun','--no-env-file','test','--preload','./backend/tests/setup.ts','backend/tests/unit/recording/live-event-snapshot.test.ts','--test-name-pattern','^Hybrid beginGame wiring includes pre-checkpoint facts'];start=time.time();code=None
try:
 p.write_bytes(after)
 with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:code=subprocess.run(cmd,cwd=root,env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8'},stdout=a,stderr=b,timeout=60).returncode
finally:
 assert p.read_bytes()==after;p.write_bytes(before)
 result={'argv':cmd,'exitCode':code,'elapsedSeconds':time.time()-start,'sourceRestoredExactly':p.read_bytes()==before,'beforeSha256':hashlib.sha256(before).hexdigest()};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
