from pathlib import Path
import hashlib,json,subprocess,time,sys
root=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/tmp/awa-hybrid-live-diagnostic');out.mkdir(exist_ok=True);source=root/'backend/src/recording/reproduction/trace.ts';before=source.read_bytes(); assert hashlib.sha256(before).hexdigest()=='34d122b03a7bfa3945a12a81c63fc652c4366c8039132c27e63ef793fc43ce08'
text=before.decode();text=text.replace('import { types } from "node:util";', 'import { writeFileSync as saveDiagnosticRecord } from "node:fs";\nlet diagnosticRecordId = 0;\nimport { types } from "node:util";',1)
old='    return parseReproductionRecord(record);';new='''    try { return parseReproductionRecord(record); }
    catch (error) {
      if (error instanceof Error && error.message === "reproduction_hybrid_state_invalid")
        saveDiagnosticRecord("/tmp/awa-hybrid-live-diagnostic/record-" + (++diagnosticRecordId) + ".json", JSON.stringify(record));
      throw error;
    }''';assert text.count(old)==1;text=text.replace(old,new);diagnostic=text.encode();(out/'trace.before.ts').write_bytes(before);(out/'trace.diagnostic.ts').write_bytes(diagnostic)
home=out/'runtime'
for n in ['home','cache','config','state','tmp']:(home/n).mkdir(parents=True,exist_ok=True)
env={'PATH':'/usr/bin:/bin','HOME':str(home/'home'),'XDG_CACHE_HOME':str(home/'cache'),'XDG_CONFIG_HOME':str(home/'config'),'XDG_STATE_HOME':str(home/'state'),'TMPDIR':str(home/'tmp'),'LANG':'C.UTF-8','CI':'1','NO_COLOR':'1','FORCE_COLOR':'0','TZ':'UTC'}
cmd=['/usr/bin/bun','--no-env-file','test','--preload','./tests/setup.ts','tests/scenarios/reproduction/hybrid/recorded-games.test.ts','--test-name-pattern','^good_alive/acp:']
(out/'launch.json').write_text(json.dumps({'command':cmd,'cwd':str(root/'backend'),'environment':env,'diagnosticOnly':'capture exact rejected input and rethrow same error; source restored in finally'},indent=2)+'\n');start=time.time(); code=None
try:
 source.write_bytes(diagnostic)
 with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:code=subprocess.run(cmd,cwd=root/'backend',env=env,stdout=a,stderr=b,timeout=120).returncode
finally:
 assert source.read_bytes()==diagnostic;source.write_bytes(before)
 records=[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(out.glob('record-*.json'))]
 result={'exitCode':code,'elapsedSeconds':time.time()-start,'sourceRestoredExactly':source.read_bytes()==before,'records':records};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
sys.exit(code or 0)
