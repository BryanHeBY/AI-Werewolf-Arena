from pathlib import Path
import json,subprocess,hashlib,time,sys
root=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/tmp/awa-cupid-hybrid-live-events-execution/scenario-failed-only-successor');out.mkdir(exist_ok=True);home=out/'runtime'
for n in ['home','cache','config','state','tmp']:(home/n).mkdir(parents=True,exist_ok=True)
env={'PATH':'/usr/bin:/bin','HOME':str(home/'home'),'XDG_CACHE_HOME':str(home/'cache'),'XDG_CONFIG_HOME':str(home/'config'),'XDG_STATE_HOME':str(home/'state'),'TMPDIR':str(home/'tmp'),'LANG':'C.UTF-8','CI':'1','NO_COLOR':'1','FORCE_COLOR':'0','TZ':'UTC'}
cmd=['/usr/bin/bun','--no-env-file','test','--preload','./tests/setup.ts','tests/scenarios/reproduction/cupid/recorded-games.test.ts','--test-name-pattern','^(?:(?:mixed_netease|mixed_lui|wolves_netease|wolves_lui|root_hunter|dream_chain|shot_chain)/(?:acp|mixed)|heartbreak_hunter/acp|two_sources/(?:llm|acp|mixed)|beauty_poison/(?:llm|acp|mixed)):']
paths=['backend/src/app/simulation/reproduction-context.ts','backend/tests/unit/recording/live-event-snapshot.test.ts','backend/src/recording/reproduction/trace.ts','backend/src/recording/verification/hybrid/validate.ts','backend/src/recording/verification/cupid/validate.ts','backend/src/recording/verification/death-history/validate.ts']
def fence():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=fence();(out/'launch.json').write_text(json.dumps({'command':cmd,'cwd':str(root/'backend'),'environment':env,'before':before,'scope':'only the twenty-one observed failure declarations, each retains its bilingual full game and exact replay assertions'},indent=2)+'\n');start=time.time()
with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:r=subprocess.run(cmd,cwd=root/'backend',env=env,stdout=a,stderr=b,timeout=300)
after=fence();result={'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'sourcesUnchanged':before==after,'after':after};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));sys.exit(r.returncode)
