# Hybrid 录制刷盘前缀缺失当前事实

## 已观测输入

固定场景 base 为 `cb02260b15288f48b99dc523852139ffa9037a89`；修补前态取当前 `da664f6defe7f653b1450b07738964efc36a315d`，两源与 cb 完整 Git 字节相同。当前 A 的 Hybrid 段完整列出 27 声明：六个六人 kind 的 LLM 通过，六 kind 的 ACP/mixed 共 12 失败；三个十二人 kind 三传输共 9 失败。21 个失败均落在 `verification/hybrid/validate.ts:225` 的本人可见选择事实必须匹配 God 流。该局部段终态不等于完整 A 终态。

Root 唯一诊断捕获 `/tmp/awa-hybrid-live-diagnostic/record-1.json`（第二份同 bytes），SHA256 `952ec824089ff18d80dc5e3e9aa07d560c362e833d46bc69ebc3a6df2d02fe64`，15980 bytes；我仅纯 JSON 读取。`finalized=false`、events 2、唯一 CP0.eventCount 2、全局 Hybrid facts 为空；actor3 的 day_speech 请求已携带 seq2 `hybrid_exemplar_chosen {actorId:3,day:1,targetId:4}`。这证明当前请求事实领先归档事件，而非原角色付款、目标或隐藏阵营规则错误。Root 的单场诊断实际红，源已精确恢复；本作者无任何执行。

## 原因与最窄修补

`beginGameReproduction` 只对 Radiant/Noble/Fragrant/Animal 传入已有 late liveEvents 端口。普通分支的 `Trace.build()` 用最后一次 checkpoint 的事件快照，但决定在请求开启时已复制完整可见事件；100ms 刷盘先于下一 checkpoint 时，Hybrid 本人可见选择找不到对应 God 事实。六人快速 LLM 较易避开窗口，ACP 与十二人可观察到该前缀。

仅为实际角色牌组包含 Hybrid 的板子接通同一个 `() => phaseManager.getEvents()`，不新增实时服务、不把所有板子切换、不改变 Trace 复制逻辑、不推进 checkpoint。新条件仍在原四个布尔分支后短路；只有此前四分支未命中时读取既有 roleSetups。Trace.build 仍在它原有的位置调用、复制完整累计事件，异常原样传播。原独立 validator 和隐私判定全部不变。

Cupid 同样有严格可见事实对应检查，但本包不以静态相似性扩大修复；实际本轮只确认 Hybrid。

## 确定性回归边界

追加两声明到现有 live-event-snapshot 单元，原三声明原文保留。Hybrid 例真实 bootstrap、beginGameReproduction→管理器入口→ReproductionTrace、HYBRID_STAGE→原工厂→真实 Trace.decide；没有手工给 Trace 传入测试自造 callback。管理器 seam 只照收真实入口给出的 callback。局部 PM 公开 getEvents 按原脱离复制约定读取真实阶段共用的事件数组，不写私有字段。

在 CP0 后执行真实榜样选择并创建本人 speech 请求；不追加 checkpoint、不等待定时器，build 必须得到两原事实，同时保 CP0。字面 Wolf 归属、本人 chosen 可见、hidden affiliation 不可见、双结算及 returned archive 不反写事件均独立核对。错误 visible target 与泄漏 affiliation 仍严格拒绝。普通六人板另核 callback 仍 undefined，原 checkpoint-only 策略未扩大。

这两个声明不证明任意异步刷盘/任意 getter，亦不替代 Root 对实际 21 个失败场景的必要后继检查。所有命令仅准备，作者未执行产品、测试、解析器、类型、门禁或格式化器。
