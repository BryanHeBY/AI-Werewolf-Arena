# cb 场景 Hybrid 独立静态诊断

实际已打印的 Hybrid 错误是 `reproduction_hybrid_state_invalid`，统一来自 verifier 225 行可见事实检查；不是 Beauty 的 `auditLastWords` 错误，也没有 canonical config 早拒／沙箱 EPERM 轨迹。

最具体原因是：Hybrid 已提交事实进入下一玩家请求的 visible_events，但该板子的 Trace 不接 liveEvents，定时100ms刷盘可在下一CP之前用旧 CP 事件快照构建档案。独立 validator 因而找不到已可见的 canonical fact，刷盘错误进入 mandatory ledger。ACP/大板更长 await 的打印分布与此一致；这里没有执行新计时实验。

建议修实际录制事件来源边界，保最终可见性/事实匹配拒绝和全部业务字面预期，不删 verifier 检查或改 fixture。Root 可用真实周期首付后／下一 CP 前 flush 风险验证最窄修。详细源码链、原始前缀 SHA 与失败清单见 report.json。

这是有限在途日志观察，不是场景最终计数或完整通过证明。

## 后继实际捕获确认

Root 的一次诊断保存两份完全相同的15980字节记录（SHA952ec824…）。其中仅初始CP0/eventCount2和两条global events，未含chosen事实；但actor3 day_speech确有seq2 chosen事实，payload actor3与target4均合法。故225行的 canonical facts.some 实际为false，与先前事件快照落后推断一致。此次exit1是诊断复现，不是修复通过；未把两份相同快照当两个独立案例。详见root-capture-confirmation.json。
