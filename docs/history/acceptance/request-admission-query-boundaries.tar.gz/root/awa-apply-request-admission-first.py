"""整合准入候选；profile仅应用局部规则片段，保留死亡owner和现有私有World归属。"""
from pathlib import Path
import hashlib,json,subprocess
repo=Path('/home/hby/dev/AI-Werewolf-Arena');root=Path('/tmp/awa-h03-request-admission-draft');d=json.loads((root/'source-ready.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip();assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b''
profiles={r['path']:r for r in json.loads((root/'profile-local-deltas.json').read_text())['source']};shared=json.loads((root/'shared-callsite-deltas.json').read_text());prepared=[]
for r in d['source']:
 p=repo/r['path'];old=p.read_bytes() if p.exists() else None;candidate=Path(r['candidate']).read_bytes();assert sha(candidate)==r['sha256'];mode=r['apply'];result=None
 if mode=='exact-validation-deltas-only':
  source=old.decode();meta=profiles[r['path']]
  if r['path']=='backend/src/features/wolf-king/profile.ts':
   assert len(meta['steps'])==2
   # 另一作者的原死亡命令程序留在现文件；只增加验证登记import并替换原验证字段。
   header=source.index('*/')+2;source=source[:header]+'\nimport { ownedToolRules } from "../../engine/actions/validation-queries";\n'+source[header:]
   step=meta['steps'][1];assert source.count(step['before'])==1;source=source.replace(step['before'],step['after'],1)
   mode+='; preserve native death-hook/import'
  else:
   assert sha(old)==r['beforeSHA256'],r['path']
   for step in sorted(meta['steps'],key=lambda x:x['beforeStart'],reverse=True):
    start=step['beforeStart'];end=step['beforeEnd'];assert source[start:end]==step['before'],r['path'];source=source[:start]+step['after']+source[end:]
   assert sha(source.encode())==r['sha256'],r['path']
  result=source.encode()
 elif mode=='shared-exact-delta-only':
  assert sha(old)==r['beforeSHA256'],r['path'];source=old.decode()
  for step in [x for x in shared if x['path']==r['path']]:
   assert source.count(step['before'])==step['count'],r['path'];source=source.replace(step['before'],step['after'])
  result=source.encode();assert sha(result)==r['sha256'],r['path']
 else:
  assert (old is None if r['change']=='new' else sha(old)==r['beforeSHA256']),r['path'];result=candidate
 prepared.append((p,result,{'path':r['path'],'beforeSHA256':sha(old) if old is not None else None,'preparedSHA256':r['sha256'],'appliedSHA256':sha(result),'mode':mode}))
# 所有准备条件先验证通过，再一次写入；失败不留下半批源。
for p,result,row in prepared:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(result)
Path('/tmp/awa-request-admission-applied.json').write_text(json.dumps({'base':base,'preparedBase':d['baseCommit'],'source':[r for p,b,r in prepared]},ensure_ascii=False,indent=2)+'\n');print('applied',len(prepared),'at',base)
