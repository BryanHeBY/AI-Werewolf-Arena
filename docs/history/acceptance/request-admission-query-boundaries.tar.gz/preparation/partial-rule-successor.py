from pathlib import Path
import shutil,json,hashlib,difflib
O=Path('/tmp/awa-h03-request-admission-draft');C=O/'candidates';S=O/'first-598143-prepared-snapshot';S.mkdir()
for n in ['candidates','HANDOFF.json','source-ready.json','README.md','git-before.json','edits.json','profile-local-deltas.json','candidate.patch','execution-plan.json','types-config.json','heads.ts','shared-callsite-deltas.json']:
 p=O/n;q=S/n
 if p.is_dir():shutil.copytree(p,q)
 else:shutil.copy2(p,q)
p=C/'backend/src/engine/actions/validation-queries.ts';t=p.read_text().replace('[name, ownedToolRule(rule as OwnedToolRule, scopeOwner)]','[name, rule === undefined ? undefined : ownedToolRule(rule as OwnedToolRule, scopeOwner)]');p.write_text(t)
p=C/'backend/tests/unit/engine/actions/validation-query-boundary.test.ts';t=p.read_text().replace('Camp, Phase, Role, type ToolCall','Camp, Phase, Role, RuleError, type ToolCall');k=t.index('import type { ValidationRuleContext }');t=t[:k]+'import { ownedToolRules } from "../../../../src/engine/actions/validation-queries";\n'+t[k:];at=t.rfind('\n});');t=t[:at]+'''
  // Partial 原表允许自有 undefined，用于显式覆盖／回退；保这个键，不在静态登记时误当函数抛错。
  const partial = ownedToolRules({ speak: undefined });
  expect(Object.keys(partial)).toEqual(["speak"]);
  expect(partial.speak).toBeUndefined();
  const noRule = new ActionValidator(new ToolValidationRuleRegistry(partial, catalog), false);
  expect(noRule.validate(first, 1, { name: "speak", args: { text: "literal" } }, { phase: Phase.Day }))
    .toMatchObject({ ok: false, error: RuleError.UnknownTool });
'''+t[at:];p.write_text(t)
p=O/'README.md';p.write_text(p.read_text()+'\n第二静态同行后继：保 `first-598143-prepared-snapshot/`；Partial 规则表自有 undefined 键原样保留、不登记也不滤掉。现 boundary 声明追加手写 undefined 表／UnknownTool 断言；不声称扩展任意非函数值接受集合。0检查。\n')
sha=lambda b:hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest();read=json.loads((O/'git-before.json').read_text());before={x['path']:x for x in read['source']};ready=json.loads((O/'source-ready.json').read_text());edits=[];profiles=[];patch=[]
for row in ready['source']:
 if not row.get('candidate'):continue
 p=row['path'];a=(C/p).read_text();row['sha256']=sha(a);row['bytes']=len(a.encode());b=before[p]['text']
 if b is None:continue
 bl=b.splitlines(keepends=True);al=a.splitlines(keepends=True);offs=[0]
 for s in bl:offs.append(offs[-1]+len(s))
 steps=[]
 for g in difflib.SequenceMatcher(None,bl,al,autojunk=False).get_grouped_opcodes(3):
  i1=min(x[1] for x in g);i2=max(x[2] for x in g);j1=min(x[3] for x in g);j2=max(x[4] for x in g)
  steps.append({'path':p,'beforeStart':offs[i1],'beforeEnd':offs[i2],'before':''.join(bl[i1:i2]),'after':''.join(al[j1:j2])})
 r={'path':p,'beforeSHA256':sha(b),'afterSHA256':sha(a),'steps':steps};edits.append(r)
 if p.endswith('/profile.ts'):profiles.append(r)
 patch.extend(difflib.unified_diff(bl,al,fromfile='a/'+p,tofile='b/'+p))
write=lambda p,v:(O/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
ready['partialRuleSuccessor']={'firstReady':'378b2bce61ef686805c6103910a4b55e782cd96aba1588f50f541f8f25745117','reason':'Preserve legal own undefined Partial rules without dropping the key or WeakMap.set(undefined)','checksExecuted':[]};write('source-ready.json',ready)
write('edits.json',{'baseCommit':read['baseCommit'],'source':edits,'localShared':json.loads((O/'shared-callsite-deltas.json').read_text())});write('profile-local-deltas.json',{'baseCommit':read['baseCommit'],'apply':'only exact validation/import/contribution fragments; preserve concurrent other owner fields','source':profiles});(O/'candidate.patch').write_text(''.join(patch))
h=json.loads((O/'HANDOFF.json').read_text());h['source']=ready['source'];h['sourceReadySHA256']=sha((O/'source-ready.json').read_bytes());h['thirdPreparedSnapshot']='first-598143-prepared-snapshot';h['partialRuleSuccessor']=ready['partialRuleSuccessor']
for a in h['artifacts']:
 p=O/a['path'];a['sha256']=sha(p.read_bytes());a['bytes']=p.stat().st_size
write('HANDOFF.json',h);print('ready',h['sourceReadySHA256']);print('HANDOFF',sha((O/'HANDOFF.json').read_bytes()))
