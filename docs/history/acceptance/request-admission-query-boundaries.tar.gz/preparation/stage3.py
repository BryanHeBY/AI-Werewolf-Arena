from pathlib import Path
import re
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-h03-request-admission-draft');C=O/'candidates';B=O/'before'
def get(p):
 q=C/p
 if q.exists():return q.read_text()
 t=(R/p).read_text();q=B/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t);return t
def put(p,t):q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
# Correct authoring concatenation, no executed source or product proof exists.
for feature,symbol in [('mechanical-wolf','MECHANICAL'),('awakened-hidden-wolf','AWAKENED')]:
 p=f'backend/src/features/{feature}/rules.ts';t=get(p).replace('Object.fromEntriesownedToolRules(Object.fromEntries(','ownedToolRules(Object.fromEntries(');put(p,t)
p='backend/src/engine/actions/validation-queries.ts';t=get(p)
t=t.replace('RuleError, type Camp','type Camp').replace('extends Omit<ValidationRuleContext, "queries">','extends ValidationRuleContext')
t=t.replace('export type OwnedToolRuleMap = Partial<Record<ToolCall["name"], OwnedToolRule | ToolRule>>;','export type ValidationHostInput = Omit<ValidationHostContext, "queries">;\nexport type OwnedToolRuleMap = Partial<Record<ToolCall["name"], OwnedToolRule>>;')
t=t.replace('host: ValidationHostContext): RuleViolation','host: ValidationHostInput): RuleViolation').replace('return run({ ...host, scope });','return run({ ...host, scope, queries: createValidationQueries(host.world) });')
put(p,t)
p='backend/src/engine/actions/tool-validation-rule-registry.ts';t=get(p)
t=t.replace('import { RuleError, type RuleViolation }','import { RuleError, type RuleViolation }')
t=t.replace('import { ToolRuleMap, ValidationRuleContext } from "./validation-contracts";','import type { ToolRuleMap } from "./validation-contracts";\nimport { invokeValidationRule, type ValidationHostInput, type RawAdmissionResult, type ValidationScopeInput } from "./validation-queries";\nimport { createDefaultActionValidationAssembly } from "../../rulesets/action-validation-assembly";\nimport type { World } from "../../domain/world";\nimport type { ActionRequest, ToolName as ContractToolName } from "../../domain/actions";')
t=t.replace('import type { ActionRequest, ToolName as ContractToolName } from "../../domain/actions";','import type { ActionRequest } from "../../domain/actions";\nimport type { ToolName as ContractToolName } from "@ai-werewolf-arena/game-contract";')
t=t.replace('function buildDefaultRules(roleProfileRegistry: RoleCatalog): ToolRuleMap {','function buildDefaultRules(roleProfileRegistry: RoleCatalog, commonRules: ToolRuleMap): ToolRuleMap {').replace('    ...COMMON_VALIDATION_RULES,','    ...commonRules,\n    ...COMMON_VALIDATION_RULES,')
t=t.replace('  private readonly useProfileRules: boolean;','  private readonly useProfileRules: boolean;\n  private readonly admission: ReturnType<typeof createDefaultActionValidationAssembly>;')
t=t.replace('    this.rules = { ...(rules ?? buildDefaultRules(roleProfileRegistry)) };','    this.admission = createDefaultActionValidationAssembly();\n    this.rules = { ...(rules ?? buildDefaultRules(roleProfileRegistry, this.admission.commonRules)) };')
s=t.index('  validate(ctx:');e=t.index('    // 同名工具',s)
t=t[:s]+'''  /** 原 raw 程序按可信装配顺序执行；首拒绝立即返回，参数读取和 getter 异常不吞掉。 */
  prepareRawArgs(world: World, request: ActionRequest, tool: ContractToolName, rawArgs: unknown): RawAdmissionResult {
    let args: Record<string, unknown> | undefined;
    for (const contribution of this.admission.raw) {
      const raw = contribution.raw;
      if (!raw) continue;
      const result = raw(world, request, tool, rawArgs);
      if (!result.ok) return result;
      if (result.args !== undefined) args = result.args;
    }
    return { ok: true, ...(args !== undefined ? { args } : {}) };
  }

  /** 每次接收都观察原全部证明；只用静态 owner 身份路由，不缓存许可、不向扩展返回证明。 */
  captureRequestScopes(world: World, request: ActionRequest): readonly ValidationScopeInput[] {
    return this.admission.scopes.map((contribution) => {
      const capture = contribution.capture;
      return { owner: contribution.owner, scope: capture(world, request) };
    });
  }

  validate(ctx: Omit<ValidationHostInput, "roleCatalog">): RuleViolation | null {
    if (this.useProfileRules && ctx.toolCall.name === "shoot" && ctx.abilityId !== undefined)
      return validateGiftGun({ ...ctx, roleCatalog: this.roleProfileRegistry });
''' +t[e:]
t=t.replace('const result = rule({ ...ctx, roleCatalog: this.roleProfileRegistry });','const result = invokeValidationRule(rule, { ...ctx, roleCatalog: this.roleProfileRegistry });')
put(p,t)
# Validator carries the one opaque proof channel only inside the trusted host.
p='backend/src/engine/actions/action-validator.ts';t=get(p)
t=re.sub(r'^  (?:thief|shapeshifter|wildChild|lonelyGirl|ghostBride|demonHunter|nobleBody|fragrantPair|animal|wall)Scope\?: object;\n','',t,flags=re.M)
t=t.replace('  day?: number;','  day?: number;\n  /** 原 owner 捕获的证明；并非任意 callback 或 true 能生成的授权。 */\n  scope?: object;\n  /** 接收器内部按贡献身份关联，公开 ToolRule 不收到此集合。 */\n  requestScopes?: readonly import("./validation-queries").ValidationScopeInput[];')
t=re.sub(r'^      (?:thief|shapeshifter|wildChild|lonelyGirl|ghostBride|demonHunter|nobleBody|fragrantPair|animal|wall)Scope: context\.\w+Scope,\n','',t,flags=re.M)
t=t.replace('      day: context.day,','      day: context.day,\n      scope: context.scope,\n      requestScopes: context.requestScopes,')
put(p,t)
p='backend/src/engine/actions/action-reception.ts';t=get(p)
a=t.index('import { nobleBodyRequestScope');b=t.index('import { z, type ZodType }',a);t=t[:a]+t[b:]
t=t.replace('import { readWallTool } from "@ai-werewolf-arena/game-contract/facts/wall-notes";\n','')
t=t.replace(' * 运行对象仍是原接收器和 World；这是消费契约，不是新的进程隔离或运行权限屏障。',' * 实际接收器不公开 World；语言在原调用点晚读，领域写入仍不属于此接口。')
t=t.replace('  readonly world: { readonly locale: Locale };','  readonly locale: Locale;')
t=t.replace('  private readonly gateway: ToolGateway;','  private readonly gateway: ToolGateway;\n  readonly #world: World;\n  private readonly rules: ToolValidationRuleRegistry;')
t=t.replace('    readonly world: World,','    world: World,')
t=t.replace('    // 这里仍关闭领域校验','    this.#world = world;\n    this.rules = rules;\n    // 这里仍关闭领域校验')
t=t.replace('  validate(request: ActionRequest,','  get locale(): Locale { return this.#world.locale; }\n\n  validate(request: ActionRequest,')
t=t.replace('this.world','this.#world')
a=t.index('    const wallCall =');b=t.index('    const properties =',a)
t=t[:a]+'''    const admission = this.rules.prepareRawArgs(this.#world, request, tool, rawArgs);
    if (!admission.ok) return fail(admission.error);
    // 仅各原 reader 明确规范化的参数取其原对象；一般工具仍在全部 raw 预检后做原 spread。
    const input = (admission.args ?? { ...rawArgs }) as Record<string, unknown>;
'''+t[b:]
a=t.index('      thiefScope:');b=t.index('      wallId:',a)
t=t[:a]+'      requestScopes: this.rules.captureRequestScopes(this.#world, request),\n'+t[b:]
t=t.replace('    // 机制 scope 按下面原字段顺序逐个读取；不提前缓存请求许可或绕过 Gateway 的提交前规则。','    // 贡献装配保原证明观察顺序；核心不持角色清单，也不提前缓存许可或绕过提交前规则。')
put(p,t)
p='backend/src/engine/actions/tool-gateway.ts';t=get(p)
t+='''
/** 夜上下文实际只交这个绑定对象；调用方不取得 World 或宿主校验器。 */
export interface BoundToolGateway {
  validateAndSanitize<T extends ToolCall>(actorId: EntityId, toolCall: T, context: ValidationContext): ToolValidationResult<T>;
}
/**
 * 两个惰性来源均由可信装配捕获。属性读取保 gateway → 原 callee → World，随后才求演员／调用／选项；
 * 原方法实际调用时才判断可调用性，且 receiver 仍是原 gateway。Reflect 准备是新增的有界观察面。
 */
export function createBoundToolGateway(gatewaySource: () => ToolGateway, worldSource: () => World): BoundToolGateway {
  return Object.freeze({
    get validateAndSanitize() {
      const gateway = gatewaySource();
      const callee = gateway.validateAndSanitize;
      const world = worldSource();
      const invoke = Reflect.apply.bind(Reflect);
      return <T extends ToolCall>(actorId: EntityId, toolCall: T, context: ValidationContext): ToolValidationResult<T> =>
        invoke(callee, gateway, [world, actorId, toolCall, context]);
    },
  });
}
''';put(p,t)
p='backend/src/agents/player/action-turn.ts';put(p,get(p).replace('this.reception.world.locale','this.reception.locale'))
# Full candidates only for these nonshared setup/window owners; Initial/Wild/three night roots are local deltas.
shared={'backend/src/features/initial-identity/setup.ts','backend/src/features/wild-child/setup.ts','backend/src/features/animal-dream/night-stages.ts','backend/src/features/fragrant-pair-seer/night-stages.ts','backend/src/features/noble-secret-body/night-stages.ts'}
paths=['backend/src/features/wall-notes/window.ts','backend/src/features/animal-dream/night-stages.ts','backend/src/features/initial-identity/setup.ts','backend/src/features/lonely-girl/setup.ts','backend/src/features/animal-dream/puffer-window.ts','backend/src/features/fragrant-pair-seer/night-stages.ts','backend/src/features/demon-hunter/controller.ts','backend/src/features/wild-child/setup.ts','backend/src/features/ghost-bride/setup.ts','backend/src/features/noble-secret-body/night-stages.ts']
import json
routes=[]
for p in paths:
 t=get(p);before=t
 if 'initial-identity/setup' in p:t=t.replace('...(this.kind === "thief" ? { thiefScope: scope } : { shapeshifterScope: scope }),','scope: this.kind === "thief" ? scope : scope,')
 else:t=re.sub(r'\b(?:wildChild|lonelyGirl|ghostBride|demonHunter|nobleBody|fragrantPair|animal|wall)Scope:', 'scope:',t)
 if t==before:raise ValueError(('missing callroute',p))
 if p not in shared:put(p,t)
 else:
  # Store exact independent replacement, not an old wholefile covering another author's ownership.
  oldline=next(x for x in before.splitlines() if re.search(r'\b(?:thief|wildChild|lonelyGirl|ghostBride|demonHunter|nobleBody|fragrantPair|animal|wall)Scope:',x))
  newline=next(x for x in t.splitlines() if 'scope:' in x and ('scope,' in x or ' b,' in x))
  routes.append({'path':p,'before':oldline,'after':newline,'count':1,'apply':'exact local delta; never wholefile'})
(O/'shared-callsite-deltas.json').write_text(json.dumps(routes,ensure_ascii=False,indent=2)+'\n')
