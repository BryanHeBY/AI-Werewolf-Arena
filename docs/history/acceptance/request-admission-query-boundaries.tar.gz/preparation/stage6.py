from pathlib import Path
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-h03-request-admission-draft');C=O/'candidates'
def get(p):return (C/p).read_text()
def put(p,t):q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
p='backend/src/engine/actions/validation-queries.ts';t=get(p)
t=t.replace('host: ValidationHostInput): RuleViolation | string | null {','host: ValidationHostInput, receiver?: unknown): RuleViolation | string | null {')
t=t.replace('    if (!host.requestScopes) return run(host as ValidationHostContext);\n    return run({ ...host, scope, queries: createValidationQueries(host.world) });','''    const context = host.requestScopes
      ? { ...host, scope, queries: createValidationQueries(host.world) }
      : host as ValidationHostContext;
    return receiver === undefined ? run(context) : Reflect.apply(run, receiver, [context]);''')
t=t.replace('  return rule(context);','  return receiver === undefined ? rule(context) : Reflect.apply(rule, receiver, [context]);')
put(p,t)
p='backend/src/features/wolf-beauty/profile.ts';t=get(p).replace('import { ownedToolRules }','import { ownedToolRules, invokeValidationRule }')
t=t.replace('const inherited = WOLF_VALIDATION_RULES.kill_vote!(ctx);','''// 原表和 callee 仍在此处晚读；转发只按原 owner 关联 scope，未知替换规则只得到公开查询。
        const inherited = invokeValidationRule(WOLF_VALIDATION_RULES.kill_vote!, ctx, WOLF_VALIDATION_RULES);''');put(p,t)
p='backend/tests/unit/rulesets/wolf-tool-admission.test.ts';t=get(p)
t=t.replace('return function (this: unknown, ctx: ValidationRuleContext) {','return function (this: unknown, ctx: import("../../../src/engine/actions/validation-contracts").ValidationRuleContext) {')
t=t.replace('          expect(ctx).toBe(f.context);','''          // H03 明确退休公开 raw host；原表 receiver／晚 callee 保留，替换函数得到实际窄对象。
          expect(Object.hasOwn(ctx, "world")).toBe(false);
          expect(ctx.role).toBe(f.context.role);
          expect(ctx.queries.isAlive(1)).toBe(true);''');put(p,t)
p='backend/tests/unit/engine/actions/registered-request-admission.test.ts';t=get(p).replace('  }, 1);','  }, 1, () => true);');put(p,t)
# No new execution definition is needed where the map contains only existing owned functions/spreads.
for feature in ['psychic','mirror-girl','gargoyle','demon-hunter']:
 q=C/f'backend/src/features/{feature}/profile.ts'
 if q.exists():q.unlink()
