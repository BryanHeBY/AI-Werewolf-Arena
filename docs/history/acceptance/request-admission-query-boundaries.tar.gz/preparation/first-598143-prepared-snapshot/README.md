# H03 请求准入与公开验证边界候选

状态：TMP SourceReady，未应用仓库，作者未运行产品、解析器、类型、测试、格式化或门禁。Root 负责共同装配和首次检查。

## 精确范围与合并

`source-ready.json` 有 76 个路径：71 份完整候选与 5 处共享局部字段接线；其中 12 个新增（10 个生产所有者／契约文件、2 个风险文件）。31 个 profile **只应用 `profile-local-deltas.json` 的验证相关片段**，完整虚拟文件供阅读，不覆盖并行的非验证部分。Initial/Wild setup 及 Animal/Fragrant/Noble 三夜只应用 `shared-callsite-deltas.json`；后三项由 H02 夜调用作者承接，不能再应用一次。

`git-before.json` 为实际 5e26b88ae5208d927bcc28d408292a2cfeb43922 完整 Git 前态（批量 cat-file），记录 mode/blob/SHA/全文和真实 current 读点。旧源 current 除 WolfKing profile 的并行 death-hook 后继外均同该 Git 字节；该 profile 只应用验证片段，不能整稿覆盖。12 新路径无 Git 旧叶。4 controls 当时全文同 Git。早期 `before/` 是准备过程材料，不代替正式 Git 前态。

完整规则边界还必须覆盖 Hunter、WolfKing 的 shoot 回调和 WhiteWolfKing 的自爆回调；这三份 profile 是原逐名提案之外、Root 已收到必要性说明的同类闭包。Psychic/MirrorGirl/Gargoyle/Demon profile 仅引用已经注册的函数，无需重复修改。

## 实际所有权

- `action-validation-assembly` 是唯一列十族的可信组合根，保原 raw 政策序与全部十次证明观察序。Registry / Reception / Validator 无角色清单。
- 六族完整验证贡献迁 `validation-rules.ts`，包含原完整资格程序、raw reader（实际存在者）及证明关联。profile 在原 `validationRules` 字段位置调用创建函数；原 spread 与 callback 捕获不提前。初始身份的两项共享 raw 政策同属 InitialIdentity，未另造两壳。
- 原内建完整回调的静态定义表只存函数和 owner 身份，不存 World、请求、许可或资源。注册保原 callback 引用；可写表、继承展开仍照原时点发生。
- 可信内建程序仍在原 owner 接收完整宿主并执行原 World／资格算法。未知自定义回调的**实际对象**逐项建立，只有演员编号、候选字段和具体值查询对象；无 World、Catalog、raw scope / scope 集合，不是先 spread 后 delete。
- WolfBeauty 晚转发普通狼规则经同一边界重新关联原 Ghost 证明；保晚 table/callee 和原表 receiver，未知热替换函数仅得窄对象。
- ActionReception 用 `#world` 私有存储，公开 ActionTurn 接口只晚读 locale。
- BoundToolGateway 只公开验证方法 getter。原序 gateway → callee → World → 演员／调用／选项，实际调用保 receiver；非 callable 在调用点才失败。新增 Reflect/bind 准备是明确工具观察面，不宣称任意 monkeypatch 环境等价。

## 接受面与旧输入适配

原领域资格、raw 读取、首错、数字字符串修复、schema/repair/schema、死亡许可及资源写入都保原职责；不把任意 true 回调当作 scope、不将候选接受当作付款。公开 custom Rule 的 ctx.World / ctx.RoleCatalog / 十个 raw scope 字段明确退出；应使用 `ctx.queries` 的五个具体值查询。没有泛型 World-token 或 binder 入口。

四个直接 owner 测试保原完整 callback、资源、getter trace、结果与 receiver；增加查询闭包以使用可信内部类型。三处公开替换函数断言由旧 host/Catalog 身份迁为窄对象实际字段；这是新公开 API 接受面，不能称测试 JS 或全部程序等价。

两个新手写风险声明：真实六人 Lonely setup 验严格 raw 拒绝／伪 scope 拒绝／候选未付款及原真实提交；自定义 profile 验实际窄对象、跨 World 值隔离、gateway 求值次序／receiver与同 Error。预期为字面，不调用生产规则生成期望。

## 边界

不声称隔离任意未知对象图或对抗恶意 JS 对内部模块、内建表、Reflect 的强制 monkeypatch。可信内建 owner 的 role 仍是原局部对象；未知 callback 无 role 组件字段，只可查询枚举值。普通/特殊完整规则的 World 只属于可信 owner；公开 extension 输入退出 World 是本批实际行为／API 收口。准入装配避免在 Registry 构造时加载六族 profile；默认角色装配仍先构造 Catalog，raw/scope 定义由真实消费取得。未声称任意冷模块加载故障具有全环境等价性。

新 facade 与静态身份不新增运行 freeze；readonly 是窄公开类型，改写自己的 facade 不授予 World 或资源写权。首 bc663 准备样保于 `first-bc663-prepared-snapshot/`，未执行。

`execution-plan.json` / `types-config.json` / `heads.ts` 仅准备，全部 Bun 入口带 `--no-env-file`。Root 应在所有作者源齐并抓共同 fence 后执行；首红保原稿，只复失败或真实变根。无旧绿／模型／完整门禁重复。

静态同行后继：首 `94ee` 完整准备稿保于 `first-94ee-prepared-snapshot/`，尚未执行。公开 role 组件字段删除，可信宿主保原引用；新 `roleValue(id)` 只返回枚举值。此为真实公开数据 API 收口，不把 readonly 组件视作完成边界。原捕获 Git before5e26 保持，不将并行 D/E WIP 纳入本族 before 或被逆掉。
