/** 有限职责头检查准备器；仅 Root 在联合源冻结后执行，不加载游戏或模型。 */
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import path from "node:path";
import { checkComments } from "/home/hby/dev/AI-Werewolf-Arena/tooling/refactor/architecture/comment-check";
import { compiler } from "/home/hby/dev/AI-Werewolf-Arena/tooling/refactor/architecture/contracts";
const repo = "/home/hby/dev/AI-Werewolf-Arena";
const ready = JSON.parse(readFileSync("/tmp/awa-h03-request-admission-draft/source-ready.json", "utf8"));
const files = ready.source.map((row: { path: string }) => {
  const text = readFileSync(path.join(repo, row.path), "utf8");
  return { path: row.path, text, sha256: createHash("sha256").update(text).digest("hex") };
});
const documentationPaths = execFileSync("git", ["ls-files", "-z", "--", "docs", "README.md"], { cwd: repo, maxBuffer: 32 * 1024 * 1024 }).toString().split("\0").filter((file) => file.endsWith(".md"));
const diagnostics = checkComments(compiler(repo), { files, documentationPaths });
console.log(JSON.stringify({ source: files.map(({ path, sha256 }: { path: string; sha256: string }) => ({ path, sha256 })), roots: files.length, documentationPaths: documentationPaths.length, diagnostics }, null, 2));
if (diagnostics.length) process.exitCode = 1;
