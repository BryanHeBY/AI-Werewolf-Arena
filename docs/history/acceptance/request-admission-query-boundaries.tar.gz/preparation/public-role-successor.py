from pathlib import Path
import shutil,json,hashlib,difflib
O=Path('/tmp/awa-h03-request-admission-draft');C=O/'candidates';S=O/'first-94ee-prepared-snapshot';S.mkdir()
for n in ['candidates','HANDOFF.json','source-ready.json','README.md','git-before.json','edits.json','profile-local-deltas.json','candidate.patch','execution-plan.json','types-config.json','heads.ts','shared-callsite-deltas.json']:
 p=O/n;q=S/n
 if p.is_dir():shutil.copytree(p,q)
 else:shutil.copy2(p,q)
p=C/'backend/src/engine/actions/validation-contracts.ts';t=p.read_text().replace('import { RoleComponent } from "../../domain/components/role";\n','').replace('  role: RoleComponent;\n','').replace('窄查询／演员局部资料与候选','窄值查询与候选');p.write_text(t)
p=C/'backend/src/engine/actions/validation-queries.ts';t=p.read_text().replace('type Camp, type EntityId','type Camp, type Role, type EntityId').replace('import type { World }','import type { RoleComponent } from "../../domain/components/role";\nimport type { World }').replace('  readonly hasRole: (id: EntityId) => boolean;','  readonly hasRole: (id: EntityId) => boolean;\n  readonly roleValue: (id: EntityId) => Role | undefined;').replace('  readonly world: World;','  readonly role: RoleComponent;\n  readonly world: World;').replace('    hasRole: (id: EntityId) => world.getComponent(id, COMPONENT.Role) !== undefined,','    hasRole: (id: EntityId) => world.getComponent(id, COMPONENT.Role) !== undefined,\n    roleValue: (id: EntityId) => world.getComponent(id, COMPONENT.Role)?.role,').replace('actorId: host.actorId, role: host.role, toolCall: host.toolCall,','actorId: host.actorId, toolCall: host.toolCall,');p.write_text(t)
p=C/'backend/tests/unit/rulesets/wolf-tool-admission.test.ts';t=p.read_text().replace('          expect(ctx.role).toBe(f.context.role);','          expect(Object.hasOwn(ctx, "role")).toBe(false);\n          expect(ctx.queries.roleValue(1)).toBe(Role.Wolf);');p.write_text(t)
p=C/'backend/tests/unit/engine/actions/validation-query-boundary.test.ts';t=p.read_text().replace('        expect(Object.hasOwn(context, "world")).toBe(false);','        expect(Object.hasOwn(context, "world")).toBe(false);\n        expect(Object.hasOwn(context, "role")).toBe(false);').replace('["aliveIds", "currentCampValue", "hasRole", "isAlive"]','["aliveIds", "currentCampValue", "hasRole", "isAlive", "roleValue"]').replace('        expect(context.queries.hasRole(999)).toBe(false);','        expect(context.queries.hasRole(999)).toBe(false);\n        expect(context.queries.roleValue(1)).toBe(Role.Villager);').replace('actor.privateState 人为埋入的对象图','外来候选人为埋入的对象图');p.write_text(t)
p=O/'README.md';t=p.read_text().replace('只有原演员局部资料、候选字段和具体值查询对象','只有演员编号、候选字段和具体值查询对象').replace('四个具体值查询','五个具体值查询').replace('演员 role 仍是原局部对象。','可信内建 owner 的 role 仍是原局部对象；未知 callback 无 role 组件字段，只可查询枚举值。').replace('先前 `before/`','先前 `before/`');t+='\n静态同行后继：首 `94ee` 完整准备稿保于 `first-94ee-prepared-snapshot/`，尚未执行。公开 role 组件字段删除，可信宿主保原引用；新 `roleValue(id)` 只返回枚举值。此为真实公开数据 API 收口，不把 readonly 组件视作完成边界。原捕获 Git before5e26 保持，不将并行 D/E WIP 纳入本族 before 或被逆掉。\n';p.write_text(t)
# Retain the captured actual 5e26 Git baseline; regenerate only this author's candidate diff from those immutable texts.
sha=lambda b:hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest();read=json.loads((O/'git-before.json').read_text());before={x['path']:x for x in read['source']};ready=json.loads((O/'source-ready.json').read_text());edits=[];profiles=[];patch=[]
for row in ready['source']:
 if not row.get('candidate'):continue
 p=row['path'];a=(C/p).read_text();row['sha256']=sha(a);row['bytes']=len(a.encode());b=before[p]['text']
 if b is None:continue
 bl=b.splitlines(keepends=True);al=a.splitlines(keepends=True);offs=[0]
 for s in bl:offs.append(offs[-1]+len(s))
 steps=[]
 for g in difflib.SequenceMatcher(None,bl,al,autojunk=False).get_grouped_opcodes(3):
  i1=min(x[1] for x in g);i2=max(x[2] for x in g);j1=min(x[3] for x in g);j2=max(x[4] for x in g)
  steps.append({'path':p,'beforeStart':offs[i1],'beforeEnd':offs[i2],'before':''.join(bl[i1:i2]),'after':''.join(al[j1:j2])})
 r={'path':p,'beforeSHA256':sha(b),'afterSHA256':sha(a),'steps':steps};edits.append(r)
 if p.endswith('/profile.ts'):profiles.append(r)
 patch.extend(difflib.unified_diff(bl,al,fromfile='a/'+p,tofile='b/'+p))
write=lambda p,v:(O/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
ready['precheckSuccessor']={'reason':'Public actual Role component removed; trusted builtin role unchanged; only role enum query exposed','firstReady':'1af4a7aa93fd217db7d55f2bcb83a16bd7311375225a3f07e50311855d7057c4','checksExecuted':[]};write('source-ready.json',ready)
write('edits.json',{'baseCommit':read['baseCommit'],'source':edits,'localShared':json.loads((O/'shared-callsite-deltas.json').read_text())});write('profile-local-deltas.json',{'baseCommit':read['baseCommit'],'apply':'only exact validation/import/contribution fragments; preserve concurrent other owner fields','source':profiles});(O/'candidate.patch').write_text(''.join(patch))
h=json.loads((O/'HANDOFF.json').read_text());h['source']=ready['source'];h['sourceReadySHA256']=sha((O/'source-ready.json').read_bytes());h['secondPreparedSnapshot']='first-94ee-prepared-snapshot';h['precheckSuccessor']=ready['precheckSuccessor']
for a in h['artifacts']:
 p=O/a['path'];a['sha256']=sha(p.read_bytes());a['bytes']=p.stat().st_size
write('HANDOFF.json',h);print('ready',h['sourceReadySHA256']);print('HANDOFF',sha((O/'HANDOFF.json').read_bytes()))
