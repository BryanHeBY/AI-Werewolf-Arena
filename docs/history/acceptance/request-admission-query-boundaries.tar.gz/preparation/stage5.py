from pathlib import Path
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-h03-request-admission-draft');C=O/'candidates'
def get(p):return (C/p).read_text()
def put(p,t):q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
p='backend/src/engine/actions/action-reception.ts';t=get(p);t=t.replace('  readonly locale: Locale;\n  get locale(): Locale { return this.#world.locale; }\n','  readonly locale: Locale;\n');put(p,t)
p='backend/tests/unit/rulesets/seer-tool-admission.test.ts';t=get(p).replace('    return grantNightAbility(\n      queries: createValidationQueries(world),\n      world,','    return grantNightAbility(\n      world,');put(p,t)
put('backend/tests/unit/engine/actions/registered-request-admission.test.ts','''/**
 * 单元测试负责真实孤独少女准备窗口的贡献准入和原严格输入读取。
 * 输入为公开六人装配、真实 factory 请求及手写候选，输出用字面拒绝码／目标／Camp／事实数量断言。
 * 伪造 isCurrent 回调不是原 scope；成功候选不代替窗口自身付款，原角色库存与事件仍由真实 setup 提交。
 */
import { expect, test } from "bun:test";
import { Camp, Phase, Role, RuleError, type GameEvent } from "@ai-werewolf-arena/game-contract";
import { bootstrapGame } from "../../../../src/app/bootstrap";
import { COMPONENT } from "../../../../src/domain/components/names";
import { ActionReception } from "../../../../src/engine/actions/action-reception";
import { GameActionRequestFactory } from "../../../../src/engine/actions/action-request-factory";
import { ToolGateway } from "../../../../src/engine/actions/tool-gateway";
import { LonelyGirlSetupWindow } from "../../../../src/features/lonely-girl/setup";
import { getLonelyGirlState } from "../../../../src/features/lonely-girl/state-slot";
import { foxBoard } from "../../../support/features/cursed-fox/builders/scenario";

test("注册贡献保严格 raw 拒绝与真实证明，任意 true 回调不能替代本族 scope", async () => {
  const roles = [Role.LonelyGirl, Role.Wolf, Role.Wolf, Role.Seer, Role.Witch, Role.Villager];
  const game = bootstrapGame(foxBoard(roles), { fixedRoles: roles });
  const events: GameEvent[] = [];
  const receive = new ActionReception(game.world);
  const gateway = new ToolGateway();
  let entered = 0;
  const result = await new LonelyGirlSetupWindow(game.world, gateway, events, {
    get requestFactory() { return GameActionRequestFactory; },
  }).execute(game.boardConfig, {
    async getAction(request) {
      entered++;
      expect(request.actorId).toBe(1);
      expect(request.context.stage).toBe("lonely_girl");
      // 本族 reader 早于一般数字字符串修复，不能因搬出核心而接受原来非法的字符串目标。
      expect(receive.validate(request, "choose_admired_player", { target_id: "2" })).toMatchObject({
        ok: false, error: RuleError.LonelyGirlChoice,
      });
      expect(gateway.validateAndSanitize(game.world, 1,
        { name: "choose_admired_player", args: { target_id: 2 } },
        { phase: Phase.Night, day: 1, scope: { isCurrent: () => true } },
      )).toMatchObject({ ok: false, error: RuleError.LonelyGirlUnavailable });
      expect(receive.validate(request, "choose_admired_player", { target_id: 2 })).toMatchObject({
        ok: true, action: { name: "choose_admired_player", args: { target_id: 2 } },
      });
      const role = game.world.getComponent(1, COMPONENT.Role)!;
      expect(getLonelyGirlState(role)?.remaining).toBe(1);
      expect(events).toHaveLength(0);
      return { name: "choose_admired_player", args: { target_id: 2 } };
    },
  }, 1);
  expect(result).toBe(true);
  expect(entered).toBe(1);
  expect(getLonelyGirlState(game.world.getComponent(1, COMPONENT.Role)!)?.remaining).toBe(0);
  expect(game.world.getComponent(1, COMPONENT.Camp)?.camp).toBe(Camp.Wolf);
  expect(events.map((event) => event.type)).toEqual(["lonely_girl_admired_chosen"]);
  expect(events[0]?.payload).toMatchObject({ actorId: 1, targetId: 2, day: 1, camp: Camp.Wolf });
  expect(Object.hasOwn(receive, "world")).toBe(false);
  expect(receive.locale).toBe(game.world.locale);
});
''')
put('backend/tests/unit/engine/actions/validation-query-boundary.test.ts','''/**
 * 单元测试负责公开验证回调的实际窄对象和绑定网关求值边界。
 * 输入为手写三实体 World、自定义合法 profile 与访问器；输出采用固定字段集合、Camp 值及 getter／同 Error 轨迹。
 * 回调只得值查询，不得 World／Catalog／原 scope；绑定仍按原 gateway、callee、World、三个参数次序晚读。
 * 这是公开接口收窄测试，不声称抵御任意 monkeypatch 或 actor.privateState 人为埋入的对象图。
 */
import { expect, test } from "bun:test";
import { Camp, Phase, Role, type ToolCall } from "@ai-werewolf-arena/game-contract";
import { World } from "../../../../src/domain/world";
import { COMPONENT } from "../../../../src/domain/components/names";
import { createAliveComponent } from "../../../../src/domain/components/alive";
import { createRoleComponent } from "../../../../src/domain/components/role";
import { RoleCatalog } from "../../../../src/rulesets/roles/catalog";
import { ToolValidationRuleRegistry } from "../../../../src/engine/actions/tool-validation-rule-registry";
import { ActionValidator, type ValidationContext } from "../../../../src/engine/actions/action-validator";
import { ToolGateway, createBoundToolGateway } from "../../../../src/engine/actions/tool-gateway";
import type { ValidationRuleContext } from "../../../../src/engine/actions/validation-contracts";

function world(camp: Camp) {
  const value = new World();
  for (let index = 0; index < 3; index++) {
    const id = value.createEntity();
    value.addComponent(id, COMPONENT.Role, createRoleComponent(Role.Villager));
    value.addComponent(id, COMPONENT.Camp, { camp });
    value.addComponent(id, COMPONENT.Alive, createAliveComponent());
  }
  return value;
}

test("自定义规则只得当前绑定值查询，网关保 receiver 和不可调用 callee 的原参数错误时点", () => {
  const trace: string[] = [];
  const seen: ValidationRuleContext[] = [];
  const catalog = new RoleCatalog([{
    role: Role.Villager, camp: Camp.Good, label: "literal", skillBrief: "literal",
    validationRules: {
      speak(context) {
        seen.push(context);
        expect(Object.hasOwn(context, "world")).toBe(false);
        expect(Object.hasOwn(context, "roleCatalog")).toBe(false);
        expect(Object.hasOwn(context, "scope")).toBe(false);
        expect(Object.hasOwn(context, "requestScopes")).toBe(false);
        expect(Object.keys(context.queries).sort()).toEqual(["aliveIds", "currentCampValue", "hasRole", "isAlive"]);
        expect(Object.isFrozen(context.queries)).toBe(true);
        expect(context.queries.aliveIds()).toEqual([1, 2, 3]);
        expect(context.queries.isAlive(2)).toBe(true);
        expect(context.queries.hasRole(999)).toBe(false);
        return null;
      },
    },
  }], []);
  const first = world(Camp.Good), second = world(Camp.Wolf);
  const gateway = new ToolGateway(new ActionValidator(new ToolValidationRuleRegistry(undefined, catalog), false));
  const original = gateway.validateAndSanitize;
  Object.defineProperty(gateway, "validateAndSanitize", {
    configurable: true,
    get() {
      trace.push("callee");
      return function (this: ToolGateway, ...args: Parameters<ToolGateway["validateAndSanitize"]>) {
        expect(this).toBe(gateway);
        trace.push("invoke");
        return Reflect.apply(original, this, args);
      };
    },
  });
  const bound = createBoundToolGateway(() => { trace.push("gateway"); return gateway; }, () => { trace.push("world"); return first; });
  function actor() { trace.push("actor"); return 1; }
  function call(): ToolCall { trace.push("call"); return { name: "speak", args: { text: "literal" } }; }
  function options(): ValidationContext { trace.push("options"); return { phase: Phase.Day, scope: { isCurrent: () => true } }; }
  expect(bound.validateAndSanitize(actor(), call(), options()).ok).toBe(true);
  expect(trace).toEqual(["gateway", "callee", "world", "actor", "call", "options", "invoke"]);
  expect(seen[0]!.queries.currentCampValue(1)).toBe(Camp.Good);
  const other = createBoundToolGateway(() => gateway, () => second);
  expect(other.validateAndSanitize(1, { name: "speak", args: { text: "literal" } }, { phase: Phase.Day }).ok).toBe(true);
  expect(seen[1]!.queries.currentCampValue(1)).toBe(Camp.Wolf);
  expect(seen[0]!.queries.currentCampValue(1)).toBe(Camp.Good);
  expect(Object.keys(bound)).toEqual(["validateAndSanitize"]);
  // 非可调用 callee 在真正调用时才报错，不能在绑定属性读取时掩盖原参数 getter 的同 Error。
  Object.defineProperty(gateway, "validateAndSanitize", { configurable: true, get: () => null });
  const failure = new Error("literal_actor_argument_failure");
  expect(() => bound.validateAndSanitize((() => { throw failure; })(), call(), options())).toThrow(failure);
});
''')
