from pathlib import Path
import subprocess,hashlib,json,difflib
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-h03-request-admission-draft');C=O/'candidates'
sha=lambda b:hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()
write=lambda p,v:(O/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
local=json.loads((O/'shared-callsite-deltas.json').read_text()); shared={x['path'] for x in local}
files=sorted(str(q.relative_to(C)) for q in C.rglob('*.ts'))
allpaths=sorted(set(files)|shared)
controls=['backend/src/domain/request-lease.ts','backend/src/domain/components/names.ts','packages/game-contract/src/facts/lonely-girl.ts','packages/game-contract/src/facts/wall-notes.ts']
ls=subprocess.check_output(['git','ls-tree','-r',base,'--',*allpaths,*controls],cwd=R).decode().splitlines();tree={line.split('\t',1)[1]:line.split('\t',1)[0].split() for line in ls}
known=[p for p in allpaths+controls if p in tree]
raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join(base+':'+p+'\n' for p in known).encode(),cwd=R);pos=0;old={}
for p in known:
 end=raw.index(b'\n',pos);head=raw[pos:end].split();size=int(head[-1]);pos=end+1;old[p]=raw[pos:pos+size];pos+=size+1
before=[];source=[];edits=[];profile_edits=[];patch=[];deltas=[]
for p in allpaths:
 b=old.get(p);cur=(R/p).read_bytes() if (R/p).exists() else None
 row={'path':p,'existed':b is not None,'mode':tree[p][0] if p in tree else None,'blob':tree[p][2] if p in tree else None,'sha256':sha(b) if b is not None else None,'bytes':len(b) if b is not None else 0,'text':b.decode() if b is not None else None,'preparationCurrentSHA256':sha(cur) if cur is not None else None,'preparationCurrentSameGit':cur==b}
 before.append(row)
 if p in shared:
  source.append({'path':p,'apply':'shared-exact-delta-only','beforeSHA256':row['sha256'],'candidateWhole':None,'currentMayContainRootOwnedDelta':cur!=b});continue
 a=(C/p).read_bytes();mode='100644' if b is None else tree[p][0]
 isprofile=p.endswith('/profile.ts')
 source.append({'path':p,'change':'added' if b is None else 'modified','mode':mode,'sha256':sha(a),'bytes':len(a),'beforeSHA256':row['sha256'],'candidate':'candidates/'+p,'apply':'exact-validation-deltas-only' if isprofile else 'whole-file-after-before-guard'})
 if b is None:continue
 bt=b.decode();at=a.decode();bl=bt.splitlines(keepends=True);al=at.splitlines(keepends=True);bo=[0];ao=[0]
 for s in bl:bo.append(bo[-1]+len(s))
 for s in al:ao.append(ao[-1]+len(s))
 groups=list(difflib.SequenceMatcher(None,bl,al,autojunk=False).get_grouped_opcodes(3))
 steps=[]
 for group in groups:
  i1=min(x[1] for x in group);i2=max(x[2] for x in group);j1=min(x[3] for x in group);j2=max(x[4] for x in group)
  step={'path':p,'beforeStart':bo[i1],'beforeEnd':bo[i2],'before':''.join(bl[i1:i2]),'after':''.join(al[j1:j2])};steps.append(step)
 record={'path':p,'beforeSHA256':sha(b),'afterSHA256':sha(a),'steps':steps}
 edits.append(record)
 if isprofile:profile_edits.append(record)
 patch+=list(difflib.unified_diff(bl,al,fromfile='a/'+p,tofile='b/'+p))
control=[]
for p in controls:
 t=(R/p).read_bytes();control.append({'path':p,'mode':tree[p][0],'blob':tree[p][2],'sha256':sha(t),'bytes':len(t),'text':t.decode(),'sameGit':t==old[p]})
write('git-before.json',{'baseCommit':base,'capture':'actual Git cat-file batch fulltext, plus explicit actual current stage','source':before,'controls':control})
write('source-ready.json',{'kind':'H03-prepared-source-ready','baseCommit':base,'source':source,'deleted':[],'counts':{'candidateWholeFiles':len(files),'sharedExactOnly':len(shared),'sourcePaths':len(allpaths),'new':sum(x.get('change')=='added' for x in source),'profileExactOnly':len(profile_edits),'newRiskFiles':2},'checksExecuted':[],'repoWrites':False,'limits':['TMP candidates only; Root integrates overlapping profiles/setup/night exact deltas before the joint fence','Trusted built-in callbacks retain their full original owner input; unknown public callbacks receive only explicit public fields and value queries','Root Role contracts/default/builtin need no additional World binder or ten-family list','Module loading is lazy at trusted assembly; no assertion of arbitrary monkeypatched module-system equivalence']})
write('edits.json',{'baseCommit':base,'source':edits,'localShared':local})
write('profile-local-deltas.json',{'baseCommit':base,'apply':'only these exact validation/import/contribution fragments, never whole candidate profile over concurrent code','source':profile_edits})
(O/'candidate.patch').write_text(''.join(patch))
config={'extends':str(R/'backend/tsconfig.tests.json'),'compilerOptions':{'noEmit':True,'typeRoots':[str(R/'backend/node_modules'),str(R/'backend/node_modules/@types')]},'include':[],'exclude':[],'files':[str(R/p) for p in allpaths]};write('types-config.json',config)
write('execution-plan.json',{'status':'prepared-not-executed','cwd':str(R),'after':'Root applies all authors and captures final joint SHA fence','commands':{'newRisks':'bun --no-env-file test --preload ./backend/tests/setup.ts backend/tests/unit/engine/actions/registered-request-admission.test.ts backend/tests/unit/engine/actions/validation-query-boundary.test.ts','changedDirectOwnerContracts':'bun --no-env-file test --preload ./backend/tests/setup.ts backend/tests/unit/rulesets/wolf-tool-admission.test.ts backend/tests/unit/rulesets/guard-tool-admission.test.ts backend/tests/unit/rulesets/seer-tool-admission.test.ts backend/tests/unit/rulesets/potion-tool-admission.test.ts','finiteTypes':'bun --no-env-file backend/node_modules/typescript/bin/tsc --project /tmp/awa-h03-request-admission-draft/types-config.json --noEmit','finiteHeads':'bun --no-env-file /tmp/awa-h03-request-admission-draft/heads.ts'},'limits':['No old unchanged tests requested; the four direct-owner test inputs/public callback assertions change with H03','No runtime/model/full architecture gate by author; actual failure receipts must be retained before any repair','Root may combine finite types with the complete H02 cohort to avoid intermediate-state loads']})
print(json.dumps({'base':base,'sourcePaths':len(allpaths),'whole':len(files),'shared':len(shared),'new':sum(x.get('change')=='added' for x in source),'profiles':len(profile_edits),'gitMismatchWhole':[x['path'] for x in before if x['path']not in shared and not x['preparationCurrentSameGit']],'controlsSame':all(x['sameGit'] for x in control)},ensure_ascii=False))
