from pathlib import Path
import re
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-h03-request-admission-draft');C=O/'candidates';B=O/'before'
def get(p):
 q=C/p
 if q.exists():return q.read_text()
 t=(R/p).read_text();q=B/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t);return t
def put(p,t):q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
p='backend/src/engine/actions/validation-queries.ts';t=get(p)
t=t.replace('  const rule: ToolRule = () => { throw new Error("owned_tool_rule_requires_validation_host"); };\n  definitions.set(rule, { run, scopeOwner });\n  return rule;','''  // 不包一层执行函数：原 callback 引用、可写表和内部晚转发保持原样。仅可信 registry 识别这个定义。
  const rule = run as ToolRule;
  definitions.set(rule, { run, scopeOwner });
  return rule;''')
t=t.replace('    return run({ ...host, scope, queries: createValidationQueries(host.world) });','''    if (!host.requestScopes) return run(host as ValidationHostContext);
    return run({ ...host, scope, queries: createValidationQueries(host.world) });''')
put(p,t)
for p in ['backend/src/features/death-actions/death-shot.ts','backend/src/features/death-actions/death-abilities.ts']:
 put(p,get(p).replace('ValidationHostContext','ValidationHostInput'))
# Direct owner tests still exercise the exact original callback/reference/receiver. Their public rule-context type is retired.
for feature in ['wolf','guard','seer','potion']:
 p=f'backend/tests/unit/rulesets/{feature}-tool-admission.test.ts';t=get(p)
 # Keep isAliveTarget at original module; move only context type to trusted owner input.
 if 'import type { ValidationRuleContext } from "../../../src/engine/actions/validation-contracts";' in t:
  t=t.replace('import type { ValidationRuleContext } from "../../../src/engine/actions/validation-contracts";','import { createValidationQueries, type ValidationHostContext as ValidationRuleContext } from "../../../src/engine/actions/validation-queries";')
 else:
  t=t.replace('  ValidationRuleContext,\n','')
  k=t.index('import ');t=t[:k]+'import { createValidationQueries, type ValidationHostContext as ValidationRuleContext } from "../../../src/engine/actions/validation-queries";\n'+t[k:]
 t=t.replace('get ghostBrideScope()', 'get scope()')
 # All non-spread direct contexts get a query closure. Its creation does not query components or enter callbacks.
 t=re.sub(r'(?m)^(\s*)world,$',r'\1queries: createValidationQueries(world),\n\1world,',t)
 t=re.sub(r'(?m)^(\s*)world: (f\.world|game\.world),$',r'\1queries: createValidationQueries(\2),\n\1world: \2,',t)
 # Getter fixtures without an inherited base context need the required query field, but retain original getter order.
 t=re.sub(r'(?m)^(\s*)get world\(\) \{',r'\1queries: createValidationQueries(f.world),\n\1get world() {',t)
 # Potion's getter fixture already spreads base, another queries property is harmless but avoid duplicate/query input outside scope.
 if feature=='potion':t=t.replace('queries: createValidationQueries(f.world),\n      get world()', 'queries: createValidationQueries(f.world),\n      get world()')
 put(p,t)
# Clarify touched contract and map headers after physical responsibility move, no behavior change.
p='backend/src/engine/actions/common-validation-rules.ts';t=get(p).replace('提供通用工具的原校验集合：匿名墙检查作者／窗口，辩论检查参与者／阶段，放逐票检查票权与候选。','提供通用工具的原校验集合：辩论检查参与者／阶段，放逐票检查票权与候选；匿名墙完整准入归该机制贡献。');put(p,t)
p='backend/src/engine/actions/validation-contracts.ts';t=get(p).replace('输入为可信 World／上下文与候选 ID，输出描述规则结果及生命资格。','公开规则输入为窄查询／演员局部资料与候选；可信宿主的生命查询辅助保原 World 输入，输出规则结果及生命资格。');put(p,t)
p='backend/src/engine/actions/action-validator.ts';t=get(p).replace('所有模型工具调用在落地前都必须通过这里，非法动作统一返回错误并要求重试。','领域调用经过原生命／死亡窗口和已注册规则；结构化拒绝与抛错各保原前缀，不把候选接受当作已提交。');put(p,t)
