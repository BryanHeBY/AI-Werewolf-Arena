/**
 * 负责可信请求准入贡献的固定装配与 scope 所属身份。身份只路由原证明，不授予行动。
 * 输入为具体本族定义，输出保原 raw 政策顺序和十次 scope 观察顺序；不保存 World、许可或资源。
 * 模块只建立静态身份，实际定义在首次构造验证 registry 时加载，不提前装配 profile／时钟。
 */
import type { TrustedRequestAdmission } from "../engine/actions/validation-queries";
export const THIEF_VALIDATION_SCOPE = Object.freeze({});
export const SHAPESHIFTER_VALIDATION_SCOPE = Object.freeze({});
export const LONELY_GIRL_VALIDATION_SCOPE = Object.freeze({});
export const GHOST_BRIDE_VALIDATION_SCOPE = Object.freeze({});
export const DEMON_HUNTER_VALIDATION_SCOPE = Object.freeze({});
export const NOBLE_BODY_VALIDATION_SCOPE = Object.freeze({});
export const FRAGRANT_PAIR_VALIDATION_SCOPE = Object.freeze({});
export const ANIMAL_VALIDATION_SCOPE = Object.freeze({});
export const WILD_CHILD_VALIDATION_SCOPE = Object.freeze({});
export const WALL_VALIDATION_SCOPE = Object.freeze({});
export function createDefaultActionValidationAssembly() {
  const initial = require("../features/initial-identity/validation-rules") as typeof import("../features/initial-identity/validation-rules");
  const lonely = require("../features/lonely-girl/profile") as typeof import("../features/lonely-girl/profile");
  const ghost = require("../features/ghost-bride/profile") as typeof import("../features/ghost-bride/profile");
  const demon = require("../features/demon-hunter/validation-rules") as typeof import("../features/demon-hunter/validation-rules");
  const noble = require("../features/noble-secret-body/profile") as typeof import("../features/noble-secret-body/profile");
  const fragrant = require("../features/fragrant-pair-seer/profile") as typeof import("../features/fragrant-pair-seer/profile");
  const animal = require("../features/animal-dream/profile") as typeof import("../features/animal-dream/profile");
  const wild = require("../features/wild-child/profile") as typeof import("../features/wild-child/profile");
  const wall = require("../features/wall-notes/validation-rules") as typeof import("../features/wall-notes/validation-rules");
  const scopes: readonly TrustedRequestAdmission[] = [initial.THIEF_REQUEST_ADMISSION, initial.SHAPESHIFTER_REQUEST_ADMISSION, lonely.LONELY_GIRL_REQUEST_ADMISSION, ghost.GHOST_BRIDE_REQUEST_ADMISSION, demon.DEMON_REQUEST_ADMISSION, noble.NOBLE_BODY_REQUEST_ADMISSION, fragrant.FRAGRANT_PAIR_REQUEST_ADMISSION, animal.ANIMAL_REQUEST_ADMISSION, wild.WILD_CHILD_REQUEST_ADMISSION, wall.WALL_REQUEST_ADMISSION];
  const raw: readonly TrustedRequestAdmission[] = [wall.WALL_REQUEST_ADMISSION, initial.THIEF_REQUEST_ADMISSION, lonely.LONELY_GIRL_REQUEST_ADMISSION, wild.WILD_CHILD_REQUEST_ADMISSION, ghost.GHOST_BRIDE_REQUEST_ADMISSION, demon.DEMON_REQUEST_ADMISSION];
  return { scopes, raw, commonRules: wall.WALL_VALIDATION_RULES };
}
