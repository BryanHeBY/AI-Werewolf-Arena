from pathlib import Path
import shutil,re
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-h03-request-admission-draft');C=O/'candidates'
S=O/'pre-owner-layout-authoring-snapshot'
if not S.exists():shutil.copytree(C,S)
def get(p):return (C/p).read_text()
def put(p,t):q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
def close(t,start):
 pairs={'{':'}','(':')','[':']'};stack=[pairs[t[start]]];i=start+1
 while stack:
  ch=t[i]
  if ch in "'\"`":
   q=ch;i+=1
   while i<len(t):
    if t[i]=='\\':i+=2;continue
    if t[i]==q:i+=1;break
    i+=1
   continue
  if t.startswith('//',i):i=t.index('\n',i);continue
  if t.startswith('/*',i):i=t.index('*/',i+2)+2;continue
  if ch in pairs:stack.append(pairs[ch])
  elif ch==stack[-1]:stack.pop()
  i+=1
 return i
rows=[
 ('lonely-girl','LONELY_GIRL',['createLonelyGirlValidationRules'],'''import { authorizedLonelyGirl, lonelyGirlRequestScope } from "./lifecycle";
import { readLonelyGirlTool } from "./state-slot";'''),
 ('wild-child','WILD_CHILD',['createWildChildValidationRules'],'''import { authorizedWildChild, wildChildRequestScope } from "./lifecycle";
import { readWildChildTool } from "./state-slot";
import { WOLF_VALIDATION_RULES } from "../wolf/ability-ports";'''),
 ('ghost-bride','GHOST_BRIDE',['createGhostBrideValidationRules'],'''import { canSubmitWeddingTool, weddingSetup, ghostBrideRequestScope } from "./authority";
import { readWeddingTool } from "@ai-werewolf-arena/game-contract/facts/ghost-bride";
import type { OwnedToolRule as ToolRule } from "../../engine/actions/validation-queries";'''),
 ('noble-secret-body','NOBLE_BODY',['createNobleValidationRules','createSecretBodyValidationRules'],'''import { canSubmitNobleBodyChoice, nobleBodyRequestScope } from "./requests";
import { ORDINARY_WOLF_CONTRIBUTIONS } from "../wolf/ability-ports";'''),
 ('fragrant-pair-seer','FRAGRANT_PAIR',['createFragrantValidationRules','createPairValidationRules'],'''import { canSubmitFragrantPairChoice, fragrantPairRequestScope } from "./requests";
import { ORDINARY_WOLF_CONTRIBUTIONS } from "../wolf/ability-ports";'''),
 ('animal-dream','ANIMAL',['createFoxValidationRules','createPufferValidationRules'],'''import { canSubmitAnimalTool, animalRequestScope } from "./requests";''')]
for feature,key,names,imports in rows:
 p=f'backend/src/features/{feature}/profile.ts';t=get(p)
 a=t.index('/** 可信装配持有本族完整准入');contribution=t[a:];t=t[:a]
 expressions=[]
 starts=[m.end() for m in re.finditer(r'validationRules: ',t) if t[m.end():].startswith('ownedToolRules(')]
 if len(starts)!=len(names):raise ValueError((feature,len(starts),names))
 for start,name in reversed(list(zip(starts,names))):
  end=close(t,t.index('(',start));expressions.insert(0,(name,t[start:end]));t=t[:start]+name+'()'+t[end:]
 private=''
 if feature=='ghost-bride':
  a=t.index('const validate: ToolRule =');b=t.index('const target =',a);private=t[a:b];t=t[:a]+t[b:]
 # Remove only validation-owned imports from profile. Remaining init/config/presentation imports stay.
 t=re.sub(r'^import \{ (?:nobleBodyRequestScope|fragrantPairRequestScope|animalRequestScope|lonelyGirlRequestScope|wildChildRequestScope|ghostBrideRequestScope) \} from .*;\n','',t,flags=re.M)
 t=re.sub(r'^import type \{ TrustedRequestAdmission \} from .*;\n','',t,flags=re.M)
 t=re.sub(r'^import \{ '+key+r'_VALIDATION_SCOPE \} from .*;\n','',t,flags=re.M)
 t=t.replace('import { ownedToolRules } from "../../engine/actions/validation-queries";\n','')
 for line in ['import { canSubmitNobleBodyChoice } from "./requests";\n','import { canSubmitFragrantPairChoice } from "./requests";\n','import { canSubmitAnimalTool } from "./requests";\n','import { weddingSetup } from "./authority";\n','import { canSubmitWeddingTool } from "./authority";\n','import { readWeddingTool } from "@ai-werewolf-arena/game-contract/facts/ghost-bride";\n','import type { OwnedToolRule as ToolRule } from "../../engine/actions/validation-queries";\n']:
  t=t.replace(line,'')
 if feature=='lonely-girl':
  t=t.replace(', readLonelyGirlTool','').replace('authorizedLonelyGirl, ','')
 if feature=='wild-child':
  t=t.replace(', readWildChildTool','').replace('  authorizedWildChild,\n','').replace('import { WOLF_VALIDATION_RULES } from "../wolf/ability-ports";\n','')
 if t.count('RuleError')==1:t=t.replace('import { RuleError } from "@ai-werewolf-arena/game-contract";\n','')
 if feature=='noble-secret-body' and t.count('Phase')==1:t=t.replace('Camp, Phase, Role','Camp, Role')
 pos=t.index('*/')+2;t=t[:pos]+'\nimport { '+', '.join(names)+' } from "./validation-rules";\n'+t[pos:];put(p,t.rstrip()+'\n')
 header='''/**
 * 负责本族完整工具验证、原请求证明关联与原始参数准入。输入为可信宿主、原候选／scope，输出原拒绝或通过。
 * 规则表在 profile 原字段位置才创建，spread／回调捕获时点不提前；模块装配不保存 World、许可或第二份资源。
 * 公共扩展只获窄查询，原 opaque 证明仍须本族权威复验；预检不付款，getter／错误前缀保原顺序。
 */
'''
 out=header+'import { RuleError } from "@ai-werewolf-arena/game-contract";\nimport { ownedToolRules, type TrustedRequestAdmission } from "../../engine/actions/validation-queries";\nimport { '+key+'_VALIDATION_SCOPE } from "../../rulesets/action-validation-assembly";\n'+imports+'\n'+private
 for name,expression in expressions:out+='\nexport function '+name+'() {\n  return '+expression+';\n}\n'
 out+='\n'+contribution;put(f'backend/src/features/{feature}/validation-rules.ts',out)
p='backend/src/rulesets/action-validation-assembly.ts';t=get(p)
for feature,_,_,_ in rows:t=t.replace(f'../features/{feature}/profile',f'../features/{feature}/validation-rules')
t=t.replace('实际定义在首次构造验证 registry 时加载，不提前装配 profile／时钟。','实际定义只加载各本族验证 owner，不提前装配 profile／阶段时钟。');put(p,t)
p='backend/src/engine/actions/validation-queries.ts';t=get(p).replace(' * 自定义 ToolRule 只收到这些查询和原候选，不收到 World、Catalog 或请求 scope。',' * 输入为可信宿主或原候选，输出为窄值查询或原规则结果；自定义 ToolRule 不收到 World、Catalog 或请求 scope。');put(p,t)
for p in ['backend/src/features/mechanical-wolf/rules.ts','backend/src/features/awakened-hidden-wolf/rules.ts']:
 t=get(p).replace(', OwnedToolRuleMap as ToolRuleMap','').replace('  type OwnedToolRuleMap as ToolRuleMap,\n','');put(p,t)
