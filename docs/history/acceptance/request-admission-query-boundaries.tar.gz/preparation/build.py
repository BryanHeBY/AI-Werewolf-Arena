from pathlib import Path
import json,re,subprocess,hashlib
ROOT=Path('/home/hby/dev/AI-Werewolf-Arena')
OUT=Path('/tmp/awa-h03-request-admission-draft')
C=OUT/'candidates'; B=OUT/'before'; C.mkdir(exist_ok=True);B.mkdir(exist_ok=True)
BASE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
S={}
def get(p):
 if p not in S:
  t=(ROOT/p).read_text();S[p]=t;q=B/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
 return S[p]
def put(p,t):
 q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
def rep(t,a,b):
 if t.count(a)!=1:raise ValueError(('exact anchor',a[:90],t.count(a)))
 return t.replace(a,b,1)
def close(t,start):
 # Authoring-only lexical boundary finder; no compiler/parser/product execution.
 pairs={'{':'}','(':')','[':']'};stack=[pairs[t[start]]];i=start+1
 while stack:
  ch=t[i]
  if ch in "'\"`":
   quote=ch;i+=1
   while i<len(t):
    if t[i]=='\\':i+=2;continue
    if t[i]==quote:i+=1;break
    i+=1
   continue
  if t.startswith('//',i):
   i=t.find('\n',i)
   if i<0:raise ValueError('comment eof')
   continue
  if t.startswith('/*',i):i=t.index('*/',i+2)+2;continue
  if ch in pairs:stack.append(pairs[ch])
  elif ch==stack[-1]:stack.pop()
  i+=1
 return i
# Public callback contracts: host implementation lives separately, no World/RoleCatalog/scope in actual rule context.
p='backend/src/engine/actions/validation-contracts.ts';t=get(p)
t=re.sub(r'^  (?:thief|shapeshifter|wildChild|lonelyGirl|ghostBride|demonHunter|nobleBody|fragrantPair|animal|wall)Scope\?: object;\n','',t,flags=re.M)
t=t.replace('  roleCatalog: RoleCatalog;\n','').replace('  world: World;\n','  readonly queries: ValidationQueries;\n')
t=t.replace('import type { RoleCatalog } from "../../rulesets/roles/catalog";','import type { ValidationQueries } from "./validation-queries";')
put(p,t)
p='backend/src/engine/actions/validation-queries.ts'
put(p,'''/**
 * 负责验证扩展的实际窄查询对象，以及可信内建规则的原程序绑定。
 * 自定义 ToolRule 只收到这些查询和原候选，不收到 World、Catalog 或请求 scope。
 * 内建定义表只存静态函数与 scope 所属身份；每次调用才绑定原 host，不缓存局、许可或资源。
 * 私有绑定不是新的授权：每个原领域程序仍用同一 World 与原 opaque scope 复验。
 */
import { RuleError, type Camp, type EntityId, type ToolCall, type RuleViolation } from "@ai-werewolf-arena/game-contract";
import { COMPONENT } from "../../domain/components/names";
import type { World } from "../../domain/world";
import type { RoleCatalog } from "../../rulesets/roles/catalog";
import type { ToolRule, ToolRuleMap, ValidationRuleContext } from "./validation-contracts";

/** 实际对象只具有这些值查询；不返回 World、组件 Map、可写句柄或可关闭的死亡许可。 */
export interface ValidationQueries {
  isAlive(id: EntityId): boolean;
  aliveIds(): readonly EntityId[];
  currentCampValue(id: EntityId): Camp | undefined;
  hasRole(id: EntityId): boolean;
}
/** 只在可信接收／验证 host 内传递，不作为可替换 ToolRule 的输入。 */
export interface ValidationScopeInput { readonly owner: object; readonly scope: object | undefined }
export interface ValidationHostContext extends Omit<ValidationRuleContext, "queries"> {
  readonly world: World;
  readonly roleCatalog: RoleCatalog;
  readonly scope?: object;
  readonly requestScopes?: readonly ValidationScopeInput[];
}
export type OwnedToolRule = (ctx: ValidationHostContext) => RuleViolation | string | null;
export type OwnedToolRuleMap = Partial<Record<ToolCall["name"], OwnedToolRule | ToolRule>>;
const definitions = new WeakMap<ToolRule, { readonly run: OwnedToolRule; readonly scopeOwner?: object }>();
/** 仅可信本族定义使用；公共 RoleRuntimeContribution 不接收或调用 World binder。 */
export function ownedToolRule(run: OwnedToolRule, scopeOwner?: object): ToolRule {
  if (definitions.has(run as ToolRule)) return run as ToolRule;
  const rule: ToolRule = () => { throw new Error("owned_tool_rule_requires_validation_host"); };
  definitions.set(rule, { run, scopeOwner });
  return rule;
}
/** 原对象字面／spread先完成；继承的真实定义保持原函数引用和自己的 scope 所属身份。 */
export function ownedToolRules(rules: OwnedToolRuleMap, scopeOwner?: object): ToolRuleMap {
  return Object.fromEntries(Object.entries(rules).map(([name, rule]) => [name, ownedToolRule(rule as OwnedToolRule, scopeOwner)]));
}
export function createValidationQueries(world: World): ValidationQueries {
  return Object.freeze({
    isAlive: (id: EntityId) => world.getComponent(id, COMPONENT.Alive)?.alive === true,
    aliveIds: () => world.getAliveEntityIds(),
    currentCampValue: (id: EntityId) => world.getComponent(id, COMPONENT.Camp)?.camp,
    hasRole: (id: EntityId) => world.getComponent(id, COMPONENT.Role) !== undefined,
  });
}
/** 内建规则只由可信 registry 以原 host执行；任意 caller 的回调不能作为 opaque scope 获权。 */
export function invokeValidationRule(rule: ToolRule, host: ValidationHostContext): RuleViolation | string | null {
  const definition = definitions.get(rule);
  if (definition) {
    const run = definition.run;
    const scope = definition.scopeOwner && host.requestScopes
      ? host.requestScopes.find((entry) => entry.owner === definition.scopeOwner)?.scope
      : host.scope;
    return run({ ...host, scope });
  }
  // 新对象显式列公共字段，不能先spread host再delete World：那会把真实句柄交给getter/扩展。
  const context: ValidationRuleContext = {
    actorId: host.actorId, role: host.role, toolCall: host.toolCall,
    phase: host.phase, day: host.day, queries: createValidationQueries(host.world),
    wallId: host.wallId, itemInstanceId: host.itemInstanceId, debateId: host.debateId,
    abilityId: host.abilityId, actionWindow: host.actionWindow,
    allowSelfDestruct: host.allowSelfDestruct, duelWindow: host.duelWindow,
    allowKnightDuel: host.allowKnightDuel, sheriffCandidates: host.sheriffCandidates,
    exileCandidates: host.exileCandidates, badgeCandidates: host.badgeCandidates,
  };
  return rule(context);
}
''')
# Existing full callback bodies remain in their actual feature owner; wrap complete map literals, never replace business conditions.
scope_features={'thief':'THIEF','shapeshifter':'SHAPESHIFTER','wild-child':'WILD_CHILD','lonely-girl':'LONELY_GIRL','ghost-bride':'GHOST_BRIDE','noble-secret-body':'NOBLE_BODY','fragrant-pair-seer':'FRAGRANT_PAIR','animal-dream':'ANIMAL'}
profiles=['thief','shapeshifter','wild-child','lonely-girl','ghost-bride','noble-secret-body','fragrant-pair-seer','animal-dream','awakened-hidden-wolf','black-market-merchant','cupid','debater','dreamer','hybrid','knight','magician','miracle-merchant','nightmare','order-prince','scholar-mentor','trickster','time-wolf-consort','wolf-beauty','wolf-sorcerer','radiant-eclipse','mist-raven']
oldscopes={'thiefScope':'THIEF','shapeshifterScope':'SHAPESHIFTER','wildChildScope':'WILD_CHILD','lonelyGirlScope':'LONELY_GIRL','ghostBrideScope':'GHOST_BRIDE','nobleBodyScope':'NOBLE_BODY','fragrantPairScope':'FRAGRANT_PAIR','animalScope':'ANIMAL'}
for feature in profiles:
 p=f'backend/src/features/{feature}/profile.ts';t=get(p);key=scope_features.get(feature)
 starts=[m.end()-1 for m in re.finditer(r'validationRules: \{',t)]
 for start in reversed(starts):
  end=close(t,start);block=t[start:end]
  for name in oldscopes:
   # Only destructured parameter names are changed; all original body local identifiers remain.
   block=re.sub(r'(?<![\w.])'+name+r'(?=[\s,}])','scope: '+name,block,count=1)
  t=t[:start]+'ownedToolRules('+block+(', '+key+'_VALIDATION_SCOPE' if key else '')+')'+t[end:]
 if starts:
  t='import { ownedToolRules } from "../../engine/actions/validation-queries";\n'+t
  if key:t='import { '+key+'_VALIDATION_SCOPE } from "../../rulesets/action-validation-assembly";\n'+t
 # Ghost named validation function must be owned; its map refers to it rather than an inline body.
 if feature=='ghost-bride':
  t=t.replace('import type { ToolRule } from "../../engine/actions/validation-contracts";','import type { OwnedToolRule as ToolRule } from "../../engine/actions/validation-queries";')
  t=t.replace('day, ghostBrideScope, toolCall','day, scope: ghostBrideScope, toolCall')
 put(p,t)
# Complete shared maps.
for p,name,key in [
 ('backend/src/engine/actions/common-validation-rules.ts','COMMON_VALIDATION_RULES',None),
 ('backend/src/rulesets/wolf-tool-admission.ts','WOLF_VALIDATION_RULES','GHOST_BRIDE'),
 ('backend/src/rulesets/guard-tool-admission.ts','GUARD_VALIDATION_RULES',None),
 ('backend/src/rulesets/seer-tool-admission.ts','SEER_VALIDATION_RULES',None),
 ('backend/src/rulesets/potion-tool-admission.ts','WITCH_VALIDATION_RULES',None),
 ('backend/src/features/sheriff/validation-rules.ts','SHERIFF_VALIDATION_RULES',None)]:
 t=get(p);match=re.search(r'export const '+name+r': ToolRuleMap = \{',t);start=match.end()-1;end=close(t,start);block=t[start:end]
 for old in ['wallScope','ghostBrideScope']:block=re.sub(r'(?<![\w.])'+old+r'(?=[\s,}])','scope: '+old,block,count=1)
 if name=='COMMON_VALIDATION_RULES':
  startwall=block.index('  write_note:');endwall=block.index('  debate_vote:');block=block[:startwall]+block[endwall:]
  t=t.replace('import { readWallTool } from "@ai-werewolf-arena/game-contract/facts/wall-notes";\n','').replace('import { authorizedWallAuthor } from "../../features/wall-notes/author-ports";\n','')
  match=re.search(r'export const '+name+r': ToolRuleMap = \{',t);start=match.end()-1;end=close(t,start)
 t=t[:start]+'ownedToolRules('+block+(', '+key+'_VALIDATION_SCOPE' if key else '')+')'+t[end:]
 helper='../../engine/actions/validation-queries' if p.startswith('backend/src/features') else ('./validation-queries' if p.startswith('backend/src/engine') else '../engine/actions/validation-queries')
 t='import { ownedToolRules } from "'+helper+'";\n'+t
 if key:t='import { '+key+'_VALIDATION_SCOPE } from "./action-validation-assembly";\n'+t
 put(p,t)
# Named full rules use owned host type; exported callable itself is wrapped at the map callsite or function definition.
for p in ['backend/src/features/demon-hunter/validation-rules.ts','backend/src/features/role-inspection/rules.ts','backend/src/features/pure-white/rules.ts','backend/src/features/mechanical-wolf/rules.ts','backend/src/features/awakened-hidden-wolf/rules.ts']:
 t=get(p);t=t.replace('type { ToolRule } from "../../engine/actions/validation-contracts"','type { OwnedToolRule as ToolRule } from "../../engine/actions/validation-queries"')
 t=t.replace('type { ToolRule, ToolRuleMap } from "../../engine/actions/validation-contracts"','type { OwnedToolRule as ToolRule, OwnedToolRuleMap as ToolRuleMap } from "../../engine/actions/validation-queries"')
 t=t.replace('  type ToolRule,\n  type ToolRuleMap,','  type OwnedToolRule as ToolRule,\n  type OwnedToolRuleMap as ToolRuleMap,') if 'awakened-hidden' in p else t
 if 'awakened-hidden' in p:
  t=t.replace('} from "../../engine/actions/validation-contracts";','} from "../../engine/actions/validation-queries";')
  t=t.replace('  isAliveTarget,\n','');t='import { isAliveTarget } from "../../engine/actions/validation-contracts";\n'+t
 if 'demon-hunter' in p:t=t.replace('  demonHunterScope,','  scope: demonHunterScope,')
 put(p,t)
for p in ['backend/src/features/death-actions/death-shot.ts','backend/src/features/death-actions/death-abilities.ts']:
 t=get(p).replace('ValidationRuleContext','ValidationHostContext')
 # keep isAliveTarget import at its actual owner, move only host type.
 t=t.replace('  type ValidationHostContext,\n','')
 t=t.replace('import type { ValidationHostContext } from "../../engine/actions/validation-contracts";','import type { ValidationHostContext } from "../../engine/actions/validation-queries";')
 if 'death-shot.ts' in p:t='import type { ValidationHostContext } from "../../engine/actions/validation-queries";\n'+t
 put(p,t)
(OUT/'authoring-status.json').write_text(json.dumps({'base':BASE,'phase':'initial fullbody wrappers and publiccontext; not sourceReady','existingCaptured':len(S),'checksExecuted':[],'repoWrites':False},indent=2)+'\n')
