from pathlib import Path
import re,json
ROOT=Path('/home/hby/dev/AI-Werewolf-Arena');OUT=Path('/tmp/awa-h03-request-admission-draft');C=OUT/'candidates';B=OUT/'before'
def get(p):
 q=C/p
 if q.exists():return q.read_text()
 t=(ROOT/p).read_text();z=B/p;z.parent.mkdir(parents=True,exist_ok=True);z.write_text(t);return t
def put(p,t):q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
def addimport(t,s):
 pos=t.index('*/')+2 if t.lstrip().startswith('/**') else 0
 return t[:pos]+'\n'+s+'\n'+t[pos:]
def close(t,start):
 pairs={'{':'}','(':')','[':']'};stack=[pairs[t[start]]];i=start+1
 while stack:
  ch=t[i]
  if ch in "'\"`":
   quote=ch;i+=1
   while i<len(t):
    if t[i]=='\\':i+=2;continue
    if t[i]==quote:i+=1;break
    i+=1
   continue
  if t.startswith('//',i):i=t.index('\n',i);continue
  if t.startswith('/*',i):i=t.index('*/',i+2)+2;continue
  if ch in pairs:stack.append(pairs[ch])
  elif ch==stack[-1]:stack.pop()
  i+=1
 return i
# Maps omitted from first group (native/learned death callbacks also need a trusted host).
for fp in (ROOT/'backend/src/features').glob('*/profile.ts'):
 p=str(fp.relative_to(ROOT));t=get(p)
 starts=[m.end()-1 for m in re.finditer(r'validationRules: \{',t)]
 if not starts:continue
 for s in reversed(starts):
  e=close(t,s);t=t[:s]+'ownedToolRules('+t[s:e]+')'+t[e:]
 t=addimport(t,'import { ownedToolRules } from "../../engine/actions/validation-queries";');put(p,t)
# Named exported full rules become public rule identities with private trusted execution definitions.
for p,symbol,key in [
 ('backend/src/features/demon-hunter/validation-rules.ts','DEMON_HUNTER_TOOL_RULE','DEMON_HUNTER'),
 ('backend/src/features/role-inspection/rules.ts','validateRoleInspection',None),
 ('backend/src/features/pure-white/rules.ts','validatePureWhiteInspection',None)]:
 t=get(p);m=re.search(r'export const '+symbol+r': ToolRule = ',t);s=m.end()
 # End of declaration: its complete arrow ends at the next top-level semicolon, balance ordinary quotes/braces.
 pos=s;level=0;quote=None
 while pos<len(t):
  ch=t[pos]
  if ch in "'\"`":
   q=ch;pos+=1
   while pos<len(t):
    if t[pos]=='\\':pos+=2;continue
    if t[pos]==q:break
    pos+=1
  elif t.startswith('//',pos):pos=t.index('\n',pos)
  elif ch in '({[':level+=1
  elif ch in ')}]':level-=1
  elif ch==';' and level==0:break
  pos+=1
 body=t[s:pos];t=t[:m.start()]+'export const '+symbol+' = ownedToolRule('+body+(', '+key+'_VALIDATION_SCOPE' if key else '')+')'+t[pos:]
 t=addimport(t,'import { ownedToolRule } from "../../engine/actions/validation-queries";')
 # The previous erased type alias is no longer needed on exported declaration.
 t=t.replace('import type { OwnedToolRule as ToolRule } from "../../engine/actions/validation-queries";\n','')
 if key:t=addimport(t,'import { '+key+'_VALIDATION_SCOPE } from "../../rulesets/action-validation-assembly";')
 put(p,t)
# Mechanical/Awakened local maps only become public at this complete map boundary.
for p,name in [('backend/src/features/mechanical-wolf/rules.ts','MECHANICAL_VALIDATION_RULES'),('backend/src/features/awakened-hidden-wolf/rules.ts','AWAKENED_VALIDATION_RULES')]:
 t=get(p);m=re.search(r'export const '+name+r': ToolRuleMap = Object.fromEntries\(',t);s=m.end()-1;e=close(t,s)
 t=t[:m.start()]+t[m.start():s].replace(': ToolRuleMap',': PublicToolRuleMap')+'ownedToolRules(Object.fromEntries'+t[s:e]+')'+t[e:]
 t=addimport(t,'import { ownedToolRules } from "../../engine/actions/validation-queries";\nimport type { ToolRuleMap as PublicToolRuleMap } from "../../engine/actions/validation-contracts";');put(p,t)
# Shared typed admission definition; these factories are private trusted composition, not user callbacks.
p='backend/src/engine/actions/validation-queries.ts';t=get(p)
t+='''
/** 原 reader 的成功参数与领域错误分开；undefined 表示保一般参数，不等空选择或失败。 */
export type RawAdmissionResult = { readonly ok: true; readonly args?: Record<string, unknown> } | { readonly ok: false; readonly error: string };
export interface TrustedRequestAdmission {
  readonly owner: object;
  capture(world: World, request: import("../../domain/actions").ActionRequest): object | undefined;
  raw?(world: World, request: import("../../domain/actions").ActionRequest, tool: ToolCall["name"], rawArgs: unknown): RawAdmissionResult;
}
''';put(p,t)
# Actual ordered root; core never names a family. Definitions are lazily loaded after Catalog construction.
put('backend/src/rulesets/action-validation-assembly.ts','''/**
 * 负责可信请求准入贡献的固定装配与 scope 所属身份。身份只路由原证明，不授予行动。
 * 输入为具体本族定义，输出保原 raw 政策顺序和十次 scope 观察顺序；不保存 World、许可或资源。
 * 模块只建立静态身份，实际定义在首次构造验证 registry 时加载，不提前装配 profile／时钟。
 */
import type { TrustedRequestAdmission } from "../engine/actions/validation-queries";
export const THIEF_VALIDATION_SCOPE = Object.freeze({});
export const SHAPESHIFTER_VALIDATION_SCOPE = Object.freeze({});
export const LONELY_GIRL_VALIDATION_SCOPE = Object.freeze({});
export const GHOST_BRIDE_VALIDATION_SCOPE = Object.freeze({});
export const DEMON_HUNTER_VALIDATION_SCOPE = Object.freeze({});
export const NOBLE_BODY_VALIDATION_SCOPE = Object.freeze({});
export const FRAGRANT_PAIR_VALIDATION_SCOPE = Object.freeze({});
export const ANIMAL_VALIDATION_SCOPE = Object.freeze({});
export const WILD_CHILD_VALIDATION_SCOPE = Object.freeze({});
export const WALL_VALIDATION_SCOPE = Object.freeze({});
export function createDefaultActionValidationAssembly() {
  const initial = require("../features/initial-identity/validation-rules") as typeof import("../features/initial-identity/validation-rules");
  const lonely = require("../features/lonely-girl/profile") as typeof import("../features/lonely-girl/profile");
  const ghost = require("../features/ghost-bride/profile") as typeof import("../features/ghost-bride/profile");
  const demon = require("../features/demon-hunter/validation-rules") as typeof import("../features/demon-hunter/validation-rules");
  const noble = require("../features/noble-secret-body/profile") as typeof import("../features/noble-secret-body/profile");
  const fragrant = require("../features/fragrant-pair-seer/profile") as typeof import("../features/fragrant-pair-seer/profile");
  const animal = require("../features/animal-dream/profile") as typeof import("../features/animal-dream/profile");
  const wild = require("../features/wild-child/profile") as typeof import("../features/wild-child/profile");
  const wall = require("../features/wall-notes/validation-rules") as typeof import("../features/wall-notes/validation-rules");
  const scopes: readonly TrustedRequestAdmission[] = [initial.THIEF_REQUEST_ADMISSION, initial.SHAPESHIFTER_REQUEST_ADMISSION, lonely.LONELY_GIRL_REQUEST_ADMISSION, ghost.GHOST_BRIDE_REQUEST_ADMISSION, demon.DEMON_REQUEST_ADMISSION, noble.NOBLE_BODY_REQUEST_ADMISSION, fragrant.FRAGRANT_PAIR_REQUEST_ADMISSION, animal.ANIMAL_REQUEST_ADMISSION, wild.WILD_CHILD_REQUEST_ADMISSION, wall.WALL_REQUEST_ADMISSION];
  const raw: readonly TrustedRequestAdmission[] = [wall.WALL_REQUEST_ADMISSION, initial.THIEF_REQUEST_ADMISSION, lonely.LONELY_GIRL_REQUEST_ADMISSION, wild.WILD_CHILD_REQUEST_ADMISSION, ghost.GHOST_BRIDE_REQUEST_ADMISSION, demon.DEMON_REQUEST_ADMISSION];
  return { scopes, raw, commonRules: wall.WALL_VALIDATION_RULES };
}
''')
put('backend/src/features/initial-identity/validation-rules.ts','''/**
 * 负责盗贼／千面人共同原始卡位读取与两份真实请求证明的接线。输入保原 request／参数，
 * 输出原 slot 或原错误；不安装身份、复制牌或把路由身份当权限。两种领域 allowedSlots 政策仍由各 profile 的完整规则复验。
 */
import { RuleError } from "@ai-werewolf-arena/game-contract";
import { readThiefChoice } from "../thief/state-ports";
import { thiefRequestScope } from "../thief/setup";
import { shapeshifterRequestScope } from "../shapeshifter/setup";
import { THIEF_VALIDATION_SCOPE, SHAPESHIFTER_VALIDATION_SCOPE } from "../../rulesets/action-validation-assembly";
import type { TrustedRequestAdmission } from "../../engine/actions/validation-queries";
export const THIEF_REQUEST_ADMISSION: TrustedRequestAdmission = {
  owner: THIEF_VALIDATION_SCOPE,
  capture: thiefRequestScope,
  raw: (_world, _request, tool, rawArgs) => {
    const initialChoice = tool === "choose_thief_card" || tool === "choose_shapeshifter_card";
    const thiefSlot = initialChoice ? readThiefChoice(rawArgs) : undefined;
    if (initialChoice && thiefSlot === undefined) return { ok: false, error: tool === "choose_thief_card" ? RuleError.ThiefChoice : RuleError.ShapeshifterChoice };
    return { ok: true, ...(initialChoice ? { args: { slot: thiefSlot } } : {}) };
  },
};
export const SHAPESHIFTER_REQUEST_ADMISSION: TrustedRequestAdmission = { owner: SHAPESHIFTER_VALIDATION_SCOPE, capture: shapeshifterRequestScope };
''')
# Append actual contributions to the same existing full validation owner modules.
rows=[
 ('lonely-girl','LONELY_GIRL','lonelyGirlRequestScope','./lifecycle','''  raw: (_world, _request, tool, rawArgs) => tool === "choose_admired_player" && !readLonelyGirlTool({ name: tool, args: rawArgs }) ? { ok: false, error: RuleError.LonelyGirlChoice } : { ok: true },'''),
 ('wild-child','WILD_CHILD','wildChildRequestScope','./lifecycle','''  raw: (_world, _request, tool, rawArgs) => {
    const call = tool === "choose_wild_model" ? readWildChildTool({ name: tool, args: rawArgs }) : null;
    if (tool === "choose_wild_model" && !call) return { ok: false, error: RuleError.WildChildChoice };
    return { ok: true, ...(call ? { args: call.args } : {}) };
  },'''),
 ('ghost-bride','GHOST_BRIDE','ghostBrideRequestScope','./authority','''  raw: (world, _request, tool, rawArgs) => {
    const weddingTool = ["choose_bridegroom", "choose_wedding_witness", "speak_to_partner", "wedding_kill_vote"].includes(tool) || (tool === "kill_vote" && weddingSetup(world) !== null);
    const call = weddingTool ? readWeddingTool({ name: tool, args: rawArgs }) : null;
    if (weddingTool && !call) return { ok: false, error: RuleError.GhostBrideChoice };
    return { ok: true, ...(call ? { args: call.args } : {}) };
  },'''),
 ('noble-secret-body','NOBLE_BODY','nobleBodyRequestScope','./requests',''),
 ('fragrant-pair-seer','FRAGRANT_PAIR','fragrantPairRequestScope','./requests',''),
 ('animal-dream','ANIMAL','animalRequestScope','./requests','')]
for feature,key,capture,mod,raw in rows:
 p=f'backend/src/features/{feature}/profile.ts';t=get(p)
 t=addimport(t,'import { '+capture+' } from "'+mod+'";\nimport type { TrustedRequestAdmission } from "../../engine/actions/validation-queries";')
 if feature=='ghost-bride':t=addimport(t,'import { weddingSetup } from "./authority";\nimport { readWeddingTool } from "@ai-werewolf-arena/game-contract/facts/ghost-bride";')
 t+='\n/** 可信装配持有本族完整准入；scope观察仍在接收器原阶段，原对象不交公开规则扩展。 */\nexport const '+key+'_REQUEST_ADMISSION: TrustedRequestAdmission = {\n  owner: '+key+'_VALIDATION_SCOPE,\n  capture: '+capture+',\n'+raw+'\n};\n'
 put(p,t)
# Wall owns both its complete rule and raw request reader; no longer in core common map.
put('backend/src/features/wall-notes/validation-rules.ts','''/**
 * 负责匿名墙原始文本准入、作者／窗口证明与完整工具验证。输入为原 World 内可信绑定与候选，
 * 输出原错误或通过；处理完成不代表纸条 accepted 或已付款，库存／事实写权仍归 window/authority。
 */
import { readWallTool } from "@ai-werewolf-arena/game-contract/facts/wall-notes";
import { RuleError, Phase } from "@ai-werewolf-arena/game-contract";
import { authorizedWallAuthor, wallRequestScope } from "./authority";
import { WALL_VALIDATION_SCOPE } from "../../rulesets/action-validation-assembly";
import { ownedToolRules, type TrustedRequestAdmission } from "../../engine/actions/validation-queries";
export const WALL_VALIDATION_RULES = ownedToolRules({
  write_note: ({ world, actorId, day, phase, toolCall, scope: wallScope, wallId, itemInstanceId }) => {
    if (day !== 1 || phase !== Phase.Voting || !authorizedWallAuthor(world, actorId, wallId, itemInstanceId, wallScope)) return { code: RuleError.WallNoteUnavailable };
    return readWallTool(toolCall) ? null : { code: RuleError.WallNoteText };
  },
}, WALL_VALIDATION_SCOPE);
export const WALL_REQUEST_ADMISSION: TrustedRequestAdmission = {
  owner: WALL_VALIDATION_SCOPE, capture: wallRequestScope,
  raw: (_world, _request, tool, rawArgs) => {
    const call = tool === "write_note" ? readWallTool({ name: tool, args: rawArgs }) : null;
    if (tool === "write_note" && !call) return { ok: false, error: RuleError.WallNoteText };
    return { ok: true, ...(call ? { args: call.args } : {}) };
  },
};
''')
p='backend/src/features/demon-hunter/validation-rules.ts';t=get(p)
t=addimport(t,'''import { demonHunterRequestScope, demonHunterActorId } from "./authority";
import { readDemonHuntTool } from "./state-slot";
import { demonWitchRequestCurrent, demonWitchRequestTargetCurrent, readDemonNativeNightTool, readDemonPotionTool } from "./native-potion-requests";
import type { TrustedRequestAdmission } from "../../engine/actions/validation-queries";''')
t+='''
/** 原生三类预检和hunt仍分别用同一权威；不因通用路由合并来源／目标当前性。 */
export const DEMON_REQUEST_ADMISSION: TrustedRequestAdmission = {
  owner: DEMON_HUNTER_VALIDATION_SCOPE, capture: demonHunterRequestScope,
  raw: (world, request, tool, rawArgs) => {
    const demonCall = tool === "demon_hunt" ? readDemonHuntTool({ name: tool, args: rawArgs }) : null;
    if (tool === "demon_hunt" && (!demonCall || !canSubmitDemonHunt(world, request.actorId, request.phase, request.context.day, demonHunterRequestScope(world, request), demonCall))) return { ok: false, error: RuleError.ToolMismatch };
    const demonNative = (tool === "check_identity" || tool === "guard") && demonHunterActorId(world) !== null;
    const nativeCall = demonNative ? readDemonNativeNightTool({ name: tool, args: rawArgs }) : null;
    if (demonNative && (!nativeCall || !demonWitchRequestCurrent(world, request) || (nativeCall.args.target_id !== null && !demonWitchRequestTargetCurrent(world, request, nativeCall.args.target_id)))) return { ok: false, error: RuleError.ToolMismatch };
    const demonWitch = tool === "use_potion" && demonHunterActorId(world) !== null;
    const potionCall = demonWitch ? readDemonPotionTool({ name: tool, args: rawArgs }) : null;
    if (demonWitch && (!potionCall || !demonWitchRequestTargetCurrent(world, request, potionCall.args.target_id))) return { ok: false, error: RuleError.ToolMismatch };
    return { ok: true, ...(potionCall ? { args: potionCall.args } : demonCall ? { args: demonCall.args } : {}) };
  },
};
''';put(p,t)
# End import/header repair: original Chinese module header stays first, imports are executable code, not a header replacement.
for q in C.rglob('*.ts'):
 t=q.read_text();at=t.find('/**')
 if at>0 and t[:at].strip().startswith('import '):
  prefix=t[:at];body=t[at:];end=body.index('*/')+2;t=body[:end]+'\n'+prefix+body[end:];q.write_text(t)
