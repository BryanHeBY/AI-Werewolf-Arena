# Beauty same-wave：不完整来源被误当完整集合

实际首轮 A 的 `same_wave/{llm,acp,mixed}` 三声明均在 `auditLastWords` 候选 episode 检查第 470 行失败，A 仍在收集完整结果。Root 另唯一诊断保存的 `record-1.json`（SHA `a2731130ec28f01df55d412b21b68bc232b0b9f3ecf7085c1498e5e5b6b0c429`）确认：未终档、operations 为空，三个遗言决定均没有 opening event cursor。

关键实际事件：10 夜报初批 `[1,5]`；12 授予 Hunter5 遗言、14 已发表遗言；15 才有 Beauty1→5 的 Charm 补因。episode5 的初始完整来源未知，后来只有已知下界 `{Charm@15}`。无 opening cursor 的审核用 MAX 再取来源，将该下界当完整来源集合，错误推断“没有原始正因”。这不是全局 wave ID，也没有证据表明生产规则错误。规则卡及 DR 真实顺序都保留同波目标按原因已有效完成的遗言。

最小修复只在 `wordsAllowed` 的 Night 缺正因分支返回 unknown：`mayHaveUnrecordedInitialNightSources` 默认 false，仅原 `night_resolved` 成员 episode、来源不完整、请求无 declared 完整来源时启用；grants 使用同样的 episode 限定。新派生 Charm 目标不是原夜报 episode，不得借此例外。全局 sources、枪审核、Day/Voting、已知禁因／非法原因／phase/day/wave 早拒保持原文。

候选单元追加三声明：手写同初批晚 Charm 正例；完整／declared Charm-only 反例；新派生 Charm-only 反例。使用既有 literal/words/request 帮助函数和字面事件，没有从生产输出计算预期。Root 可先仅应用测试正例记录首红，再应用生产候选及必要整文件回归。这里没有执行测试、parser、编译、门禁或写仓库；诊断执行及实际修复均由 Root 持有。
