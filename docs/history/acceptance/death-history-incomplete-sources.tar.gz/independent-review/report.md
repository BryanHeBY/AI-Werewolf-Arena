# Wolf Beauty same_wave：独立规则／历史证据审查

固定源码：`cb02260b15288f48b99dc523852139ffa9037a89`。只读审查，无产品、parser、测试或仓库写入。

## 已见事实

A lane 的已输出前缀三例均在 `auditLastWords:470` 被拒，调用来自 `flushDirtyFiles → Trace.build()`。完整失败 Tape 尚由 Root 捕获；前缀不显示具体被拒席位，不能冒称已确认。

## 最窄静态归因

现有代码不把全局许可 ID 当 wave：新死亡入口重置 wave0。更精确的路径是 **增量档没有 operations／普通请求没有 opening cursor，晚 Charm 使原不完整来源被当成完整来源**：

1. `recorder.ts:282` 无参数 build，`trace.ts:203` 令 operations=[]；Beauty 的普通 decision 无 openedAtEventCount。
2. 夜报5建立未知原源 episode；先初批遗言，再 charm_death1→5，给同 episode 追加唯一已知 Charm。
3. `validate.ts:80–83` 只要 known 非空便交出数组；无 opening 的遗言复核在 MAX 查询，得到仅 Charm。
4. `wordsAllowed([Charm], Night, 1, 0)` 拒绝，可能正是470的三例失败。

Root 实际诊断只需确认 operations、5的 decision 与带事件位置的 episode。不能据此把所有来源未知的记录全免验；也不能把晚Charm当早先动作的撤销依据。

## 保留的字面规则

规则卡第10/13行明确：同波初批5的原遗言保留；晚补Charm只挡尚未执行死亡技能。原三例 words=[1,5,2]、alive=[3,4,6]、无枪／无additional_deaths应保。另2的放逐是新链初始波；新Charm死者和真实shot晚波的拒绝不能被放宽。

完整来源、已读16源SHA、307行固定raw前缀及限界见 `report.json`。
