# 实际拒绝输入：确认结论

Root 捕获的 `record-1.json`（SHA `a2731130…`，33339 bytes）确认：`finalized=false`、operations=[]，5的遗言 decision7 没有 opening cursor。夜报@10含[1,5]，grant5@12、spoken5@14，Charm1→5在@15才发布。

原 collector 因缺夜伤害操作把5的初始来源记为 unknown/completeSources=false；晚Charm只是该episode的唯一已知下界。审核却在MAX读取并把[Charm]当成全部来源，故拒绝已完成遗言。**这不是全局wave编号错误**：5仍是wave0；晚放逐2也是新链wave0，permit3不表示第三波。

最窄修正应只给LastWords判断保来源完整性：不因未知允许项缺席判矛盾，仍拒已知禁源、phase/day/wave及完整源负例；不改共享sources或枪审计，不改生产付款/遗言/Charm次序。规则卡要求同波旧遗言保留，字面words[1,5,2]、alive[3,4,6]、无枪/额外死亡均保持。

本报告只读JSON、源码和Root原收据，未调用validator/parser或运行产品、测试、类型、检查。它确认原因，尚不表示TMP修补或后继运行已经批准/通过。完整字段与哈希见 `confirmed-input-review.json`。
