import {readFile,writeFile,mkdir} from "node:fs/promises";
import {createRequire} from "node:module";
const root="/home/hby/dev/AI-Werewolf-Arena",p="backend/tests/unit/recording/reproduction-trace-causality.test.ts",out="/tmp/awa-c47-format-single-idempotence";
await mkdir(out,{recursive:true});const api=createRequire(root+"/package.json")("prettier"),config=await api.resolveConfig(root+"/"+p),before=await readFile(root+"/"+p,"utf8"),after=await api.format(before,{...config,filepath:root+"/"+p}),second=await api.format(after,{...config,filepath:root+"/"+p});await writeFile(out+"/before.ts",before);await writeFile(out+"/after.ts",after);await writeFile(out+"/after-second.ts",second);process.stdout.write(JSON.stringify({beforeEqualAfter:before===after,secondStable:after===second})+"\n");
