# X06 下层判胜扩展的实际查询边界

## 具体缺口与退出范围

上层 `WinConditionSpec.evaluate` 已取得 `VictoryQueries`，下层 `ConditionRegistry` 仍曾向结构注入的 `WinConditionEvaluator.evaluate` 传原 `World`。这条实际可替换接口允许回调取得 `addComponent` 等写入口，不能因上层已经窄化便视为关闭。

本候选共 15 个现有路径：5 生产源、10 测试源。`ConditionRegistry.evaluate/evaluateMany` 与 `WinConditionRegistry.evaluate` 的首参统一改为实际 `VictoryQueries`；两个真实引擎调用在原 `World` 参数位置调用现有 `bindVictoryQueries`。旧的 World 首参代码 API 明确退出，现有自定义 evaluator 仍按原对象 receiver 调用，返回 `null` 或候选原引用，覆盖优先级与条件顺序不变。

`AliveVictoryCounts`、`VictoryQueries` 两个纯类型归现有领域注册器契约，避免 domain 反导 engine/rulesets。原 `engine/victory/contracts` 路径以 type 重导出同一声明，`WinConditionSpec` 保持原位置与含义。没有新运行模块、通用框架或兼容 World 回门。

## 原行为与新增观察面

现有 `default-specs.ts` 的完整查询绑定、真实 Camp 统计、Cupid/Ghost 分支及原 `results.ts` 完整不改。查询仍晚读；构造查询对象不读取 World 字段、组件、时钟或状态。不返回原组件、World 或通用存储方法。查询输出是编号、枚举、统计或结果数据，不是付款或封盘许可。

公开调用方如今显式构造查询：新增绑定函数的 callee 查找及对象分配发生在原 World 实参位置；规格检查点仍先于任何实际 query 调用。原测试标题相应从“先于查询构造和实际读取”准确改为“先于实际查询读取”，旧标题保存在完整 before。本候选不承诺任意 Reflect/CJS monkeypatch、内存分配或所有新 module load 观察完全相同。

`PhaseManager` 与 RedMoon 的原 registry/callee→World→后续参数求值、三/四参数数量、receiver、覆盖短路、首异常及已提交前缀保留。RedMoon 已有 getter 轨迹的首参期望从原 World 身份迁为窄 query，原 trace 和候选同引用期望不改。

## 必要输入与责任分界

现有所有直接 `.evaluate/.evaluateMany` 调用按已登记实际接口迁移；没有改角色、配置、资源、隐私或封盘结果断言。追加三个字面风险：真实下层自定义 evaluator 只收到实际 query 且保 receiver/候选引用；覆盖结果不调用 evaluator，晚 callee 抛原 Error 时不触发 query。

本包只在 TMP 构造。当前 Root 有 H03/D-E/Night WIP：`source-ready.json` 分开记录 actual before 与 HEAD Git blob，逐文件 `sameAsActualBefore` 明示；不冒整树清洁或统一 before。PhaseManager 与 Hybrid 测试为共享 owner，只应用 `phase-manager-local-delta.json` / `hybrid-local-delta.json` 的精确 import/call 片段，不覆盖其完整候选。其他路径也必须在实际 before guard 后才写。

Root 唯一执行；作者没有运行产品、TS/AST parser、类型、测试、formatter、门禁或网络，也未写仓库。

## 非作者静态后继：每规格查询表隔离

首稿共享同一个 query 到多个实际规格，早规格改写 `camp` 等可写方法并返回 null 会污染后规格。这与已交付的 Upper `WinConditionSpec` 隔离政策不同，不能当作退出面豁免。首完整准备材料已原字节保存在 `first-prepared-snapshot/`。

后继只改 WinConditionRegistry 与边界单元：每次真正执行 spec 前建立私有八方法新字面对象，所有方法在被调用时才委托原 source，原 source 不交 spec。没有 spread／Object.assign／方法或 getter 预读，没有新 World 私表、服务或 freeze。默认 source 仍是原完整 `bindVictoryQueries`；早规格的本地字段写入只影响自己的新表。第三个手写声明以真实两个 spec 证明这一点，不重写首两个新声明。

新 lower API 的外来自造 source 若有方法 getter，其查找发生在转发方法的实参完成之后，返回函数身份／length／分配也属于新增观察；不宣称这类新输入保持旧 World API 的全部 JS 观察。默认 binder 的八个原 own-data 方法和 World 查询／原体读取程序不改。单元首头另补准确“单元测试负责”层级，属于检查前静态精度，无运行红。
