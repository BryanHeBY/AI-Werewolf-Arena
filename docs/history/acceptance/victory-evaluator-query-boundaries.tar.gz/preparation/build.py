from pathlib import Path
import hashlib,json,subprocess,difflib,os
root=Path('/home/hby/dev/AI-Werewolf-Arena'); out=Path('/tmp/awa-h02-victory-evaluator-query-boundary')
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=[
'backend/src/domain/registries/condition-registry.ts',
'backend/src/engine/victory/contracts.ts',
'backend/src/engine/victory/condition-registry.ts',
'backend/src/engine/phase-manager.ts',
'backend/src/rulesets/red-moon-expiry-settlement.ts',
'backend/tests/unit/engine/bootstrap-and-condition.test.ts',
'backend/tests/unit/engine/elimination-priority.test.ts',
'backend/tests/unit/engine/victory-query-boundary.test.ts',
'backend/tests/unit/mechanisms/victory-membership-and-outcome-readers.test.ts',
'backend/tests/unit/features/hybrid/affiliation-authority.test.ts',
'backend/tests/unit/features/lonely-girl/setup-and-audit-contracts.test.ts',
'backend/tests/unit/rulesets/beauty-exile-victory.test.ts',
'backend/tests/unit/rulesets/red-moon-expiry-settlement.test.ts',
'backend/tests/scenarios/features/victory/checkpoints-and-terminal-sealing.test.ts',
'backend/tests/scenarios/features/wild-child/model-death-and-pack-activation.test.ts',
]
before={p:(root/p).read_text() for p in paths}; cand=dict(before); edits=[]
def edit(p,a,b,n=1):
 s=cand[p]; actual=s.count(a)
 if actual!=n: raise RuntimeError(f'anchor {p}: expected {n}, got {actual}: {a[:60]}')
 cand[p]=s.replace(a,b); edits.append({'path':p,'before':a,'after':b,'count':n})
def add_import(p):
 module=os.path.relpath(root/'backend/src/rulesets/victory/default-specs', (root/p).parent).replace(os.sep,'/')
 if not module.startswith('.'):module='./'+module
 line=f'import {{ bindVictoryQueries }} from "{module}";\n'
 # 插入原首import之前；不移动或重排其他原导入。
 pos=cand[p].index('import '); cand[p]=cand[p][:pos]+line+cand[p][pos:]
 edits.append({'path':p,'before':'','after':line,'insertBeforeFirstImport':True})
# 纯查询契约留领域层，旧引擎契约路径type重导出同一声明。
domain=paths[0]; contracts=paths[1]; win=paths[2]
source=before[contracts]; lo=source.index('/** 真实存活阵营统计'); hi=source.index('/** 单个胜利条件规格定义。 */')
queries=source[lo:hi]
edit(domain,'import type { VictoryCheckpoint } from "@ai-werewolf-arena/game-contract";','import type { VictoryCheckpoint, VictoryTarget } from "@ai-werewolf-arena/game-contract";')
edit(domain,'import { WinDecision, WinCondition } from "../model";\nimport { World } from "../world";','import { type Camp, type EntityId, type Role, WinDecision, WinCondition } from "../model";\n\n'+queries.rstrip())
edit(domain,'输入为原 World、只读条件 ID、检查点及覆盖数据','输入为实际判胜查询、只读条件 ID、检查点及覆盖数据')
edit(domain,'胜负判定注册中心抽象：由机制层实现并在装配期注入。','胜负判定注册中心抽象：由机制层实现并在装配期注入。\n * 可替换 evaluate 只接专用查询，不接原 World 或可写组件；领域提交和唯一封盘仍归引擎。')
edit(domain,'world: World','queries: VictoryQueries',3)
edit(domain,'this.winRegistry.evaluate(world, condition, checkpoint)','this.winRegistry.evaluate(queries, condition, checkpoint)')
edit(domain,'this.evaluate(world, condition, checkpoint)','this.evaluate(queries, condition, checkpoint)')
edit(contracts,'import type { VictoryTarget } from "@ai-werewolf-arena/game-contract";\n','')
edit(contracts,'import { Camp, type EntityId, type Role, WinDecision, WinCondition } from "../../domain/model";','import { WinDecision, WinCondition } from "../../domain/model";\nimport type { VictoryQueries } from "../../domain/registries/condition-registry";\nexport type { AliveVictoryCounts, VictoryQueries } from "../../domain/registries/condition-registry";')
edit(contracts,queries,'')
edit(win,'输入为原规格、World、条件与检查点','输入为原规格、实际判胜查询、条件与检查点')
edit(win,'import { World } from "../../domain/world";\n','')
edit(win,'import {\n  bindVictoryQueries,\n  DEFAULT_WIN_CONDITION_SPECS,\n} from "../../rulesets/victory/default-specs";','import { DEFAULT_WIN_CONDITION_SPECS } from "../../rulesets/victory/default-specs";')
edit(win,'import { WinConditionSpec } from "./contracts";','import { WinConditionSpec, type VictoryQueries } from "./contracts";')
edit(win,'world: World','queries: VictoryQueries')
edit(win,'// 查询对象每次评估单独绑定；默认规格表不持有 World，跨局不会共享运行能力。\n    return spec.evaluate(bindVictoryQueries(world), checkpoint);','// 可信调用方在原World参数位置绑定查询；先核原条件和检查点，再按原receiver调用规格。\n    // 本入口不反向取得World，也不以查询对象或候选返回值授予封盘权。\n    return spec.evaluate(queries, checkpoint);')
# 两个真实运行调用在原World参数位置绑定，不提前读World或任何查询。
for p,indent in [(paths[3],'      '),(paths[4],'          ')]:
 add_import(p)
 edit(p,'.evaluateMany(\n'+indent+('this.world' if p==paths[3] else 'runtime.world')+',','.evaluateMany(\n'+indent+'bindVictoryQueries('+('this.world' if p==paths[3] else 'runtime.world')+'),')
# 精确已有直接调用接入；原机器字面、选择/资源/隐私断言不改。
for p in paths[5:]:
 add_import(p)
 for token in ['world','game.world','g.world','context.world','first','second']:
  for method in ['evaluate','evaluateMany']:
   a=f'.{method}({token},'
   if a in cand[p]: edit(p,a,f'.{method}(bindVictoryQueries({token}),',cand[p].count(a))
 if p.endswith('beauty-exile-victory.test.ts'):
  edit(p,'evaluate(_world, condition, checkpoint)','evaluate(_queries, condition, checkpoint)')
  edit(p,'.evaluateMany(\n      f.world,','.evaluateMany(\n      bindVictoryQueries(f.world),',2)
 if p.endswith('model-death-and-pack-activation.test.ts'):
  edit(p,'.evaluate(\n      g.world,','.evaluate(\n      bindVictoryQueries(g.world),')
 if p.endswith('red-moon-expiry-settlement.test.ts'):
  edit(p,'expect(args[0]).toBe(f.world);','// 公开评估参数已退出原World；查询仍绑定同一局，且构造不触发组件读取。\n        expect(args[0]).not.toBe(f.world);\n        expect("world" in args[0]).toBe(false);\n        expect(typeof args[0].camp).toBe("function");')
# 追加两个手写字面风险；原三声明正文仅首参接线，不删断言。
p='backend/tests/unit/engine/victory-query-boundary.test.ts'
edit(p,'检查点先于查询构造和实际读取，首次查询异常保原错误','检查点先于实际查询读取，首次查询异常保原错误')
edit(p,'import type { VictoryQueries, WinConditionSpec } from "../../../src/engine/victory/contracts";','import type { VictoryQueries, WinConditionSpec } from "../../../src/engine/victory/contracts";\nimport { ConditionRegistry, type WinConditionEvaluator } from "../../../src/domain/registries/condition-registry";')
append='''

test("下层判胜评估器只取得实际查询与原接收者，返回候选不提交世界", () => {
  const { world } = fixture();
  const candidate = {
    winner: null,
    reason: "literal_custom_evaluator",
    outcome: { kind: "no_winner" as const },
  };
  const trace: string[] = [];
  let observed: VictoryQueries | undefined;
  const evaluator: WinConditionEvaluator = {
    evaluate(queries, condition, checkpoint) {
      trace.push("evaluate");
      expect(this).toBe(evaluator);
      observed = queries;
      expect(condition).toBe(WinCondition.SlaughterCity);
      expect(checkpoint).toBe("night_settled");
      expect(Object.keys(queries).sort()).toEqual([
        "aliveIds", "camp", "cupidCityDecision", "decision", "eliminationCounts", "entityIds",
        "role", "weddingFactionResult",
      ]);
      for (const key of ["world", "getWorld", "getComponent", "addComponent", "removeComponent", "createEntity"])
        expect(key in queries).toBe(false);
      expect(queries.role(3)).toBe(Role.Seer);
      expect(queries.camp(1)).toBe(Camp.Wolf);
      expect(queries.aliveIds()).toEqual([1, 2, 3, 4, 5, 6]);
      return candidate;
    },
  };
  const registry = new ConditionRegistry(evaluator);
  const result = registry.evaluate(bindVictoryQueries(world), WinCondition.SlaughterCity, "night_settled");
  expect(result).toBe(candidate);
  expect(trace).toEqual(["evaluate"]);
  // 只有真实所有者写生命；旧查询仍晚读同一局，返回数组本身不持组件或库存。
  const ids = observed!.entityIds() as number[];
  ids.push(99);
  expect(world.entityIds()).toEqual([1, 2, 3, 4, 5, 6]);
  world.getComponent(1, COMPONENT.Alive)!.alive = false;
  expect(observed!.aliveIds()).toEqual([2, 3, 4, 5, 6]);
  expect(world.activeDeathActionCount).toBe(0);
});

test("下层判胜覆盖先于评估，晚callee首异常保原对象且不读取查询", () => {
  const world = new World();
  const failure = new Error("literal_lower_evaluator_callee");
  const candidate = { winner: null, reason: "literal_override", outcome: { kind: "no_winner" as const } };
  const trace: string[] = [];
  const evaluator: WinConditionEvaluator = {
    get evaluate(): WinConditionEvaluator["evaluate"] {
      trace.push("callee");
      throw failure;
    },
  };
  Object.defineProperty(world, "getComponent", {
    get() { trace.push("component"); throw new Error("must_not_query"); },
  });
  const queries = bindVictoryQueries(world);
  const registry = new ConditionRegistry(evaluator);
  expect(registry.evaluateMany(queries, [WinCondition.SlaughterCity], "night_settled", {
    [WinCondition.SlaughterCity]: candidate,
  })).toBe(candidate);
  expect(trace).toEqual([]);
  try {
    registry.evaluateMany(queries, [WinCondition.SlaughterCity], "night_settled");
    throw new Error("must_throw");
  } catch (error) { expect(error).toBe(failure); }
  expect(trace).toEqual(["callee"]);
});
'''
cand[p]+=append; edits.append({'path':p,'append':append})
# 完整前态/候选输出只写TMP；Git与当前WIP分别登记，绝不把Root共享生产误标同Git。
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
records=[]
(out/'candidate.patch').write_text('')
for p in paths:
 b=before[p].encode(); a=cand[p].encode()
 for folder,data in [('before',b),('candidates',a)]:
  q=out/folder/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
 git=subprocess.check_output(['git','show',base+':'+p],cwd=root)
 tree=subprocess.check_output(['git','ls-tree',base,'--',p],cwd=root,text=True).strip().split()
 records.append({'path':p,'beforeSHA256':sha(b),'beforeBytes':len(b),'sha256':sha(a),'bytes':len(a),'mode':'100755' if (root/p).stat().st_mode&0o100 else '100644','gitBefore':{'commit':base,'blob':tree[2],'mode':tree[0],'sha256':sha(git),'bytes':len(git),'sameAsActualBefore':git==b},'candidate':'candidates/'+p,'before':'before/'+p,'apply':'exact-delta-only' if p=='backend/src/engine/phase-manager.ts' else 'whole-after-before-guard'})
 patch=''.join(difflib.unified_diff(before[p].splitlines(True),cand[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 with (out/'candidate.patch').open('a') as f:f.write(patch)
controls=[]
for p in ['backend/src/domain/world.ts','backend/src/engine/victory/results.ts','backend/src/rulesets/victory/default-specs.ts','backend/src/recording/reproduction/format.ts','backend/src/domain/night-effects.ts']:
 b=(root/p).read_bytes();controls.append({'path':p,'sha256':sha(b),'bytes':len(b),'mode':'100755' if (root/p).stat().st_mode&0o100 else '100644'})
(out/'source-ready.json').write_text(json.dumps({'kind':'X06 lower evaluator genuine query boundary prepared','observedHEAD':base,'source':records,'deleted':[],'controls':controls,'checksExecuted':False,'repoWrites':False,'limits':['actual before includes Root H03/D-E WIP; per-file Git identity explicit','query binding is now explicit at old World argument positions; new binding lookup/allocation is an intentional public API observation','default bindVictoryQueries full program and original condition algorithms unchanged','not a JavaScript sandbox or arbitrary monkeypatch equivalence claim']},ensure_ascii=False,indent=2)+'\n')
(out/'edits.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
(out/'phase-manager-local-delta.json').write_text(json.dumps({'path':paths[3],'beforeSHA256':sha(before[paths[3]].encode()),'edits':[e for e in edits if e['path']==paths[3]],'warning':'Root concurrent shared owner; use exact import/call delta, never whole candidate overwrite.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source':len(records),'oldPaths':len(records),'newPaths':0,'exactEdits':len(edits),'sourceReadySHA256':sha((out/'source-ready.json').read_bytes())},ensure_ascii=False))
