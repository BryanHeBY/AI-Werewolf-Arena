from pathlib import Path
import json,hashlib,difflib
p=Path('/tmp/awa-h02-victory-evaluator-query-boundary');sha=lambda b:hashlib.sha256(b).hexdigest()
first=json.loads((p/'first-prepared-snapshot'/'HANDOFF.json').read_bytes());ready=json.loads((p/'source-ready.json').read_bytes());edits=json.loads((p/'edits.json').read_bytes());delta=[]
win='backend/src/engine/victory/condition-registry.ts';unit='backend/tests/unit/engine/victory-query-boundary.test.ts'
def edit(rel,old,new,reason):
 q=p/'candidates'/rel;s=q.read_text()
 if s.count(old)!=1:raise RuntimeError('successor anchor '+rel+' '+str(s.count(old)))
 a=s.replace(old,new);q.write_text(a);e={'path':rel,'before':old,'after':new,'count':1,'reason':reason};edits.append(e);delta.append(e)
helper='''/**
 * 每个实际规格独占一份可写查询表，保原规格覆盖本地方法但不污染后续规格的隔离。
 * 不展开 source 或预读任何方法；默认 source 仍由原 bindVictoryQueries 私有绑定同一 World。
 * 新 lower API 传入的外来自造 source，其方法只在使用时查找并保 source receiver／实参数量；
 * 这层晚委托不承诺任意 Proxy、函数身份／length 或 getter 相对实参的旧观察完全相同。
 */
function specQueries(source: VictoryQueries): VictoryQueries {
  return {
    entityIds: (...args) => source.entityIds(...args),
    aliveIds: (...args) => source.aliveIds(...args),
    role: (...args) => source.role(...args),
    camp: (...args) => source.camp(...args),
    eliminationCounts: (...args) => source.eliminationCounts(...args),
    cupidCityDecision: (...args) => source.cupidCityDecision(...args),
    weddingFactionResult: (...args) => source.weddingFactionResult(...args),
    decision: (...args) => source.decision(...args),
  };
}

'''
edit(win,'/** 胜利条件注册表。 */',helper+'/** 胜利条件注册表。 */','每实际spec独占新查询表；没有World回门/全局身份表')
edit(win,'return spec.evaluate(queries, checkpoint);','return spec.evaluate(specQueries(queries), checkpoint);','在原spec实际调用处新建，条件/检查点拒绝仍不创建spec view')
edit(unit,' * 验证真实判胜扩展只取得窄查询；手写成员、统计和调用顺序作为预期。',' * 单元测试负责验证真实判胜扩展只取得窄查询；手写成员、统计和调用顺序作为预期。','独立静态职责层级精度；不是运行head红')
append='''

test("下层判胜连续规格各持新查询表，早规格改方法并返回空不污染后规格", () => {
  const { world } = fixture();
  const source = bindVictoryQueries(world);
  const views: VictoryQueries[] = [];
  const candidate = { winner: null, reason: "literal_second_spec", outcome: { kind: "no_winner" as const } };
  const registry = new ConditionRegistry(new WinConditionRegistry([
    {
      id: WinCondition.SlaughterCity,
      evaluate(queries) {
        views.push(queries);
        // 现行规格可以覆盖自己的数据字段；下一规格应仍取得新的表和真实默认查询。
        queries.camp = () => Camp.Good;
        queries.eliminationCounts = () => ({ wolves: 99, gods: 0, villagers: 0, good: 0 });
        expect(queries.camp(1)).toBe(Camp.Good);
        return null;
      },
    },
    {
      id: WinCondition.SlaughterSide,
      evaluate(queries) {
        views.push(queries);
        expect(queries).not.toBe(views[0]);
        expect(queries.camp(1)).toBe(Camp.Wolf);
        expect(queries.eliminationCounts()).toEqual({ wolves: 2, gods: 2, villagers: 2, good: 4 });
        return candidate;
      },
    },
  ]));
  expect(registry.evaluateMany(source, [WinCondition.SlaughterCity, WinCondition.SlaughterSide], "night_settled")).toBe(candidate);
  expect(views).toHaveLength(2);
  expect(source.camp(1)).toBe(Camp.Wolf);
  expect(world.activeDeathActionCount).toBe(0);
});
'''
q=p/'candidates'/unit;q.write_text(q.read_text()+append);e={'path':unit,'append':append,'reason':'非作者静态相互污染反例；本次新增第3个声明，首2新声明不改'};edits.append(e);delta.append(e)
# 所有原before与13其它candidate保持；只这2source后继。Hybrid与PM为Root并行局部合入。
for r in ready['source']:
 b=(p/r['candidate']).read_bytes();r['sha256']=sha(b);r['bytes']=len(b)
 if r['path']=='backend/tests/unit/features/hybrid/affiliation-authority.test.ts':r['apply']='exact-delta-only'
ready['successor']={'finding':'原每spec fresh可写query被首稿跨条件共享；保持Upper API本地覆盖隔离','changedSource':[win,unit],'sameOtherCandidate':13,'newRiskDeclarations':3,'firstPreparedHandoffSHA256':sha((p/'first-prepared-snapshot'/'HANDOFF.json').read_bytes()),'headPrecision':'单元测试层级一行精度，检查前静态修正','rootConcurrentInput':'Hybrid test必须局部合入，保Night真实execute适配；首before不重写'}
(p/'source-ready.json').write_text(json.dumps(ready,ensure_ascii=False,indent=2)+'\n')
(p/'edits.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
(p/'successor-delta.json').write_text(json.dumps({'kind':'X06 per-spec query isolation successor','changedSource':[win,unit],'deltas':delta,'beforeReferences':'first-prepared-snapshot/candidates retains full original two candidates','checksExecuted':False,'repositoryWrites':False},ensure_ascii=False,indent=2)+'\n')
patch=''
for r in ready['source']:
 rel=r['path'];a=(p/r['before']).read_text();b=(p/r['candidate']).read_text();patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(p/'candidate.patch').write_text(patch)
rel='backend/tests/unit/features/hybrid/affiliation-authority.test.ts'
(p/'hybrid-local-delta.json').write_text(json.dumps({'path':rel,'beforeSHA256':next(r['beforeSHA256'] for r in ready['source'] if r['path']==rel),'edits':[e for e in edits if e['path']==rel],'warning':'Root Night已另改同文件；仅合入本局部query import与6个evaluate实参，不whole覆盖。'},ensure_ascii=False,indent=2)+'\n')
readme=(p/'README.md').read_text();readme=readme.replace('追加两个字面风险','追加三个字面风险').replace('PhaseManager 为共享 owner，只应用 `phase-manager-local-delta.json` 的精确 import/call 片段，不覆盖其完整候选。','PhaseManager 与 Hybrid 测试为共享 owner，只应用 `phase-manager-local-delta.json` / `hybrid-local-delta.json` 的精确 import/call 片段，不覆盖其完整候选。')
readme+='''
## 非作者静态后继：每规格查询表隔离

首稿共享同一个 query 到多个实际规格，早规格改写 `camp` 等可写方法并返回 null 会污染后规格。这与已交付的 Upper `WinConditionSpec` 隔离政策不同，不能当作退出面豁免。首完整准备材料已原字节保存在 `first-prepared-snapshot/`。

后继只改 WinConditionRegistry 与边界单元：每次真正执行 spec 前建立私有八方法新字面对象，所有方法在被调用时才委托原 source，原 source 不交 spec。没有 spread／Object.assign／方法或 getter 预读，没有新 World 私表、服务或 freeze。默认 source 仍是原完整 `bindVictoryQueries`；早规格的本地字段写入只影响自己的新表。第三个手写声明以真实两个 spec 证明这一点，不重写首两个新声明。

新 lower API 的外来自造 source 若有方法 getter，其查找发生在转发方法的实参完成之后，返回函数身份／length／分配也属于新增观察；不宣称这类新输入保持旧 World API 的全部 JS 观察。默认 binder 的八个原 own-data 方法和 World 查询／原体读取程序不改。单元首头另补准确“单元测试负责”层级，属于检查前静态精度，无运行红。
'''
(p/'README.md').write_text(readme)
plan=json.loads((p/'execution-plan.json').read_bytes());plan['newDeclarations']=3;plan['successorOnlyChangedRoots']=[win,unit];plan['sameFirstNewDeclarations']=2
(p/'execution-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
art=[]
for name in ['README.md','build.py','build-first-prepare-error.py','prepare-history.json','source-ready.json','edits.json','candidate.patch','phase-manager-local-delta.json','hybrid-local-delta.json','types-config.json','execution-plan.json','successor.py','successor-delta.json']:
 b=(p/name).read_bytes();art.append({'path':name,'sha256':sha(b),'bytes':len(b)})
h={'kind':'H02-X06 lower victory evaluator query-boundary prepared successor handoff','status':'source-ready; Root execution pending','sourceReadySHA256':sha((p/'source-ready.json').read_bytes()),'source':ready['source'],'deleted':[],'counts':{'source':15,'production':5,'tests':10,'newSource':0,'newRiskDeclarations':3,'exactTextOperations':len(edits),'changedSuccessor':2,'sameCandidate':13},'artifacts':art,'controls':ready['controls'],'firstPreparedSnapshot':{'path':'first-prepared-snapshot/HANDOFF.json','sha256':sha((p/'first-prepared-snapshot'/'HANDOFF.json').read_bytes())},'successor':ready['successor'],'checksExecuted':False,'repositoryWrites':False,'publicAPI':'旧World首参明确退出；Upper每spec可写新query隔离保持；无运行wrapper或World token','limits':ready['limits']}
(p/'HANDOFF.json').write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'handoff':str(p/'HANDOFF.json'),'sha256':sha((p/'HANDOFF.json').read_bytes()),'readySHA256':h['sourceReadySHA256'],'exactOperations':len(edits),'changed':2,'checksExecuted':False},ensure_ascii=False))
