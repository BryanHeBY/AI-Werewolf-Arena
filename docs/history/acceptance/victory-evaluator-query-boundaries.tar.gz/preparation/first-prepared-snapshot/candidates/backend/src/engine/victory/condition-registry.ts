/**
 * 负责胜利条件规格索引和具名评估委托。输入为原规格、实际判胜查询、条件与检查点，输出原判定或 null，未知条件保原错误。
 * 索引唯一持有规格 Map，允许检查点才调用原 evaluate；本注册表不推进阶段或封盘。
 */
import type { VictoryCheckpoint } from "@ai-werewolf-arena/game-contract";
/** 文件说明：管理胜利条件规格与评估入口。 */
import { WinDecision, WinCondition } from "../../domain/model";
import { DEFAULT_WIN_CONDITION_SPECS } from "../../rulesets/victory/default-specs";
import { WinConditionSpec, type VictoryQueries } from "./contracts";

/** 胜利条件注册表。 */
export class WinConditionRegistry {
  private readonly specById = new Map<WinCondition, WinConditionSpec>();

  constructor(specs: WinConditionSpec[] = DEFAULT_WIN_CONDITION_SPECS) {
    for (const spec of specs) {
      this.specById.set(spec.id, spec);
    }
  }

  get(condition: WinCondition): WinConditionSpec | undefined {
    return this.specById.get(condition);
  }

  evaluate(
    queries: VictoryQueries,
    condition: WinCondition,
    checkpoint?: VictoryCheckpoint,
  ): WinDecision | null {
    const spec = this.specById.get(condition);
    if (!spec) {
      throw new Error(`Unknown win condition: ${condition}`);
    }
    if (spec.checkpoints && (checkpoint === undefined || !spec.checkpoints.includes(checkpoint)))
      return null;
    // 可信调用方在原World参数位置绑定查询；先核原条件和检查点，再按原receiver调用规格。
    // 本入口不反向取得World，也不以查询对象或候选返回值授予封盘权。
    return spec.evaluate(queries, checkpoint);
  }

  all(): WinConditionSpec[] {
    return Array.from(this.specById.values());
  }
}

let defaultRegistry: WinConditionRegistry | null = null;

/** 获取默认胜利条件注册表实例。 */
export function getDefaultWinConditionRegistry(): WinConditionRegistry {
  if (!defaultRegistry) {
    defaultRegistry = new WinConditionRegistry();
  }
  return defaultRegistry;
}
