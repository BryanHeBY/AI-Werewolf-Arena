"""在干净独立环境验证本批夜阶段的实际调用端；不调用模型或全仓重门禁。"""
from pathlib import Path
import hashlib,json,subprocess,sys,time
repo=Path('/home/hby/dev/AI-Werewolf-Arena');task=sys.argv[1];out=Path('/tmp/awa-victory-evaluator-ports-execution')/task;out.mkdir(parents=True,exist_ok=False)
for name in ['home','tmp','cache']:(out/name).mkdir()
source=json.loads(Path('/tmp/awa-victory-evaluator-ports-final-source.json').read_text());paths=[row['path'] for row in source['source']]+[row['path'] for row in source['controls']];sha=lambda b:hashlib.sha256(b).hexdigest()
def fence():return {path:sha((repo/path).read_bytes()) for path in paths}
before=fence();env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','CI':'1','BUN_RUNTIME_EXECUTABLE':'/usr/bin/bun','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'cache'),'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'}
if task=='types':args=['node_modules/typescript/bin/tsc','-p','tsconfig.tests.json','--noEmit']
else:
 prefix='backend/tests/'+('scenarios/' if task=='scenarios' else 'unit/')
 tests=[path.removeprefix('backend/') for path in paths if path.startswith(prefix) and path.endswith('.test.ts')]
 assert tests;args=['test','--preload','./tests/setup.ts',*tests]
argv=['/usr/bin/bun','--no-env-file',*args];start=time.time()
with (out/'stdout.raw').open('wb') as stdout,(out/'stderr.raw').open('wb') as stderr:result=subprocess.run(argv,cwd=repo/'backend',env=env,stdout=stdout,stderr=stderr,timeout=600)
assert before==fence();receipt={'task':task,'argv':argv,'cwd':str(repo/'backend'),'env':env,'base':source['base'],'exitCode':result.returncode,'elapsedSeconds':time.time()-start,'sourceSHA256':before,'prePostSame':True,'raw':[{'path':name,'bytes':(out/name).stat().st_size,'sha256':sha((out/name).read_bytes())} for name in ['stdout.raw','stderr.raw']]};(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'task':task,'exitCode':result.returncode,'seconds':receipt['elapsedSeconds'],'tail':(out/'stderr.raw').read_text()[-3000:]}));sys.exit(result.returncode)
