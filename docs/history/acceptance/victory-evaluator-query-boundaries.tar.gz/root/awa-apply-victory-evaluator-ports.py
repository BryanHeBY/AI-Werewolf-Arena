"""整合下层判胜查询；阶段经理和混血儿测试仅应用明确局部差异。"""
from pathlib import Path
import hashlib,json,re,subprocess
repo=Path('/home/hby/dev/AI-Werewolf-Arena');prepared=Path('/tmp/awa-h02-victory-evaluator-query-boundary');sha=lambda b:hashlib.sha256(b).hexdigest();ready=json.loads((prepared/'source-ready.json').read_text());local={}
for name in ['phase-manager-local-delta.json','hybrid-local-delta.json']:
 row=json.loads((prepared/name).read_text());local[row['path']]=row
for row in ready['controls']:assert sha((repo/row['path']).read_bytes())==row['sha256'],row['path']
updates=[]
for row in ready['source']:
 path=repo/row['path'];before=path.read_bytes();actual=sha(before);candidate=(prepared/row['candidate']).read_bytes();assert sha(candidate)==row['sha256']
 if row['path'] in local:
  text=before.decode()
  if row['path'].endswith('/phase-manager.ts'):assert actual==row['beforeSHA256']
  for edit in local[row['path']]['edits']:
   if edit.get('insertBeforeFirstImport'):
    match=re.search(r'^import ',text,re.M);assert match;assert edit['after'].strip() not in text;text=text[:match.start()]+edit['after']+text[match.start():]
   else:assert text.count(edit['before'])==edit['count'];text=text.replace(edit['before'],edit['after'])
  after=text.encode()
  if actual==row['beforeSHA256']:assert after==candidate
 else:assert actual==row['beforeSHA256'],row['path'];after=candidate
 updates.append((path,after,row,actual))
for path,after,row,actual in updates:path.write_bytes(after)
result={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'preparedBase':ready['observedHEAD'],'controls':ready['controls'],'source':[{'path':row['path'],'beforeSHA256':actual,'preparedBeforeSHA256':row['beforeSHA256'],'preparedSHA256':row['sha256'],'appliedSHA256':sha(after),'mode':row['apply']} for path,after,row,actual in updates]};Path('/tmp/awa-victory-evaluator-ports-applied.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['/usr/bin/bun','--no-env-file','node_modules/prettier/bin/prettier.cjs','--write',*[row['path'] for path,after,row,actual in updates]],cwd=repo,env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8','CI':'1'},check=True,stdout=subprocess.DEVNULL)
for row in result['source']:row['finalSHA256']=sha((repo/row['path']).read_bytes())
Path('/tmp/awa-victory-evaluator-ports-final-source.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'source':len(updates),'base':result['base']}))
