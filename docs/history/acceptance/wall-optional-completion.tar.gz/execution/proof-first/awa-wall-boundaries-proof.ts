import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
import { checkComments } from "/home/hby/dev/AI-Werewolf-Arena/tooling/refactor/architecture/comment-check";
const root="/home/hby/dev/AI-Werewolf-Arena", out="/tmp/awa-wall-completion-execution/proof";
await mkdir(out,{recursive:true});
const ts=createRequire(root+"/backend/package.json")("typescript"), hash=(text:string)=>createHash("sha256").update(text).digest("hex");
const paths=["backend/src/features/wall-notes/window.ts","backend/src/domain/request-lease.ts","backend/tests/scenarios/reproduction/wall-notes/optional-request-completion.test.ts","backend/tests/unit/events/wall-notes/optional-completion-failure-prefixes.test.ts"];
const files=await Promise.all(paths.map(async(path)=>{const text=await readFile(root+"/"+path,"utf8");return {path,text,sha256:hash(text)}}));
const comments=checkComments(ts,{files,documentationPaths:[]});
if(comments.length)throw Error(JSON.stringify(comments));
const edits=JSON.parse(await readFile("/tmp/awa-wall-optional-request-completion/production-edits.json","utf8")).edits;
const report:any={kind:"bounded syntax proof; two new completion callsites are intentional behavior change",heads:{files:4,violations:0},sources:files.map(({path,sha256})=>({path,sha256})),programs:[]};
for(const file of files.slice(0,2)) {
 const before=await readFile("/tmp/awa-wall-completion-execution/before/"+file.path,"utf8"); let inverse=file.text;
 if(file.path.endsWith("window.ts"))for(const edit of edits){if(inverse.split(edit.after).length-1!==edit.count)throw Error("inverse count");inverse=inverse.replace(edit.after,edit.before)}
 for(const [name,kind] of [["esm",ts.ModuleKind.ESNext],["cjs",ts.ModuleKind.CommonJS]]){
  const options={target:ts.ScriptTarget.ES2022,module:kind,removeComments:true};
  const a=ts.transpileModule(before,{compilerOptions:options,fileName:file.path}).outputText;
  const b=ts.transpileModule(inverse,{compilerOptions:options,fileName:file.path}).outputText;
  if(a!==b)throw Error("remaining program changed: "+file.path);
  const key=file.path.endsWith("window.ts")?"window":"request-lease";
  await writeFile(out+`/${key}-${name}-before.js`,a);await writeFile(out+`/${key}-${name}-inverse.js`,b);
  report.programs.push({path:file.path,module:name,bytes:Buffer.byteLength(a),sha256:hash(a),scope:key==="window"?"exact inverse of four explicit replacements including two completion additions":"comments only"});
 }
}
await writeFile(out+"/report.json",JSON.stringify(report,null,2)+"\n");process.stdout.write(JSON.stringify({commentFiles:4,commentViolations:0,pairedOutputs:4,intentionalCompleteAdditions:2})+"\n");
