import { Phase, } from "../../domain";
import { shuffled } from "../../domain/random";
import { readWallTool } from "@ai-werewolf-arena/game-contract/facts/wall-notes";
import { openWall, openWallRequestDelivery, closeWall, grantWallNote, sameWallAuthor, hasActiveWall, hasWallCommit, } from "./authority";
export class WallNotesWindow {
    world;
    gateway;
    events;
    constructor(world, gateway, events) {
        this.world = world;
        this.gateway = gateway;
        this.events = events;
    }
    async execute(config, requests, provider, day, isCurrent, random) {
        if (hasActiveWall(this.world))
            throw new Error("wall_window_reentry");
        if (config.events?.pack !== "awa_wall_notes_once_v1" ||
            day !== 1 ||
            hasWallCommit(this.world) ||
            !isCurrent())
            return;
        const pack = config.events;
        const windowCurrent = () => isCurrent() && config.events === pack && pack.pack === "awa_wall_notes_once_v1";
        const a = openWall(this.world, windowCurrent);
        const cancel = () => {
            if (isCurrent())
                this.events.push({
                    timestamp: Date.now(),
                    type: "wall_notes_canceled",
                    payload: { day: 1, eventId: "awa_wall_notes_v1", reason: "scope_changed" },
                });
        };
        const change = (author, operation, text) => this.events.push({
            timestamp: Date.now(),
            type: "wall_note_changed",
            payload: {
                actorId: author.id,
                day: 1,
                eventId: "awa_wall_notes_v1",
                itemId: "anonymous_note",
                instanceId: author.instanceId,
                operation,
                remaining: author.remaining,
                expired: operation === "expired",
                ...(operation === "accepted" ? { text: text } : {}),
            },
        });
        const base = { day: 1, eventId: "awa_wall_notes_v1" };
        const deliveries = [];
        let failed = false;
        try {
            this.events.push({ timestamp: Date.now(), type: "wall_notes_started", payload: base });
            const authors = this.world
                .getAliveEntityIds()
                .sort((x, y) => x - y)
                .flatMap((id) => {
                const author = grantWallNote(this.world, a, id);
                if (!author)
                    return [];
                change(author, "granted");
                return [author];
            });
            const calls = authors.map((author) => {
                const request = requests.create({
                    actorId: author.id,
                    phase: Phase.Voting,
                    allowedTools: ["write_note"],
                    stage: "wall_notes",
                    requiresAction: false,
                    summary: { key: "request.summary.wall_notes" },
                    context: { wall_id: a.token, item_instance_id: author.instanceId, allow_fallback: false },
                });
                const delivery = openWallRequestDelivery(this.world, request);
                if (delivery)
                    deliveries.push(delivery);
                return { author, request, delivery };
            });
            const results = await Promise.allSettled(calls.map(({ author, request, delivery }) => sameWallAuthor(this.world, a, author) && delivery?.current() === true
                ? Promise.resolve().then(() => sameWallAuthor(this.world, a, author) && delivery?.current() === true ? provider.getAction(request) : null)
                : Promise.resolve(null)));
            const failure = results.find((result) => result.status === "rejected");
            if (failure?.status === "rejected")
                throw failure.reason;
            if (!windowCurrent()) {
                cancel();
                return;
            }
            const accepted = [];
            for (let i = 0; i < calls.length; i++) {
                const { author, delivery } = calls[i], result = results[i];
                if (!sameWallAuthor(this.world, a, author) || delivery?.current() !== true) {
                    change(author, "revoked");
                    continue;
                }
                const call = result.status === "fulfilled" ? readWallTool(result.value) : null;
                if (!call) {
                    if (result.status === "fulfilled" && result.value !== null)
                        change(author, "rejected");
                    continue;
                }
                const valid = this.gateway.validateAndSanitize(this.world, author.id, call, {
                    phase: Phase.Voting,
                    day: 1,
                    wallScope: a,
                    wallId: a.token,
                    itemInstanceId: author.instanceId,
                });
                if (!sameWallAuthor(this.world, a, author) || delivery?.current() !== true) {
                    change(author, "revoked");
                    continue;
                }
                if (!valid.ok) {
                    change(author, "rejected");
                    continue;
                }
                author.remaining = 0;
                author.note.remaining = 0;
                delivery.complete();
                change(author, "accepted", call.args.text);
                accepted.push({ author, text: call.args.text });
            }
            if (!windowCurrent()) {
                cancel();
                return;
            }
            const current = accepted.filter((row) => {
                if (sameWallAuthor(this.world, a, row.author))
                    return true;
                change(row.author, "revoked");
                return false;
            });
            const ordered = current.sort((x, y) => x.text < y.text ? -1 : x.text > y.text ? 1 : x.author.id - y.author.id);
            const final = shuffled(ordered, random());
            if (!windowCurrent() || final.some((row) => !sameWallAuthor(this.world, a, row.author))) {
                cancel();
                return;
            }
            this.events.push({
                timestamp: Date.now(),
                type: "wall_note_order_recorded",
                payload: {
                    ...base,
                    rows: final.map(({ author, text }, rank) => ({
                        actorId: author.id,
                        instanceId: author.instanceId,
                        text,
                        rank,
                    })),
                },
            }, {
                timestamp: Date.now(),
                type: "wall_notes_published",
                payload: { ...base, texts: final.map((row) => row.text) },
            });
        }
        catch (error) {
            failed = true;
            throw error;
        }
        finally {
            try {
                closeWall(this.world, a);
                for (const author of a.authors.values())
                    change(author, "expired");
            }
            catch (error) {
                failed = true;
                throw error;
            }
            finally {
                let notificationFailed = false, notificationError;
                for (const delivery of deliveries) {
                    try {
                        delivery.close();
                    }
                    catch (error) {
                        if (!notificationFailed) {
                            notificationFailed = true;
                            notificationError = error;
                        }
                    }
                }
                if (!failed && notificationFailed)
                    throw notificationError;
            }
        }
    }
}
