import { bindRequestDeliveryGuard, registerRequestAliasPropagation, settleRequestDelivery } from "./request-delivery";
function sameIndexedFields(source, target) {
    const keys = Object.keys(source).filter((k) => k !== "deadlineAtMs"), other = Object.keys(target).filter((k) => k !== "deadlineAtMs");
    return !(keys.length !== other.length ||
        keys.some((k) => !other.includes(k) || source[k] !== target[k]));
}
function everyIndexedField(source, target) {
    const keys = Object.keys(source).filter((k) => k !== "deadlineAtMs"), other = Object.keys(target).filter((k) => k !== "deadlineAtMs");
    return (keys.length === other.length &&
        keys.every((k) => other.includes(k) && source[k] === target[k]));
}
function everyReflectedField(source, target) {
    const keys = Object.keys(source).filter((k) => k !== "deadlineAtMs"), other = Object.keys(target).filter((k) => k !== "deadlineAtMs");
    return (keys.length === other.length &&
        keys.every((k) => other.includes(k) && Reflect.get(source, k) === Reflect.get(target, k)));
}
function pinFields(request) {
    const keys = Object.keys(request).filter((key) => key !== "deadlineAtMs");
    return { keys, values: keys.map((key) => Reflect.get(request, key)) };
}
function samePinnedFields(request, pin) {
    const keys = Object.keys(request).filter((key) => key !== "deadlineAtMs");
    return keys.length === pin.keys.length && keys.every((key) => {
        const index = pin.keys.indexOf(key);
        return index !== -1 && Object.is(Reflect.get(request, key), pin.values[index]);
    });
}
export class RequestLease {
    order;
    bindRequest;
    matches;
    bindingOwner;
    bindingScope;
    sameFields;
    domainCurrent;
    records = new WeakMap();
    propagate = (source, target) => {
        this.inherit(source, target);
    };
    constructor(order, bindRequest, matches, bindingOwner, bindingScope, sameFields, domainCurrent) {
        this.order = order;
        this.bindRequest = bindRequest;
        this.matches = matches;
        this.bindingOwner = bindingOwner;
        this.bindingScope = bindingScope;
        this.sameFields = sameFields;
        this.domainCurrent = domainCurrent;
    }
    static window(queries, order, contextKeys = []) {
        const keys = [...contextKeys];
        return new RequestLease(order, (scope, request, lease) => {
            if (request.actorId === queries.actorId(scope) &&
                request.phase === queries.phase(scope) &&
                request.context.day === queries.day(scope) &&
                request.context.stage === queries.stage(scope)) {
                lease.records.set(request, lease.entry(scope, request, { scope, context: request.context, fields: [] }));
                registerRequestAliasPropagation(request, lease.order, lease.propagate);
                const binding = lease.records.get(request).turn.binding;
                for (const key of keys)
                    binding.fields.push({ key, value: Reflect.get(binding.context, key) });
                lease.capture(request);
            }
        }, (scope, request, binding) => request.actorId === queries.actorId(scope) &&
            request.phase === queries.phase(scope) &&
            request.context === binding.context &&
            request.context.day === queries.day(scope) &&
            request.context.stage === queries.stage(scope) &&
            binding.fields.every(({ key, value }) => Object.is(Reflect.get(request.context, key), value)), (binding) => binding.scope, (binding) => binding.scope, sameIndexedFields, (_scope, binding) => queries.current(binding.scope));
    }
    static actorPhaseDayStage(queries, order) {
        return new RequestLease(order, (owner, request, lease) => {
            const scope = queries.active(owner);
            if (scope &&
                request.actorId === queries.actorId(scope) &&
                request.phase === queries.phase() &&
                request.context.day === 1 &&
                request.context.stage === queries.stage(scope)) {
                lease.records.set(request, lease.entry(owner, request, { scope, context: request.context }));
                registerRequestAliasPropagation(request, lease.order, lease.propagate);
                lease.capture(request);
            }
        }, (owner, request, binding) => queries.owner(binding.scope) === owner &&
            queries.active(owner) === binding.scope &&
            request.actorId === queries.actorId(binding.scope) &&
            request.context === binding.context &&
            request.phase === queries.phase() &&
            request.context.day === 1 &&
            request.context.stage === queries.stage(binding.scope), (binding) => queries.owner(binding.scope), (binding) => binding.scope, sameIndexedFields, (_owner, binding) => queries.current(binding.scope));
    }
    static stagePhaseDayActor(queries, order) {
        return new RequestLease(order, (owner, request, lease) => {
            const b = queries.active(owner);
            if (b &&
                request.context.stage === queries.stage(b) &&
                request.phase === queries.phase() &&
                request.context.day === 1 &&
                request.actorId === queries.actorId(b) &&
                queries.current(b)) {
                lease.records.set(request, lease.entry(owner, request, { binding: b, context: request.context }));
                registerRequestAliasPropagation(request, lease.order, lease.propagate);
                lease.capture(request);
            }
        }, (owner, request, a) => queries.owner(a.binding) === owner &&
            request.actorId === queries.actorId(a.binding) &&
            request.context === a.context &&
            request.context.stage === queries.stage(a.binding) &&
            request.context.day === 1 &&
            request.phase === queries.phase() &&
            queries.current(a.binding), (binding) => queries.owner(binding.binding), (binding) => binding.binding, everyReflectedField, () => true);
    }
    static actorPhaseStageDay(queries, order) {
        return new RequestLease(order, (owner, request, lease) => {
            const b = queries.active(owner);
            if (b &&
                request.actorId === queries.actorId(b) &&
                request.phase === queries.phase() &&
                request.context.stage === queries.stage(b) &&
                request.context.day === 1 &&
                queries.current(b)) {
                lease.records.set(request, lease.entry(owner, request, { binding: b, context: request.context }));
                registerRequestAliasPropagation(request, lease.order, lease.propagate);
                lease.capture(request);
            }
        }, (owner, request, a) => queries.owner(a.binding) === owner &&
            request.actorId === queries.actorId(a.binding) &&
            request.phase === queries.phase() &&
            request.context === a.context &&
            request.context.stage === queries.stage(a.binding) &&
            request.context.day === 1 &&
            queries.current(a.binding), (binding) => queries.owner(binding.binding), (binding) => binding.binding, everyIndexedField, () => true);
    }
    static item(queries, order) {
        return new RequestLease(order, (world, request, lease) => {
            const a = queries.active(world), author = a == null ? undefined : queries.authors(a).get(request.actorId);
            if (a &&
                author &&
                request.context.wall_id === queries.token(a) &&
                request.context.item_instance_id === queries.instanceId(author)) {
                lease.records.set(request, lease.entry(world, request, {
                    scope: a,
                    world,
                    actorId: request.actorId,
                    instanceId: queries.instanceId(author),
                    context: request.context,
                    author,
                }));
                registerRequestAliasPropagation(request, lease.order, lease.propagate);
                lease.capture(request);
            }
        }, (world, request, binding) => queries.active(world) === binding.scope &&
            request.actorId === binding.actorId &&
            request.context === binding.context &&
            request.context.wall_id === queries.token(binding.scope) &&
            request.context.item_instance_id === binding.instanceId &&
            request.phase === queries.phase() &&
            request.context.day === 1 &&
            request.context.stage === queries.stage(), (binding) => binding.world, (binding) => binding.scope, sameIndexedFields, (owner, binding) => queries.current(owner, binding.scope, binding.author));
    }
    bind(owner, request) {
        if (this.records.has(request))
            return;
        this.bindRequest(owner, request, this);
    }
    entry(owner, original, binding) {
        return { turn: { owner, original, binding, closed: true, settled: false, opened: false,
                completion: {}, aliases: new Set(), deadline: null }, retired: false, deadline: undefined };
    }
    capture(request) {
        const entry = this.records.get(request), turn = entry.turn;
        turn.pin = pinFields(request);
        entry.deadline = request.deadlineAtMs;
        turn.originalDeadline = entry.deadline;
        if (entry.deadline === undefined)
            turn.closed = false;
        else if (typeof entry.deadline === "number" && Number.isFinite(entry.deadline) && entry.deadline > Date.now()) {
            turn.deadline = entry.deadline;
            turn.closed = false;
        }
    }
    scope(owner, request) {
        const entry = this.records.get(request);
        if (!entry || entry.turn.owner !== owner || entry.turn.closed || entry.retired)
            return;
        const turn = entry.turn;
        if (request !== turn.original) {
            try {
                if (!samePinnedFields(request, turn.pin) || !Object.is(request.deadlineAtMs, entry.deadline)) {
                    entry.retired = true;
                    return;
                }
            }
            catch (error) {
                entry.retired = true;
                throw error;
            }
        }
        try {
            if (!this.matches(owner, turn.original, turn.binding) ||
                !samePinnedFields(turn.original, turn.pin) ||
                !Object.is(turn.original.deadlineAtMs, turn.originalDeadline) ||
                !this.domainCurrent(owner, turn.binding) ||
                (turn.deadline !== null && turn.deadline <= Date.now())) {
                turn.closed = true;
                return;
            }
            return this.bindingScope(turn.binding);
        }
        catch (error) {
            turn.closed = true;
            throw error;
        }
    }
    openDelivery(owner, request) {
        if (!this.scope(owner, request))
            return;
        const turn = this.records.get(request).turn;
        if (!turn.handle)
            turn.handle = {
                current: () => this.scope(owner, request) !== undefined,
                complete: () => this.finish(turn, true),
                close: () => this.finish(turn, false),
            };
        if (!turn.opened) {
            bindRequestDeliveryGuard(turn.original, () => this.scope(owner, turn.original) !== undefined, turn.completion);
            turn.opened = true;
            for (const alias of turn.aliases)
                this.bindDelivery(turn, alias);
        }
        return turn.handle;
    }
    bindDelivery(turn, request) {
        bindRequestDeliveryGuard(request, () => this.scope(turn.owner, request) !== undefined, turn.completion);
    }
    finish(turn, accepted) {
        if (turn.settled)
            return;
        turn.closed = true;
        turn.settled = true;
        turn.aliases.clear();
        settleRequestDelivery(turn.completion, accepted);
    }
    inherit(source, target) {
        const sourceEntry = this.records.get(source);
        if (!sourceEntry || !this.scope(sourceEntry.turn.owner, source) || this.records.has(target))
            return;
        if (!this.sameFields(source, target))
            return;
        const turn = sourceEntry.turn;
        if (!samePinnedFields(target, turn.pin))
            return;
        const deadline = target.deadlineAtMs;
        if (typeof deadline !== "number" || !Number.isFinite(deadline) || deadline <= Date.now() ||
            (turn.deadline !== null && deadline > turn.deadline))
            return;
        this.records.set(target, { turn, retired: false, deadline });
        turn.deadline = deadline;
        turn.aliases.add(target);
        registerRequestAliasPropagation(target, this.order, this.propagate);
        if (turn.opened)
            this.bindDelivery(turn, target);
    }
}
