from pathlib import Path
import subprocess,os,time,json,hashlib,sys
root=Path('/home/hby/dev/AI-Werewolf-Arena');base=Path('/tmp/awa-wall-completion-execution');attempt=sys.argv[1];out=base/attempt;out.mkdir(exist_ok=True)
private=out/'runtime';private.mkdir(exist_ok=True)
for name in ('home','cache','config','state','tmp'):(private/name).mkdir(exist_ok=True)
env={'PATH':'/usr/bin:/bin','HOME':str(private/'home'),'XDG_CACHE_HOME':str(private/'cache'),'XDG_CONFIG_HOME':str(private/'config'),'XDG_STATE_HOME':str(private/'state'),'TMPDIR':str(private/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','CI':'1','NO_COLOR':'1','FORCE_COLOR':'0','TZ':'Asia/Shanghai'}
paths=['backend/src/features/wall-notes/window.ts','backend/src/features/wall-notes/authority.ts','backend/src/domain/request-lease.ts','backend/src/domain/request-delivery.ts','backend/src/recording/reproduction/trace.ts','backend/tests/scenarios/reproduction/wall-notes/optional-request-completion.test.ts','bun.lock','package.json','backend/package.json','bunfig.toml']
def fence():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
if attempt in ('failure-prefixes','failure-prefixes-type-successor','type-successor'):
    paths.append('backend/tests/unit/events/wall-notes/optional-completion-failure-prefixes.test.ts')
cmd=['/usr/bin/bun','--no-env-file','test','--preload','./backend/tests/setup.ts','backend/tests/scenarios/reproduction/wall-notes/optional-request-completion.test.ts'];
if attempt in ('failure-prefixes','failure-prefixes-type-successor','type-successor'):cmd[-1]='backend/tests/unit/events/wall-notes/optional-completion-failure-prefixes.test.ts'

if attempt=='type-successor':cmd=['/usr/bin/bun','--no-env-file',str(root/'backend/node_modules/typescript/bin/tsc'),'-p','backend/tsconfig.tests.json','--noEmit']
before=fence();start=time.time()
(out/'launch.json').write_text(json.dumps({'command':cmd,'cwd':str(root),'environment':env,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'before':before},indent=2)+'\n')
with (out/'stdout.raw').open('wb') as stdout,(out/'stderr.raw').open('wb') as stderr:
    result=subprocess.run(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=180)
after=fence();receipt={'exitCode':result.returncode,'elapsedSeconds':time.time()-start,'sourcesUnchanged':before==after,'after':after,'outputs':{n:{'sha256':hashlib.sha256((out/n).read_bytes()).hexdigest(),'bytes':(out/n).stat().st_size} for n in ('stdout.raw','stderr.raw')}}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'attempt':attempt,**{k:receipt[k] for k in ('exitCode','elapsedSeconds','sourcesUnchanged')}}));sys.exit(result.returncode)
