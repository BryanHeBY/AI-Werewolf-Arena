# 匿名墙可选请求完成：TMP 候选

状态：仅准备；没有应用仓库、加载候选、运行类型／测试／证明。首 f449 稿完整保留于 `/tmp/awa-wall-optional-request-completion-first-f449-snapshot/`。最终 before 与 controls 须等 Root 公共边界提交后重新捕获，不能用本稿冒充其未来 Git 前态。

## 精确职责与候选路径

- 生产仅 `backend/src/features/wall-notes/window.ts`：原处理分支内新增两处完成调用，覆盖 null／坏形态／网关拒绝三类完成分支，没有改 RequestLease、Trace、Tape schema、默认 validator 或库存／事实算法。
- 新独立测试 `backend/tests/scenarios/reproduction/wall-notes/optional-request-completion.test.ts`：两条可选回复循环声明、一个显式网关拒绝声明（共三个场景声明）；不修改既有 golden 或二十种子场景。

## true／false 与异常前缀

1. **合法 null**：原结果收集、全局 current、作者／delivery current 复验全部经过后，原来直接 continue 的位置完成一次；无拒绝事实、无扣库存、无 accepted 纸条。
2. **非 null 坏形态**：沿原 `readWallTool` 失败分支，先成功追加原 rejected 事实，再完成一次；拒绝事实抛错则未到 true，后续 finally 仍关闭未完成请求。
3. **网关拒绝**：原 gateway 调用和第二次作者 current 复验保持；先成功追加原 rejected 事实，再完成一次；不扣库存、不产生 accepted。
4. **付款**：原 `author.remaining=0` → `note.remaining=0` → complete → accepted 事实的次序完全不动。第二写失败仍未 true，已经成功的第一写保留。
5. **撤权／provider throw／当前分支拒绝事实失败**：没有新增 true；原 false 收口与原异常保留。
6. complete 原实现先设置 turn.closed/settled、清 aliases，再一次通知，不重新核付款或 callback 后撤回。通知自身抛错保持同错，finally 不再补第二次 false。
7. 全局后续排序／RNG／order／published 事实可能在各作者已经 true 后失败；这时不追溯改回 false，保留领域处理已落定的前缀。这是现有付款路径也已有的规则，不承诺整面匿名墙原子成功。
8. finally 原 `closeWall` → 全作者 expired 事实 → 全 delivery.close 的次序完全不动。cleanup 先抛仍覆盖 try 中异常；收口循环记第一个新通知异常，只有没有原处理／cleanup 错时才抛它。本稿不改变该历史优先级。

`complete` 在此处表示**一次可选领域处理已经结束**，不是纸条 accepted 或库存付款。当前 RequestLease 首头将其概括为“完整付款后才 complete”，算法并不强制付款；若 Root 采用本政策，需要另登记该概括的说明精度。本候选不越权修改共同 owner。

## 三类最小回归与真实覆盖限界

- null 与空文本坏形态：分别使用手写六人身份与行动，运行一个真实 PhaseManager 周期、真实 Trace／录制，再经现有 `readReproduction` 与 `replayReproduction` 精确重放。字面 oracle 为全活、day2、六库存 remaining1/expired、零 accepted、拒绝 0 或 6、最终 texts=[]；重放相等只声明本局录制一致性。
- 网关拒绝：使用真实 ToolGateway／ActionValidator／ToolValidationRuleRegistry 的**显式输入规则**，六条合法文本都被同一规则拒绝。真实 WallWindow＋Trace 必须保原候选 action、六份原库存和六条原 rejected。再用记录候选与同一显式规则重放窗口，逐事件 type/payload 相等。
- **第三类没有伪称默认全局 strict replay 通过**：现有 Tape 不记录自定义 validator。默认规则在 shape 合法且原作者仍 current 时，没有找到可自然触发网关拒绝的纯候选；若在记录端注入规则而在精确重放端换回默认 validator，拒绝会变 accepted，不能靠本修复保证一致。需要 Root 决定是否接受这个有界窗口风险覆盖，或先给可由现有 Tape 重建的真实默认拒绝输入。不得为了第三个绿例改 Tape、全局错误策略或偷改 replay 默认 registry。

## 尚未执行的最小命令计划

候选应用／联合 source fence 后，由 Root 首运行新文件三个声明一次、两根有限严格类型和两头；纯程序证明只核真实两个新增 complete 调用点（覆盖三类完成分支）及其它分支／finally 保持。原主场景二十种子、已绿 3992 unit、原 F02 风险不重复。所有 Bun 入口 `--no-env-file`，实际 cwd／preload 以最终 Root 方案记录。本 TMP 不提供可提前运行的动态 import 命令。

## Root 首红执行准备

C46 公开边界提交后，由 Root 先仅落本新场景测试（生产 window 仍旧体），捕获实际 HEAD、旧 window 与新测试完整 SHA／字节并保存运行前后 fence，再首次运行以下三个新声明。此步骤是新增行为政策回归的真实 first-red，不是公共路由迁移等价验证；未运行前不预填失败数量或候选终态。

```sh
bun --no-env-file test --preload ./backend/tests/setup.ts backend/tests/scenarios/reproduction/wall-notes/optional-request-completion.test.ts
```

实际 cwd 为仓库根；Root 将原始 stdout／stderr、真实退出与命令保存至独立临时收据目录，失败时保留本次真实 Tape，而非用生产算法重造预期。之后才应用生产两处 complete，按实际受影响声明首次后继检查；不重跑旧二十种子／其他已绿场景。
