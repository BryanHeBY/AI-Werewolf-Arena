"""Root 在隔离环境运行名称词典归属修复的有限验证；保留原始输出及源码前后指纹。"""
from pathlib import Path
import hashlib,json,subprocess,sys,time
repo=Path('/home/hby/dev/AI-Werewolf-Arena');task=sys.argv[1];out=Path('/tmp/awa-role-name-i18n-owner-execution')/task;out.mkdir(parents=True,exist_ok=False)
for name in ['home','tmp','cache']:(out/name).mkdir()
manifest=json.loads(Path('/tmp/awa-role-name-i18n-owner-applied.json').read_text());paths=[row['path'] for row in manifest['source']+manifest['controls']];sha=lambda b:hashlib.sha256(b).hexdigest()
def fence():return {path:sha((repo/path).read_bytes()) for path in paths}
before=fence();env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','CI':'1','BUN_RUNTIME_EXECUTABLE':'/usr/bin/bun','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'cache'),'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'}
if task=='format':cwd=repo;args=['node_modules/prettier/bin/prettier.cjs','--write',*[row['path'] for row in manifest['source']]]
elif task=='tests':cwd=repo/'backend';args=['test','--preload','./tests/setup.ts','tests/unit/presentation/i18n-literal-scanner.test.ts','tests/integration/tooling/i18n-source-discovery.test.ts']
elif task=='scanner':cwd=repo/'backend';args=['scripts/check-i18n-literals.mjs']
else:raise ValueError(task)
argv=['/usr/bin/bun','--no-env-file',*args];start=time.time()
with (out/'stdout.raw').open('wb') as stdout,(out/'stderr.raw').open('wb') as stderr:result=subprocess.run(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=300)
after=fence();assert task=='format' or before==after
receipt={'task':task,'argv':argv,'cwd':str(cwd),'env':env,'base':manifest['base'],'exitCode':result.returncode,'elapsedSeconds':time.time()-start,'sourceBefore':before,'sourceAfter':after,'prePostSame':before==after,'raw':[{'path':name,'bytes':(out/name).stat().st_size,'sha256':sha((out/name).read_bytes())} for name in ['stdout.raw','stderr.raw']]};(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'task':task,'exitCode':result.returncode,'seconds':receipt['elapsedSeconds'],'stdout':(out/'stdout.raw').read_text()[-2000:],'stderr':(out/'stderr.raw').read_text()[-3000:]}));sys.exit(result.returncode)
