# 角色名称词典的 i18n 扫描归属接线

状态：仅 TMP 两源候选；尚无解析器、类型、格式、测试、门禁或产品运行。

实际根因是 H01 将六十四个角色名称迁入唯一 game-text 词典后，扫描器仍只认识十二个消息文件的顶层 `export const zhCN` 对象。现有政策是表达式级，不是文件级豁免。

本候选只承认 `packages/game-text/src/role-names.ts` 的顶层 `const roleNames` 数组中直接条目的 `names` 对象，且只豁免静态 `"zh-CN"` 属性直接字符串／无插值模板值。`id`、`en`、附加字段、嵌套对象、函数业务文案、局部同名表、可变表及其它文件仍扫描。名称不是兼容例外，不登记64条白名单，不跳过目录或整个模块。

新增一个手写源码／手写命中清单的单元声明，覆盖真实表形状准入与同文件业务／其它字段／冒名拒绝。原仓库发现集成声明不改，后续 Root 可用它直接验证真实64项词典与现有精确例外。四个 controls 包括实际唯一名称表、text入口、例外JSON、原集成测试，全未改。

Root 可按需要首跑现有 scanner unit 与原失败的 discovery integration；本作者未执行：

```sh
cd backend
bun --no-env-file test --preload ./tests/setup.ts tests/unit/presentation/i18n-literal-scanner.test.ts tests/integration/tooling/i18n-source-discovery.test.ts
```

此修复属于静态扫描准入归属，没有更改词典数据或角色行为。最终全42仍需新固定source；旧 f2bd 真红不得改作全绿或拼后继局部结果。
