from pathlib import Path
import json,hashlib,subprocess,difflib,datetime
repo=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/tmp/awa-role-name-i18n-owner-repair')
def sha(b):return hashlib.sha256(b).hexdigest()
paths=['backend/scripts/check-i18n-literals.mjs','backend/tests/unit/presentation/i18n-literal-scanner.test.ts']
controls=['packages/game-text/src/role-names.ts','packages/game-text/src/index.ts','tooling/refactor/policies/i18n-source-exceptions.json','backend/tests/integration/tooling/i18n-source-discovery.test.ts']
base=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=repo).decode().strip()
rows=[]
for p in paths+controls:
 b=(repo/p).read_bytes();g=subprocess.check_output(['/usr/bin/git','show',base+':'+p],cwd=repo)
 if b!=g:raise ValueError('Requested source/control is not actual Git: '+p)
 mode=subprocess.check_output(['/usr/bin/git','ls-tree',base,'--',p],cwd=repo).decode().split()[0]
 rows.append({'path':p,'sha256':sha(b),'bytes':len(b),'mode':mode,'text':b.decode(),'sameActualGit':True})
before={'base':base,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':rows[:2],'controls':rows[2:],'scope':'Two source paths only; Root five header WIP is not source/control.'}
(out/'before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
source={r['path']:r['text'] for r in rows[:2]};edits=[]
def edit(p,a,b):
 if source[p].count(a)!=1:raise ValueError('Exact replacement count: '+p+' '+str(source[p].count(a)))
 edits.append({'path':p,'before':a,'after':b,'occurrences':1});source[p]=source[p].replace(a,b,1)
p=paths[0]
edit(p,' * 唯一翻译所有者清单只豁免其 exported const zhCN 对象的直接中文值，不豁免相邻代码或整个目录。',
' * 消息词典只放行登记文件中 exported const zhCN 的直接值；角色名称只放行唯一 roleNames 表中 names["zh-CN"] 的直接值。\n * 两种许可均按 AST 数据位置识别，相邻业务、键名、其他字段和目录仍接受普通扫描。')
anchor='''  /** @type {ChineseLiteral[]} */
  const found = [];
  /** @param {import("typescript").Node} node */'''
addition='''  /** @type {Set<import("typescript").ObjectLiteralExpression>} */
  const roleNameObjects = new Set();
  // 名称唯一归 game-text：只识别该文件顶层 const roleNames 数组的直接条目及 names 对象。
  // 不把整个名称模块当词典，不放行 id、en、额外字段、局部同名变量或返回文案。
  if (file === "packages/game-text/src/role-names.ts") {
    for (const statement of parsed.statements) {
      if (
        !ts.isVariableStatement(statement) ||
        !(statement.declarationList.flags & ts.NodeFlags.Const)
      )
        continue;
      for (const declaration of statement.declarationList.declarations) {
        if (!ts.isIdentifier(declaration.name) || declaration.name.text !== "roleNames") continue;
        let value = declaration.initializer;
        while (value && (ts.isAsExpression(value) || ts.isSatisfiesExpression(value)))
          value = value.expression;
        if (!value || !ts.isArrayLiteralExpression(value)) continue;
        for (const entry of value.elements) {
          if (!ts.isObjectLiteralExpression(entry)) continue;
          for (const property of entry.properties) {
            if (
              ts.isPropertyAssignment(property) &&
              ts.isIdentifier(property.name) &&
              property.name.text === "names" &&
              ts.isObjectLiteralExpression(property.initializer)
            )
              roleNameObjects.add(property.initializer);
          }
        }
      }
    }
  }
'''+anchor
edit(p,anchor,addition)
edit(p,'      // 只放行登记 owner 中 zhCN 对象的直接 property 值；键名和相邻表达式仍走普通扫描。',
'      // 只放行登记消息对象的直接值，或唯一名称表 names 对象中静态 "zh-CN" 属性的直接值。\n      // 字面必须仍是 initializer；键名、en 和相邻表达式均不继承词典许可。')
edit(p,'        translationObjects.has(property.parent);',
'''        (translationObjects.has(property.parent) ||
          (roleNameObjects.has(property.parent) &&
            ts.isStringLiteral(property.name) &&
            property.name.text === "zh-CN"));''')
p=paths[1]
addition='''

test("role name dictionary admission is restricted to the canonical table Chinese values", () => {
  // 字面正例覆盖当前私有表的 const／satisfies 形状；手写拒绝清单保同文件业务与其它字段可见。
  const source = [
    'const roleNames = [{ id: "wolf", names: { "zh-CN": "狼人", en: "Werewolf" } }, { id: "身份字段硬编码", names: { "zh-CN": `规划名称`, en: "英文中夹中文", nested: { "zh-CN": "嵌套硬编码" } }, label: "表内业务硬编码" }] as const satisfies readonly Entry[];',
    'const label = "词典邻近业务";',
    'function helper() { const roleNames = [{ names: { "zh-CN": "局部冒名" } }]; return "函数业务硬编码"; }',
  ].join("\\n");
  expect(
    collectChineseLiterals("packages/game-text/src/role-names.ts", source).map(
      (entry) => entry.text,
    ),
  ).toEqual([
    "身份字段硬编码",
    "英文中夹中文",
    "嵌套硬编码",
    "表内业务硬编码",
    "词典邻近业务",
    "局部冒名",
    "函数业务硬编码",
  ]);
  for (const file of [
    "packages/game-text/src/unregistered.ts",
    "packages/game-catalog/src/role-names.ts",
  ])
    expect(
      collectChineseLiterals(
        file,
        'const roleNames = [{ names: { "zh-CN": "非所有者冒名" } }];',
      ).map((entry) => entry.text),
    ).toEqual(["非所有者冒名"]);
  expect(
    collectChineseLiterals(
      "packages/game-text/src/role-names.ts",
      'let roleNames = [{ names: { "zh-CN": "可变表冒名" } }];',
    ).map((entry) => entry.text),
  ).toEqual(["可变表冒名"]);
});
'''
edit(p,source[p].rstrip()+'\n',source[p].rstrip()+addition)
# No language parser/formatter/test or candidate helper is invoked. This only serializes authored text.
patch=''
for p in paths:
 b=source[p].encode();target=out/'candidates'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 old=next(r['text'] for r in rows if r['path']==p)
 patch+=''.join(difflib.unified_diff(old.splitlines(True),source[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(out/'candidate.patch').write_text(patch)
(out/'edits.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
proposal={'status':'TMP-only prepared bounded policy wiring; not executed','base':base,'source':[{'path':p,'beforeSHA256':next(r['sha256'] for r in rows if r['path']==p),'candidateSHA256':sha(source[p].encode()),'bytes':len(source[p].encode())} for p in paths],'controls':[{'path':r['path'],'sha256':r['sha256'],'bytes':r['bytes']} for r in rows[2:]],'exactEdits':len(edits),'newTestDeclarations':1,'policy':'Exact canonical role-names file, top-level const roleNames array, direct object entry.names object, direct static zh-CN string/template-no-substitution initializer only. Existing message policy unchanged; no file/directory blanket exemption.','retained':['64 bilingual role name literals and sole production table','All five existing scanner/discovery test declarations and assertions','Exact file/text/count exceptions JSON','All private-root/symlink discovery policy','No new English/Chinese fallback or runtime role behavior'],'executionByAuthor':[],'repositoryWrites':False}
(out/'proposal.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
(out/'README.md').write_text('''# 角色名称词典的 i18n 扫描归属接线\n\n状态：仅 TMP 两源候选；尚无解析器、类型、格式、测试、门禁或产品运行。\n\n实际根因是 H01 将六十四个角色名称迁入唯一 game-text 词典后，扫描器仍只认识十二个消息文件的顶层 `export const zhCN` 对象。现有政策是表达式级，不是文件级豁免。\n\n本候选只承认 `packages/game-text/src/role-names.ts` 的顶层 `const roleNames` 数组中直接条目的 `names` 对象，且只豁免静态 `"zh-CN"` 属性直接字符串／无插值模板值。`id`、`en`、附加字段、嵌套对象、函数业务文案、局部同名表、可变表及其它文件仍扫描。名称不是兼容例外，不登记64条白名单，不跳过目录或整个模块。\n\n新增一个手写源码／手写命中清单的单元声明，覆盖真实表形状准入与同文件业务／其它字段／冒名拒绝。原仓库发现集成声明不改，后续 Root 可用它直接验证真实64项词典与现有精确例外。四个 controls 包括实际唯一名称表、text入口、例外JSON、原集成测试，全未改。\n\nRoot 可按需要首跑现有 scanner unit 与原失败的 discovery integration；本作者未执行：\n\n```sh\ncd backend\nbun --no-env-file test --preload ./tests/setup.ts tests/unit/presentation/i18n-literal-scanner.test.ts tests/integration/tooling/i18n-source-discovery.test.ts\n```\n\n此修复属于静态扫描准入归属，没有更改词典数据或角色行为。最终全42仍需新固定source；旧 f2bd 真红不得改作全绿或拼后继局部结果。\n''')
refs=[]
for name in ['before.json','edits.json','candidate.patch','proposal.json','README.md']:
 b=(out/name).read_bytes();refs.append({'path':str(out/name),'sha256':sha(b),'bytes':len(b)})
h={'status':'prepared only','base':base,'source':proposal['source'],'controls':proposal['controls'],'artifacts':refs,'checksExecuted':[],'repositoryWrites':False}
(out/'HANDOFF.json').write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n')
print('HANDOFF',sha((out/'HANDOFF.json').read_bytes()));print(json.dumps(proposal,ensure_ascii=False,indent=2))
