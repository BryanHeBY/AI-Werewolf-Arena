"""准备目标提示的实际查询边界；完整筛选规则仍归目标提示 owner。"""
from pathlib import Path
out=Path('/tmp/awa-target-hint-query-candidates');out.mkdir(exist_ok=False)
p=Path('backend/src/agents/tool-repair/contracts.ts');s=p.read_text().replace('import { World } from "../../domain/world";','import type { Locale } from "@ai-werewolf-arena/game-contract";')
s=s.replace(' * 目标提示按当前工具与候选来源选择编号，World 保原 live 引用；这里不持有提交回执或独立库存。',' * 目标提示按当前工具与候选来源选择编号；查询实时读取所属 owner，不持有提交回执或独立库存。')
s=s.replace('  /** 规则在原查询点读取组件、存活名单和 locale；此引用不是数据快照。 */\n  world: World;\n  roleCatalog?: import("../../rulesets/roles/catalog").RoleCatalog;','  /** 只暴露编号、标量和受限查询句柄，不返回原组件或可写世界。 */\n  readonly queries: TargetHintQueries;')
s+='''

/** 捕获本次行动者原能力引用，只返回目标判断；不授予使用能力或付款的权限。 */
export interface TargetHintActorQueries {
  luckyAllowed(tool: ToolName, id: EntityId): boolean;
  awakenedGuardAllowed(id: EntityId): boolean;
  potion(): { isLucky(): boolean } | undefined;
}

/** 目标提示的具体查询；候选只是建议，实际提交仍须由网关与资源 owner 复验。 */
export interface TargetHintQueries {
  locale(): Locale;
  aliveIds(): EntityId[];
  nobleChoiceTargets(): EntityId[];
  shelterTargets(): EntityId[];
  eclipseSwallowTargets(): EntityId[];
  isRadiantBoard(): boolean;
  inspection(): { allows(id: EntityId): boolean } | undefined;
  actorRules(): TargetHintActorQueries;
  fearTargets(): EntityId[];
  swapTargets(): EntityId[];
  wolfKnifeAllows(id: EntityId): boolean;
  wolfWitchTargetAllowed(id: EntityId): boolean;
  canBeExiled(id: EntityId): boolean;
  loversVoteAllowed(id: EntityId): boolean;
  canBeSheriff(id: EntityId): boolean;
}
'''
(out/'contracts.ts').write_text(s)
p=Path('backend/src/agents/tool-repair/target-hint-registry.ts');s=p.read_text();s=s.replace('import { TargetHintContext, TargetHintRegistry } from "./contracts";','import { TargetHintContext, TargetHintRegistry, type TargetHintQueries } from "./contracts";\nimport type { World } from "../../domain/world";\nimport type { RoleCatalog } from "../../rulesets/roles/catalog";')
s=s.replace('''nobleBodyChoiceTargets(
        ctx.world,
        ctx.day ?? 1,
        ctx.allowedTools.includes("choose_servant") ? "noble" : "body",
      )''','ctx.queries.nobleChoiceTargets()')
s=s.replace('shelterTargets(ctx.world, ctx.day ?? 1, ctx.actorId, ctx.abilityId!)','ctx.queries.shelterTargets()').replace('eclipseSwallowTargets(ctx.world, ctx.day ?? 1)','ctx.queries.eclipseSwallowTargets()')
s=s.replace('ctx.world.locale','ctx.queries.locale()').replace('ctx.world.getAliveEntityIds()','ctx.queries.aliveIds()').replace('isRadiantEclipseBoard(ctx.world)','ctx.queries.isRadiantBoard()')
a=s.index('    const inspection = getRoleInspectionState(');b=s.index('    const ids = ctx.world',a)
original=s[a:b];la=original.index('    const luckyAllowed = ');lucky=original[la:].replace('    const luckyAllowed = (tool: ToolName, id: number) => {','      luckyAllowed(tool, id) {').replace('    };\n','      },\n');lucky=lucky.replace('ctx.','source.')
s=s[:a]+'''    const inspection = ctx.queries.inspection();
    const actorRules = ctx.queries.actorRules();
'''+s[b:]
s=s.replace('ctx.world\n      .getAliveEntityIds()','ctx.queries\n      .aliveIds()').replace('luckyAllowed(tool, id)','actorRules.luckyAllowed(tool, id)')
s=s.replace('nightmareFearTargets(ctx.world, ctx.actorId, ctx.day ?? 1)','ctx.queries.fearTargets()').replace('magicianChoiceTargets(ctx.world, ctx.day ?? 1)','ctx.queries.swapTargets()').replace('bindWolfKnifeTargetQuery(ctx.world).allows(id)','ctx.queries.wolfKnifeAllows(id)')
s=s.replace('''(ctx.world.getComponent(id, COMPONENT.Role) &&
                ctx.world.getComponent(id, COMPONENT.Camp)?.camp) !== "wolf"''','ctx.queries.wolfWitchTargetAllowed(id)')
s=s.replace('''awakenedGuard?.kind !== "guard" ||
              awakenedGuard.lastGuardDay !== (ctx.day ?? 1) - 1 ||
              awakenedGuard.lastTarget !== id''','actorRules.awakenedGuardAllowed(id)')
s=s.replace('canBeExiled(ctx.world, id, ctx.roleCatalog)','ctx.queries.canBeExiled(id)').replace('!prohibitsLoversVote(ctx.world, ctx.actorId, id)','ctx.queries.loversVoteAllowed(id)').replace('canBeSheriff(ctx.world, id, ctx.roleCatalog)','ctx.queries.canBeSheriff(id)')
s=s.replace('''!inspection ||
              inspectionRepeats(inspection) ||
              !inspection.history.some((report) => report.targetId === id)''','!inspection || inspection.allows(id)')
s=s.replace('const potion = findNightAbility(ownRole, "potion", ctx.abilityId);','const potion = actorRules.potion();').replace('potion?.activation === "lucky"','potion?.isLucky()')
assert 'ctx.world' not in s and 'ctx.roleCatalog' not in s
s+='''

/** 可信提示装配输入；只在调用端绑定，不交给可替换 TargetHintRegistry。 */
export type TargetHintRuntimeInput = Omit<TargetHintContext, "queries"> & {
  world: World;
  roleCatalog?: RoleCatalog;
};

/**
 * 每次提示建立实际窄对象。数据字段保持晚读，组件和能力原引用只留在具体查询闭包里。
 * 这里不快照或复制资源，不发许可；查询异常仍由原提示调用路径传播。
 */
export function bindTargetHintContext(source: TargetHintRuntimeInput): TargetHintContext {
  const queries: TargetHintQueries = {
    locale: () => source.world.locale,
    aliveIds: () => [...source.world.getAliveEntityIds()],
    nobleChoiceTargets: () => nobleBodyChoiceTargets(source.world, source.day ?? 1,
      source.allowedTools.includes("choose_servant") ? "noble" : "body"),
    shelterTargets: () => shelterTargets(source.world, source.day ?? 1, source.actorId, source.abilityId!),
    eclipseSwallowTargets: () => eclipseSwallowTargets(source.world, source.day ?? 1),
    isRadiantBoard: () => isRadiantEclipseBoard(source.world),
    inspection() {
      const inspection = getRoleInspectionState(source.world.getComponent(source.actorId, COMPONENT.Role)!, source.abilityId);
      return inspection ? { allows: (id) => inspectionRepeats(inspection) || !inspection.history.some((report) => report.targetId === id) } : undefined;
    },
    actorRules() {
      const ownRole = source.world.getComponent(source.actorId, COMPONENT.Role);
      const awakenedGuard = getAwakenedState(ownRole)?.learned?.skill;
      return {
LUCKY
        awakenedGuardAllowed: (id) => awakenedGuard?.kind !== "guard" ||
          awakenedGuard.lastGuardDay !== (source.day ?? 1) - 1 || awakenedGuard.lastTarget !== id,
        potion() {
          // 定位仍先于外层工具分支，activation 仅在原幸运毒提示分支读取。
          const potion = findNightAbility(ownRole, "potion", source.abilityId);
          return potion ? { isLucky: () => potion.activation === "lucky" } : undefined;
        },
      };
    },
    fearTargets: () => nightmareFearTargets(source.world, source.actorId, source.day ?? 1),
    swapTargets: () => magicianChoiceTargets(source.world, source.day ?? 1),
    wolfKnifeAllows: (id) => bindWolfKnifeTargetQuery(source.world).allows(id),
    wolfWitchTargetAllowed: (id) => (source.world.getComponent(id, COMPONENT.Role) &&
      source.world.getComponent(id, COMPONENT.Camp)?.camp) !== "wolf",
    canBeExiled: (id) => canBeExiled(source.world, id, source.roleCatalog),
    loversVoteAllowed: (id) => !prohibitsLoversVote(source.world, source.actorId, id),
    canBeSheriff: (id) => canBeSheriff(source.world, id, source.roleCatalog),
  };
  return {
    get modifierCandidates() { return source.modifierCandidates; },
    get modifierBonusCandidates() { return source.modifierBonusCandidates; },
    get actorId() { return source.actorId; },
    get day() { return source.day; },
    get actorRole() { return source.actorRole; },
    get abilityId() { return source.abilityId; },
    get debateTargetId() { return source.debateTargetId; },
    get allowedTools() { return source.allowedTools; },
    get sheriffCandidates() { return source.sheriffCandidates; },
    get badgeCandidates() { return source.badgeCandidates; },
    get exileCandidates() { return source.exileCandidates; },
    queries,
  };
}
'''.replace('LUCKY',lucky)
(out/'target-hint-registry.ts').write_text(s)
print(out)
