/** 只在实际调用的对象字面量外插入可信绑定；保留原参数字段及 getter 的源码顺序。 */
const fs=require('fs'),path=require('path'),cp=require('child_process');
const repo='/home/hby/dev/AI-Werewolf-Arena';const ts=require(repo+'/backend/node_modules/typescript');
const files=cp.execFileSync('rg',['-l','buildActionableIdsHint','backend/src','backend/tests','--glob','*.ts'],{cwd:repo,encoding:'utf8'}).trim().split('\n');const changed=[];
for(const p of files){const full=path.join(repo,p),s=fs.readFileSync(full,'utf8');const source=ts.createSourceFile(p,s,ts.ScriptTarget.Latest,true);const edits=[];
 function walk(n){if(ts.isCallExpression(n)&&ts.isPropertyAccessExpression(n.expression)&&n.expression.name.text==='buildActionableIdsHint'&&n.arguments.length===1&&ts.isObjectLiteralExpression(n.arguments[0])){const a=n.arguments[0];edits.push({at:a.getStart(source),text:'bindTargetHintContext('},{at:a.end,text:')'});}ts.forEachChild(n,walk);}walk(source);if(!edits.length)continue;
 let result=s;for(const e of edits.sort((a,b)=>b.at-a.at))result=result.slice(0,e.at)+e.text+result.slice(e.at);
 let rel=path.relative(path.dirname(full),path.join(repo,'backend/src/agents/tool-repair/target-hint-registry')).replaceAll(path.sep,'/');if(!rel.startsWith('.'))rel='./'+rel;
 const importAt=source.statements[0].getStart(source);result=result.slice(0,importAt)+'import { bindTargetHintContext } from '+JSON.stringify(rel)+';\n'+result.slice(importAt);fs.writeFileSync(full,result);changed.push({path:p,calls:edits.length/2});}
fs.writeFileSync('/tmp/awa-target-hint-query-candidates/call-adaptations.json',JSON.stringify(changed,null,2)+'\n');process.stdout.write(JSON.stringify(changed)+'\n');
