# Tape3 pending/action 构造静态审查

输入 Git：`07ef28ef06f2579a6e7fb7467bca588c87608348`。只读现行源码；没有执行产品、解析器、测试、类型或门禁，也没有写仓库。

## 结论

两处真实失败返回后构造 pending 的夹具需要移除终态 `returnedCandidate`：

- Radiant 两个原声明共两处；原 null Seer 失败录制。
- Ghost Bride 一个原声明一处；原 initial/null 选婚失败录制。

两份候选分别保完整 actual Git 前态、单文件 diff 和精确替换。所有原输入、断言、截断与错误政策保持。Root 独占执行；Ghost 当前仍为静态推导。

其余已追踪的显式 outcome 改写来自成功 action、边界 Provider 抛错前捕获的真 pending、手写 Tape2，或是明确测试返回候选非法形状的 schema 负例。没有发现第三处同类真实失败候选残留；不据此宣称任意动态写入或全 C47 已通过。

## 关键不改项

- `request-delivery.test.ts` 让候选字段与 pending/action/TypeError 并存是故意 schema 负例，必须保。
- Mist 并行 null 与 Scholar/Fragrant/Wolf King 成功动作模板没有被终态 false-close 候选污染；不能因 null 或失败前缀文件名一概删除字段。
- Wolf King 第二组虽来自失败记录，但复制的是失败前已完成的 LastWords，不是终端失败枪行。
- Magician/Mist 增量驱动在边界 Provider 抛错前捕获 `trace.build()`；尚未返回候选，字段不存在。
- Ghost 原夹具的 settleOrder 和 CP/events 截断未改；本次只移除新增终态证据，不加强旧接受策略。

逐文件实际来源、原 SHA、文本检索原输出与限界见 `report.json`。
