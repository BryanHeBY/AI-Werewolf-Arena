"""Root隔离运行单一诊断，收据和运行目录独占，不修改正式42输入。"""
from pathlib import Path
import os,json,subprocess,hashlib,time
p=Path('/var/tmp/awa-refactor-20261015/radiant-pending-diagnostic');p.mkdir()
for name in ('home','tmp','cache'):(p/name).mkdir()
env={'PATH':'/usr/bin:/bin','HOME':str(p/'home'),'TMPDIR':str(p/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','BUN_RUNTIME_EXECUTABLE':'/usr/bin/bun','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(p/'cache'),'AWA_DIAGNOSTIC_ROOT':str(p)}
argv=['/usr/bin/bun','--no-env-file','--preload','./tests/setup.ts','/tmp/awa-radiant-pending-candidate-diagnostic.ts'];cwd='/var/tmp/awa-refactor-20261015/c47-07ef28ef/snapshot/backend';start=time.time()
with (p/'stdout.raw').open('wb') as out,(p/'stderr.raw').open('wb') as err:r=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=err,timeout=120)
files=[]
for f in p.iterdir():
 if f.is_file():
  b=f.read_bytes();files.append({'path':f.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
report={'scope':'single actual fixed07ef radiantRecording diagnostic, not final42 or a test count','argv':argv,'cwd':cwd,'env':env,'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'files':files}
(p/'execution.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'exitCode':r.returncode,'files':len(files),'root':str(p)}));raise SystemExit(r.returncode)
