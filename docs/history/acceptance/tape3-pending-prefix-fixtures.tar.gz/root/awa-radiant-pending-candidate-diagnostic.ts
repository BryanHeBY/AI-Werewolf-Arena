/** 使用固定07ef实际录制核对pending夹具字段；不改生产格式、断言或固定验收输入。 */
import { writeFile } from 'node:fs/promises';
import { radiantRecording } from '/var/tmp/awa-refactor-20261015/c47-07ef28ef/snapshot/backend/tests/support/features/radiant-eclipse/drivers/recording';
import { parseReproductionRecord } from '/var/tmp/awa-refactor-20261015/c47-07ef28ef/snapshot/backend/src/recording/reproduction/format';
const root=process.env.AWA_DIAGNOSTIC_ROOT!;
const original=await radiantRecording({failureStage:'seer'});
await writeFile(root+'/original.json',JSON.stringify(original,null,2)+'\n');
function result(value: unknown){try{parseReproductionRecord(value);return {accepted:true};}catch(error){return {accepted:false,error:error instanceof Error?error.message:'non_error'};}}
const pending=structuredClone(original);
pending.finalized=false;pending.termination=null;pending.operations=[];pending.checkpoints.pop();
pending.events=pending.events.slice(0,pending.checkpoints.at(-1)!.eventCount);
pending.decisions.at(-1)!.outcome={kind:'pending'};delete pending.decisions.at(-1)!.settleOrder;
const withCandidate=result(pending);
const candidate=pending.decisions.at(-1)!.returnedCandidate;
delete pending.decisions.at(-1)!.returnedCandidate;
const withoutCandidate=result(pending);
const finalizedPending=structuredClone(original);
finalizedPending.decisions.at(-1)!.outcome={kind:'pending'};
delete finalizedPending.decisions.at(-1)!.settleOrder;
const finalizedWithCandidate=result(finalizedPending);
delete finalizedPending.decisions.at(-1)!.returnedCandidate;
const finalizedWithoutCandidate=result(finalizedPending);
const report={schemaVersion:original.schemaVersion,original:result(original),terminalOriginal:original.decisions.at(-1),candidate,withCandidate,withoutCandidate,finalizedWithCandidate,finalizedWithoutCandidate};
await writeFile(root+'/diagnostic.json',JSON.stringify(report,null,2)+'\n');
await writeFile(root+'/pending-without-candidate.json',JSON.stringify(pending,null,2)+'\n');
console.log(JSON.stringify({schemaVersion:report.schemaVersion,terminalCandidateOwn:Object.hasOwn(original.decisions.at(-1)!,'returnedCandidate'),candidate,withCandidate,withoutCandidate,finalizedWithCandidate,finalizedWithoutCandidate}));
if(withCandidate.accepted||!withoutCandidate.accepted||finalizedWithoutCandidate.accepted)process.exitCode=1;
