"""Root仅执行修改文件的两个原声明，保原断言/生产源及首次红。"""
from pathlib import Path
import json,subprocess,hashlib,time
root=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/var/tmp/awa-refactor-20261015/radiant-pending-fixture-successor');out.mkdir()
name='backend/tests/scenarios/failures/radiant-eclipse/pending-trace-state.test.ts'
sha=lambda b:hashlib.sha256(b).hexdigest()
def changed():return subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root).decode().splitlines()
assert changed()==[name]
expected='bcc91c66531210332e3c0855bb148b7ac753f37bc52090a6fb25980dc1934eb0';assert sha((root/name).read_bytes())==expected
for p in ('home','tmp','cache'):(out/p).mkdir()
env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','CI':'1','BUN_RUNTIME_EXECUTABLE':'/usr/bin/bun','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'cache'),'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'}
argv=['/usr/bin/bun','--no-env-file','test','--preload','./tests/setup.ts','tests/scenarios/failures/radiant-eclipse/pending-trace-state.test.ts'];start=time.time()
with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:p=subprocess.run(argv,cwd=root/'backend',env=env,stdout=a,stderr=b,timeout=120)
assert changed()==[name] and sha((root/name).read_bytes())==expected
report={'base':'07ef28ef06f2579a6e7fb7467bca588c87608348','changedSource':{'path':name,'sha256':expected},'sourceFence':'only the specified test file differs from07ef before and after','argv':argv,'cwd':str(root/'backend'),'environment':env,'exitCode':p.returncode,'elapsedSeconds':time.time()-start,'raw':[{'path':n,'sha256':sha((out/n).read_bytes()),'bytes':(out/n).stat().st_size} for n in ('stdout.raw','stderr.raw')]}
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'exitCode':p.returncode,'elapsedSeconds':report['elapsedSeconds'],'root':str(out)}));raise SystemExit(p.returncode)
