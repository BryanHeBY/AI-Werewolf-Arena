"""Root运行单个原Ghost pending声明；前后输入摘要和实际首红/后继分开保存。"""
from pathlib import Path
import json,subprocess,hashlib,time,sys
stage=sys.argv[1];assert stage in ('before','after')
root=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/var/tmp/awa-refactor-20261015/ghost-pending-fixture-'+stage);out.mkdir()
name='backend/tests/scenarios/boards/ghost-bride/reproduction.test.ts';sha=lambda b:hashlib.sha256(b).hexdigest()
expected='f659d57ddee08c341999d57cc836d76041345d01fc0444252d104cf441cfb22c' if stage=='before' else '586328ffdae265350234f662571acb932f360419df25fd4c7dfb9fa6ce5ee92c'
assert sha((root/name).read_bytes())==expected
before=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root).decode().splitlines();allowed=['backend/tests/scenarios/failures/radiant-eclipse/pending-trace-state.test.ts']
if stage=='after':allowed.append(name)
assert set(before)==set(allowed)
for p in ('home','tmp','cache'):(out/p).mkdir()
env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','CI':'1','BUN_RUNTIME_EXECUTABLE':'/usr/bin/bun','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'cache'),'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'}
argv=['/usr/bin/bun','--no-env-file','test','--preload','./tests/setup.ts','tests/scenarios/boards/ghost-bride/reproduction.test.ts','-t','^pending first setup decision is a terminal prefix even in an unfinalized archive$'];start=time.time()
with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:p=subprocess.run(argv,cwd=root/'backend',env=env,stdout=a,stderr=b,timeout=120)
assert sha((root/name).read_bytes())==expected and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root).decode().splitlines()==before
report={'base':'07ef28ef06f2579a6e7fb7467bca588c87608348','stage':stage,'source':{'path':name,'sha256':expected},'otherChangedInput':allowed,'beforeAfterDiffPathsEqual':True,'argv':argv,'cwd':str(root/'backend'),'environment':env,'exitCode':p.returncode,'elapsedSeconds':time.time()-start,'raw':[{'path':n,'sha256':sha((out/n).read_bytes()),'bytes':(out/n).stat().st_size} for n in ('stdout.raw','stderr.raw')]}
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'exitCode':p.returncode,'seconds':report['elapsedSeconds'],'root':str(out)}));raise SystemExit(p.returncode)
