# 角色贡献的值查询与初始化写端口

这是 H02 后继的 TMP SourceReady 候选。作者没有写仓库，也没有执行产品、parser、类型、测试、formatter 或门禁。Root 负责应用、格式化、首轮必要验证与提交。

## 实际职责

公开 `RoleRuntimeContribution` 的参与资格、狼队／队友知识、熊感知、自爆资格、查验标签、胜利归属、基线和渲染回调不再收到 World、原 Role 或 Camp 组件。`RoleQueries` 是每次调用实际构造的普通对象，只提供枚举／编号／布尔查询；`stateData` 在被调用时以既有 `copyEventData` 复制私态。这个新查询的 JSON 接受面和复制错误是明确 API 表面，不在调用未知 callback 前提前复制／验证私态。具体值随原现场晚读，不缓存来源或把阵营当成权限。

自定义 init 是唯一例外：仍可写同一 ownRole 的原私态容器／扩展键，并改实际待安装 initialCamp。它得到独立 public ctx，不再得到宿主 ctx 身份或 `.world`；currentCamp 只返回当前枚举，不回退 initialCamp。胜利归属回调另用 `RoleValueContext`，没有 initialCamp 写端口。板子数据沿原 readonly/frozen-plan 契约，不引入新的 deep freeze。

`owned-bindings.ts` 是可信内建程序的内部静态装配。私表只保存原函数身份与贡献种类，不保存 World、角色索引、每局状态或第二份许可。每个原完整 callback 在原属性创建点登记且返回同一函数；函数体、默认参数、闭包和数据贡献保原样。完整内建得到原参数和 receiver；未知函数得到实际窄输入。没有依角色 ID 选 World 的核心表，没有通用 BaseRuntime，也没有为每个角色新建 wrapper 文件。

## 时点与归属

- Catalog 的实际 init 仍先于默认 locale；两个 render getter、原 receiver、`ctx.world` 参数位置及晚 currentCamp 调用保留。public init 构造 query 时不读取 host.world；只有用户实际调用有关查询才晚读该宿主来源。
- participation 保原 typeof getter 与实际第二次 method getter；权限 callback 原裸调用 receiver 仍为 undefined，原 ready／Camp／wedding 和三种阻断顺序不动。
- 基线保原候选与 picker／locale 参数先后；原后置狼聊／刀执行重检不变。普通狼委托继续读取可写 runtime 和方法；未知替换函数只得到窄查询及原 request／picker／locale。
- `roleMethod` 只有原 owner 的 optional-chain 才跳过空 owner；字段非 callable 不在准备阶段提前抛，真正调用时才出现原 TypeError。Scholar 的 base 空值与 runtime 空值区分保留。
- 熊仍先查原 Role 和真实 Camp，再可选调用感知；查验仍先形成标签、再按原顺序读取 Camp／Role，role-only 缺 Camp 的既有政策不变。
- init、当前真实 Camp、历史知识、披露标签与 Victory membership 独立。Lonely 追随狼只改变其原胜利归属，不能据此把实际 Camp 写成 Wolf；本批不改该生产规则。

## 应用边界

`before.json` 保存开始时真实 Git d19114fb7203056ec6552b77f96933dff6439881 全文／mode／blob，以及当时实际 current 全文和 SHA，两者不混称。H03 当时处于已授权 WIP；当前 Root 已另提交 H03 3437745e，Chooser 后继也只更改 WolfKing deathHook。所有 44 个 profile 和 app/bootstrap 只按 `shared-exact-deltas.json` 合并本批非 validation／非 death 片段，禁止 whole-file 覆盖。Root 若已改格式或行偏移，按完整 before/after、精确片段和上下文迁入相同局部变更，不能覆盖新 deathHook。其它完整候选也必须核实际 beforeSHA；新两路径要求真实 absence。

旧测试中直接执行可信 native callback 的输入改经同一个内部 dispatch，仍调用同原函数和原参数；unknown custom 用例改用公开 queries／scalar currentCamp，明确退出旧组件和宿主 ctx 身份。故测试输入/API 的变化不是全 JS 等价。自有测试闭包原本显式持有的 World 可继续注入变化，不隐式从新 public 参数取得写权。

## 风险与验证计划

新 `narrow-role-contribution-boundaries.test.ts` 只有两个手写独立声明：实际 Catalog／狼队／知识／查验／自爆／熊采样／基线消费公开 queries，检查脱离数据不改原体与当前值晚读；实际 native renderer 同引用／sameError，注入 renderer 不取 World，WolfBeauty 委托原普通狼可写表时保 late getter／receiver 且未知替换只有 5 个窄参数。预期是字面字段、序列、对象引用和同一 Error，不调用生产算法生成 oracle。

建议 Root 首跑新两声明；完整 backend test-types 一次闭 API 所有消费者；按准备清单运行受影响的旧自定义接口和实际原 native 输入用例。没有在此声明已通过，未重跑已有 D/E/H03 绿。未知外部闭包本来显式持有的 World、任意强制类型／反射篡改或导入内部可信登记器不在此公共参数隔离承诺内。
