from pathlib import Path
import re,json,hashlib,subprocess,difflib
ROOT=Path('/home/hby/dev/AI-Werewolf-Arena'); OUT=Path('/tmp/awa-role-contribution-query-boundary-draft'); C=OUT/'candidates'
sha=lambda b:hashlib.sha256(b).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
before={}; edits=[]; candidates={}; shared=[]
def load(path):
 if path in candidates:return candidates[path]
 q=ROOT/path
 raw=q.read_bytes() if q.exists() else None
 git=subprocess.run(['git','cat-file','blob',f'{base}:{path}'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 mode=subprocess.run(['git','ls-tree',base,'--',path],cwd=ROOT,stdout=subprocess.PIPE,text=True).stdout
 before[path]={'path':path,'currentText':raw.decode() if raw is not None else None,'currentSHA256':sha(raw) if raw is not None else None,'gitText':git.stdout.decode() if git.returncode==0 else None,'gitSHA256':sha(git.stdout) if git.returncode==0 else None,'gitModeBlob':mode.strip(),'absent':raw is None}
 candidates[path]=raw.decode() if raw is not None else ''
 return candidates[path]
def setfile(path,t):
 if path not in before:load(path)
 candidates[path]=t
 q=C/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
def rep(path,old,new,label):
 s=load(path)
 if s.count(old)!=1:raise ValueError((path,label,s.count(old),old[:100]))
 pos=s.index(old); edits.append({'path':path,'label':label,'start':pos,'before':old,'after':new})
 setfile(path,s[:pos]+new+s[pos+len(old):])
def addimport(path,line):
 s=load(path)
 # Place after existing informative file header, not before directives/license.
 m=re.search(r'(?m)^import ',s)
 if m is None:raise ValueError(path)
 edits.append({'path':path,'label':'private owned binding import','start':m.start(),'before':'','after':line+'\n'})
 setfile(path,s[:m.start()]+line+'\n'+s[m.start():])

# Public callbacks receive scalar queries. Initialization alone keeps its explicitly owned writable slots.
p='backend/src/rulesets/roles/contracts.ts';s=load(p)
s=s.replace('import type { CampComponent, CurrentCampSource }','import type { CampComponent }').replace('import type { World } from "../../domain/world";\n','')
a=s.index('/** 初始化持有实际待安装 Camp;') if '/** 初始化持有实际待安装 Camp;' in s else s.index('/** 初始化持有实际待安装 Camp；')
b=s.index('/** 仅初始化可写',a)
s=s[:a]+'''/** 公开运行查询只返回枚举、编号和脱离的 JSON 数据；不返回 World、原组件或新的许可。 */
export interface RoleQueries {
  actorRole(): Role;
  stateData(): unknown;
  currentCamp(): Camp | undefined;
  entityIds(): readonly number[];
  aliveIds(): readonly number[];
  roleValue(id: number): Role | undefined;
  campValue(id: number): Camp | undefined;
  isAlive(id: number): boolean;
}
/** 归属声明只有值输入；它不能通过初始化上下文取得可写 Camp 或任意 World。 */
export interface RoleValueContext {
  readonly currentCamp: () => Camp | undefined;
  readonly locale?: Locale;
  readonly boardConfig?: ReadonlyBoardConfig;
}
/** 初始化可写同一 ownRole 和待安装 Camp；查询当前值不回退该 draft，也不授运行许可。 */
export interface RoleInitContext extends RoleValueContext {
  readonly initialCamp: CampComponent;
  readonly queries: RoleQueries;
}

'''+s[b:]
s=s.replace('detectableByBear?: (world: World, role: RoleComponent) => boolean;','detectableByBear?: (queries: RoleQueries) => boolean;')
s=s.replace('((role: RoleComponent, ctx: RoleInitContext) => readonly VictoryAffiliation[])','((queries: RoleQueries, ctx: RoleValueContext) => readonly VictoryAffiliation[])')
s=s.replace('((role: RoleComponent) => { canVote: boolean; canBeExiled: boolean; canBeSheriff: boolean })','((queries: RoleQueries) => { canVote: boolean; canBeExiled: boolean; canBeSheriff: boolean })')
s=s.replace('''((
        role: RoleComponent,
        world: World | undefined,
        currentCamp: CurrentCampSource,
      ) => WolfTeamPermissions)''','((queries: RoleQueries) => WolfTeamPermissions)')
s=s.replace('knownTeammates?: (role: RoleComponent, world: World) => readonly number[];','knownTeammates?: (queries: RoleQueries) => readonly number[];')
s=s.replace('boolean | ((role: RoleComponent, currentCamp: CurrentCampSource) => boolean)','boolean | ((queries: RoleQueries) => boolean)')
s=s.replace('((role: RoleComponent) => { camp?: InspectionCamp; role?: RoleId })','((queries: RoleQueries) => { camp?: InspectionCamp; role?: RoleId })')
s=s.replace('''    roleComp: RoleComponent,
    request: ActionRequest,''','''    queries: RoleQueries,
    request: ActionRequest,''')
s=s.replace('''    locale: Locale | undefined,
    world: World | undefined,
    currentCamp: CurrentCampSource,
  ) => ToolCall | null;''','''    locale: Locale | undefined,
  ) => ToolCall | null;''')
s=s.replace('''    roleComp: RoleComponent,
    locale: Locale | undefined,
    world: World | undefined,
    currentCamp: CurrentCampSource,
  ) => string;''','''    queries: RoleQueries,
    locale: Locale | undefined,
  ) => string;''')
s=s.replace('getter、receiver 与读取时点，不在接入时摊平或调用展示。init 可写原容器及实际初始 Camp，当前 source 不授许可。','getter、receiver 与读取时点，不在接入时摊平或调用展示。未知扩展只得值查询；init 仅可写原容器及实际初始 Camp。')
setfile(p,s)

# Actual dispatch sites retain original late receiver lookup and legacy argument order privately.
p='backend/src/rulesets/roles/catalog.ts'
rep(p,'import type { World } from "../../domain/world";\n','', 'public catalog renderer no World type')
rep(p,'import type { CurrentCampSource } from "../../domain/components/camp";\n','', 'public renderer no Camp component source')
rep(p,'  RoleInitContext,','  RoleQueries,','public renderer queries import')
addimport(p,'import { roleMethod, type OwnedRoleInitContext } from "./owned-bindings";')
rep(p,'''  role: RoleComponent,
  locale: Locale,
  world: World | undefined,
  currentCamp: CurrentCampSource,
) => string;''','''  queries: RoleQueries,
  locale: Locale,
) => string;''','public injected renderer scalar queries')
rep(p,'? { ...runtime.participation(role) }','? { ...roleMethod(runtime, "participation")!(role) }','late method receiver participation')
rep(p,'applyRuntime(roleComp: RoleComponent, ctx: RoleInitContext): void','applyRuntime(roleComp: RoleComponent, ctx: OwnedRoleInitContext): void','trusted init host API')
rep(p,'runtime.init?.(roleComp as RoleInitializationComponent, ctx);','roleMethod(runtime, "init")?.(roleComp as RoleInitializationComponent, ctx);','init same receiver private/public route')
rep(p,'active.profile.renderPrompt(roleComp, locale, ctx.world, () => ctx.currentCamp())','roleMethod(active.profile, "renderPrompt")!(roleComp, locale, ctx.world, () => ctx.currentCamp())','custom renderer actual second late getter')
rep(p,'active.renderNative(presentation.id, roleComp, locale, ctx.world, () =>','roleMethod(active, "renderNative")!(presentation.id, roleComp, locale, ctx.world, () =>','injected renderer private/public route')
rep(p,'presentation.renderPrompt(roleComp, locale, ctx.world, () => ctx.currentCamp())','roleMethod(presentation, "renderPrompt")!(roleComp, locale, ctx.world, () => ctx.currentCamp())','custom contribution renderer receiver')
p='backend/src/rulesets/roles/role-catalog-assembly.ts'
addimport(p,'import { ownRoleCallback } from "./owned-bindings";')
rep(p,'renderNative: captureNativeRolePresentation,','renderNative: ownRoleCallback("renderNative", captureNativeRolePresentation),','actual native capture static identity')
p='backend/src/features/wolf-team/permissions.ts';addimport(p,'import { invokeRoleCallback } from "../../rulesets/roles/owned-bindings";')
rep(p,'? permissions(role, world, currentCamp)','? invokeRoleCallback("wolfTeam", permissions, undefined, role, world, currentCamp)','bare original permission callback route')
rep(p,'new Set(snapshot(role!, world))','new Set(invokeRoleCallback("knownTeammates", snapshot, undefined, role!, world))','bare known teammates callback route')
p='backend/src/features/self-destruct/capability.ts';addimport(p,'import { invokeRoleCallback } from "../../rulesets/roles/owned-bindings";')
rep(p,'typeof capability === "function" ? capability(role, currentCamp) : capability === true','typeof capability === "function" ? invokeRoleCallback("canSelfDestruct", capability, undefined, role, currentCamp) : capability === true','original bare self-destruct callback before retirement')
p='backend/src/features/bear/night-frame.ts';addimport(p,'import { roleMethod } from "../../rulesets/roles/owned-bindings";')
rep(p,'catalog.runtime(target.role)?.detectableByBear?.(world, target)','roleMethod(catalog.runtime(target.role), "detectableByBear")?.(world, target)','bear original optional method receiver')
p='backend/src/engine/inspection.ts';addimport(p,'import { invokeRoleCallback } from "../rulesets/roles/owned-bindings";')
rep(p,'typeof definition === "function" ? definition(target) : definition','typeof definition === "function" ? invokeRoleCallback("inspectionLabels", definition, undefined, target) : definition','original bare label callback')
p='backend/src/agents/baseline/privileged.ts';addimport(p,'import { roleMethod } from "../../rulesets/roles/owned-bindings";')
rep(p,'// 角色基线钩子可使用真实 World。这是显式特权驱动，不能复用为玩家受限观察回退。','// 完整内建基线私用原 World；未知贡献只得值查询和原 picker，选择不授予狼聊／刀权。','baseline authority boundary')
rep(p,'const action = roleProfile.baselineAction(','const action = roleMethod(roleProfile, "baselineAction")!(','baseline second method read receiver same args')
p='backend/src/app/bootstrap.ts';addimport(p,'import { invokeRoleCallback } from "../rulesets/roles/owned-bindings";')
rep(p,'? membership(roleComp, {','? invokeRoleCallback("initialVictoryAffiliations", membership, undefined, roleComp, {','membership bare callback private/value route')
shared.append(p)

# Comment/string aware authoring scanner locates complete field expressions; no project parser/compiler is executed.
def expression_end(text,start):
 stack=[];i=start;quote=None
 while i<len(text):
  c=text[i];n=text[i:i+2]
  if quote:
   if c=='\\':i+=2;continue
   if c==quote:quote=None
   i+=1;continue
  if n=='//':
   z=text.find('\n',i);i=len(text) if z<0 else z+1;continue
  if n=='/*':
   z=text.find('*/',i+2);i=z+2;continue
  if c in '\'"`':quote=c;i+=1;continue
  if c in '({[':stack.append(c)
  elif c in ')}]':
   if not stack:return i
   stack.pop()
  elif c==',' and not stack:return i
  i+=1
 return i
fields=['init','initialVictoryAffiliations','participation','wolfTeam','knownTeammates','detectableByBear','canSelfDestruct','inspectionLabels','baselineAction','renderPrompt']
profiles=sorted((ROOT/'backend/src/features').glob('*/profile.ts'))+[ROOT/'backend/src/features/wolf/ability-assembly.ts']
for file in profiles:
 path=str(file.relative_to(ROOT));s=load(path);changes=[]
 for m in re.finditer(r'(?m)^\s*('+ '|'.join(fields) +r'):\s*',s):
  kind=m.group(1);st=m.end();end=expression_end(s,st);expr=s[st:end]
  if kind not in ('init','baselineAction','knownTeammates','detectableByBear','renderPrompt') and '=>' not in expr:continue
  if kind=='init' and expr.strip()=='undefined':continue
  changes.append((st,end,kind,expr))
 if not changes:
  candidates.pop(path,None);before.pop(path,None);continue
 for st,en,kind,expr in reversed(changes):
  new=f'ownRoleCallback("{kind}", {expr})';edits.append({'path':path,'label':'complete original '+kind+' program static identity','start':st,'before':expr,'after':new});s=s[:st]+new+s[en:]
 setfile(path,s)
 # Full original nested wolf programs still late-read the writable table, but unknown replacement gets values.
 s=load(path);s2=re.sub(r'ORDINARY_WOLF_CONTRIBUTIONS\.runtime\.baselineAction', 'roleMethod(ORDINARY_WOLF_CONTRIBUTIONS.runtime, "baselineAction")',s)
 s2=s2.replace('base?.runtime.baselineAction?.(', 'roleMethod(base?.runtime, "baselineAction")?.(')
 if s2!=s:
  setfile(path,s2);needs_method=True
 else:needs_method=False
 line='import { ownRoleCallback'+(', roleMethod' if needs_method else '')+' } from "../../rulesets/roles/owned-bindings";'
 addimport(path,line)
 if path=='backend/src/features/pure-white/profile.ts':
  rep(path,'const inspectionBaseline: NonNullable<RoleRuntimeContribution["baselineAction"]>', 'const inspectionBaseline: import("../../rulesets/roles/owned-bindings").OwnedRoleCallbacks["baselineAction"]','original private full baseline contextual type')

# Emit compact preparation inputs. Current bytes and actual fixed Git are distinct and both kept.
(OUT/'before.json').write_text(json.dumps({'baseCommit':base,'captureKind':'actual complete current source plus actual Git before; current WIP may differ','files':before},ensure_ascii=False,indent=2)+'\n')
(OUT/'edits-authoring.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
(OUT/'working-index.json').write_text(json.dumps({'baseCommit':base,'paths':list(candidates),'sharedExactOnly':shared,'notReady':True},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'baseCommit':base,'candidateCount':len(candidates),'profileCount':sum(p.endswith('/profile.ts') for p in candidates),'status':'working TMP, not source-ready'}))
