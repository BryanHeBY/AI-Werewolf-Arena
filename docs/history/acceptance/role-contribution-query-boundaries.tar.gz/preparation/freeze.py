from pathlib import Path
import json,hashlib,subprocess,difflib
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-role-contribution-query-boundary-draft');C=O/'candidates';b=json.loads((O/'before.json').read_text());idx=json.loads((O/'working-index.json').read_text());base=b['baseCommit'];h=lambda bb:hashlib.sha256(bb).hexdigest()
new=['backend/src/rulesets/roles/owned-bindings.ts','backend/tests/unit/rulesets/narrow-role-contribution-boundaries.test.ts']
for p in new:
 g=subprocess.run(['git','cat-file','blob',f'{base}:{p}'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert g.returncode!=0,p
 assert not (R/p).exists(),p
 b['files'][p]={'path':p,'currentText':None,'currentSHA256':None,'gitText':None,'gitSHA256':None,'gitModeBlob':'','absent':True}
 if p not in idx['paths']:idx['paths'].append(p)
# Remove now-unused local contextual type; full original function is still OwnedRoleCallbacks typed.
p=C/'backend/src/features/pure-white/profile.ts';p.write_text(p.read_text().replace('  RoleRuntimeContribution,\n',''))
p=C/'backend/tests/unit/domain/role-private-container.test.ts';p.write_text(p.read_text().replace('RoleProfile, RoleQueries }','RoleProfile }'))
source=[];changes=[];shared=[];patch=[]
for p in idx['paths']:
 old=b['files'][p]['currentText'];after=(C/p).read_text();beforeText=old or ''
 assert old is None or old!=after,p
 steps=[]
 for op,a,z,x,y in difflib.SequenceMatcher(a=beforeText,b=after,autojunk=False).get_opcodes():
  if op!='equal':steps.append({'start':a,'end':z,'before':beforeText[a:z],'after':after[x:y],'contextBefore':beforeText[max(0,a-96):a],'contextAfter':beforeText[z:z+96]})
 # Only authoring-data identity, not AST/proof execution.
 replay=beforeText
 for step in reversed(steps):replay=replay[:step['start']]+step['after']+replay[step['end']:]
 assert replay==after,p
 exactOnly=p.endswith('/profile.ts') or p=='backend/src/app/bootstrap.ts'
 item={'path':p,'beforeSHA256':h(beforeText.encode()) if old is not None else None,'sha256':h(after.encode()),'bytes':len(after.encode()),'mode':'100644','change':'added' if old is None else 'modified','candidate':str(C/p),'apply':'exact local nonvalidation/nondeath deltas only; no whole-file overwrite' if exactOnly else 'whole candidate only if current beforeSHA/absence matches'}
 source.append(item);record={'path':p,'beforeSHA256':item['beforeSHA256'],'afterSHA256':item['sha256'],'offsetUnit':'Unicode code points, all positions refer to original before','edits':steps,'wholeFileApplyProhibited':exactOnly}
 changes.append(record)
 if exactOnly:shared.append(record)
 patch.extend(difflib.unified_diff(beforeText.splitlines(True),after.splitlines(True),fromfile=p,tofile=p))
controls=[]
for p in ['backend/src/domain/world.ts','backend/src/domain/components/role.ts','backend/src/domain/components/camp.ts','backend/src/agents/observation/native-role-presentation-capture.ts']:
 bb=(R/p).read_bytes();g=subprocess.check_output(['git','cat-file','blob',f'{base}:{p}'],cwd=R);m=subprocess.check_output(['git','ls-tree',base,'--',p],cwd=R,text=True).strip();assert bb==g,p
 controls.append({'path':p,'sha256':h(bb),'bytes':len(bb),'gitModeBlob':m,'text':bb.decode(),'sameActualFixedGit':True})
(O/'before.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n');(O/'source-edits.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n');(O/'shared-exact-deltas.json').write_text(json.dumps(shared,ensure_ascii=False,indent=2)+'\n');(O/'controls.json').write_text(json.dumps({'baseCommit':base,'controls':controls},ensure_ascii=False,indent=2)+'\n');(O/'candidate.patch').write_text(''.join(patch))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
ready={'status':'TMP source-ready; no project checks executed','baseCommit':base,'headAtFreeze':head,'beforeKind':'complete actual fixed Git + complete actual current bytes at initial preparation; H03 WIP explicitly preserved','source':source,'sourceCount':len(source),'productionCount':sum(p['path'].startswith('backend/src/') for p in source),'testCount':sum(p['path'].startswith('backend/tests/') for p in source),'newPaths':new,'deleted':[],'sharedExactOnly':len(shared),'checksExecuted':[],'repoWrites':False}
(O/'source-ready.json').write_text(json.dumps(ready,ensure_ascii=False,indent=2)+'\n')
oldTests=[p['path'] for p in source if p['path'].startswith('backend/tests/') and p['change']=='modified']
checks={'executed':False,'cwd':str(R),'mandatory':{'newRiskUnit':['bun','--no-env-file','test','--preload','./backend/tests/setup.ts',new[1]],'types':['bun','--no-env-file','run','backend/node_modules/typescript/bin/tsc','--project','backend/tsconfig.tests.json','--noEmit']},'affectedExistingApiTests':oldTests,'executionBoundary':'Root chooses exact changed old callbacks/direct-owner assertions; no model/fullgame/fullgate/unchanged-green reruns by author','headRoots':[p['path'] for p in source],'proofBoundary':'This packet contains exact full byte before/after/deltas. No AST/emit/type/test proof has been run. New explicit custom API is not claimed whole-JS equivalent.'}
(O/'prepared-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
art=[]
for name in ['before.json','source-edits.json','shared-exact-deltas.json','controls.json','candidate.patch','source-ready.json','prepared-checks.json','README.md','prepare.py','adapt-tests.py','finish-working.py','freeze.py','prepare-first-authoring.py.txt','prepare-first-authoring-error.txt','owned-bindings-initial-unpublished.ts.txt','named-declarations.py','named-declaration-precision.json']:
 bb=(O/name).read_bytes();art.append({'path':name,'sha256':h(bb),'bytes':len(bb)})
packet={'status':'prepared source-ready; Root application/checks required','sourceCount':len(source),'productionCount':ready['productionCount'],'testCount':ready['testCount'],'newSourceCount':2,'sourceReadySHA256':h((O/'source-ready.json').read_bytes()),'baseCommit':base,'headAtFreeze':head,'sharedMerge':'44 profiles + bootstrap exact nonvalidation/nondeath fragments; WolfKing chooser successor must survive','apiRetirements':['Unknown role callbacks no World/Role/Camp component except explicit init ownRole + initialCamp.','Custom init context identity/world and component-returning currentCamp retired; currentCamp enum only.','Custom initialVictory context no initialCamp or original role.','Unknown renderer/baseline callback full World/source tails retired; actual query values/detached private data only.'],'newRiskDeclarations':2,'artifacts':art,'checksExecuted':[],'repoWrites':False,'limits':['No product/parser/compiler/test/check/formatter executed.','Byte replay used only to author exact patch; not a program equivalence proof.','Does not sandbox unknown closures already owning World, arbitrary invalid object graphs, internal privileged-module imports or JS monkeypatches.','Native complete programs and metadata/state authority not moved into generic role-id branches.']}
(O/'HANDOFF.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'sourceReadySHA256':packet['sourceReadySHA256'],'HANDOFF':h((O/'HANDOFF.json').read_bytes()),'sources':len(source),'prod':ready['productionCount'],'tests':ready['testCount'],'sharedExact':len(shared)},ensure_ascii=False))
