# RoleQ 深状态查询后继

前态是 Root 已格式化／实际首执行的两个完整文件，与 unit/types/interactions 三份原 sourceSHA256 精确一致，不重放早期未格式化 candidate。原 d50e/3af08 prepared、Pres 首批准以及 Root 所有首红和原绿保留。作者没有运行产品、parser、类型、测试或 formatter，也未写仓库。

首实现误用事件事实复制器默认容器深度三：真实原生能力包含 privateState→abilities→metadata→state→history，多层合法状态触发 event_fact_not_data。Root 首 unit 的四红和 interaction 七红确认此路径；此前作者静态发现不冒单独执行红。

只改实际 stateData 查询：调用时经原 domain snapshotPlainData（深度十六、数组上限65536，拒绝 Proxy／访问器／循环／非惰性数据），再 structuredClone 已确认的数据快照以获得普通可写脱离副本。原体及查询对象不冻结；复制错误原样向实际调用方传播，不在进入 callback 前预读或回退空数据。structuredClone／反射和有限接受集合是这个新 API 的明确观察面，不是任意外部图的安全沙箱。原 native 完整程序仍私用同一 Role/World，不经复制器；记录／当前 Camp／Victory 规则不变。

其余仅类型：roleMethod 使用参数/返回值映射的显式泛型调用签名，移除 TypeScript 不接受的 indexed-function 强交叉断言；不扩大 public query 或 any。newunit 的 ownRole 比较泛型、extension 读取断言、locale 字面返回注解均擦除，不改原两声明的运行读取、字面预期或流程。第三声明经真实 Catalog 安装 Seer，再由真实 resolveInspection 调未知 callback 取完整深树，修改副本的历史／uses 而原库存仍空／零，检查组件原引用和非冻结。

建议 Root 仅复先前同根失败及该新声明，并对这两个变化根和其 Root-owned 第77测试适配统一 types；受影响 stateData 既有浅副本断言可按具体风险核，不复无关绿。所有真正执行与命令由 Root 决定和记收据。
