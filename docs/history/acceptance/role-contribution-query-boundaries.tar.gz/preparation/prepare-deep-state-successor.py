from pathlib import Path
import json,hashlib,subprocess,difflib,shutil
R=Path('/home/hby/dev/AI-Werewolf-Arena');OLD=Path('/tmp/awa-role-contribution-query-boundary-draft');O=OLD/'successor-deep-state';C=O/'candidates';O.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest();base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();paths=['backend/src/rulesets/roles/owned-bindings.ts','backend/tests/unit/rulesets/narrow-role-contribution-boundaries.test.ts'];before={};sources=[];changes=[];patch=[]
for p in paths:
 bb=(R/p).read_bytes();g=subprocess.run(['git','cat-file','blob',f'{base}:{p}'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);m=subprocess.check_output(['git','ls-tree',base,'--',p],cwd=R,text=True).strip();before[p]={'text':bb.decode(),'sha256':h(bb),'bytes':len(bb),'gitModeBlob':m,'gitText':g.stdout.decode() if g.returncode==0 else None,'gitAbsent':g.returncode!=0}
 s=bb.decode()
 if p==paths[0]:
  assert s.count('  copyEventData,\n')==1;s=s.replace('  copyEventData,\n','')
  a='import { COMPONENT } from "../../domain/components/names";';assert s.count(a)==1;s=s.replace(a,'import { snapshotPlainData } from "../../domain/plain-data";\n'+a)
  a='/** 每次调用的闭包只给具体值；stateData 明确脱离复制，非 JSON 私态在调用这个新查询时按 copyEventData 原规则失败。 */'
  z='''/** 每次调用的闭包只给具体值。私态按原深数据工具在调用时复制，容纳实际能力元数据／状态／历史层级。
 * snapshotPlainData 拒绝 getter、Proxy、循环及深度／数组超限；其错误向调用方传播，不提前读取或回退空私态。
 * structuredClone 只消费已确认的数据快照，恢复普通可写副本；既不冻结原体，也不把能力别名／组件引用当新许可。
 */''';assert s.count(a)==1;s=s.replace(a,z)
  a='stateData: () => copyEventData(role.privateState),';z='stateData: () => structuredClone(snapshotPlainData(role.privateState, new Set(), 0, 65536)),';assert s.count(a)==1;s=s.replace(a,z)
  a='/** 保原对象的晚字段读取；只有原 owner optional-chain 才跳过空 owner，非函数值不在准备时提前抛错。 */'
  z='''/** 显式泛型调用签名表达同一种类的参数／返回值；不把所有种类的函数强交叉断言为单一成员。 */
type OwnedRoleMethod<K extends Kind> = (...args: Parameters<OwnedRoleCallbacks[K]>) => ReturnType<OwnedRoleCallbacks[K]>;

'''+a;assert s.count(a)==1;s=s.replace(a,z)
  s=s.replace('): OwnedRoleCallbacks[K] | undefined {', '): OwnedRoleMethod<K> | undefined {')
  s=s.replace('return callback as OwnedRoleCallbacks[K] | undefined;', 'return callback as OwnedRoleMethod<K> | undefined;')
  a='''  return ((...args: Parameters<OwnedRoleCallbacks[K]>) =>
    invokeRoleCallback(kind, callback, owner, ...args)) as OwnedRoleCallbacks[K];'''
  z='''  return (...args: Parameters<OwnedRoleCallbacks[K]>) =>
    invokeRoleCallback(kind, callback, owner, ...args);''';assert s.count(a)==1;s=s.replace(a,z)
 else:
  a='expect(ownRole).toBe(f.role);';assert s.count(a)==1;s=s.replace(a,'expect<unknown>(ownRole).toBe(f.role);')
  a='expect(f.role.privateState.extension).toBe("custom owned init");';assert s.count(a)==1;s=s.replace(a,'expect((f.role.privateState as { readonly extension?: unknown }).extension).toBe("custom owned init");')
  a='''    get locale() {
      trace.push("locale");''';assert s.count(a)==1;s=s.replace(a,'''    get locale(): "en" {
      trace.push("locale");''')
  a='import { createRoleCatalog } from "../../../src/rulesets/roles/role-catalog-assembly";';assert s.count(a)==1;s=s.replace(a,'import { createRoleCatalog, getDefaultRoleCatalog } from "../../../src/rulesets/roles/role-catalog-assembly";\nimport { activeNightAbility } from "../../../src/features/night-abilities/inventory-ports";')
  s+='''

// 真正原生安装含 abilities→metadata→state→history 深树；不以平面 marker 代替合法机制数据。
test("custom role state query copies an actual installed Seer ability tree without returning stock references", () => {
  const world = new World("en"), id = world.createEntity(), role = createRoleComponent(Role.Seer), initialCamp = { camp: Camp.Good };
  world.addComponent(id, COMPONENT.Role, role);
  world.addComponent(id, COMPONENT.Camp, initialCamp);
  world.addComponent(id, COMPONENT.Alive, createAliveComponent());
  getDefaultRoleCatalog().applyRuntime(role, { world, initialCamp, currentCamp: () => world.getComponent(id, COMPONENT.Camp), locale: "en" });
  const native = activeNightAbility(role, "seer_check", 1)!;
  expect(native.id).toBe("native:seer_check");
  expect(native.state.history).toEqual([]);
  let captured: unknown;
  const custom = createRoleCatalog([{ role: Role.Seer, label: "raw seer", skillBrief: "raw rules", inspectionLabels(queries) {
    captured = queries.stateData();
    return { camp: Camp.Good, role: Role.Seer };
  } }]);
  expect(resolveInspection(world, id, "combined", custom)).toEqual({ kind: "combined", camp: Camp.Good, role: Role.Seer });
  const copied = captured as { abilities: Record<string, { uses: number; state: { history: unknown[] } }> }, ability = copied.abilities["native:seer_check"]!;
  expect(ability).not.toBe(native);
  expect<unknown>(ability.state).not.toBe(native.state);
  expect(ability.state.history).toEqual([]);
  ability.state.history.push({ day: 1, targetId: 2, isWerewolf: false });
  ability.uses = 99;
  expect(native.state.history).toEqual([]);
  expect(native.uses).toBe(0);
  expect(Object.isFrozen(role.privateState)).toBe(false);
  expect(world.getComponent(id, COMPONENT.Role)).toBe(role);
  expect(world.getComponent(id, COMPONENT.Camp)).toBe(initialCamp);
});
'''
 q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s);aa=q.read_bytes();sources.append({'path':p,'beforeSHA256':h(bb),'sha256':h(aa),'bytes':len(aa),'mode':'100644','candidate':str(q),'apply':'whole file only after actual Root formatted first-executed beforeSHA match'})
 es=[]
 for op,a,z,x,y in difflib.SequenceMatcher(a=bb.decode(),b=s,autojunk=False).get_opcodes():
  if op!='equal':es.append({'start':a,'end':z,'before':bb.decode()[a:z],'after':s[x:y]})
 changes.append({'path':p,'offsetUnit':'Unicode code points; original before positions','edits':es});patch.extend(difflib.unified_diff(bb.decode().splitlines(True),s.splitlines(True),fromfile=p,tofile=p))
(O/'before.json').write_text(json.dumps({'baseAtCapture':base,'kind':'actual Root formatted first-executed current, not original unformatted prepared candidate','source':before},ensure_ascii=False,indent=2)+'\n')
(O/'edits.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n');(O/'candidate.patch').write_text(''.join(patch))
receipts=[]
for group in ['unit','types','interactions']:
 root=Path('/tmp/awa-role-query-ports-execution')/group
 for name in ['receipt.json','stdout.raw','stderr.raw']:
  p=root/name
  if p.exists():
   target=O/'first-executed'/group/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);bb=target.read_bytes();receipts.append({'path':str(target.relative_to(O)),'origin':str(p),'sha256':h(bb),'bytes':len(bb)})
 if (root/'receipt.json').exists():
  x=json.loads((root/'receipt.json').read_text())
  for p,v in before.items():assert x['sourceSHA256'][p]==v['sha256'],(group,p)
(O/'first-receipts.json').write_text(json.dumps({'kind':'Root actual first execution files copied byte for byte, author did not execute','files':receipts,'reportedUnit':'138 pass / 4 fail / 2028 expect / 18 files; count includes failure expectations, not all successful','reportedInteractions':'26 pass / 7 fail / 285 expect / 3 files; same depth failure','reportedTypes':'exit2 / five diagnostics: four in these two files, one Root-owned wolf-tool-admission fixture','sourceBeforeMatchesAll3ReceiptFences':True},ensure_ascii=False,indent=2)+'\n')
ready={'status':'prepared successor; Root failed/affected-only execution pending','baseAtCapture':base,'source':sources,'sourceCount':2,'newSourceCount':0,'deleted':[],'firstPrepared':{'path':str(OLD/'HANDOFF.json'),'sha256':h((OLD/'HANDOFF.json').read_bytes())},'firstPreparedUnchanged':'d50e7bd2989ab7877dba0de14b4fb8a75c89b5fb86078c618a647e3246bf9830','changes':['Actual state query depth/readonly-data copy fixed via existing complete snapshot owner then structuredClone; no native owner algorithm change.','Internal generic roleMethod call signature and three unit erasure annotations; no public interface widening/any.','Third independent declaration uses actual installed Seer ability depth tree; original two declarations retain literal oracles and runtime instructions except three erased type annotations.'],'checksExecuted':[],'repoWrites':False}
(O/'source-ready.json').write_text(json.dumps(ready,ensure_ascii=False,indent=2)+'\n')
(O/'README.md').write_text('''# RoleQ 深状态查询后继

前态是 Root 已格式化／实际首执行的两个完整文件，与 unit/types/interactions 三份原 sourceSHA256 精确一致，不重放早期未格式化 candidate。原 d50e/3af08 prepared、Pres 首批准以及 Root 所有首红和原绿保留。作者没有运行产品、parser、类型、测试或 formatter，也未写仓库。

首实现误用事件事实复制器默认容器深度三：真实原生能力包含 privateState→abilities→metadata→state→history，多层合法状态触发 event_fact_not_data。Root 首 unit 的四红和 interaction 七红确认此路径；此前作者静态发现不冒单独执行红。

只改实际 stateData 查询：调用时经原 domain snapshotPlainData（深度十六、数组上限65536，拒绝 Proxy／访问器／循环／非惰性数据），再 structuredClone 已确认的数据快照以获得普通可写脱离副本。原体及查询对象不冻结；复制错误原样向实际调用方传播，不在进入 callback 前预读或回退空数据。structuredClone／反射和有限接受集合是这个新 API 的明确观察面，不是任意外部图的安全沙箱。原 native 完整程序仍私用同一 Role/World，不经复制器；记录／当前 Camp／Victory 规则不变。

其余仅类型：roleMethod 使用参数/返回值映射的显式泛型调用签名，移除 TypeScript 不接受的 indexed-function 强交叉断言；不扩大 public query 或 any。newunit 的 ownRole 比较泛型、extension 读取断言、locale 字面返回注解均擦除，不改原两声明的运行读取、字面预期或流程。第三声明经真实 Catalog 安装 Seer，再由真实 resolveInspection 调未知 callback 取完整深树，修改副本的历史／uses 而原库存仍空／零，检查组件原引用和非冻结。

建议 Root 仅复先前同根失败及该新声明，并对这两个变化根和其 Root-owned 第77测试适配统一 types；受影响 stateData 既有浅副本断言可按具体风险核，不复无关绿。所有真正执行与命令由 Root 决定和记收据。
''')
arts=[]
for name in ['before.json','edits.json','candidate.patch','first-receipts.json','source-ready.json','README.md']:
 bb=(O/name).read_bytes();arts.append({'path':name,'sha256':h(bb),'bytes':len(bb)})
hand={'status':'TMP source-ready successor, no author project execution','source':sources,'sourceReadySHA256':h((O/'source-ready.json').read_bytes()),'sourceCount':2,'artifacts':arts,'firstActualReceipts':receipts,'firstPreparedSHA256':ready['firstPreparedUnchanged'],'rootOwnedExcluded':'backend/tests/unit/rulesets/wolf-tool-admission.test.ts (Root alone handles custom query API fixture)','checksExecuted':[],'repoWrites':False}
(O/'HANDOFF.json').write_text(json.dumps(hand,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'HANDOFF':h((O/'HANDOFF.json').read_bytes()),'ready':hand['sourceReadySHA256'],'sources':2}))
