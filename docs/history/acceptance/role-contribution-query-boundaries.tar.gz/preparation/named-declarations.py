from pathlib import Path
import shutil,re,json,hashlib
O=Path('/tmp/awa-role-contribution-query-boundary-draft');snap=O/'first-702927-before-named-declarations';snap.mkdir(exist_ok=True)
for name in ['HANDOFF.json','source-ready.json','source-edits.json','shared-exact-deltas.json','candidate.patch','README.md','before.json','controls.json','prepared-checks.json']:
 shutil.copy2(O/name,snap/name)
shutil.copytree(O/'candidates',snap/'candidates',dirs_exist_ok=True)
# Authoring delimiter scan only; no TypeScript/project parser is executed.
def end(text,start):
 stack=[];q=None;i=start
 while i<len(text):
  c=text[i];n=text[i:i+2]
  if q:
   if c=='\\':i+=2;continue
   if c==q:q=None
   i+=1;continue
  if n=='//':i=text.find('\n',i)+1;continue
  if n=='/*':i=text.find('*/',i+2)+2;continue
  if c in '\'"`':q=c;i+=1;continue
  if c in '([{':stack.append(c)
  elif c in ')]}':
   if not stack:return i
   stack.pop()
  i+=1
 raise ValueError('unclosed authoring text')
changes=[]
for p in (O/'candidates').rglob('*.ts'):
 if p.name=='owned-bindings.ts':continue
 s=p.read_text();todo=[]
 for m in re.finditer(r'ownRoleCallback\("([A-Za-z]+)",\s*',s):
  z=end(s,m.end());assert s[z]==')';todo.append((m.end(),z,m.group(1),s[m.end():z]))
 if not todo:continue
 for a,z,k,e in reversed(todo):s=s[:a]+'{ '+k+': '+e+' }'+s[z:]
 changes.append({'path':str(p.relative_to(O/'candidates')),'completePrograms':len(todo)})
 p.write_text(s)
p=O/'candidates/backend/src/rulesets/roles/owned-bindings.ts';s=p.read_text()
a=s.index('/** 只登记原函数身份;') if '/** 只登记原函数身份;' in s else s.index('/** 只登记原函数身份；')
z=s.index('\n/** 每次调用',a)
s=s[:a]+'''/** 具名冷声明保原属性推断 name／length 和同一完整函数；只登记函数＋种类，不保声明对象。 */
export function ownRoleCallback<K extends Kind>(kind: K, program: Pick<OwnedRoleCallbacks, K>): NonNullable<PublicCallbacks[K]>;
export function ownRoleCallback<K extends Kind>(kind: K, program: { [P in K]: OwnedRoleCallbacks[P] | Exclude<PublicCallbacks[P], Function> }): PublicCallbacks[K];
export function ownRoleCallback(kind: Kind, program: Partial<Record<Kind, unknown>>): unknown {
  const value = program[kind];
  if (typeof value === "function") {
    const kinds = definitions.get(value) ?? new Set<Kind>();
    kinds.add(kind); definitions.set(value, kinds);
  }
  return value;
}
'''+s[z:]
p.write_text(s)
p=O/'README.md';s=p.read_text().replace('每个原完整 callback 在原属性创建点登记且返回同一函数；函数体、默认参数、闭包和数据贡献保原样。','每个原完整 callback 在原属性创建点以具名冷声明登记且返回同一函数；声明对象不被保存，属性推断的函数 name／length、函数体、默认参数、闭包和数据贡献保原样。')
s+='\n初冻结 702927/a016 在首次检查前静态发现匿名箭头作为函数参数会失去原属性推断 name，完整首样保 first-702927-before-named-declarations。末稿仅用具名冷声明恢复该函数属性，不是产品执行红；作者仍 0 项目工具执行。\n';p.write_text(s)
(O/'named-declaration-precision.json').write_text(json.dumps({'kind':'pre-first-check static authoring precision; no runtime failure claimed','beforeHandoffSHA256':'7029274cde845b8b504ae39ce0048c0ae7fe1baf622e163cd924538391cbdbd1','changed':changes,'statement':'All complete programs retained. Named declaration preserves property inferred function name before static registration; object is not stored; no World captured in static table.','checksExecuted':[]},ensure_ascii=False,indent=2)+'\n')
print('named declaration programs',sum(i['completePrograms'] for i in changes),'files',len(changes))
