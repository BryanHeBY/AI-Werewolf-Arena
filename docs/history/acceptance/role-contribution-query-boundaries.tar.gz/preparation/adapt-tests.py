from pathlib import Path
import json,re,subprocess,hashlib
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-role-contribution-query-boundary-draft');C=O/'candidates';idx=json.loads((O/'working-index.json').read_text());base=idx['baseCommit'];b=json.loads((O/'before.json').read_text());ed=[]
sha=lambda bb:hashlib.sha256(bb).hexdigest()
def read(p):
 q=C/p
 if q.exists() and p in b['files']:return q.read_text()
 bb=(R/p).read_bytes();g=subprocess.run(['git','cat-file','blob',f'{base}:{p}'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);m=subprocess.check_output(['git','ls-tree',base,'--',p],cwd=R,text=True)
 b['files'][p]={'path':p,'currentText':bb.decode(),'currentSHA256':sha(bb),'gitText':g.stdout.decode() if g.returncode==0 else None,'gitSHA256':sha(g.stdout) if g.returncode==0 else None,'gitModeBlob':m.strip(),'absent':False}
 if p not in idx['paths']:idx['paths'].append(p)
 return bb.decode()
def write(p,s):
 q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
def change(p,fn,label):
 old=read(p);new=fn(old)
 if new!=old:ed.append({'path':p,'label':label,'beforeSHA256':sha(old.encode()),'afterSHA256':sha(new.encode())});write(p,new)
def replace(p,a,z,label):
 def f(s):
  if s.count(a)!=1:raise ValueError((p,label,s.count(a),a[:90]))
  return s.replace(a,z)
 change(p,f,label)
def addimport(p,names):
 rel='../'*(len(Path(p).parts)-3)+'src/rulesets/roles/owned-bindings'
 # tests/unit/file depth4 => ../../../src; all tests paths base backend/tests.
 rel='../'*(len(Path(p).parts)-2)+'src/rulesets/roles/owned-bindings'
 line='import { '+names+' } from "'+rel+'";\n'
 change(p,lambda s: s[:s.index('import ')]+line+s[s.index('import '):], 'trusted dispatch import for original owner test')

# Direct trusted owner tests continue invoking the same actual program, with old full arguments privately routed.
paths=[
'backend/tests/unit/features/radiant-eclipse/state.test.ts','backend/tests/unit/features/evil-knight/state-slot.test.ts','backend/tests/unit/features/red-moon/state-slot.test.ts',
'backend/tests/unit/features/fragrant-pair-seer/pair-state-slot.test.ts','backend/tests/unit/features/seer/seer-policies.test.ts','backend/tests/unit/features/noble-secret-body/state-installation.test.ts',
'backend/tests/unit/mechanisms/night-ability-inventory-owner.test.ts','backend/tests/unit/features/wolf/ability-assembly.test.ts','backend/tests/unit/mechanisms/configured-inspection-and-death-policy-instances.test.ts']
for p in paths:
 def route(s):
  s=re.sub(r'([A-Z][A-Z_0-9]+\.runtime|item\.profile\.runtime|profile\.runtime|profile)\.(init|baselineAction)!',r'roleMethod(\1, "\2")!',s)
  s=s.replace('getDefaultRoleCatalog().requireRuntime(kind).baselineAction!', 'roleMethod(getDefaultRoleCatalog().requireRuntime(kind), "baselineAction")!')
  s=s.replace('const mock = WOLF_ROLE_PROFILE.runtime.baselineAction!;', 'const mock = roleMethod(WOLF_ROLE_PROFILE.runtime, "baselineAction")!;')
  return s
 change(p,route,'direct native test through same static trusted callback route');addimport(p,'roleMethod')
 # Host input annotation, only where direct full native initializer context is built.
 s=read(p)
 if 'RoleInitContext' in s:
  s=s.replace('  RoleInitContext,\n','').replace('RoleInitContext','OwnedRoleInitContext')
  # Removed old named type, add actual private host annotation.
  s=s.replace('import { roleMethod }','import { roleMethod, type OwnedRoleInitContext }')
  write(p,s)
p='backend/tests/unit/features/wolf-sorcerer-frame.test.ts';addimport(p,'invokeRoleCallback')
change(p,lambda s:s.replace('capability(role, f.world, () => f.world.getComponent(2, COMPONENT.Camp))','invokeRoleCallback("wolfTeam", capability, undefined, role, f.world, () => f.world.getComponent(2, COMPONENT.Camp))'),'bare original callback test through trusted dispatch')

# Custom-context and renderer tests describe the explicitly retired API, not a claim of raw identity equivalence.
for p in ['backend/tests/unit/domain/role-private-container.test.ts','backend/tests/unit/mechanisms/role-contributions.test.ts','backend/tests/unit/presentation/native-role-presentation.test.ts']:
 addimport(p,'type OwnedRoleInitContext')
 change(p,lambda s:s.replace('RoleInitContext,\n','').replace('RoleInitContext }','RoleQueries }').replace(': RoleInitContext =',': OwnedRoleInitContext ='),'host context distinguished from actual public init context')
 # Avoid accidental double Owned string from broad replacement (none expected).
 change(p,lambda s:s.replace('expect(actualContext).toBe(ctx);','expect(actualContext).not.toBe(ctx);\n      expect(Object.hasOwn(actualContext, "world")).toBe(false);\n      expect(actualContext.initialCamp).toBe(initialCamp);').replace('expect(context).toBe(ctx);','expect(context).not.toBe(ctx);\n      expect(Object.hasOwn(context, "world")).toBe(false);\n      expect(context.initialCamp).toBe(initialCamp);').replace('expect(ctx).toBe(context);','expect(ctx).not.toBe(context);\n      expect(Object.hasOwn(ctx, "world")).toBe(false);\n      expect(ctx.initialCamp).toBe(initialCamp);'),'custom init allowed slots but distinct worldless actual context')
# renderRolePrompt callbacks are replaced narrowly; all original raw strings and getter trace assertions stay.
p='backend/tests/unit/domain/role-private-container.test.ts'
replace(p,'renderPrompt(actualRole, locale, actualWorld) {','renderPrompt(queries, locale) {','worldless custom renderer signature')
replace(p,'expect(actualRole).toBe(role);','expect(queries.actorRole()).toBe(Role.Villager);','renderer scalar actor value')
replace(p,'expect(actualWorld).toBe(world);','expect(Object.hasOwn(queries, "world")).toBe(false);','no World render argument')
# Two getter-created custom renderer functions in mechanism contribution tests.
p='backend/tests/unit/mechanisms/role-contributions.test.ts'
change(p,lambda s:s.replace('  RoleProfile,\n','  RoleProfile,\n  RoleQueries,\n'),'public renderer type')
replace(p,'return function (this: RoleProfile, actual: typeof role, locale: Locale, passedWorld: World) {','return function (this: RoleProfile, queries: RoleQueries, locale: Locale) {','raw custom profile renderer new input')
replace(p,'expect(this).toBe(profile);\n        expect(actual).toBe(role);','expect(this).toBe(profile);\n        expect(queries.actorRole()).toBe(Role.Villager);','profile render actor value')
replace(p,'expect(passedWorld).toBe(world);','expect(Object.hasOwn(queries, "world")).toBe(false);','profile render no live World')
replace(p,'renderNative(id, actual, locale, world) {','renderNative(id, queries, locale) {','custom native renderer new input')
replace(p,'expect(actual).toBe(role);','expect(queries.actorRole()).toBe(Role.Guard);','injected renderer reads actual current role')
replace(p,'expect(world).toBeUndefined();','expect(Object.hasOwn(queries, "world")).toBe(false);','injected renderer no World parameter')
replace(p,'''        _role: typeof role,
        _locale: Locale,
        actualWorld: World,''','''        queries: RoleQueries,
        _locale: Locale,''','custom contribution renderer new input')
replace(p,'expect(actualWorld).toBe(world);','expect(queries.actorRole()).toBe(Role.Villager);\n        expect(Object.hasOwn(queries, "world")).toBe(false);','contribution scalar actor data')
p='backend/tests/unit/presentation/native-role-presentation.test.ts'
change(p,lambda s:s.replace('  RoleProfile,\n','  RoleProfile,\n  RoleQueries,\n'),'public renderer query annotation')
replace(p,'''        actual: RoleComponent,
        locale?: Locale,
        actualWorld?: World,''','''        queries: RoleQueries,
        locale?: Locale,''','custom renderer new signature')
replace(p,'expect(actual).toBe(role);','expect(queries.actorRole()).toBe(Role.Villager);','new actual scalar render query')
replace(p,'expect(actualWorld).toBe(world);','expect(Object.hasOwn(queries, "world")).toBe(false);','custom renderer no raw world')

p='backend/tests/unit/engine/camp-canonical-bootstrap.test.ts'
change(p,lambda s:s.replace('  RoleInitContext,','  RoleInitContext,\n  RoleValueContext,'),'membership value context annotation')
replace(p,'const beforeInstall: Array<CampComponent | undefined> = [];','const beforeInstall: Array<Camp | undefined> = [];','public currentCamp returns values')
replace(p,'expect(ctx.currentCamp()).toBe(ctx.initialCamp);','expect(ctx.currentCamp()).toBe(ctx.initialCamp.camp);','custom current value after original draft installed')
replace(p,'membershipContexts: RoleInitContext[] = [];','membershipContexts: RoleValueContext[] = [];','membership context lacks initializer write slots')
replace(p,'''        expect(Object.keys(membership)).toEqual([
          "boardConfig",
          "locale",
          "initialCamp",
          "currentCamp",
        ]);''','''        expect(Object.keys(membership)).toEqual(["currentCamp", "locale", "boardConfig"]);''','actual narrow membership shape')
replace(p,'expect(membership.world).toBeUndefined();','expect(Object.hasOwn(membership, "world")).toBe(false);','membership no world')
replace(p,'expect(membership.initialCamp).toBe(init.initialCamp);','expect(Object.hasOwn(membership, "initialCamp")).toBe(false);','membership has no mutable Camp write port')
replace(p,'expect(membership.currentCamp).toBe(init.currentCamp);','expect(typeof membership.currentCamp).toBe("function");','actual value query not component source identity')
replace(p,'expect(membership.currentCamp()).toBe(world.getComponent(1, COMPONENT.Camp));','expect(membership.currentCamp()).toBe(world.getComponent(1, COMPONENT.Camp)?.camp);','membership current scalar value')

# Add complete actual test sources/edits to working index, not a claim of execution.
(O/'before.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n');(O/'test-api-adaptations.json').write_text(json.dumps(ed,ensure_ascii=False,indent=2)+'\n');(O/'working-index.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidateCount':len(idx['paths']),'adaptedTests':len(set(x['path'] for x in ed)),'notReady':True}))
