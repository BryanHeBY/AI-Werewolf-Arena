from pathlib import Path
import json,hashlib,subprocess
R=Path('/home/hby/dev/AI-Werewolf-Arena');O=Path('/tmp/awa-role-contribution-query-boundary-draft');C=O/'candidates';idx=json.loads((O/'working-index.json').read_text());b=json.loads((O/'before.json').read_text());base=idx['baseCommit']
h=lambda bb:hashlib.sha256(bb).hexdigest()
def read(p):
 if p in b['files']:return (C/p).read_text()
 bb=(R/p).read_bytes();g=subprocess.run(['git','cat-file','blob',f'{base}:{p}'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);m=subprocess.check_output(['git','ls-tree',base,'--',p],cwd=R,text=True)
 b['files'][p]={'path':p,'currentText':bb.decode(),'currentSHA256':h(bb),'gitText':g.stdout.decode() if g.returncode==0 else None,'gitSHA256':h(g.stdout) if g.returncode==0 else None,'gitModeBlob':m.strip(),'absent':False};idx['paths'].append(p);return bb.decode()
def write(p,s):
 q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
def imp(p,n):
 s=read(p);at=s.index('import ');rel='../'*(len(Path(p).parts)-2)+'src/rulesets/roles/contracts';write(p,s[:at]+f'import type {{ {n} }} from "{rel}";\n'+s[at:])
for p in ['backend/tests/unit/domain/role-private-container.test.ts','backend/tests/unit/mechanisms/role-contributions.test.ts','backend/tests/unit/presentation/native-role-presentation.test.ts']:
 write(p,read(p).replace('type OwnedRoleQueries','type OwnedRoleInitContext'))
# Existing literal policies query detached extension data instead of receiving the original role component.
ps=['backend/tests/scenarios/mechanisms/wolf-team-dynamic-night-scheduling.test.ts','backend/tests/integration/recording/wolf-team-event-audience-provenance.test.ts','backend/tests/unit/mechanisms/wolf-team-permission-and-prompt-contracts.test.ts','backend/tests/unit/engine/visibility/inspection-result-contract.test.ts','backend/tests/integration/agents/protocol/action-reception-sdk-mcp-parity.test.ts']
for p in ps:
 s=read(p);s=s.replace('wolfTeam: (state: RoleComponent)', 'wolfTeam: (queries: RoleQueries)').replace('inspectionLabels: (state: RoleComponent)','inspectionLabels: (queries: RoleQueries)')
 # Only these actual callback expressions use state.privateState in these files.
 s=s.replace('(state.privateState as { readonly knife?: unknown })','(queries.stateData() as { readonly knife?: unknown })').replace('(state.privateState as { readonly revealed?: unknown })','(queries.stateData() as { readonly revealed?: unknown })').replace('(state.privateState as { readonly unmasked?: unknown })','(queries.stateData() as { readonly unmasked?: unknown })')
 write(p,s);imp(p,'RoleQueries')
p='backend/tests/unit/agents/fallback-current-wolf-actions.test.ts';s=read(p)
a='''wolfTeam: (role, world) => {
                  if (change === "role") role.role = Role.Villager;
                  if (change === "camp") world!.getComponent(1, COMPONENT.Camp)!.camp = Camp.Good;
                  if (change === "alive") world!.getComponent(1, COMPONENT.Alive)!.alive = false;'''
z='''wolfTeam: () => {
                  // 测试自有闭包显式持本局写权；公开贡献参数不再隐式取得 World 或角色组件。
                  if (change === "role") f.world.getComponent(1, COMPONENT.Role)!.role = Role.Villager;
                  if (change === "camp") f.world.getComponent(1, COMPONENT.Camp)!.camp = Camp.Good;
                  if (change === "alive") f.world.getComponent(1, COMPONENT.Alive)!.alive = false;'''
assert s.count(a)==1;write(p,s.replace(a,z))
(O/'before.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n');(O/'working-index.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
print('working candidates',len(idx['paths']))
