"""应用角色贡献精确差异；并发修改只在原文未变区间定位，不覆盖夜间或死亡适配。"""
from pathlib import Path
from difflib import SequenceMatcher
import hashlib,json,subprocess
repo=Path('/home/hby/dev/AI-Werewolf-Arena');prepared=Path('/tmp/awa-role-contribution-query-boundary-draft');sha=lambda b:hashlib.sha256(b).hexdigest()
ready=json.loads((prepared/'source-ready.json').read_text());before_rows=json.loads((prepared/'before.json').read_text())['files'];all_edits={row['path']:row for row in json.loads((prepared/'source-edits.json').read_text())};updates=[];rebased=[]
controls=json.loads((prepared/'controls.json').read_text())
if isinstance(controls,dict):controls=controls.get('controls',controls.get('files'))
assert isinstance(controls,list)
for row in controls:assert sha((repo/row['path']).read_bytes())==row['sha256'],row['path']
for row in ready['source']:
 path=repo/row['path'];old=before_rows[row['path']].get('currentText') or '';current=path.read_text() if path.exists() else '';candidate=Path(row['candidate']).read_bytes();assert sha(candidate)==row['sha256']
 assert (sha(old.encode()) if row['beforeSHA256'] is not None else None)==row['beforeSHA256']
 edits=all_edits[row['path']]['edits'];expected=old
 for edit in sorted(edits,key=lambda e:e['start'],reverse=True):
  assert expected[edit['start']:edit['end']]==edit['before'];expected=expected[:edit['start']]+edit['after']+expected[edit['end']:]
 assert expected.encode()==candidate,row['path']
 if current!=old:
  assert path.exists() and row['beforeSHA256'] is not None,row['path'];blocks=SequenceMatcher(None,old,current,autojunk=False).get_matching_blocks();rebased.append(row['path'])
 else:blocks=None
 mapped=[]
 for edit in edits:
  if blocks is None:start,end=edit['start'],edit['end']
  else:
   matches=[block for block in blocks if block.a<=edit['start'] and edit['end']<=block.a+block.size];assert matches,(row['path'],edit)
   block=matches[0];start=block.b+edit['start']-block.a;end=block.b+edit['end']-block.a
  assert current[start:end]==edit['before'];mapped.append({**edit,'currentStart':start,'currentEnd':end})
 after=current
 for edit in sorted(mapped,key=lambda e:e['currentStart'],reverse=True):after=after[:edit['currentStart']]+edit['after']+after[edit['currentEnd']:]
 updates.append((path,after,row,mapped,sha(current.encode()) if path.exists() else None))
assert set(rebased)=={'backend/src/rulesets/roles/contracts.ts','backend/src/features/wolf-king/profile.ts','backend/tests/unit/features/seer/seer-policies.test.ts','backend/tests/unit/mechanisms/configured-inspection-and-death-policy-instances.test.ts'},rebased
for path,after,row,mapped,actual_before in updates:path.parent.mkdir(parents=True,exist_ok=True);path.write_text(after)
source={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'preparedBase':ready['baseCommit'],'controls':controls,'rebasedPaths':rebased,'source':[{'path':row['path'],'beforeSHA256':actual_before,'preparedBeforeSHA256':row['beforeSHA256'],'preparedSHA256':row['sha256'],'appliedSHA256':sha(after.encode()),'exactEditCount':len(mapped),'mode':'mapped-exact-deltas' if row['path'] in rebased else 'exact-deltas','appliedEdits':mapped} for path,after,row,mapped,actual_before in updates]}
Path('/tmp/awa-role-query-ports-applied.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['/usr/bin/bun','--no-env-file','node_modules/prettier/bin/prettier.cjs','--write',*[row['path'] for path,after,row,mapped,actual_before in updates]],cwd=repo,env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8','CI':'1'},check=True,stdout=subprocess.DEVNULL)
for row in source['source']:row['finalSHA256']=sha((repo/row['path']).read_bytes())
Path('/tmp/awa-role-query-ports-formatted.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'source':len(updates),'rebased':rebased,'exactEdits':sum(len(mapped) for path,after,row,mapped,actual_before in updates),'base':source['base']}))
