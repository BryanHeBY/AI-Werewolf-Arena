"""独立净环境执行初始身份与野孩子句柄私有归属验证。"""
from pathlib import Path
import hashlib,json,subprocess,time,sys
repo=Path('/home/hby/dev/AI-Werewolf-Arena');task=sys.argv[1];out=Path('/tmp/awa-private-scope-worlds-execution')/task;out.mkdir(parents=True,exist_ok=False)
for x in ['home','tmp','cache']:(out/x).mkdir()
paths=['backend/src/features/initial-identity/setup.ts','backend/src/features/wild-child/lifecycle.ts','backend/tests/unit/domain/request-lease-terminal-boundaries.test.ts']
sha=lambda b:hashlib.sha256(b).hexdigest()
def fence():return {p:sha((repo/p).read_bytes()) for p in paths}
pre=fence();env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','CI':'1','BUN_RUNTIME_EXECUTABLE':'/usr/bin/bun','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'cache'),'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'}
argv=['/usr/bin/bun','--no-env-file']+(['test','--preload','./tests/setup.ts','tests/unit/domain/request-lease-terminal-boundaries.test.ts','tests/unit/features/initial-identity','tests/unit/features/thief','tests/unit/features/shapeshifter','tests/unit/features/wild-child'] if task=='tests' else ['node_modules/typescript/bin/tsc','-p','tsconfig.tests.json','--noEmit'])
start=time.time()
with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:r=subprocess.run(argv,cwd=repo/'backend',env=env,stdout=a,stderr=b,timeout=300)
post=fence();assert pre==post
receipt={'task':task,'argv':argv,'cwd':str(repo/'backend'),'env':env,'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'sourceSHA256':pre,'prePostSame':True,'raw':[{ 'path':x,'sha256':sha((out/x).read_bytes()),'bytes':(out/x).stat().st_size} for x in ['stdout.raw','stderr.raw']]};(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'task':task,'exitCode':r.returncode,'seconds':receipt['elapsedSeconds'],'tail':(out/'stderr.raw').read_text()[-3200:]}));sys.exit(r.returncode)
