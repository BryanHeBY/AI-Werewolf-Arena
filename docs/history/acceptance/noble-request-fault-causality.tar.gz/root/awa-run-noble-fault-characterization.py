"""在当前实际源码保留未记录换体因果的原十项失败，禁止修改录制预期。"""
from pathlib import Path
import hashlib,json,subprocess,time,sys
repo=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/tmp/awa-noble-fault-characterization');out.mkdir(exist_ok=False)
for name in ['home','tmp','cache']:(out/name).mkdir()
source=json.loads(Path('/tmp/awa-noble-request-fault-repair/HANDOFF.json').read_text())['source'];sha=lambda b:hashlib.sha256(b).hexdigest()
def fence():return {row['path']:sha((repo/row['path']).read_bytes()) if (repo/row['path']).exists() else None for row in source}
before=fence();env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','CI':'1','BUN_RUNTIME_EXECUTABLE':'/usr/bin/bun','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'cache'),'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'};argv=['/usr/bin/bun','--no-env-file','test','--preload','./tests/setup.ts','tests/scenarios/boards/noble-secret-body/revocation-transport.test.ts'];start=time.time()
with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:r=subprocess.run(argv,cwd=repo/'backend',env=env,stdout=a,stderr=b,timeout=600)
assert before==fence();receipt={'argv':argv,'env':env,'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'sourceSHA256':before,'prePostSame':True,'raw':[{'path':name,'sha256':sha((out/name).read_bytes()),'bytes':(out/name).stat().st_size} for name in ['stdout.raw','stderr.raw']]};(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'exitCode':r.returncode,'seconds':receipt['elapsedSeconds'],'tail':(out/'stderr.raw').read_text()[-2500:]}));sys.exit(r.returncode)
