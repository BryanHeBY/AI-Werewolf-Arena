"""按十份原态整合显式贵族故障因果，阶段经理合并保留已提交判胜查询。"""
from pathlib import Path
import hashlib,json,re,subprocess
repo=Path('/home/hby/dev/AI-Werewolf-Arena');prepared=Path('/tmp/awa-noble-request-fault-repair');sha=lambda b:hashlib.sha256(b).hexdigest();handoff=json.loads((prepared/'HANDOFF.json').read_text());updates=[]
for row in handoff['artifacts']:assert sha(Path(row['path']).read_bytes())==row['sha256'],row['path']
delta=json.loads(Path('/tmp/awa-h02-victory-evaluator-query-boundary/phase-manager-local-delta.json').read_text())
def victory(text):
 for edit in delta['edits']:
  if edit.get('insertBeforeFirstImport'):
   match=re.search(r'^import ',text,re.M);assert match;text=text[:match.start()]+edit['after']+text[match.start():]
  else:assert text.count(edit['before'])==edit['count'];text=text.replace(edit['before'],edit['after'])
 return text
for row in handoff['source']:
 path=repo/row['path'];before=path.read_bytes() if path.exists() else None;candidate=Path(row['candidate']).read_bytes();assert sha(candidate)==row['candidateSHA256'],row['path']
 if row['new']:assert before is None;after=candidate
 elif row['path']==delta['path']:
  original=subprocess.check_output(['git','show','6abfe493f39fd38265f2219abec76b2ce18e38fe:'+row['path']],cwd=repo);assert sha(original)==row['beforeSHA256'];assert victory(original.decode()).encode()==before;after=victory(candidate.decode()).encode()
 else:assert sha(before)==row['beforeSHA256'],row['path'];after=candidate
 updates.append((path,after,row,sha(before) if before is not None else None))
for path,after,row,actual in updates:path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(after)
source={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'source':[{'path':row['path'],'beforeSHA256':actual,'preparedBeforeSHA256':None if row['new'] else row['beforeSHA256'],'preparedSHA256':row['candidateSHA256'],'appliedSHA256':sha(after),'mode':'preserve-victory-local-deltas' if row['path']==delta['path'] else 'whole-before-guard'} for path,after,row,actual in updates]};Path('/tmp/awa-noble-request-fault-applied.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['/usr/bin/bun','--no-env-file','node_modules/prettier/bin/prettier.cjs','--write',*[row['path'] for path,after,row,actual in updates]],cwd=repo,env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8','CI':'1'},check=True,stdout=subprocess.DEVNULL)
for row in source['source']:row['finalSHA256']=sha((repo/row['path']).read_bytes())
Path('/tmp/awa-noble-request-fault-formatted.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'source':len(updates),'base':source['base']}))
