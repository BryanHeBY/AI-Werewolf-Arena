from pathlib import Path
import json,subprocess,hashlib,difflib
R=Path('/home/hby/dev/AI-Werewolf-Arena');D=Path('/tmp/awa-noble-request-fault-repair');C=D/'candidates';before={}
def get(p):
 if p not in before:
  q=R/p;before[p]={'present':q.exists(),'text':q.read_text() if q.exists() else None}
 return before[p]['text'] or ''
def put(p,s):q=C/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
p='backend/src/domain/fault-plan.ts';s=get(p);s=s.replace('只接受既有猎魔决策后、夜来源冻结前的替换生命步骤，计划执行和实际 World 写入归引擎。','保留猎魔来源冻结前的原 v1；另有显式贵族请求返回点单步协议，计划执行和实际 World 写入归引擎。')
s=s.replace('export type FaultPlan = z.infer<typeof faultPlanSchema>;\nexport type FaultStep = FaultPlan["steps"][number];','''/** 贵族仅重放这三个实际请求边界；独立版本不把旧猎魔协议扩成任意 World patch。 */
const nobleRequestFaultPlanSchema = z.strictObject({
  version: z.literal("awa_noble_request_fault_plan_v1"),
  steps: z.tuple([z.strictObject({
    id: z.string().regex(/^[a-z][a-z0-9_-]{0,63}$/),
    at: z.strictObject({
      day: positive,
      point: z.literal("after_provider_return"),
      afterDecision: z.strictObject({ actorId: positive, stage: z.enum(["secret_body", "night_noble", "awakened_idiot_reveal_speech"]), turn: z.literal(1) }),
    }),
    mutation: z.strictObject({ kind: z.literal("replace_alive_component"), playerId: positive, alive: z.literal(true) }),
  })]),
});
export type DemonFaultPlan = z.infer<typeof faultPlanSchema>;
export type NobleRequestFaultPlan = z.infer<typeof nobleRequestFaultPlanSchema>;
export type FaultPlan = DemonFaultPlan | NobleRequestFaultPlan;
export type FaultStep = DemonFaultPlan["steps"][number];
export type NobleRequestFaultStep = NobleRequestFaultPlan["steps"][number];''')
s=s.replace('return deepFreeze(faultPlanSchema.parse(readFaultPlanData(value)));','''const data = readFaultPlanData(value);
  return deepFreeze(z.union([faultPlanSchema, nobleRequestFaultPlanSchema]).parse(data));''');put(p,s)
p='backend/src/engine/fault-plan.ts';s=get(p);s=s.replace('type FaultStep }','type FaultStep, type NobleRequestFaultStep }',1);s=s.replace('  type AliveComponent,','  type AliveComponent,\n  type ActionRequest,\n  type ToolCall,\n  Role,');s=s.replace('  readonly plan: FaultPlan;','  readonly plan: FaultPlan;\n  private requestTurns = new Map<string, number>();');s=s.replace('    input: unknown,\n  ) {','    input: unknown,\n    allowNobleRequest = false,\n  ) {');s=s.replace('    this.plan = readFaultPlan(input);','''    this.plan = readFaultPlan(input);
    if (this.plan.version === "awa_noble_request_fault_plan_v1" && !allowNobleRequest)
      throw new Error("fault_plan_noble_board_required");''');s=s.replace('    if (this.failed) throw new Error("fault_plan_failed");\n    try {\n      return this.apply(day, decision, recordApplied);','''    if (this.failed) throw new Error("fault_plan_failed");
    if (this.plan.version !== "awa_fault_plan_v1") return [];
    try {
      return this.apply(day, decision, recordApplied);''',1);s=s.replace('    if (\n      typeof recordApplied !== "function"','''    if (this.plan.version !== "awa_fault_plan_v1") return [];
    if (
      typeof recordApplied !== "function"''',1)
needle='  assertConsumed(): void {';assert needle in s
s=s.replace(needle,'''  /**
   * 显式贵族故障只在真实 Provider 正常返回后、原领域资格复验前执行。
   * 候选仍是候选，不伪造 paid/错误；替换本身先提交，必需因果记录失败不回滚，失败计划不再重试。
   * 无此计划时 PhaseManager 不安装此代理；旧猎魔冻结端口也不消费这些请求步骤。
   */
  applyAfterProviderReturn(
    request: ActionRequest,
    action: ToolCall | null,
    recordApplied: (fault: { step: NobleRequestFaultStep; originalVersion: number; replacementVersion: number }) => void,
  ): void {
    if (this.failed) throw new Error("fault_plan_failed");
    if (this.plan.version !== "awa_noble_request_fault_plan_v1") return;
    const step = this.plan.steps[0], after = step.at.afterDecision;
    if (request.actorId !== after.actorId || request.context.day !== step.at.day || request.context.stage !== after.stage) return;
    const key = `${request.actorId}/${request.context.day}/${request.context.stage}`,
      turn = (this.requestTurns.get(key) ?? 0) + 1;
    this.requestTurns.set(key, turn);
    try {
      if (this.consumed.has(step.id) || turn !== after.turn) throw new Error("fault_plan_boundary_repeated");
      if (typeof recordApplied !== "function" || types.isProxy(recordApplied) || types.isAsyncFunction(recordApplied) || types.isGeneratorFunction(recordApplied))
        throw new Error("fault_plan_recorder_invalid");
      const actorRole = this.world.getComponent(request.actorId, COMPONENT.Role)?.role,
        reveal = after.stage === "awakened_idiot_reveal_speech",
        tool = reveal ? "speak" : after.stage === "secret_body" ? "protect_secret_body" : "choose_servant";
      if (actorRole !== (after.stage === "night_noble" ? Role.NightNoble : Role.AwakenedIdiot) ||
          !action || action.name !== tool ||
          !(step.mutation.playerId === request.actorId || (!reveal && action.args.target_id === step.mutation.playerId)))
        throw new Error("fault_plan_decision_boundary_invalid");
      const original = this.world.getComponent(step.mutation.playerId, COMPONENT.Alive),
        version = original && aliveLifeVersion(original),
        factory = original && aliveLifeDescriptor(original),
        actual = original && Object.getOwnPropertyDescriptor(original, "alive");
      if (!original || types.isProxy(original) || version === undefined || !factory || !actual ||
          actual.get !== factory.get || actual.set !== factory.set ||
          actual.enumerable !== factory.enumerable || actual.configurable !== factory.configurable || original.alive !== true)
        throw new Error("fault_plan_original_life_invalid");
      const replacement = createAliveComponent(true, this.world.locale);
      this.world.addComponent(step.mutation.playerId, COMPONENT.Alive, replacement);
      this.consumed.add(step.id);
      // 使用与原 v1 相同的同步记录器规则；不能吞异步结果或执行任意 thenable。
      const result: unknown = recordApplied({ step, originalVersion: version, replacementVersion: aliveLifeVersion(replacement)! });
      if (result !== undefined) {
        if (types.isPromise(result) && !types.isProxy(result) && Object.getPrototypeOf(result) === Promise.prototype &&
            !Object.hasOwn(result, "constructor") && Object.getOwnPropertyDescriptor(Promise.prototype, "constructor")?.value === Promise &&
            Object.getOwnPropertyDescriptor(Promise, Symbol.species)?.get === nativePromiseSpecies)
          nativePromiseThen.call(result, undefined, () => undefined);
        throw new Error("fault_plan_recorder_not_sync");
      }
    } catch (error) { this.failed = true; throw error; }
  }

'''+needle);put(p,s)
p='backend/src/engine/phase-manager.ts';s=get(p);s=s.replace('new NightFaultPlan(world, options.faultPlan)','new NightFaultPlan(world, options.faultPlan, !!config.nobleSecretBody)')
needle='    if (demonHunterActorId(this.world) !== null) {\n      const underlying = actionProvider;';assert s.count(needle)==1
s=s.replace(needle,'''    // 只有明确声明的贵族因果计划才接这一正常返回边界；普通运行不增加代理或 World 读取。
    if (this.nightFaultPlan?.plan.version === "awa_noble_request_fault_plan_v1") {
      const faultPlan = this.nightFaultPlan, underlying = actionProvider;
      actionProvider = {
        getAction: async (request) => {
          const action = await underlying.getAction(request);
          faultPlan.applyAfterProviderReturn(request, action, (fault) => {
            getSessionRecorder()?.recordRequiredLogicOp({
              scope: "resolution", op: "noble_request_fault_applied", actorId: request.actorId,
              phase: request.phase, status: "ok",
              input: { version: "awa_noble_request_fault_plan_v1", step: fault.step },
              output: { originalVersion: fault.originalVersion, replacementVersion: fault.replacementVersion },
            });
          });
          return action;
        },
      };
    }
'''+needle);put(p,s)
p='backend/src/app/game-runner.ts';s=get(p);s=s.replace('export interface GameRunDependencies {','''export interface GameRunDependencies {
  /** 可信 controller 的显式离线故障数据；进入原 metadata.faultPlan，同一 owner 在录制和重放消费，不是模型／JSON 配置。 */
  faultPlan?: unknown;''');needle='    playerNames: Object.fromEntries(\n      Object.entries(setup.players).flatMap(([seat, entry]) =>\n        entry.name !== undefined ? [[seat, entry.name]] : [],\n      ),\n    ),';assert needle in s;s=s.replace(needle,needle+'\n    ...(dependencies.faultPlan !== undefined ? { faultPlan: dependencies.faultPlan } : {}),');put(p,s)
p='backend/src/recording/verification/demon-hunter/validate.ts';s=get(p);needle='const plan = record.metadata.faultPlan ? readFaultPlan(record.metadata.faultPlan) : null,';assert needle in s;s=s.replace(needle,'''const plan = record.metadata.faultPlan?.version === "awa_fault_plan_v1" ? readFaultPlan(record.metadata.faultPlan) : null,''');put(p,s)
p='backend/tests/support/transport/contracts.ts';s=get(p).replace('export interface TransportGameScenario {','''export interface TransportGameScenario {
  /** 显式离线输入经真实 controller/metadata 交原故障 owner；不是在 replay 另造一份镜像 mutation。 */
  faultPlan?: import("../../../src/domain/fault-plan").FaultPlan;''');put(p,s)
p='backend/tests/support/drivers/transport/run-game.ts';s=get(p);needle='      {\n        selectRequestDeadline(request) {';assert needle in s;s=s.replace(needle,'      {\n        ...(scenario.faultPlan ? { faultPlan: scenario.faultPlan } : {}),\n        selectRequestDeadline(request) {',1);put(p,s)
# The independent Noble audit binds the new narrow causal plan to one original error decision and one operation.
p='backend/src/recording/verification/noble-secret-body/validate.ts';s=get(p);s=s.replace('      !board.nightNoble &&','      record.metadata.faultPlan?.version !== "awa_noble_request_fault_plan_v1" &&\n        !record.operations.some((op) => op.op === "noble_request_fault_applied") &&\n        !board.nightNoble &&',1)
needle='  for (const p of roster.values())\n    check(p.camp === ([Role.Wolf, Role.NightNoble].includes(p.role) ? Camp.Wolf : Camp.Good));';assert needle in s
s=s.replace(needle,needle+'''
  // 正常候选不解释生命换体；只有这份显式、单步且具名的外部因果能支撑同源重放。
  const requestPlan = record.metadata.faultPlan?.version === "awa_noble_request_fault_plan_v1" ? record.metadata.faultPlan : null,
    requestFaults = record.operations.filter((op) => op.op === "noble_request_fault_applied");
  if (!requestPlan) check(requestFaults.length === 0);
  else {
    const step = requestPlan.steps[0], point = step.at.afterDecision,
      decisions = record.decisions.filter((d) => d.actorId === point.actorId && d.day === step.at.day && d.stage === point.stage && d.turn === point.turn),
      decision = decisions[0], candidate = decision?.returnedCandidate,
      reveal = point.stage === "awakened_idiot_reveal_speech",
      expectedTool = reveal ? "speak" : point.stage === "secret_body" ? "protect_secret_body" : "choose_servant";
    check(point.actorId === (point.stage === "night_noble" ? nobleId : bodyId));
    check(requestFaults.length <= 1);
    if (requestFaults.length) {
      const op = requestFaults[0]!;
      check(decisions.length === 1 && decision!.outcome.kind === "error" && candidate && candidate.name === expectedTool &&
        (step.mutation.playerId === point.actorId || (!reveal && candidate.args.target_id === step.mutation.playerId)) &&
        op.scope === "resolution" && op.status === "ok" && op.actor_id === point.actorId && op.phase === decision!.request.phase &&
        equal(op.input, { version: "awa_noble_request_fault_plan_v1", step }) &&
        equal(op.output, { originalVersion: 0, replacementVersion: 0 }) &&
        !record.checkpoints.at(-1)!.complete && record.checkpoints.at(-1)!.snapshot.day === step.at.day);
    }
    // 返回的合规候选必须有实际换体记录；不能删掉因果 operation 再借 false-close 证明撤权。
    if (candidate && candidate.name === expectedTool &&
        (step.mutation.playerId === point.actorId || (!reveal && candidate.args.target_id === step.mutation.playerId)))
      check(requestFaults.length === 1);
    if (record.checkpoints.at(-1)!.complete) check(requestFaults.length === 1);
  }
''');put(p,s)
p='backend/tests/scenarios/boards/noble-secret-body/revocation-transport.test.ts';s=get(p);s=s.replace('import { createAliveComponent } from "../../../../src/agents/observation/component-presentation";\n','');s=s.replace(' * 受控原角色／生命替换及迟到模型回复；撤销后无消费／提交选择与原字面部分 checkpoint／wire',' * 显式归档的单步生命替换与原模型回复；同一故障 owner 在录制／严格重放执行，撤销后无消费／提交选择与原字面部分 checkpoint／wire');s=s.replace('// 只锁定 runner 的首个管理器，避免影响后续严格 Tape 重放。','// 只锁定 runner 的首个管理器观察原引用；不写生命，不在 replay 注入另一份镜像故障。')
s=s.replace('        let manager: PhaseManager | undefined,\n          fired = 0;','''        const playerId = changed === "actor" ? actorId : scenario.mapping.get(stage === "secret_body" ? 7 : 6)!;
        const faultPlan = { version: "awa_noble_request_fault_plan_v1" as const, steps: [{
          id: "noble_original_life_replaced", at: { day, point: "after_provider_return" as const, afterDecision: { actorId, stage, turn: 1 as const } },
          mutation: { kind: "replace_alive_component" as const, playerId, alive: true as const },
        }] as [import("../../../../src/domain/fault-plan").NobleRequestFaultStep] };
        let manager: PhaseManager | undefined, previousLife: AliveComponent | undefined, observedWorld: World | undefined,
          fired = 0;''')
a=s.index('                    const id =\n');b=s.index('                    fired++;',a)
s=s[:a]+'''                    previousLife = world.getComponent(playerId, COMPONENT.Alive);
                    observedWorld = world;
                    expect(Number.isSafeInteger(playerId)).toBe(true);
                    expect(previousLife).toBeDefined();
'''+s[b:]
s=s.replace('{ ...scenario, turns, expectedFailure: { actorId, stage } }','{ ...scenario, turns, faultPlan, expectedFailure: { actorId, stage } }');needle='          expect(fired).toBe(1);';assert needle in s;s=s.replace(needle,needle+'''
          const replacement = observedWorld!.getComponent(playerId, COMPONENT.Alive)!;
          expect(replacement).not.toBe(previousLife);
          expect(replacement.alive).toBe(true);
          expect(run.record.metadata.faultPlan).toEqual(faultPlan);
          expect(run.record.operations.filter((op) => op.op === "noble_request_fault_applied")).toHaveLength(1);''');put(p,s)
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();records=[]
for p,v in before.items():
 g=subprocess.run(['git','show',base+':'+p],cwd=R,capture_output=True);v.update(sha256=hashlib.sha256((v['text'] or '').encode()).hexdigest(),gitSHA256=hashlib.sha256(g.stdout).hexdigest() if g.returncode==0 else None,sameGit=g.returncode==0 and g.stdout.decode()==v['text'])
(D/'before.json').write_text(json.dumps({'base':base,'files':before},ensure_ascii=False,indent=2)+'\n')
print('Prepared nine current paths in TMP; no source/TS/parser/test/check execution')
