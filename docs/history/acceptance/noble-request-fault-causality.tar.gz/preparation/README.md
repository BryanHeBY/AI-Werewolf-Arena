# Noble 原生命撤销的可重放因果

## 已确认的旧轮范围

07ef 的场景 raw 12 个 fail 行不是超时解释：Radiant pending 1、Ghost pending 1，分别由已提交的两源／三处 `returnedCandidate` 删除修正覆盖。另 10 个均为 Noble `revocation-transport.test.ts`：secret_body/night_noble × actor/target × llm/acp 的 8 个 unexpected_request；reveal-speech × actor × llm/acp 的 2 个 checkpoint_mismatch。

原 live fixture 在 Provider 已正常返回后替换真实 Alive，却显式不向 replay 的新 manager 注入；World.addComponent 本身不记 operation。Tape3 false-close 保正常 candidate，replay 正确返回该 candidate，但没有换体因果，故原资源 owner 继续执行。这里不能删 candidate、删 checkpoint、跳严格 replay、将 false 当付款或根据错误码猜一次换体。

## 最小实际 owner 修复

复用现有 `domain/fault-plan.ts` 和 `engine/fault-plan.ts`，新增独立嵌套协议 `awa_noble_request_fault_plan_v1`：**单步**、仅 `secret_body` / `night_noble` / `awakened_idiot_reveal_speech`，day/actor/turn 明确，phase 与实际角色、候选 tool 及 actor/所选 target 对应。只能把这一人的真实 Alive 换成新的 alive=true 组件；没有任意 component patch 或回调执行器。

PhaseManager 只在显式此计划时包同一 Provider，原 action 正常返回后、原 owner 复验前调用该故障 owner。旧 Demon v1 gate 与冻结点不变，新增还要求实际 canonical config 的 Noble 机制；当前只承诺已装 Demon 的现行十二人 Noble canonical 板，不放开未来无 Demon 的自定义板。无计划不安装此代理，不给公开扩展 World。返回 action 原样继续，原 guard/错误/付款顺序仍由机制决定。

先真实换体并消费步骤，再必需记录 `noble_request_fault_applied`，记录晚错保已写前缀且计划永久失败。metadata 仍用原 `faultPlan` 字段，版本值明确区分旧 Demon 协议；现有 capture/replay bootstrap 原接线自动用同一数据／同一 owner 重放，无测试镜像写。新嵌套计划只允许 strict Tape3；旧 strict2 不借此扩接受面。没有变更公共/玩家 envelope、原 fixtures/history 或 Tape outcome/returnedCandidate 规则。

Noble 独立审计将实际单个 operation、候选、actor/phase/day/target、失败 checkpoint 与显式计划交叉绑定；旧 Demon 审计只消费其旧 v1 步骤，不将 Noble op 当猎魔冻结故障。原增量 Trace 不附 operations，该阶段只查计划结构，最终归档才要求对应 op；不捏造尚未发表证据。

Controller `GameRunDependencies.faultPlan` 只接离线明确数据，沿原 bootstrap 输入捕获。新增字段读取是这个新入口的可观察面；不声称未知 Proxy/任意 monkeypatch 或所有外部注入都可精确复现。

## 测试输入与原 oracle

10 原声明、两 locale、llm/acp、原 partial checkpoint／库存／事实／wire／严格 replay 断言保留。原 spy 改为**只读首 live manager 原引用**，不再写 Alive；实际故障由 metadata 计划驱动。前后生命引用不等／新组件 alive=true 及实际只记一次因果仍被断言。相同候选动作断言仍在原 Provider 返回观察点。无需给 replay 再装一份 mutation。

新增 unit 两声明只核本 owner 的真实引用替换、独立版本/记录输出、重复拒绝及必需记录同一 Error 对象后不回滚／不二写。旧 Demon v1 兼容是源码静态审读范围，不能称这两个新 unit 已覆盖其执行。它们不是已执行结果。完整验证由 Root 首执行，作者没有运行产品、解析器、类型、formatter、测试、门禁。

## 路径与合并

9 既有源＋1 新 unit；`before.json` 保存开始时真实全文/原 Git SHA，候选仅 TMP。Root application 前逐源 SHA 比较，尤其 PhaseManager 若有后继需只迁入本 plan 片段，不覆盖其它角色接口。Root 原 RoleQ/夜/死亡范围不在本包改动。

建议 Root 最小首验证为新 unit 两声明＋原 Noble 此文件 10 声明；它们保完整两 locale／真实传输／严格重放，勿筛去错误断言。旧 Demon fault-plan 精准用例按共享 owner 影响选原必要声明；有限 types 覆实际新10根与传递图，非全 C47。旧 07ef raw 的 12 红与 timeout 都保留。
