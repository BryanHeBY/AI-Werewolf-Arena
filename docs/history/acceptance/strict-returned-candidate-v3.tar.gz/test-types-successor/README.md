# Tape3 两个新增回归的有限类型修复（TMP）

Root 首次真实受影响类型检查仅报告两个 TS2339。本候选保存当次格式化后的完整两文件；不覆盖原13路径准备包、首单元红/绿、首次类型原输出，不改任何生产或原八场景。

1. 集成测试读取真实 Hybrid 槽改用现有公开 `getHybridState`，角色、字面 `remaining: 1 / choice: null` 和全部断言保持。新增一个测试 import 和一次实际调用，不冒类型擦除或原 raw emit 相同；对本合法 fixture 的原状态预期保持。
2. copy mutation 在前面完整字面断言之后只对 `candidate?.name === "kill_vote"` 写 `target_id = 5`。这是真正的 discriminant 窄化；fixture只提供 null/kill_vote，变异目标和后继复制断言保持。不冒该条件的 JS 字节等价。

共2文件3精确编辑，头/标题/预期/其余正文保持。全体输入与Root当前两文件在纯字节读取时一致；Root应在此前在跑命令终态后、按 beforeSHA guard应用。差分文本已做纯字符串正演/逆演；没有执行 TypeScript/AST、编译器、formatter、产品或测试，也没有仓库写入。

Root后继有限类型只需两变根。原新增9/69、shared3/15、writer11/59等由Root真实收据登记；本候选不复跑这些绿，也不提前宣称本类型后继通过。
