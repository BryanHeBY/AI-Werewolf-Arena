from pathlib import Path
import json,hashlib,subprocess,difflib
repo=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/tmp/awa-returned-candidate-replay-repair');doc=json.loads((out/'prepared-production-and-docs.json').read_text());paths=[s['path'] for s in doc['source']]
def read(p):return (out/'candidates'/p).read_text()
def write(p,s):q=out/'candidates'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
p='backend/tests/unit/recording/request-delivery.test.ts';s=read(p);a='import { ReproductionTrace } from "../../../src/recording/reproduction/trace";';b=a+'\nimport { parseReproductionRecord } from "../../../src/recording/reproduction/format";';assert s.count(a)==1;s=s.replace(a,b)
s+='''

test("returned candidate: false completion preserves copied action or explicit null without accepting either", async () => {
  for (const isNull of [true, false]) {
    const { trace, request } = fixture(), scope = {};
    const supplied: ToolCall | null = isNull ? null : { name: "kill_vote", args: { target_id: 3, abstain: false } };
    bindRequestDeliveryGuard(request, () => true, scope);
    await trace.decide(request, { getAction: async () => supplied });
    if (supplied) supplied.args.target_id = 6;
    settleRequestDelivery(scope, false);
    settleRequestDelivery(scope, false);
    const recorded = trace.build().decisions[0]!;
    expect(Object.hasOwn(recorded, "returnedCandidate")).toBe(true);
    expect(recorded.returnedCandidate).toEqual(isNull ? null : { name: "kill_vote", args: { target_id: 3, abstain: false } });
    expect(recorded.outcome).toEqual({ kind: "error", code: "decision_failed", name: "Error" });
    expect(trace.settlementCount).toBe(1);
    if (recorded.returnedCandidate) recorded.returnedCandidate.args.target_id = 5;
    expect(trace.build().decisions[0]!.returnedCandidate).toEqual(isNull ? null : { name: "kill_vote", args: { target_id: 3, abstain: false } });
  }
});

test("returned candidate: true completion, real provider throw and early delivery refusal keep the field absent", async () => {
  const accepted = fixture(), scope = {};
  bindRequestDeliveryGuard(accepted.request, () => true, scope);
  await accepted.trace.decide(accepted.request, { getAction: async () => action });
  settleRequestDelivery(scope, true);
  expect(Object.hasOwn(accepted.trace.build().decisions[0]!, "returnedCandidate")).toBe(false);
  expect(accepted.trace.build().decisions[0]!.outcome).toEqual({ kind: "action", action });
  const thrown = fixture(), original = new TypeError("literal provider failure");
  await expect(thrown.trace.decide(thrown.request, { getAction: async () => { throw original; } })).rejects.toBe(original);
  expect(Object.hasOwn(thrown.trace.build().decisions[0]!, "returnedCandidate")).toBe(false);
  expect(thrown.trace.build().decisions[0]!.outcome).toEqual({ kind: "error", code: "decision_failed", name: "TypeError" });
  const refused = fixture();
  bindRequestDeliveryGuard(refused.request, () => false, {});
  await expect(refused.trace.decide(refused.request, { getAction: async () => action })).rejects.toThrow("action_request_delivery_authority_revoked");
  expect(Object.hasOwn(refused.trace.build().decisions[0]!, "returnedCandidate")).toBe(false);
});

test("returned candidate: Tape3 owns the optional fact while Tape2 and malformed presence remain strict", async () => {
  const { trace, request } = fixture();
  await trace.decide(request, { getAction: async () => null });
  const current = trace.build();
  expect(current.schemaVersion).toBe(3);
  const legacy = structuredClone(current); legacy.schemaVersion = 2;
  expect(parseReproductionRecord(legacy).schemaVersion).toBe(2);
  const rejected = structuredClone(current);
  rejected.decisions[0]!.outcome = { kind: "error", code: "decision_failed", name: "Error" };
  rejected.decisions[0]!.returnedCandidate = null;
  expect(parseReproductionRecord(rejected).decisions[0]!.returnedCandidate).toBeNull();
  const known = structuredClone(rejected); known.decisions[0]!.returnedCandidate = { name: "kill_vote", args: { target_id: 3, abstain: false } };
  expect(parseReproductionRecord(known).decisions[0]!.returnedCandidate).toEqual({ name: "kill_vote", args: { target_id: 3, abstain: false } });
  const oldWithNew = structuredClone(rejected); oldWithNew.schemaVersion = 2;
  expect(() => parseReproductionRecord(oldWithNew)).toThrow("reproduction_record_invalid");
  for (const outcome of [{ kind: "pending" }, { kind: "action", action: null }, { kind: "error", code: "decision_failed", name: "TypeError" }] as const) {
    const bad = structuredClone(rejected); bad.decisions[0]!.outcome = outcome;
    expect(() => parseReproductionRecord(bad)).toThrow("reproduction_record_invalid");
  }
  for (const value of [undefined, { name: "unknown_tool", args: {} }, { name: "kill_vote", args: { target_id: () => 3 } }]) {
    const bad = structuredClone(rejected);
    Object.defineProperty(bad.decisions[0]!, "returnedCandidate", { value, enumerable: true, configurable: true });
    expect(() => parseReproductionRecord(bad)).toThrow("reproduction_record_invalid");
  }
  const inherited = structuredClone(rejected); delete inherited.decisions[0]!.returnedCandidate;
  Object.setPrototypeOf(inherited.decisions[0]!, { returnedCandidate: null });
  expect(() => parseReproductionRecord(inherited)).toThrow("reproduction_record_invalid");
  const accessor = structuredClone(rejected); let calls = 0;
  Object.defineProperty(accessor.decisions[0]!, "returnedCandidate", { enumerable: true, get() { calls++; return null; } });
  expect(() => parseReproductionRecord(accessor)).toThrow("reproduction_record_invalid");
  expect(calls).toBe(0);
  const future = structuredClone(rejected) as unknown as { schemaVersion: number }; future.schemaVersion = 4;
  expect(() => parseReproductionRecord(future)).toThrow("reproduction_schema_not_supported");
});
''';write(p,s)
p='backend/tests/unit/recording/relationship-reproduction-ledgers.test.ts';s=read(p);s+='''

test("returned candidate: the last known reply constrains both ledgers without manufacturing payment", () => {
  for (const family of ["cupid", "hybrid"] as const) {
    const record = family === "cupid" ? cupidMixed() : hybridWolf();
    failure(record, 0);
    record.schemaVersion = 3;
    record.decisions[0]!.outcome = { kind: "error", code: "decision_failed", name: "Error" };
    record.decisions[0]!.returnedCandidate = family === "cupid"
      ? { name: "choose_lovers", args: { first_id: 2, second_id: 4 } }
      : { name: "choose_exemplar", args: { target_id: 2 } };
    // 两份手写 fixture 已给完整安装但尚无事实的失败前缀；候选只限制输入，不把 false 改成 true。
    expect(() => parseReproductionRecord(record)).not.toThrow();
    const nullReply = structuredClone(record); nullReply.decisions[0]!.returnedCandidate = null;
    expect(() => parseReproductionRecord(nullReply)).toThrow(family === "cupid" ? cupidError : hybridError);
    const invalid = structuredClone(record); invalid.decisions[0]!.returnedCandidate = { name: "speak", args: { text: "not the requested choice" } };
    expect(() => parseReproductionRecord(invalid)).toThrow(family === "cupid" ? cupidError : hybridError);
    const conflict = structuredClone(record); conflict.decisions[0]!.returnedCandidate = family === "cupid"
      ? { name: "choose_lovers", args: { first_id: 2, second_id: 5 } }
      : { name: "choose_exemplar", args: { target_id: 4 } };
    expect(() => parseReproductionRecord(conflict)).toThrow(family === "cupid" ? cupidError : hybridError);
    const unpaid = structuredClone(record);
    unpaid.checkpoints[1]!.players = structuredClone(unpaid.checkpoints[0]!.players);
    expect(() => parseReproductionRecord(unpaid)).not.toThrow();
    const legacy = structuredClone(record); legacy.schemaVersion = 2;
    delete legacy.decisions[0]!.returnedCandidate;
    expect(() => parseReproductionRecord(legacy)).not.toThrow();
  }
});
''';write(p,s)
p='backend/tests/unit/recording/returned-candidate-replay.test.ts';assert not (repo/p).exists();assert not subprocess.check_output(['git','ls-tree',doc['baseCommit'],'--',p],cwd=repo)
s='''/**
 * 单元测试负责已返回但未完成候选的原生重放边界。
 * 输入为合法六人 Hybrid、真实 Trace／PhaseManager、三次字面 null 或一个真实抛错；不接模型或网络。
 * 输出核对原库存、请求／结算序与精确失败快照；不从生产资格函数计算玩法预期。
 * 缺候选仍保旧异常语义，版本读取不豁免来源指纹；临时文件由共享测试目录 owner 清理。
 */
import { expect, test } from "bun:test";
import { bootstrapGame } from "../../../src/app/bootstrap";
import { COMPONENT, Role, WinCondition } from "../../../src/domain";
import { SessionRecordManager } from "../../../src/recording/session/recorder";
import { ReproductionTrace } from "../../../src/recording/reproduction/trace";
import type { ReproductionMetadata } from "../../../src/recording/reproduction/format";
import { beginGameReproduction, captureCheckpoint, currentEngineVersion } from "../../../src/app/simulation/reproduction-context";
import { replayReproduction } from "../../../src/app/simulation/replay-reproduction";
import { sixPlayerMvpConfig } from "../../../src/rulesets/presets/six-player-mvp";
import { createTestTempDirectory } from "../../support/drivers/temp-directories";

async function fixture() {
  const roles = [Role.Hybrid, Role.Wolf, Role.Seer, Role.Witch, Role.Villager, Role.Villager];
  const game = bootstrapGame({
    ...sixPlayerMvpConfig,
    roleSetups: [...new Set(roles)].map((role) => ({ role, count: roles.filter((value) => value === role).length })),
    winConditions: [WinCondition.SlaughterCity],
    selfDestruct: { enabledWindows: [] },
  }, { fixedRoles: roles, locale: "en" });
  const manager: SessionRecordManager = Object.create(SessionRecordManager.prototype);
  Object.defineProperty(manager, "beginReproduction", {
    value(metadata: ReproductionMetadata, liveEvents?: () => readonly import("../../../src/domain").GameEvent[]) {
      return new ReproductionTrace(metadata, () => {}, liveEvents);
    },
  });
  const trace = beginGameReproduction(manager, game, {
    engine: await currentEngineVersion(), boardId: "literal_hybrid_retry", locale: "en", maxDays: 2,
  });
  return { game, trace };
}

test("returned candidate: three real Hybrid null returns replay all retries and preserve the unpaid failure", async () => {
  const { game, trace } = await fixture();
  let calls = 0, failure: unknown;
  try {
    await game.phaseManager.runSingleCycle({ getAction(request) {
      calls++;
      return trace.decide(request, { getAction: async () => null });
    } }, 2);
  } catch (error) { failure = error; }
  expect((failure as Error).message).toBe("hybrid_valid_action_missing");
  expect(calls).toBe(3);
  expect(game.world.getComponent(1, COMPONENT.Role)!.privateState.hybrid).toEqual({ remaining: 1, choice: null });
  expect(game.world.getComponent(1, COMPONENT.Victory)!.affiliations).toEqual([]);
  trace.checkpoint(captureCheckpoint(game.world, game.phaseManager.getSnapshot(), 1, false, game.phaseManager.getEvents().length, failure), game.phaseManager.getEvents());
  trace.noteFailure("cycle", failure);
  const record = trace.build({ operations: [], termination: { reason: "runtime_error", winner: null } });
  expect(record.decisions.map((decision) => ({ opened: decision.openedAfterSettlement, settle: decision.settleOrder, candidate: decision.returnedCandidate, outcome: decision.outcome }))).toEqual([
    { opened: 0, settle: 1, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
    { opened: 1, settle: 2, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
    { opened: 2, settle: 3, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
  ]);
  const root = await createTestTempDirectory("awa-returned-candidate-replay-");
  expect((await replayReproduction(record, root)).snapshot).toEqual(game.phaseManager.getSnapshot());
});

test("returned candidate: a real provider throw stays absent and old Tape2 shape still rejects foreign source", async () => {
  const { game, trace } = await fixture(), original = new TypeError("literal provider throw");
  let calls = 0;
  await expect(game.phaseManager.runSingleCycle({ getAction(request) {
    calls++;
    return trace.decide(request, { getAction: async () => { throw original; } });
  } }, 2)).rejects.toBe(original);
  expect(calls).toBe(1);
  trace.checkpoint(captureCheckpoint(game.world, game.phaseManager.getSnapshot(), 1, false, game.phaseManager.getEvents().length, original), game.phaseManager.getEvents());
  trace.noteFailure("cycle", original);
  const record = trace.build({ operations: [], termination: { reason: "runtime_error", winner: null } });
  expect(Object.hasOwn(record.decisions[0]!, "returnedCandidate")).toBe(false);
  const legacyShape = structuredClone(record); legacyShape.schemaVersion = 2;
  const root = await createTestTempDirectory("awa-returned-candidate-legacy-");
  expect((await replayReproduction(legacyShape, root)).snapshot).toEqual(game.phaseManager.getSnapshot());
  const foreign = structuredClone(legacyShape); foreign.metadata.engine.sourceHash = "0".repeat(64);
  await expect(replayReproduction(foreign, root)).rejects.toThrow("reproduction_engine_or_lock_incompatible");
});
''';write(p,s);doc['source'].append({'path':p,'expectedAbsent':True,'candidate':'candidates/'+p});paths.append(p)
# 形成完整精确正文差分；这里只进行 JSON/text 准备，不运行 parser 或产品验证。
patch=[]
for row in doc['source']:
 p=row['path'];before='' if row.get('expectedAbsent') else (out/'before'/p).read_text();after=read(p);row['afterSHA256']=hashlib.sha256(after.encode()).hexdigest();row['afterBytes']=len(after.encode());patch+=difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='/dev/null' if row.get('expectedAbsent') else 'a/'+p,tofile='b/'+p)
(out/'patch.diff').write_text(''.join(patch));doc['status']='TMP prepared only; no product/parser/compiler/test/check or repository write';doc['sharedParallelOwner']={'owner':'NativePresentation','paths':['packages/replay-contract/src/archive-envelope.ts','backend/src/recording/archive-identity.ts','packages/replay-contract/tests/archive-envelope.test.ts'],'limits':'Not produced by this author; Root must merge matching explicit fourth version parameter and wrapper descriptor policy before checks.'};doc['versions']={'writer':3,'reader':[2,3],'legacy2':'original strict shape, new field rejected','envelope':1,'strictPayload':[2,3],'publicPlayerPayload':2,'manifest':1,'sourceHash':'unchanged exact gate after parsing/semantic verification; no forward-reader claim'};doc['commands']={'firstNewUnitOnly':'bun --no-env-file test --preload ./backend/tests/setup.ts backend/tests/unit/recording/request-delivery.test.ts backend/tests/unit/recording/relationship-reproduction-ledgers.test.ts backend/tests/unit/recording/returned-candidate-replay.test.ts --test-name-pattern "^returned candidate:"','existingActualHybrid8':'bun --no-env-file test --preload ./backend/tests/setup.ts backend/tests/scenarios/failures/hybrid/required-affiliation-choice.test.ts','writerAssertionUnit':'bun --no-env-file test --preload ./backend/tests/setup.ts backend/tests/unit/recording/board-config-recording.test.ts --test-name-pattern "JSON Tape retains the normalized contribution"','writerAssertionIntegration':'bun --no-env-file test --preload ./backend/tests/setup.ts backend/tests/integration/recording/archive-identities.test.ts'}
(out/'proposal.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n');print('sources',len(doc['source']),'new1','proposal',hashlib.sha256((out/'proposal.json').read_bytes()).hexdigest())
