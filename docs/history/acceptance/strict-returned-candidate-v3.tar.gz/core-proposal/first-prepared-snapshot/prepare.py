from pathlib import Path
import json,hashlib,subprocess,difflib,re
repo=Path('/home/hby/dev/AI-Werewolf-Arena');out=Path('/tmp/awa-returned-candidate-replay-repair');base='e8837e9f0df5a5c8553ff622c3ec083f01b79f10'
paths=[
'backend/src/recording/reproduction/format.ts',
'backend/src/recording/reproduction/trace.ts',
'backend/src/app/simulation/replay-reproduction.ts',
'backend/src/recording/verification/cupid/validate.ts',
'backend/src/recording/verification/hybrid/validate.ts',
'backend/src/recording/archive-identity.ts',
'packages/replay-contract/src/archive-envelope.ts',
'backend/tests/unit/recording/request-delivery.test.ts',
'backend/tests/unit/recording/relationship-reproduction-ledgers.test.ts',
'backend/tests/unit/recording/board-config-recording.test.ts',
'backend/tests/integration/recording/archive-identities.test.ts',
'packages/replay-contract/tests/archive-envelope.test.ts',
'docs/contracts/action-requests.md',
'docs/contracts/archive-compatibility.md',
'docs/decisions/0003-request-policy-and-completion.md',
]
texts={};edits=[];sources=[]
def sha(b):return hashlib.sha256(b).hexdigest()
sharedOwnedElsewhere={paths[5],paths[6],paths[11]}
for p in paths:
 if p in sharedOwnedElsewhere:continue
 b=subprocess.check_output(['git','show',base+':'+p],cwd=repo);assert b==(repo/p).read_bytes(),p
 mode,kind,blob=subprocess.check_output(['git','ls-tree',base,'--',p],cwd=repo,text=True).split('\t',1)[0].split();assert kind=='blob'
 q=out/'before'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);texts[p]=b.decode();sources.append({'path':p,'mode':mode,'beforeBlob':blob,'beforeSHA256':sha(b),'beforeBytes':len(b),'before':'before/'+p,'candidate':'candidates/'+p})
def edit(p,a,b):
 assert texts[p].count(a)==1,(p,a[:70],texts[p].count(a));texts[p]=texts[p].replace(a,b);edits.append({'path':p,'before':a,'after':b})
p=paths[0]
edit(p,'export const REPRODUCTION_SCHEMA_VERSION = 2 as const;','export const REPRODUCTION_SCHEMA_VERSION = 3 as const;')
edit(p,'  openedAtEventCount?: number;\n  outcome:','''  openedAtEventCount?: number;
  /** 仅 Tape3 的 deferred false-close 保存已返回且安全复制的候选；缺席不是 null，也不是付款许可。 */
  returnedCandidate?: ToolCall | null;
  outcome:''')
edit(p,'  schemaVersion: typeof REPRODUCTION_SCHEMA_VERSION;','  schemaVersion: 2 | typeof REPRODUCTION_SCHEMA_VERSION;')
edit(p,'const schema = z.strictObject({\n  schemaVersion: z.literal(REPRODUCTION_SCHEMA_VERSION),','''// Tape2 保原严格字段：不接受 returnedCandidate，也不为历史 error 补造候选。
const schema2 = z.strictObject({
  schemaVersion: z.literal(2),''')
a='''/** 先保原版本／严格 envelope 准入，再按固定独立装配审核角色与板子；审核不执行游戏规则。 */'''
b='''/** Tape3 只扩充明确的返回候选事实；旧字段与 outcome 仍复用原严格结构。 */
const schema3 = schema2.extend({
  schemaVersion: z.literal(REPRODUCTION_SCHEMA_VERSION),
  decisions: z.array(
    z.preprocess(
      (value, ctx) => {
        if (value && typeof value === "object") {
          const field = Object.getOwnPropertyDescriptor(value, "returnedCandidate");
          // 新字段只接纳自身可枚举数据。继承值、accessor、undefined 不能伪装成显式 null。
          if (
            (field && (!field.enumerable || !("value" in field) || field.value === undefined)) ||
            (!field && "returnedCandidate" in value)
          ) {
            ctx.addIssue({ code: "custom", message: "reproduction_returned_candidate_invalid" });
            return z.NEVER;
          }
        }
        return value;
      },
      schema2.shape.decisions.element
        .extend({
          returnedCandidate: z
            .strictObject({ name: z.enum(TOOL_NAMES), args: jsonObject })
            .nullable()
            .optional(),
        })
        .superRefine((decision, ctx) => {
          if (
            Object.hasOwn(decision, "returnedCandidate") &&
            (decision.outcome.kind !== "error" || decision.outcome.name !== "Error")
          )
            ctx.addIssue({ code: "custom", message: "reproduction_returned_candidate_invalid" });
        }),
    ),
  ),
});

/** 先保版本／严格 envelope 准入，再按固定独立装配审核角色与板子；审核不执行游戏规则。 */'''
edit(p,a,b)
edit(p,'    value.schemaVersion !== REPRODUCTION_SCHEMA_VERSION','    value.schemaVersion !== 2 &&\n    value.schemaVersion !== REPRODUCTION_SCHEMA_VERSION')
edit(p,'  const parsed = schema.safeParse(value);','''  const selected =
    value && typeof value === "object" && "schemaVersion" in value && value.schemaVersion === 2
      ? schema2
      : schema3;
  const parsed = selected.safeParse(value);''')
edit(p,' * 输入为未知归档数据，输出为已审核的 schema 2 Tape。',' * 输入为未知归档数据，输出为已审核的 schema 2／3 Tape。') if ' * 输入为未知归档数据，输出为已审核的 schema 2 Tape。' in texts[p] else None
# 头首句在同一行，单独精准承接。
edit(p,'输入为未知归档数据，输出为已审核的 schema 2 Tape。','输入为未知归档数据，输出为已审核的 schema 2／3 Tape。')
p=paths[1]
edit(p,'      const settle = (accepted: boolean) => {\n        entry.outcome = accepted','''      const settle = (accepted: boolean) => {
        // 只在实际 false-close 保留此前 copyDecisionData 已成功返回的候选，包括 null。
        // 这份事实不把 error 改成接受；真 Provider 抛错和交付检查早抛仍不产生该字段。
        if (!accepted) entry.returnedCandidate = recordedAction;
        entry.outcome = accepted''')
edit(p,'输出为经原 schema 2 准入的 Tape 与游标。','输出为本构建 schema 3 Tape 与游标，历史读取另由格式 owner 保留。')
p=paths[2]
edit(p,'''        if (decision.outcome.kind === "error") {
          const error = new Error("reproduction_recorded_decision_failed");
          error.name = decision.outcome.name;
          reject(error);
''','''        if (decision.outcome.kind === "error") {
          // 只有 Tape3 明确保存的已返回候选才能重交；缺席不能猜成 null 或伪造接受。
          // 真正的领域检查和付款仍在原 stage 执行，外部安装故障不因此保证可以 exact 重现。
          const candidate = decision.returnedCandidate;
          if (Object.hasOwn(decision, "returnedCandidate") && candidate !== undefined)
            resolve(structuredClone(candidate));
          else {
            const error = new Error("reproduction_recorded_decision_failed");
            error.name = decision.outcome.name;
            reject(error);
          }
''')
for p,family,tool,func in [(paths[3],'cupid','choose_lovers','actionPair'),(paths[4],'hybrid','choose_exemplar','actionTarget')]:
 a=f'function {func}(decision: RecordedDecision)'
 helper='''/** 候选是回复事实，不是付款；只有旧缺席的 error／pending 仍为 unknown。 */
function recordedCandidate(decision: RecordedDecision) {
  if (decision.outcome.kind === "action") return decision.outcome.action;
  if (decision.outcome.kind === "error" && Object.hasOwn(decision, "returnedCandidate"))
    return decision.returnedCandidate;
  return undefined;
}
'''
 assert texts[p].count(a)==1;texts[p]=texts[p].replace(a,helper+a);edits.append({'path':p,'before':a,'after':helper+a})
 if family=='cupid':
  edit(p,'''  if (decision.outcome.kind !== "action" || decision.outcome.action?.name !== "choose_lovers")
    return null;
  const args = decision.outcome.action.args;''','''  const action = recordedCandidate(decision);
  if (action?.name !== "choose_lovers") return null;
  const args = action.args;''')
  edit(p,'  // 延后结算的末 error／pending 未保存候选，可由 CP／事实确定合法配对，但不能据它证明回复内容或许可。','  // 只有未保存候选的末 error／pending 可由 CP／事实约束；显式 null／无效候选不能绕过已知证据。')
 else:
  edit(p,'''  if (decision.outcome.kind !== "action" || decision.outcome.action?.name !== "choose_exemplar")
    return null;
  const target = decision.outcome.action.args.target_id;''','''  const action = recordedCandidate(decision);
  if (action?.name !== "choose_exemplar") return null;
  const target = action.args.target_id;''')
  edit(p,'  // 末 error／pending 没有序列化候选，不等于未付款；只允许 CP／事实提供合法数据，不补造权限。','  // 仅缺候选的末 error／pending 仍为 unknown；显式 null／无效目标不能用 CP／事实遮掉。')
 edit(p,'  const opaqueDecision = lastDecision !== undefined && lastDecision.outcome.kind !== "action";','  const opaqueDecision = lastDecision !== undefined && recordedCandidate(lastDecision) === undefined;')
# 两处真实当前 writer 断言，不把旧 literal/fixture 改造成新版本。
edit(paths[9],'expect(record.schemaVersion).toBe(2);','expect(record.schemaVersion).toBe(3);')
edit(paths[10],'expect(prefix.payload.schemaVersion).toBe(2);','expect(prefix.payload.schemaVersion).toBe(3);')
# 现行合同仅准确替换发生变化的选择；历史来源文件不写。
p=paths[12]
a='Trace等待真实完成通知：defer=false即时结算和deferred领域结算必须区分；settle(false)可能使decision outcome为error，不能假设returned action仍在档案中。'
b='Trace等待真实完成通知：defer=false即时结算和deferred领域结算必须区分。严格Tape3只在实际settle(false)时，保留已安全复制且正常返回的`returnedCandidate`（ToolCall或显式null）；`outcome`仍为error，不代表接受、付款或回滚。真Provider抛错／交付检查早抛没有该字段，缺席不能推断为null。Tape2保持原严格shape，不接这个字段。'
edit(p,a,b)
edit(p,'实际owner：`domain/request-lease.ts`','Tape3重放只在error且自身明确带候选时重交该事实，让原stage继续校验、重试和付款；旧缺字段仍在Provider点抛原记录错误。Cupid／Hybrid独立核验从最后一次决定读取已知候选，显式null／错工具／坏目标不能被CP或更早选择遮蔽；候选与合法部分付款前缀分别审核。此修补针对已存在的Hybrid三次未付重试消费者，不保证任意外部安装故障的exact replay。\n\n实际owner：`domain/request-lease.ts`')
p=paths[13]
edit(p,'| reproduction.json     | envelope1，strict_reproduction，内层Tape2           | 裸Tape2保精确执行检查，不自动跨构建    |','| reproduction.json     | envelope1，strict_reproduction，内层Tape3           | 保留旧裸／封装Tape2原shape；不自动跨构建 |')
texts[p]+='''

## 严格 Tape3 的返回候选事实

Tape3新增可选`returnedCandidate`，只允许在error结算中保存已返回的ToolCall或显式null。Tape2 reader保原严格decision字段，版本2带该字段仍拒绝；不把旧档迁写为3或补造缺失候选。当前reader接受合法2及3，旧reader对新3没有前向兼容承诺。未知内层版本继续拒绝。

封装自身仍为envelope1；只有`strict_reproduction`允许`payloadSchemaVersion`为2或3，并必须与payload.schemaVersion一致。公开／玩家只允许2，manifest仍1；request／presentation语义身份没有变更。writer用显式末参数声明内层版本，不提前读取unknown payload的版本getter，保完整数据检查的先后。

真实顺序是先unwrap、结构准入及独立机制审计，再检查finalized与精确source／lock等；旧reader可能在版本或结构阶段就拒新档，不能宣称所有不兼容都先报source错误。本笔源码与schema变化正常改变sourceHash，严格执行门槛未降低；合法读取旧shape不授权跨构建重放。
'''
p=paths[14]
a='现有 Tape outcome 不能同时承诺原候选和独立事务结果；本轮保持这两类既有合同，不引入新格式或全角色完成框架。未来若有具体消费者确实需要两种事实，须另行规定字段、版本、调度和失败政策。'
b='原Tape2的outcome不能同时保存返回候选和独立事务结果；这一历史限制保持，不回写旧档。后续八个真实Hybrid失败消费者暴露三次未付null重试无法exact重放：false-close覆写为error后，旧重放把第一条当Provider抛错，余下重试没有开启而进入因果死锁。该具体反例促成下面的Tape3修正，不推广全角色完成框架。'
edit(p,a,b)
texts[p]+='''

## 后继决定：严格 Tape3 保存被拒的返回候选

只在Trace实际settle(false)时保存此前安全复制成功的`returnedCandidate: ToolCall|null`，error与原结算计数不变。null是已知正常返回；字段缺席是未记录，不得猜成null。真Provider throw、copy失败或交付检查早抛不产生该字段；不增加请求、领域许可、统一付款或故障补偿框架。

重放仅在error且自身明确有候选时重交原值，原stage再次决定重试／拒绝／付款。旧无字段的error仍走原异常路径。Cupid／Hybrid的独立核验把已知null、错工具或目标与unknown严格分开，最后决定的已知冲突不能借CP或早先选择绕过；合法候选只约束原来支持的partial前缀，不证明它已经付款。

本次同时更新writer、reader和版本：新严格writer写Tape3；reader保原Tape2shape且2拒新字段，3才允许该可选事实。envelope1只为strict允许内层2／3配对，public/player2及manifest1不变。旧reader不承诺读新3；结构／机制准入先于精确source检查，sourceHash变化按原门槛处理，不改历史fixture或来源身份。

原[八个失败窗口消费者](../../backend/tests/scenarios/failures/hybrid/required-affiliation-choice.test.ts)保exact重放断言。此决定不承诺任意外部安装失败或缺候选历史档都能重现领域partial；实际CP、facts、ops与错误前缀仍是独立约束。
'''
# 后续由同目录 append-tests.py 加入必要回归；本文件仅准备，不执行验证器。
writeback={'baseCommit':base,'source':sources,'edits':edits}
for p,t in texts.items():
 q=out/'candidates'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
(out/'prepared-production-and-docs.json').write_text(json.dumps(writeback,ensure_ascii=False,indent=2)+'\n')
print('prepared production/docs',len(texts),'exact edits',len(edits))
