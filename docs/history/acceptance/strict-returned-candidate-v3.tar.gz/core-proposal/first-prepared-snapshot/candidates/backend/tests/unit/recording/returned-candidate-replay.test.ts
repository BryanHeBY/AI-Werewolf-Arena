/**
 * 单元测试负责已返回但未完成候选的原生重放边界。
 * 输入为合法六人 Hybrid、真实 Trace／PhaseManager、三次字面 null 或一个真实抛错；不接模型或网络。
 * 输出核对原库存、请求／结算序与精确失败快照；不从生产资格函数计算玩法预期。
 * 缺候选仍保旧异常语义，版本读取不豁免来源指纹；临时文件由共享测试目录 owner 清理。
 */
import { expect, test } from "bun:test";
import { bootstrapGame } from "../../../src/app/bootstrap";
import { COMPONENT, Role, WinCondition } from "../../../src/domain";
import { SessionRecordManager } from "../../../src/recording/session/recorder";
import { ReproductionTrace } from "../../../src/recording/reproduction/trace";
import type { ReproductionMetadata } from "../../../src/recording/reproduction/format";
import { beginGameReproduction, captureCheckpoint, currentEngineVersion } from "../../../src/app/simulation/reproduction-context";
import { replayReproduction } from "../../../src/app/simulation/replay-reproduction";
import { sixPlayerMvpConfig } from "../../../src/rulesets/presets/six-player-mvp";
import { createTestTempDirectory } from "../../support/drivers/temp-directories";

async function fixture() {
  const roles = [Role.Hybrid, Role.Wolf, Role.Seer, Role.Witch, Role.Villager, Role.Villager];
  const game = bootstrapGame({
    ...sixPlayerMvpConfig,
    roleSetups: [...new Set(roles)].map((role) => ({ role, count: roles.filter((value) => value === role).length })),
    winConditions: [WinCondition.SlaughterCity],
    selfDestruct: { enabledWindows: [] },
  }, { fixedRoles: roles, locale: "en" });
  const manager: SessionRecordManager = Object.create(SessionRecordManager.prototype);
  Object.defineProperty(manager, "beginReproduction", {
    value(metadata: ReproductionMetadata, liveEvents?: () => readonly import("../../../src/domain").GameEvent[]) {
      return new ReproductionTrace(metadata, () => {}, liveEvents);
    },
  });
  const trace = beginGameReproduction(manager, game, {
    engine: await currentEngineVersion(), boardId: "literal_hybrid_retry", locale: "en", maxDays: 2,
  });
  return { game, trace };
}

test("returned candidate: three real Hybrid null returns replay all retries and preserve the unpaid failure", async () => {
  const { game, trace } = await fixture();
  let calls = 0, failure: unknown;
  try {
    await game.phaseManager.runSingleCycle({ getAction(request) {
      calls++;
      return trace.decide(request, { getAction: async () => null });
    } }, 2);
  } catch (error) { failure = error; }
  expect((failure as Error).message).toBe("hybrid_valid_action_missing");
  expect(calls).toBe(3);
  expect(game.world.getComponent(1, COMPONENT.Role)!.privateState.hybrid).toEqual({ remaining: 1, choice: null });
  expect(game.world.getComponent(1, COMPONENT.Victory)!.affiliations).toEqual([]);
  trace.checkpoint(captureCheckpoint(game.world, game.phaseManager.getSnapshot(), 1, false, game.phaseManager.getEvents().length, failure), game.phaseManager.getEvents());
  trace.noteFailure("cycle", failure);
  const record = trace.build({ operations: [], termination: { reason: "runtime_error", winner: null } });
  expect(record.decisions.map((decision) => ({ opened: decision.openedAfterSettlement, settle: decision.settleOrder, candidate: decision.returnedCandidate, outcome: decision.outcome }))).toEqual([
    { opened: 0, settle: 1, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
    { opened: 1, settle: 2, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
    { opened: 2, settle: 3, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
  ]);
  const root = await createTestTempDirectory("awa-returned-candidate-replay-");
  expect((await replayReproduction(record, root)).snapshot).toEqual(game.phaseManager.getSnapshot());
});

test("returned candidate: a real provider throw stays absent and old Tape2 shape still rejects foreign source", async () => {
  const { game, trace } = await fixture(), original = new TypeError("literal provider throw");
  let calls = 0;
  await expect(game.phaseManager.runSingleCycle({ getAction(request) {
    calls++;
    return trace.decide(request, { getAction: async () => { throw original; } });
  } }, 2)).rejects.toBe(original);
  expect(calls).toBe(1);
  trace.checkpoint(captureCheckpoint(game.world, game.phaseManager.getSnapshot(), 1, false, game.phaseManager.getEvents().length, original), game.phaseManager.getEvents());
  trace.noteFailure("cycle", original);
  const record = trace.build({ operations: [], termination: { reason: "runtime_error", winner: null } });
  expect(Object.hasOwn(record.decisions[0]!, "returnedCandidate")).toBe(false);
  const legacyShape = structuredClone(record); legacyShape.schemaVersion = 2;
  const root = await createTestTempDirectory("awa-returned-candidate-legacy-");
  expect((await replayReproduction(legacyShape, root)).snapshot).toEqual(game.phaseManager.getSnapshot());
  const foreign = structuredClone(legacyShape); foreign.metadata.engine.sourceHash = "0".repeat(64);
  await expect(replayReproduction(foreign, root)).rejects.toThrow("reproduction_engine_or_lock_incompatible");
});
