# Tape3 返回候选：TMP 冻结候选

## 范围与实际失败

本作者仅准备 5 个生产源、2 个已有单元测试尾部的 5 个新声明、1 个新集成文件的 2 个声明、2 处当前 writer 版本字面预期及 3 份当前合同文档，共 13 路径。base 为 `e8837e9f0df5a5c8553ff622c3ec083f01b79f10`；12 个现有源保存完整 Git before，新的集成路径固定为 absent。没有仓库写入或任何产品、解析器、编译器、格式化、测试和门禁执行。

真实首证是 Root 在旧 cb02260b 全场景中观测的 Hybrid required-affiliation-choice 八个失败：正常返回 null 被 deferred false 结算记为 error，旧 Replay 在 Provider 点抛错而没有开启剩余两个真实重试，因果调度最终死锁。原八个场景及其 exact-replay 断言全部保持。本包没有声称新回归已执行。

## 版本和事实合同

- 新 writer 写严格 Tape3；reader 保原严格 Tape2 字段，2 仍拒 `returnedCandidate`，3 才允许可选新事实。
- 仅实际 settle(false) 保存此前 `copyDecisionData` 成功复制的 ToolCall 或显式 null；outcome:error、错误名及原结算计数保持。真 Provider/copy/交付早抛无字段；true 结算也无字段。
- false 可以来自 null/无效输入、当前性/期限或 partial。字段证明正常返回，不证明拒绝原因、领域接受、付款、补偿或任意外部故障 exact replay。
- Replay 只在 error 且自身有候选时重交该事实；旧缺席仍在 Provider 点抛原错误，绝不补 null。
- Cupid/Hybrid 沿同一族入口读取最后候选：action 或 error+own candidate 为 known；缺席才 opaque。已知 null、坏工具和冲突目标不能用 CP/更早选择洗掉；候选仍不证明付款。
- schema3 新字段要求自身可枚举数据，拒 undefined/accessor/inherited、非 ToolCall、非 JSON args；仅原 false-close 的 Error outcome 可以携带。schema2 原 decision 结构不扩。
- 版本先由原一次 in/一次 get 捕获，再选 schema；legacy2 后续原 Zod getter/第一失败点不额外增加读取。
- 外层 envelope1、public/player2、manifest1、request/presentation 身份不变。NativePresentation 独占共享 envelope、backend archive identity 和它们的回归；Root 必须合并其显式第四版本参数接口再执行。本包不冒共享源已由本作者写完。
- 实际读取顺序是 unwrap→结构/独立语义审核→finalized→精确 source/lock，旧 reader 可先结构拒绝新3。旧 shape 可读不代表跨构建可执行；历史 fixture 不重写。

## 新回归与执行边界

`proposal.json.commands.firstNewRegressionsOnly` 是 4 个 request-delivery 声明 + 1 个独立关系账本声明 + 2 个真实录制/引擎集成声明，合计 7 个新声明。所有只调用现有公开 Trace/parse/replay/manager 入口，不导入仅新实现才存在的 helper，可由 Root 在旧实现先运行选定首证。

集成用真实 `beginGameReproduction`→`SessionRecordManager`→`runWithSessionRecorder`→`PhaseManager.runSingleCycle`→最终档→`readReproduction`→`replayReproduction`，并保留实际 recorder 操作，不手工构造空 operations。合法六人 Hybrid；正常 null 三次和真 TypeError 一次分别核字面轨迹、库存、错误与实际重放；历史2 shape同构建读取/重放与 foreign source拒绝单列，不称跨构建保证。

两个已有单元文件原完整正文不改，只加 import/尾部声明；既有 writer 两处 2→3 是有意格式预期变化，不能称原 JS 同。旧场景不改 oracle。Root 可先只新增有界 filter，再原八消费者；所有命令均 `bun --no-env-file`。本作者没有执行这些命令。

## 首准备与静态修订

`first-prepared-snapshot/` 保留此前完整候选/proposal/patch及原准备脚本：其版本选择重复读和新集成归属是 Root 静态 finding；原 stub/manual operations 是作者静态装配修订，均未执行，不是运行红。`static-preparation-repairs.json` 保存三个精确前后全文；末包还收窄 false原因说明并将新候选工具接入原同族分类。原准备脚本是历史输入，不是本包应用器，不能重跑来覆末候选。

`exact-edits.json` 是 13 路径全部实际 UTF-8 字节绑定与 Unicode 字符坐标编辑；`patch.diff`/完整 candidate 共同可审。仅用 stdlib 文本重建校准差分；没有 AST/类型/双 emit 或玩法证明执行。机器字面、未知版本拒绝、原结算顺序和 sourceHash 门槛均由 Root 后续真实检查验证，不预先宣布绿。
