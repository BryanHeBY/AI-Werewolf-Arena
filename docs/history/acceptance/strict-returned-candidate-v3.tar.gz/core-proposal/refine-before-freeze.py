from pathlib import Path
import json,hashlib,shutil,difflib
out=Path('/tmp/awa-returned-candidate-replay-repair')
first=out/'first-prepared-snapshot'
assert not first.exists()
first.mkdir()
for name in ['proposal.json','patch.diff','prepared-production-and-docs.json','prepare.py','append-tests.py']:
 shutil.copy2(out/name, first/name)
shutil.copytree(out/'candidates',first/'candidates')
def read(p):return (out/'candidates'/p).read_text()
def write(p,s):q=out/'candidates'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
p='backend/src/recording/reproduction/format.ts';s=read(p)
a='''  if (
    value &&
    typeof value === "object" &&
    "schemaVersion" in value &&
    value.schemaVersion !== 2 &&
    value.schemaVersion !== REPRODUCTION_SCHEMA_VERSION
  )
    throw new Error("reproduction_schema_not_supported");
  const selected =
    value && typeof value === "object" && "schemaVersion" in value && value.schemaVersion === 2
      ? schema2
      : schema3;
'''
b='''  let version: unknown;
  if (value && typeof value === "object" && "schemaVersion" in value) {
    // 保历史裸 Tape2 的一次 in／一次预检读取；schema 选择不再次触发 caller getter。
    version = value.schemaVersion;
    if (version !== 2 && version !== REPRODUCTION_SCHEMA_VERSION)
      throw new Error("reproduction_schema_not_supported");
  }
  const selected = version === 2 ? schema2 : schema3;
'''
assert s.count(a)==1;s=s.replace(a,b);write(p,s)
p='backend/tests/unit/recording/request-delivery.test.ts';s=read(p);s+='''

test("returned candidate: legacy Tape2 keeps one version precheck read and the original schema read", async () => {
  const { trace, request } = fixture();
  await trace.decide(request, { getAction: async () => null });
  const legacy = trace.build(); legacy.schemaVersion = 2;
  let reads = 0;
  Object.defineProperty(legacy, "schemaVersion", { enumerable: true, configurable: true, get() { reads++; return 2; } });
  expect(parseReproductionRecord(legacy).schemaVersion).toBe(2);
  expect(reads).toBe(2);
  const changesVersion = trace.build();
  reads = 0;
  Object.defineProperty(changesVersion, "schemaVersion", { enumerable: true, get() { return ++reads === 1 ? 2 : 3; } });
  expect(() => parseReproductionRecord(changesVersion)).toThrow("reproduction_record_invalid");
  expect(reads).toBe(2);
});
''';write(p,s)
old='backend/tests/unit/recording/returned-candidate-replay.test.ts'
p='backend/tests/integration/recording/returned-candidate-replay.test.ts'
(out/'candidates'/old).unlink()
s='''/**
 * 集成测试负责已返回但未完成候选的真实录制／阶段／重放接线。
 * 输入为合法六人 Hybrid、SessionRecordManager 与三次字面 null 或一个真实抛错；不接模型或网络。
 * 原 SessionRecorder 上下文收集必需领域操作，终结档仍由实际 manager 生成，不手工删去 operations。
 * 输出核对原库存、请求／结算序与精确失败快照；缺候选仍保旧异常，历史 shape 不豁免来源指纹。
 * 夹具目录由共享测试 owner 清理，不从生产资格函数计算玩法预期。
 */
import { expect, test } from "bun:test";
import path from "node:path";
import { bootstrapGame } from "../../../src/app/bootstrap";
import { COMPONENT, Role, WinCondition } from "../../../src/domain";
import { SessionRecordManager } from "../../../src/recording/session/recorder";
import { runWithSessionRecorder } from "../../../src/recording/session/context";
import { beginGameReproduction, captureCheckpoint, currentEngineVersion } from "../../../src/app/simulation/reproduction-context";
import { readReproduction, replayReproduction } from "../../../src/app/simulation/replay-reproduction";
import { sixPlayerMvpConfig } from "../../../src/rulesets/presets/six-player-mvp";
import { createTestTempDirectory } from "../../support/drivers/temp-directories";

async function failedRecord(original?: Error) {
  const roles = [Role.Hybrid, Role.Wolf, Role.Seer, Role.Witch, Role.Villager, Role.Villager];
  const game = bootstrapGame({
    ...sixPlayerMvpConfig,
    roleSetups: [...new Set(roles)].map((role) => ({ role, count: roles.filter((value) => value === role).length })),
    winConditions: [WinCondition.SlaughterCity],
    selfDestruct: { enabledWindows: [] },
  }, { fixedRoles: roles, locale: "en" });
  const manager = await SessionRecordManager.create({
    sessionId: "literal-hybrid-retry", board: "literal_hybrid_retry", locale: "en",
    startedAtIso: "2026-10-15T00:00:00.000Z",
  }, await createTestTempDirectory("awa-returned-candidate-record-"));
  let calls = 0, failure: unknown;
  await runWithSessionRecorder(manager, async () => {
    const trace = beginGameReproduction(manager, game, {
      engine: await currentEngineVersion(), boardId: "literal_hybrid_retry", locale: "en", maxDays: 2,
    });
    try {
      await game.phaseManager.runSingleCycle({ getAction(request) {
        calls++;
        return trace.decide(request, { getAction: async () => { if (original) throw original; return null; } });
      } }, 2);
    } catch (error) { failure = error; }
    trace.checkpoint(captureCheckpoint(game.world, game.phaseManager.getSnapshot(), 1, false, game.phaseManager.getEvents().length, failure), game.phaseManager.getEvents());
    manager.noteReproductionFailure("cycle", failure);
    // 与真实失败驱动一致：保留 manager 收集的完整操作，不能用空数组替代录制装配。
    await manager.finalize({ endedAtIso: "2026-10-15T00:01:00.000Z", winner: null, finishReason: "runtime_error", players: [] });
  });
  const record = await readReproduction(path.join(manager.sessionDir, "reproduction.json"));
  return { game, record, failure, calls };
}

test("returned candidate: three real Hybrid null returns replay all retries and preserve the unpaid failure", async () => {
  const { game, record, failure, calls } = await failedRecord();
  expect((failure as Error).message).toBe("hybrid_valid_action_missing");
  expect(calls).toBe(3);
  expect(game.world.getComponent(1, COMPONENT.Role)!.privateState.hybrid).toEqual({ remaining: 1, choice: null });
  expect(game.world.getComponent(1, COMPONENT.Victory)!.affiliations).toEqual([]);
  expect(record.decisions.map((decision) => ({ opened: decision.openedAfterSettlement, settle: decision.settleOrder, candidate: decision.returnedCandidate, outcome: decision.outcome }))).toEqual([
    { opened: 0, settle: 1, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
    { opened: 1, settle: 2, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
    { opened: 2, settle: 3, candidate: null, outcome: { kind: "error", code: "decision_failed", name: "Error" } },
  ]);
  const root = await createTestTempDirectory("awa-returned-candidate-replay-");
  expect((await replayReproduction(record, root)).snapshot).toEqual(game.phaseManager.getSnapshot());
});

test("returned candidate: a real provider throw stays absent and old Tape2 shape still rejects foreign source", async () => {
  const original = new TypeError("literal provider throw");
  const { game, record, failure, calls } = await failedRecord(original);
  expect(failure).toBe(original);
  expect(calls).toBe(1);
  expect(Object.hasOwn(record.decisions[0]!, "returnedCandidate")).toBe(false);
  const legacyShape = structuredClone(record); legacyShape.schemaVersion = 2;
  const root = await createTestTempDirectory("awa-returned-candidate-legacy-");
  expect((await replayReproduction(legacyShape, root)).snapshot).toEqual(game.phaseManager.getSnapshot());
  const foreign = structuredClone(legacyShape); foreign.metadata.engine.sourceHash = "0".repeat(64);
  await expect(replayReproduction(foreign, root)).rejects.toThrow("reproduction_engine_or_lock_incompatible");
});
''';write(p,s)
doc=json.loads((out/'proposal.json').read_text());doc['source'][-1]['path']=p;doc['source'][-1]['candidate']='candidates/'+p
# 新集成路径也固定检查 actual base absence，而不是以旧准备路径的 absence 替代。
import subprocess
assert not subprocess.check_output(['git','ls-tree',doc['baseCommit'],'--',p],cwd='/home/hby/dev/AI-Werewolf-Arena')
# 保留首稿原差分，把未执行的修订作为独立精确后继，不能暗称首稿已校验。
repairs=[]
for path in ['backend/src/recording/reproduction/format.ts','backend/tests/unit/recording/request-delivery.test.ts',p]:
 before=(first/'candidates'/path).read_text() if (first/'candidates'/path).exists() else (first/'candidates'/old).read_text()
 after=read(path);repairs.append({'path':path,'priorPreparedPath':old if path==p else path,'beforeSHA256':hashlib.sha256(before.encode()).hexdigest(),'afterSHA256':hashlib.sha256(after.encode()).hexdigest(),'before':before,'after':after})
(out/'static-preparation-repairs.json').write_text(json.dumps({'status':'static findings before any execution, not runtime reds','changes':['Root: preserve original Tape2 version in/get/read count','Root: integration ownership for real engine/filesystem/replay regression','Author: collect real required operations through SessionRecordManager context, rather than manual operations:[]'],'source':repairs},ensure_ascii=False,indent=2)+'\n')
for edit in doc['edits']:
 if edit['path']=='backend/src/recording/reproduction/format.ts' and edit['before']=='    value.schemaVersion !== REPRODUCTION_SCHEMA_VERSION':
  edit['before']='''  if (
    value &&
    typeof value === "object" &&
    "schemaVersion" in value &&
    value.schemaVersion !== REPRODUCTION_SCHEMA_VERSION
  )
    throw new Error("reproduction_schema_not_supported");'''
  edit['after']='''  let version: unknown;
  if (value && typeof value === "object" && "schemaVersion" in value) {
    // 保历史裸 Tape2 的一次 in／一次预检读取；schema 选择不再次触发 caller getter。
    version = value.schemaVersion;
    if (version !== 2 && version !== REPRODUCTION_SCHEMA_VERSION)
      throw new Error("reproduction_schema_not_supported");
  }'''
 if edit['path']=='backend/src/recording/reproduction/format.ts' and edit['before']=='  const parsed = schema.safeParse(value);':
  edit['after']='  const selected = version === 2 ? schema2 : schema3;\n  const parsed = selected.safeParse(value);'
doc['commands']['firstNewUnitOnly']=doc['commands'].pop('firstNewUnitOnly').replace('backend/tests/unit/recording/returned-candidate-replay.test.ts','backend/tests/integration/recording/returned-candidate-replay.test.ts')
doc['commands']['firstNewRegressionsOnly']=doc['commands'].pop('firstNewUnitOnly')
doc['staticPreparationRepairs']='static-preparation-repairs.json'
doc['newDeclarations']={'request-delivery.test.ts':4,'relationship-reproduction-ledgers.test.ts':1,'integration/recording/returned-candidate-replay.test.ts':2,'total':7,'executed':0}
patch=[]
for row in doc['source']:
 p=row['path'];before='' if row.get('expectedAbsent') else (out/'before'/p).read_text();after=read(p);row['afterSHA256']=hashlib.sha256(after.encode()).hexdigest();row['afterBytes']=len(after.encode());patch+=difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='/dev/null' if row.get('expectedAbsent') else 'a/'+p,tofile='b/'+p)
(out/'patch.diff').write_text(''.join(patch));(out/'proposal.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
print('prepared paths',len(doc['source']),'newDeclarations7; no product/check execution')
