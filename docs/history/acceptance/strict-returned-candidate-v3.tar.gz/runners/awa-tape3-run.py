from pathlib import Path
import hashlib,json,subprocess,time,sys
root=Path('/home/hby/dev/AI-Werewolf-Arena');stage=sys.argv[1];out=Path('/var/tmp/awa-refactor-20261015/tape3-execution')/stage;out.mkdir(parents=True);runtime=out/'runtime'
for n in ['home','cache','config','state','tmp']:(runtime/n).mkdir(parents=True,exist_ok=True)
groups={
'hybrid-eight':['tests/scenarios/failures/hybrid/required-affiliation-choice.test.ts'],
'writer-contracts':['tests/unit/recording/board-config-recording.test.ts','tests/integration/recording/archive-identities.test.ts','--test-name-pattern','JSON Tape retains the normalized contribution|^actual initial prefix final and export write|^current explicit strict envelope performs'],
'late-prefixes':['tests/scenarios/failures/pure-white/required-inspection-response.test.ts','tests/scenarios/failures/order-prince/late-committed-prefix.test.ts','--test-name-pattern','^(pure_white_girl/late/llm:|wolf_witch/late/acp:|Order Prince late order_prince_choice/(llm|acp) preserves committed state$)']}
cmd=['/usr/bin/bun','--no-env-file','test','--preload','./tests/setup.ts',*groups[stage]];env={'PATH':'/usr/bin:/bin','HOME':str(runtime/'home'),'XDG_CACHE_HOME':str(runtime/'cache'),'XDG_CONFIG_HOME':str(runtime/'config'),'XDG_STATE_HOME':str(runtime/'state'),'TMPDIR':str(runtime/'tmp'),'LANG':'C.UTF-8','CI':'1','NO_COLOR':'1','FORCE_COLOR':'0','TZ':'UTC'};manifest=json.loads(Path('/tmp/awa-tape3-execution/formatted-candidates.json').read_text())
def fence():return {r['path']:hashlib.sha256((root/r['path']).read_bytes()).hexdigest() for r in manifest['orderedSource']}
before=fence();assert before=={r['path']:r['formattedSha256'] for r in manifest['orderedSource']};(out/'launch.json').write_text(json.dumps({'argv':cmd,'cwd':str(root/'backend'),'environment':env,'before':before,'scope':stage,'base':manifest['base'],'limits':'focused modified-scope or concrete late-failure regression; not a full C47 gate'},indent=2)+'\n');start=time.time()
with (out/'stdout.raw').open('wb') as a,(out/'stderr.raw').open('wb') as b:r=subprocess.run(cmd,cwd=root/'backend',env=env,stdout=a,stderr=b,timeout=360)
after=fence();result={'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'all17SourcesUnchanged':before==after,'after':after};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));sys.exit(r.returncode or (0 if before==after else 2))
