# returnedCandidate：已选 Tape3 版本政策

Root 已明确选择内部严格 Tape 新写入升3；reader 保原2 strict形状并拒2携带新字段。共享 envelope 仍1，只有strict支持payload2/3且与内层一致；公开／玩家2、manifest1不变。此方案把结构版本与sourceHash分开，符合plan§11.3/§19.4的版本责任。

`createRecordingEnvelope` 的新末参默认2，backend strict入口晚传 `record.schemaVersion`，不提前读取unknown payload getter。解析拒绝仍先于source/lock检查，不能把旧reader前向拒绝都描述成engine-incompatible。

新证据只能来自settle(false)后的原候选，error仍error，own null不等缺席，throw/早guard无字段；两族CP受已知候选约束而不视作付款。8原exact断言保，任意partial故障支持不扩大。

这里只审版本决定，尚未批准实现或运行；待NativeFinal冻结后增量审。原schema2考虑稿保存在 `schema2-consideration-before-root-decision.*`，不作当前政策。
