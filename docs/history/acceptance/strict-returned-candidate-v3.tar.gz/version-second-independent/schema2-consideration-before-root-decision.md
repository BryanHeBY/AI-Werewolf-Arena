# returnedCandidate：版本与兼容合同静态结论

固定已发布来源 `e8837e9f…`。本审只读，尚未批准实现。

## 结论

没有发现一定要改公共 replay/envelope 或强制升 Tape3 的可执行硬约束。Root 可明确选择 **Tape2 的可选 error 证据扩展、新 reader 向后读旧、旧 reader 不承诺读新**。这是真实 shape 变化，需要同笔 writer、reader、版本判定与拒绝政策；不能以“内部字段”或新 sourceHash 宣称无格式影响。

现 ADR0003 写“本轮不引入新格式”，必须明确由本次有界后继取代；plan§11.3/§19.4 的格式责任也须正面落实。保2不是自动兼容豁免。

## 必须写准的旧 reader 行为

当前 `format.ts:455/470` 使用 strictObject；旧 reader 读新字段会先在 `parseReproductionRecord:773` 报 `reproduction_record_invalid`。`replay-reproduction.ts:233` 先 parse，`:245` 才查 source/lock。不能声称旧 reader 必先由指纹报 engine-incompatible。新 build 精确身份检查仍完整保留，但不是前置 schema 验证的替代。

## 新证据边界

只在真实候选已返回、复制与原 delivery 检查成功后的 settle(false)保存 ToolCall|null；outcome 仍error。own null 与无字段不同，真实throw/早guard无字段；Replay只在error且ownpresence时交回原候选，其余旧error原抛。两族须用已知null/invalid/target约束CP，不能当付款。

普通raw action、Radiant args:{}失败、旧opaque支持及source/lock/RNG/ruleset均保；不承诺任意getter/部分安装错误exact。Root的8原exact断言不能降成expect deadlock。

详源与行号、兼容矩阵、候选检查项见report.json。
