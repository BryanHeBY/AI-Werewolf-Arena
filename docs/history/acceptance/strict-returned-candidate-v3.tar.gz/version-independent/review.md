# returnedCandidate 的版本与证据边界（静态审查）

## 版本结论

现行计划不能只用“sourceHash 变了”推导 Tape2 可任意扩展。计划 §11.3 分开构建身份与归档结构，要求实际 shape 变化同笔落实 writer、reader、版本判定以及精确迁移／拒绝政策；§19.4 还要求已发布格式修正明确版本与迁移。

保留 Tape2 可以作为本次明确批准的新兼容决定：把它界定为精确构建身份约束的格式家族，仅增加可选的 Provider 正常返回事实；新 reader 保持旧字段与旧形状解析，旧 reader 对新字段可先结构拒绝，新执行器对旧 source／lock 仍拒绝。完整约束为 `(schemaVersion=2, sourceHash, lockHash)`，不承诺旧 reader 前向读取或跨构建执行。这不是现有文本已经明定的扩展政策。若不批准这项决定，strict 内层升3是最无歧义方案，公开 Replay／player 的2不因此必须联动。

## 最小消费约束

- `returnedCandidate` 只说明 Provider 曾正常返回且完成原安全复制／delivery guard；它不说明 accepted、付款或授权。
- false 后 outcome 仍为 error，正常 settlement 次序和通知错误前缀不改。true、真实 throw、复制／guard 早抛没有此字段。
- 必须用 own-data presence 区分缺席与显式 null；undefined、accessor、继承字段不算候选。候选沿原 ToolCall／JSON args 结构，不额外要求属于本请求 allowedTools。
- Replay 只对 error 且字段实际存在重交候选；旧 error 缺字段仍抛原拒绝。所有请求／因果／来源以及 CP、事件、操作精确比较照旧。
- Cupid／Hybrid 独立账本应把已有候选当已知回复，而非 opaque；末次已知 null／无效／冲突候选不能解释相反付款。候选仍不能替代关系／归属、失败写前缀和事实审核。

## 范围

没有运行任何产品、parser、类型、测试、门禁或探针；没有仓库写入。此稿只读当前原实现和现行合同，尚未审核 NativeFinal 待交的实现候选。Provider 合同外任意 malformed 值、任意外部故障的严格重现均不能据此宣称兼容。
