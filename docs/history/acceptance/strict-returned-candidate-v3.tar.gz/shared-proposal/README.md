# 严格 Tape 3 的共享封装候选（仅 TMP）

## 范围

真实基线 `e8837e9f0df5a5c8553ff622c3ec083f01b79f10`。三个既有源和四个控制均已保完整 Git/current 原文；新 wrapper 单元文件在原 Git/current 均缺席。四个候选与逐条原文差分位于 `candidates/`、`edits.json`、`candidate.patch`。未写仓库，也未执行候选、格式器、解析器、类型、测试或门禁。

## 版本与顺序

- envelope 保持 1；严格内层接受 2／3，公开和玩家内层仍只接受 2，manifest 仍为内联 1。
- 统一 reader 保原纯数据检查 → 外声明 → 身份 → payload 顺序，并要求外声明与内层版本相等。
- `createRecordingEnvelope` 的第 4 个显式版本参数默认 2，不从未知 payload 提前读取版本。
- 严格 backend wrapper 先完成原 `currentRecordingIdentities(record.metadata)`，随后只通过自身描述符的 data 值选择 3；其余仍声明 2，交原统一检查拒绝坏数据。该描述符反射可触发 Proxy trap；新增观察点及 imported callee 读取次序变化均为有意版本选择差异，不承诺任意反射等价。
- Tape 2／3 严格 shape、新证据采集／重放和两族 verifier 由 NativeFinal 的互斥切片提供；本包不复制这些算法。

## 测试候选

原共享包测试正文逐字保留，只改两句维护头并追加 3 个声明。新 backend 文件有 2 个声明。手写最小数据仅证明封装和 wrapper 的版本、缺参默认、配对拒绝和 getter／错误顺序边界，不冒完整 Tape 或真实游戏输入。源码推导的新增期望执行次数为 15＋10，**尚未运行**。

Root 后续整合时再固定共同 source fence 并执行必要检查；本交接不提供绿色收据。不会修改历史 fixture bytes。
