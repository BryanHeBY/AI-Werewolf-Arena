# Hybrid 旧伪造负例的准确拒绝层（TMP）

Root 实际八个回归均已越过第216行的精确 snapshot 比较，失败在原第221行伪造档案的错误字符串断言。原 e883 的独立 Hybrid validator 已要求每个首夜请求 `allow_fallback === false`；`replayReproduction` 在重放请求观察前先 parse 和执行独立审核。因此 false→true 篡改应由现有 `reproduction_hybrid_state_invalid` 拒绝，不会走到后层的 `reproduction_observation_mismatch`。

本候选只把这一处旧期待字符串改为已存在的独立审核错误，并加一条中文说明。false→true 篡改、await rejects、原八个标题和全部正面 exact/库存/隐藏归属/noFallback/传输断言均保持；不改 validator、parser、付款或任何生产。原场景全文与 actual e883 Git 相同，完整 before/candidate、精确单范围正逆和首 raw hash均保。

这是旧负例对错误层的期待不准确，之前因因果死锁早停而未到达；不是降低拒绝、吞错或修改玩法。新候选没有执行产品、解析器、编译器、formatter、测试或门禁，也没有写仓库。Root 后继应用/执行与第三方审查独立登记，不把此静态候选当通过。
