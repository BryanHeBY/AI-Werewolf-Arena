# 夜阶段公开输入与完整内建 owner

本目录是 TMP 准备候选，尚未应用或执行产品／解析器／类型／头检查／测试／证明。实际前态固定在 `source-ready.json` 的完整 Git；早期 8dd 原稿、pilot 和被否决的组件返回端口草稿另保，不用后者应用。

## 实际职责

- 34 个机制模块保留完整原阶段算法，定义时保存真实 handler 与原 execute 双引用；此表不持运行 World。流水线在原 execute 读取点取一次 callee，组合根按双引用分派，原 receiver 保留。
- 完整内建程序是可信资源 owner，World、原组件、Catalog、events、requestFactory、nightActors 和整夜提案只停留在私有 runtime。替换的 execute、同 id 外来定义均拿到实际窄对象；没有通用 getWorld／withWorld／反查 runtime token。
- 公开对象只提供请求／bound action validation、编号查询和显式具体命令。Provider 也由仅 getAction 的实际对象代理。合成毒印、旧觉醒提案、已付 Dream 探针及 Gravekeeper 完整反馈委托各有真实具体 owner；不返回组件、提案数组或 World。
- 可覆写 registry 的 World 第二参数退休，改为 cold-bound 编号／布尔／kind 查询；原收集器仍拥有完整收集、预约、去重、来源和排序算法。kind 原两次读取位置保留，新增数组投影与方法调用是新 API 可观察面。
- Mechanical／Awakened owner scope 不再公开 World；捕获类私字段在原绑定比较点使用。原 paid isCurrent／skill／effect 逻辑不增加退休旗；手造结构 scope-with-World 接受面有意退出。

## 调用与兼容

`NightStageHandler` 是可替换公开 callback；计划保存 `NightStageDefinition` 原引用。直接向内建 `.execute` 传原公共 raw ctx 的扩展调用方式退休，生产由 NightPipeline 调用；测试可信 fixture 经 `executeNightStage(handler)(runtime)` 走同一真实分派，callee 仍先于 runtime 参数求值。没有新兼容 rawWorld 入口。

`bindNightStageAlias` 仅由可信组合根显式关联已知完整行为；不按机器 id／priority 授权。Ghost priority clone 的 Map.set 成功后才登记来源。完整算法仍在机制模块；没有新逐角色 run-forwarder。静态 owned table 新增模块依赖／定义引用捕获，Reflect 准备、公开 facade、别名和捕获类是明确 API 变化，不能称任意 Proxy／全局 monkeypatch／冷加载完全等价。

57 个测试／support 文件仅适配真实执行入口、collector 参数和明确 fixture 注入。四个原 custom 场景取得具体操作；另赠枪 custom 场景以自己原先持有的 fixture World／sink 写入，不由 engine ctx 提供。registry identity 测试改核实际 query 对象，不冒所有断言逐字不变。H03 三夜 scope 和 learned test invokeValidationRule 后继已保留。

## Root 集成

1. `source-ready.json` 50 生产＋57 测试/support，3 新 absent；before-current 与 before-git 完整保存，采样时 own physical 均同 Git。外部 death-hook WIP 不在本 scope。
2. `roles/contracts.ts` 与 `rule-plan.ts` **只应用 root-shared-edits.json 的三段精确差异**，不覆盖 Root 后继完整文件。其它文件用候选，三 H03 scope 不重复应用。
3. 4 个新增 unit 声明：原赠枪完整内建执行、替换 getter callback 真实窄对象／receiver、同名同函数外来 handler 不能拿私有输入、显式合成伤害只取得 void command。尚无结果。
4. Root 统一对合流后实际源码运行有限头／完整 backend test 类型入口与必要回归；作者未运行旧绿或新检查。
5. `prove.cjs` 仅准备供 Root 单次执行：完整精确正逆、34机制原完整 body 的 AST／NodeArray／非注释 token、原/新 ESNext 与 CJS 全输出存档。它明确不声称新公开绑定等程序全等，未执行。

建议首命令（Root）:

```sh
bun --no-env-file test backend/tests/unit/engine/night-stage-query-command-boundary.test.ts
bun --no-env-file /tmp/awa-h02-night-stage-owner-implementation/prove.cjs --repo /home/hby/dev/AI-Werewolf-Arena
```

类型与头请合并 Root 当前全组安排，避免中间态重复。真实结果后再生成正式仓库证据；本 handoff 不预填通过。
