from pathlib import Path
import json,re,os
R=Path('/home/hby/dev/AI-Werewolf-Arena');D=Path('/tmp/awa-h02-night-stage-owner-implementation');W=Path('/tmp/awa-h02-night-stage-ports-implementation/candidates')
def save(path,s):
 p=D/'candidates'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
# Reuse only already prepared exact caller adaptations, not the superseded component-returning ports.
paths=json.load(open('/tmp/awa-h02-night-stage-ports-implementation/fixture-callers.json'))
for path in paths:save(path,(W/path).read_text())
path='backend/tests/support/builders/night-stage-context.ts';s=(R/path).read_text()
s=s.replace('import type { NightStageContext } from "../../../src/engine/night/contracts";','import type { TrustedNightStageRuntime as NightStageContext } from "../../../src/engine/night/trusted-runtime";\nimport type { NightStageHandler } from "../../../src/engine/night/contracts";\nimport { executePreparedNightStage } from "../../../src/rulesets/night-stage-bindings";')
s=s.replace('import { ToolGateway }','import { createBoundToolGateway, ToolGateway }')
s=s.replace('    toolGateway: new ToolGateway(),','    toolGateway: new ToolGateway(),\n    get actions() { return createBoundToolGateway(() => this.toolGateway, () => this.world); },')
s=s.replace('负责测试中构造内存夜间上下文和提取已完成摘要。输入为明确 World／Provider 覆盖；输出保留 typed 阶段端口和原 World getter 时点，未配置依赖直接抛错。本 builder 不拥有规则预期、不改 fixture、不运行完整对局。','负责测试可信装配输入与已完成摘要。fixture 可持原 World／状态，但执行可替换 handler 必须走实际程序身份绑定；未配置依赖原样抛错。此对象不是公开 NightStageContext，不拥有规则预期或运行整局。')
s+='''
/** 原 .execute 点先准备同一函数，fixture 参数后求值；实际 receiver 和可信程序／公开 callback 分界走生产 owner。 */
export function executeNightStage<P extends object>(handler: NightStageHandler<P>): (runtime: NightStageContext) => Promise<void> {
  const callee = handler.execute;
  return (runtime) => executePreparedNightStage(handler, callee, runtime);
}
''';save(path,s)
# Exact object extent selector for these fixed source literals; this is text preparation, not a TypeScript parser/check.
def close(s,start):
 stack=[];quote=None;esc=False
 for k in range(start,len(s)):
  c=s[k]
  if quote:
   if esc:esc=False
   elif c=='\\':esc=True
   elif c==quote:quote=None
   continue
  if c in "\"'`":quote=c;continue
  if c in '{[(':stack.append(c)
  elif c in '}])':
   stack.pop()
   if not stack:return k
 raise Exception('missing delimiter')
def wrap(s,ident,fn,source=None):
 marker='id: "'+ident+'"';i=s.index(marker);a=s.rfind('{',0,i);b=close(s,a)
 return s[:a]+fn+'('+s[a:b+1]+(', '+source if source else '')+')'+s[b+1:]
# Original custom injection owns its input graph; only specific proposal append and mark commands reach the running state.
path='backend/tests/scenarios/engine/awakened-proposal-settlement.test.ts';s=(R/path).read_text()
s=s.replace('ctx.state.awakenedEffects!.shields.push','ctx.ports!.appendShield').replace('ctx.state.awakenedEffects!.attacks.push','ctx.ports!.appendAttack').replace('ctx.ensureMarks(5).add(StatusMark.WolfKillMark)','ctx.ports!.addWolfKillMark(5)')
s=s.replace('async execute(ctx) {','async execute(ctx: import("../../../src/engine/night/contracts").NightStageContext<import("../../../src/rulesets/night-stage-bindings").LegacyAwakenedStagePorts>) {',1)
s=wrap(s,'controlled_damage','bindNightStageAlias','AWAKENED_NIGHT_STAGES[0]!')
s+='\nimport { bindNightStageAlias } from "../../../src/rulesets/night-stage-bindings";\nimport { AWAKENED_NIGHT_STAGES } from "../../../src/features/awakened-hidden-wolf/night-stages";\n';save(path,s)
# Paid Dream query must not return original links/life or a Frame object with private TypeScript fields.
path='backend/tests/scenarios/features/radiant-eclipse/paid-dream-effects.test.ts';s=(R/path).read_text()
s=s.replace('async execute(ctx: any) {\n              ctx.ensureMarks(dead).add(StatusMark.PoisonMark);','async execute(ctx: import("../../../../src/engine/night/contracts").NightStageContext<import("../../../../src/rulesets/night-stage-bindings").SyntheticNightDamagePorts>) {\n              ctx.ports!.addPoisonMark(dead);')
s=wrap(s,'synthetic_attack','bindSyntheticNightDamageStage')
s=s.replace('let links: readonly DreamNightLink[] = [];','let captureProbe: import("../../../../src/rulesets/night-stage-bindings").PaidDreamStagePorts["captureProbe"] | undefined;')
s=s.replace('async execute(ctx: any) {\n            links = readDreamNightLinks(ctx.state);','async execute(ctx: import("../../../../src/engine/night/contracts").NightStageContext<import("../../../../src/rulesets/night-stage-bindings").PaidDreamStagePorts>) {\n            captureProbe = ctx.ports!.captureProbe;')
s=wrap(s,'synthetic_failure','bindNightStageAlias','DREAMER_NIGHT_STAGE')
s=s.replace('frame = new DreamNightFrame(links)','frame = captureProbe!()')
s=s.replace('frame.protectedTargets(bindDreamLifeQueries(f.world))','frame.protectedTargets()').replace('frame.linkedDeaths(bindDreamLifeQueries(f.world), [1])','frame.linkedDeaths([1])')
s=s.replace('frame.protectedTargets(f.world)','frame.protectedTargets()').replace('frame.linkedDeaths(f.world, [1])','frame.linkedDeaths([1])')
s+='''
import { bindNightStageAlias, bindSyntheticNightDamageStage } from "../../../../src/rulesets/night-stage-bindings";
import { DREAMER_NIGHT_STAGE } from "../../../../src/features/dreamer/night-stages";
''';save(path,s)
# Explicit wrapper alias delegates only whole feedback behavior, never private runtime.
path='backend/tests/scenarios/features/gravekeeper/native-exile-feedback.test.ts';s=(R/path).read_text()
a=s.index('...GRAVEKEEPER_FEEDBACK_STAGE,');start=s.rfind('{',0,a);stop=close(s,start)
obj=s[start:stop+1].replace('async execute(ctx)','async execute(ctx: import("../../../../src/engine/night/contracts").NightStageContext<import("../../../../src/rulesets/night-stage-bindings").GravekeeperStagePorts>)').replace('await GRAVEKEEPER_FEEDBACK_STAGE.execute(ctx)','await ctx.ports!.runFeedback()')
s=s[:start]+'bindNightStageAlias('+obj+', GRAVEKEEPER_FEEDBACK_STAGE)'+s[stop+1:]
s+='\nimport { bindNightStageAlias } from "../../../../src/rulesets/night-stage-bindings";\n';save(path,s)
# Keep the late original inspectionAttacks getter injection in trusted fixture composition, not public ctx.state.
path='backend/tests/scenarios/interactions/noble-secret-body/night-handoff-prefix.test.ts';s=(R/path).read_text()
s=s.replace('import { expect, test } from "bun:test";','import { expect, test, spyOn } from "bun:test";')
s=s.replace('import type { NightStageContext } from "../../../../src/engine/night/contracts";','import type { NightStageContext, NightStageState } from "../../../../src/engine/night/contracts";\nimport * as nightStateOwner from "../../../../src/engine/night/trusted-runtime";')
s=s.replace('NightStageContext["state"]','NightStageState')
s=s.replace('''          async execute(ctx: NightStageContext) {
            capturedState = ctx.state;
          },''','''          async execute(_ctx: NightStageContext) {},''')
needle='  let capturedState: NightStageState | undefined;'
s=s.replace(needle,needle+'''
  // 可信 fixture 在实际唯一容器创建点观察引用；公开扩展不取得 state，也不加生产 getter 后门。
  const createState = nightStateOwner.createNightStageState;
  const stateFixture = spyOn(nightStateOwner, "createNightStageState").mockImplementation(() => {
    capturedState = createState();
    return capturedState;
  });''')
s=s.replace('  } finally {\n    if (originalDescriptor)','  } finally {\n    stateFixture.mockRestore();\n    if (originalDescriptor)')
s=s.replace('末阶段只捕获状态，在真实 native_damage 事件已进入测试数组后才安装晚输出字段 getter。','可信装配捕获实际新状态，末阶段不收原容器；在真实 native_damage 事件已进入测试数组后才安装晚输出字段 getter。')
s=s.replace('不用生产 hook、模型或整局替代原结果。','不用公开状态回门、模型或整局替代原结果。');save(path,s)
print('Existing fixture consumers and four explicit custom capabilities prepared; no execution')
