from pathlib import Path
import re,json,subprocess,hashlib,difflib
R=Path('/home/hby/dev/AI-Werewolf-Arena');D=Path('/tmp/awa-h02-night-stage-owner-implementation');S=Path('/tmp/awa-h02-night-stage-ports-proposal/before');W=Path('/tmp/awa-h02-night-stage-ports-implementation/candidates')
I=json.load(open('/tmp/awa-h02-night-stage-ports-proposal/inventory.json'));F=I['orderedFeatureConsumers']
def save(path,text):
 p=D/'candidates'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
# Whole mechanisms remain the actual complete owners; only their private input ownership and H03's scope slot change.
for path in F:
 s=(S/path).read_text()
 for m in list(re.finditer(r'import(?: type)? \{([^}]+)\} from "([^\"]*engine/night/contracts)";',s))[::-1]:
  names=m[1];kept=[];private=[]
  for item in names.split(','):
   name=item.strip()
   if name=='NightStageContext':private.append('TrustedNightStageRuntime as NightStageContext')
   elif name=='NightStageHandler':private.append('TrustedNightStageHandler as NightStageHandler')
   elif name:kept.append(name)
  repl=('import type { '+', '.join(kept)+' } from "'+m[2]+'";\n' if kept else '')+('import type { '+', '.join(private)+' } from "'+m[2].replace('/contracts','/trusted-runtime')+'";' if private else '')
  s=s[:m.start()]+repl+s[m.end():]
 for scope in ['thiefScope','shapeshifterScope','wildChildScope','lonelyGirlScope','ghostBrideScope','demonHunterScope','nobleBodyScope','fragrantPairScope','animalScope','wallScope']:
  s=re.sub(r'\b'+scope+r'(?=\s*:)', 'scope',s)
 save(path,s)
# Private owner interface extends only the safe common context; it is never passed to a replaceable program.
old=(S/'backend/src/engine/night/contracts.ts').read_text();start=old.index('export interface NightStageContext {');stop=old.index('\n/** 默认收集器',start)
raw=old[start:stop].replace('export interface NightStageContext {','export interface TrustedNightStageRuntime extends NightStageContext {')
imports=old[old.index('import '):old.index('/** 狼刀选定时')]
rawsrc='''/**
 * 可信夜流水线与完整内建资源程序的私有输入。World、组件、事件、Catalog、请求构造器和整夜状态只停留在此侧。
 * 组合根同时核实际 handler 与原 execute 引用；被替换的 execute 永远只取得公开窄对象。
 * 此接口不提供公开反查 token，不复制组件或缓存另一份资源；内建原资格／付款／已付复验仍是原程序。
 */\n'''+imports+'''\nimport type { NightStageContext, NightStageHandler, NightStageState } from "./contracts";\n\n'''+raw+'''
/** 完整内建程序私留原组件引用；该较窄输入不作为可替换扩展的 callback 契约。 */
export interface TrustedNightStageHandler extends NightStageHandler {
  execute(runtime: TrustedNightStageRuntime): Promise<void>;
}
'''
# Allocate the original complete literal through a real owner, so tests can observe trusted composition without public ctx.state.
pipeline=(S/'backend/src/engine/phases/night-pipeline.ts').read_text();a=pipeline.index('      const stageState: NightStageState = {');b=pipeline.index('\n\n      const requests',a)
literal=pipeline[a:b].split(' = ',1)[1].rstrip(';')
rawsrc+='''
/** 建立这一夜唯一的提案容器；尚未绑定 World，创建本身不支付或赋予请求权。 */
export function createNightStageState(): NightStageState { return '''+literal+'''; }

/**
 * 可信自定义伤害阶段只获明确加毒印记命令，不取得 StatusMarks 组件或任意槽写入。
 * 组件仍由原 ensureMarks 唯一取得／创建，add 及失败前缀留在该原调用点。
 */
export function bindSyntheticNightDamageCommands(runtime: TrustedNightStageRuntime) {
  return { addPoisonMark(id: EntityId): void { runtime.ensureMarks(id).add(importedStatusMark.PoisonMark); } };
}

/** 旧自定义觉醒提案输入保宽；不读取额外 kind/origin，不返回真实提案数组或组件。 */
export function bindLegacyAwakenedProposals(runtime: TrustedNightStageRuntime) {
  return {
    get appendShield() {
      const values = runtime.state.awakenedEffects!.shields, callee = values.push, invoke = Reflect.apply.bind(Reflect);
      return (effect: NightAwakenedEffect) => invoke(callee, values, [effect]) as number;
    },
    get appendAttack() {
      const values = runtime.state.awakenedEffects!.attacks, callee = values.push, invoke = Reflect.apply.bind(Reflect);
      return (effect: NightAwakenedEffect) => invoke(callee, values, [effect]) as number;
    },
    addWolfKillMark(id: EntityId): void { runtime.ensureMarks(id).add(importedStatusMark.WolfKillMark); },
  };
}
import { StatusMark as importedStatusMark } from "../../domain/model";
'''
save('backend/src/engine/night/trusted-runtime.ts',rawsrc)
public='''/**
 * 可替换夜阶段实际取得的对象：请求与校验、编号查询和显式授予的具体操作。
 * 不提供 World、组件、整夜状态、事件数组、Catalog、请求构造器或能反查私有 runtime 的 token。
 * Provider 也为只含 getAction 的真实对象；候选不是付款，原资格、部分写入与已付效果仍由具体 owner 负责。
 */
export interface NightStageContext<Ports extends object = object> {
  isCurrent(): boolean;
  readonly previousExile: Readonly<ExileFeedback> | null;
  readonly actions: import("../actions/tool-gateway").BoundToolGateway;
  readonly actionProvider: ActionProvider;
  currentDay(): number;
  makeRequest(actorId: EntityId, allowedTools: ActionRequest["allowedTools"], context: ActionRequestExtras & { stage: ActionStage; requiresAction?: boolean }): ActionRequest;
  getAliveByRole(role: Role): EntityId[];
  pickMajorityTarget(votes: Record<number, number>): EntityId | null;
  pickMistKnife?(ids: readonly EntityId[]): EntityId | null;
  shuffleWolves(ids: EntityId[]): EntityId[];
  /** 未绑定本族操作的扩展没有此能力；不填入空函数或根据机器 id 推断权限。 */
  readonly ports?: Ports;
}

/** handler 引用及 execute 仍可替换；流水线在原点只读一次实际 callee，并保原 receiver。 */
export interface NightStageHandler<Ports extends object = object> {
  id: string;
  priority: number;
  execute(ctx: NightStageContext<Ports>): Promise<void>;
}
'''
s=old[:start]+public
for x in ['import { World } from "../../domain/world";\n','import { ToolGateway } from "../actions/tool-gateway";\n','import type { RoleCatalog } from "../../rulesets/roles/catalog";\n','import type { ActionRequestFactoryConstructorPort } from "../../domain/actions";\n']:
 s=s.replace(x,'')
save('backend/src/engine/night/contracts.ts',s)
# Paid/composition algorithms retain their full old bodies and original getters, but the input is explicitly private.
for path in ['backend/src/rulesets/native-night-effects.ts','backend/src/rulesets/native-night-target-policy.ts','backend/src/rulesets/ordinary-wolf-knife-routing.ts','backend/src/rulesets/night-damage-composition.ts']:
 s=(R/path).read_text()
 s=s.replace('import type { NightStageContext } from "../engine/night/contracts";','import type { TrustedNightStageRuntime as NightStageContext } from "../engine/night/trusted-runtime";')
 s=s.replace('import type { NightStageContext, WolfKnifeTargetScope } from "../engine/night/contracts";','import type { WolfKnifeTargetScope } from "../engine/night/contracts";\nimport type { TrustedNightStageRuntime as NightStageContext } from "../engine/night/trusted-runtime";')
 s=s.replace('import type { NightStageContext, NightStageState } from "../engine/night/contracts";','import type { NightStageState } from "../engine/night/contracts";\nimport type { TrustedNightStageRuntime as NightStageContext } from "../engine/night/trusted-runtime";')
 save(path,s)
# Capture World in class-private fields in the two existing scope owners (no reverse-map or global World cache).
for family in ['mechanical-wolf','awakened-hidden-wolf']:
 path=f'backend/src/features/{family}/night-scope.ts';save(path,(W/path).read_text())
# New paid probe belongs to the real Dream relation owner; it returns only a closure/ID queries, never links/Frame/components.
path='backend/src/features/dreamer/night-links.ts';s=(R/path).read_text()
s+='''
/**
 * 可信扩展的已付关系探针：在原关系读取点捕获同一数组，之后按调用点建立 Frame；不把生命组件交给 callback。
 * 返回的方法只产生编号，World 与 Frame 留在闭包；本探针不改变 paid-current 或原关系撤权。
 */
export function bindPaidDreamNightProbe(runtime: { state(): object; world(): import("../../domain/world").World }) {
  return {
    get captureProbe() {
      const links = readDreamNightLinks(runtime.state());
      return () => {
        const frame = new ProbeDreamNightFrame(links);
        return {
          protectedTargets: () => frame.protectedTargets(bindProbeDreamLifeQueries(runtime.world())),
          linkedDeaths: (deaths: readonly number[]) => frame.linkedDeaths(bindProbeDreamLifeQueries(runtime.world()), deaths),
        };
      };
    },
  };
}
import { DreamNightFrame as ProbeDreamNightFrame } from "./night-frame";
import { bindDreamLifeQueries as bindProbeDreamLifeQueries } from "../../domain/dream-night-effects";
''';save(path,s)
# recipient factory records only its actual complete program; callers cannot register arbitrary callbacks as owned.
path='backend/src/features/night-abilities/recipient-ability-stage.ts';s=(D/'candidates'/path).read_text();start=s.index('export function recipientAbilityStage(');a=s.index('  return {',start);b=s.index('\n  };\n}',a)
s=s[:a]+s[a:b].replace('  return {','  const handler: NightStageHandler = {',1)+s[b:b+len('\n  };')]+'''\n  recipientPrograms.set(handler, handler.execute);\n  return handler;'''+s[b+len('\n  };'):]
i=s.index('export function recipientAbilityStage(');s=s[:i]+'''const recipientPrograms = new WeakMap<object, unknown>();
/** 只识别本工厂完整原程序的真实引用；不登记 World，也不以 id／同形函数授权。 */
export function isOwnedRecipientAbilityProgram(handler: object, execute: unknown): boolean { return recipientPrograms.get(handler) === execute && recipientPrograms.has(handler); }
'''+s[i:];save(path,s)
print('Complete private owners and actual public contract prepared; no parser/check execution')
