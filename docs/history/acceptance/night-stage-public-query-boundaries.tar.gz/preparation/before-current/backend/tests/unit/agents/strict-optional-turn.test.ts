/**
 * 单元测试验证 strict-optional-turn 的既有传输、回合与显式特权回退边界。输入为原假客户端、请求、取消／期限和回调控制；预期来自原手写动作、引用、记录与拒绝断言。特权 provider 保留原请求及测试状态控制，不进入默认生产观察策略。
 */
import { expect, test } from "bun:test";
import { bootstrapGame } from "../../../src/app/bootstrap";
import { COMPONENT, Phase, Role, type GameEvent, type RoleComponent } from "../../../src/domain";
import { LlmActionProvider } from "../../../src/agents/llm/llm-action-provider";
import { AcpActionProvider } from "../../../src/agents/acp/acp-action-provider";
import { GameActionRequestFactory } from "../../../src/engine/actions/action-request-factory";
import { getDefaultRoleCatalog } from "../../../src/rulesets/roles/role-catalog-assembly";
import { AWAKENED_NIGHT_STAGES } from "../../../src/features/awakened-hidden-wolf/night-stages";
import { getAwakenedState } from "../../../src/features/awakened-hidden-wolf/state";
import { ToolGateway } from "../../../src/engine/actions/tool-gateway";
import { sixPlayerMvpConfig } from "../../../src/rulesets/presets/six-player-mvp";
import { nightStageContext } from "../../support/builders/night-stage-context";

const modes = [
  "clean_wait",
  "correct_after_one",
  "correct_after_two",
  "reject3",
  "valid_fourth",
  "malformed3",
  "transport_failure",
] as const;
for (const transport of ["sdk", "acp"] as const)
  for (const locale of ["zh-CN", "en"] as const)
    for (const mode of modes)
      test(`${transport}/${locale}/${mode}: strict optional turns distinguish intentional waiting from failure`, async () => {
        const roles = [
          Role.AwakenedHiddenWolf,
          Role.Wolf,
          Role.MirrorGirl,
          Role.Witch,
          Role.Guard,
          Role.Villager,
        ];
        const config = {
            ...sixPlayerMvpConfig,
            roleSetups: roles.map((role) => ({ role, count: 1 })),
          },
          game = bootstrapGame(config, { fixedRoles: roles, locale });
        const events: GameEvent[] = [],
          denials: any[] = [],
          factory = new GameActionRequestFactory(game.world, events, 1);
        let fallbackCalls = 0,
          closes = 0;
        const privilegedFallbackProvider = {
          async getAction() {
            fallbackCalls++;
            return null;
          },
        };
        const submissions = async (submit: (args: any) => Promise<any> | any) => {
          const count =
            mode === "correct_after_one"
              ? 1
              : mode === "correct_after_two"
                ? 2
                : ["reject3", "valid_fourth", "malformed3"].includes(mode)
                  ? 3
                  : 0;
          for (let i = 0; i < count; i++)
            denials.push(
              await submit(
                mode === "malformed3"
                  ? { turn_id: "t1", action: "awakened_mimic" }
                  : { turn_id: "t1", action: "awakened_mimic", arguments: { target_id: 1 } },
              ),
            );
          if (["correct_after_one", "correct_after_two", "valid_fourth"].includes(mode))
            return submit({ turn_id: "t1", action: "awakened_mimic", arguments: { target_id: 3 } });
        };
        const client: any = {
          async chat() {
            throw new Error("unexpected_chat");
          },
          async runToolLoop(_messages: any, _tools: any, callbacks: any) {
            if (mode === "transport_failure") throw new Error("synthetic_transport_failure");
            const result = await submissions(async (args) => {
              const result = await callbacks.onToolCall({ name: "submit_action", args });
              return { ...result.toolResult, finalAction: result.finalAction };
            });
            return { finalAction: result?.finalAction ?? null, assistantText: "Synthetic end" };
          },
        };
        const provider =
          transport === "sdk"
            ? new LlmActionProvider(game.world, client, {
                boardConfig: config,
                privilegedFallbackProvider,
                maxConcurrentRequests: 1,
                llmTimeoutMs: 1500,
              })
            : new AcpActionProvider(game.world, {
                boardConfig: config,
                privilegedFallbackProvider,
                maxConcurrentRequests: 1,
                turnTimeoutMs: 1500,
                sessionFactory: {
                  async createSession(input) {
                    if (mode === "transport_failure")
                      throw new Error("synthetic_transport_failure");
                    return {
                      sessionId: "strict-optional",
                      async prompt() {
                        await submissions((args) =>
                          input.registry.submitAction("strict-optional", args),
                        );
                      },
                      async cancel() {},
                      async close() {
                        closes++;
                      },
                    };
                  },
                },
              });
        const ctx = nightStageContext({
          world: game.world,
          roleCatalog: getDefaultRoleCatalog(),
          toolGateway: new ToolGateway(),
          events,
          isCurrent: () => true,
          currentDay: () => 1,
          actionProvider: provider,
          makeRequest: (actorId, allowedTools, extra) => {
            const { stage, requiresAction, ...context } = extra;
            return factory.create({
              actorId,
              phase: Phase.Night,
              allowedTools,
              stage,
              requiresAction: requiresAction ?? false,
              context,
              summary: { key: "request.summary.night_action" },
            });
          },
        });
        await AWAKENED_NIGHT_STAGES.find((stage) => stage.id === "awakened_opening")!.execute(ctx);
        const action = () =>
          AWAKENED_NIGHT_STAGES.find((stage) => stage.id === "awakened_mimic")!.execute(ctx);
        try {
          const success = ["clean_wait", "correct_after_one", "correct_after_two"].includes(mode);
          if (success) await action();
          else await expect(action()).rejects.toThrow("action_turn_failed");
          const state = getAwakenedState(game.world.getComponent(1, COMPONENT.Role)!)!;
          expect(fallbackCalls).toBe(0);
          if (mode === "clean_wait") {
            expect(state.learned).toBeNull();
            expect(state.mimicClosedDay).toBe(1);
            expect(events.map((e) => e.type)).toEqual(["awakened_mimic_skipped"]);
          } else if (success) {
            expect(state.learned).toMatchObject({
              targetId: 3,
              role: "mirror_girl",
              activationNight: null,
            });
            expect(events.map((e) => e.type)).toEqual(["awakened_mimicked"]);
          } else {
            expect(state.learned).toBeNull();
            expect(state.mimicClosedDay).toBeNull();
            expect(events).toEqual([]);
          }
          expect(denials.every((result) => result.ok === false)).toBe(true);
        } finally {
          await provider.close();
        }
        if (transport === "acp") expect(closes).toBe(mode === "transport_failure" ? 0 : 1);
      });
