from pathlib import Path
import re,json
D=Path('/tmp/awa-h02-night-stage-owner-implementation/candidates');S=Path('/tmp/awa-h02-night-stage-ports-proposal/before');I=json.load(open('/tmp/awa-h02-night-stage-ports-proposal/inventory.json'))
rows=[]
for path in I['orderedFeatureConsumers']:
 p=D/path;s=p.read_text()
 exports=re.findall(r'export const (\w+)\s*(?::[^=]+)?=',(S/path).read_text());exports=[x for x in exports if x!='BLACK_MARKET_RECIPIENT_STAGE']
 if not exports:continue
 family=path.split('/')[3];label=''.join(part.title() for part in (family+'-'+p.stem).split('-'))+'Programs'
 entries=[]
 for x in exports:
  if x.endswith('_STAGES'):entries.append('...'+x)
  else:entries.append(x)
 s+='''
/** 模块定义完成时固定完整原程序引用；后来替换 execute 不能借原 handler 对象取得私有输入。这里不持有运行 World。 */
export const OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
  '''+', '.join(entries)+'''
].map((handler) => Object.freeze([handler, handler.execute] as const)));
''';p.write_text(s)
 rows.append((path,label,exports))
p=D/'backend/src/rulesets/night-stage-bindings.ts';s=p.read_text()
for path,label,exports in rows:
 rel='../'+path.split('backend/src/',1)[1][:-3]
 old='import { '+', '.join(exports)+' } from "'+rel+'";'
 # Keep stage refs solely for the few actual concrete extension commands.
 refs=[x for x in exports if x in ['DREAMER_NIGHT_STAGE','AWAKENED_NIGHT_STAGES','GRAVEKEEPER_FEEDBACK_STAGE']]
 new='import { '+', '.join(refs+['OWNED_NIGHT_STAGE_PROGRAMS as '+label])+' } from "'+rel+'";'
 assert old in s,(path,old)
 s=s.replace(old,new)
a=s.index('const programs: ReadonlyArray<readonly [object, unknown]> = [');b=s.index('\n];',a)
s=s[:a]+'''const programs: ReadonlyArray<readonly [object, unknown]> = [
'''+',\n'.join('  ...'+label for path,label,exports in rows)+s[b:]
p.write_text(s)
print('Original execute identity now captured at each actual owner definition, not first pipeline import')
