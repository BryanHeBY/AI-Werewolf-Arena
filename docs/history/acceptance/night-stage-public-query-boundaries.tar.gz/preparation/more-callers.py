from pathlib import Path
import re,os
R=Path('/home/hby/dev/AI-Werewolf-Arena');D=Path('/tmp/awa-h02-night-stage-owner-implementation/candidates')
for p in (R/'backend/tests').rglob('*.ts'):
 path=p.relative_to(R);q=D/path;s=q.read_text() if q.exists() else p.read_text();old=s
 if 'NightStageContext' not in s and '.getStages(' not in s:continue
 patterns=[r'(AWAKENED_NIGHT_STAGES\.find\([^\n]+?\)!)\.execute\(',r'(\(stage === "native" \? SEER_NIGHT_STAGES\[0\]! : LUCKY_ABILITY_STAGE\))\.execute\(',r'(\(family === "cupid" \? CUPID_STAGE : HYBRID_STAGE\))\.execute\(',r'(stage\(family\))\.execute\(',r'((?:entry\.handler|plan\.entries\[0\]!\.handler|game\.stage|item\.stage|stages\[f\.family\]|[A-Z_]+(?:\[\d+\]!?)?|stage|guard|handler))\.execute\(']
 # Do not rewrite declarations, local orchestration f.execute, pipelines or backend controllers.
 for pat in patterns:s=re.sub(pat,r'executeNightStage(\1)(',s)
 if s==old:continue
 rel=os.path.relpath(R/'backend/tests/support/builders/night-stage-context',p.parent).replace(os.sep,'/')
 if not rel.startswith('.'):rel='./'+rel
 if not re.search(r'import[^;]*\bexecuteNightStage\b[^;]*night-stage-context',s,re.S):s+='\nimport { executeNightStage } from "'+rel+'";\n'
 q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
# Metadata-only rule-plan iterators still execute through the real public binding, with a real fixture World.
p=D/'backend/tests/unit/rulesets/rule-plan.test.ts'
if p.exists():
 s=p.read_text().replace('executeNightStage(entry.handler)({} as NightStageContext)','executeNightStage(entry.handler)(nightStageContext({ world }))')
 if 'nightStageContext({ world })' in s and not re.search(r'import[^;]*\bnightStageContext\b[^;]*night-stage-context',s,re.S):
  s+='\nimport { nightStageContext } from "../../support/builders/night-stage-context";\n'
 p.write_text(s)
print('Remaining trusted fixture execution references prepared; no execution')
