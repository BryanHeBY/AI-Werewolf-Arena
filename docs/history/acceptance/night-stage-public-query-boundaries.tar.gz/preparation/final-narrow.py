from pathlib import Path
import re,os
R=Path('/home/hby/dev/AI-Werewolf-Arena');D=Path('/tmp/awa-h02-night-stage-owner-implementation/candidates')
# Preserve H03's actual admitted-rule invocation in its shared test before adding only night execution routing.
p='backend/tests/unit/mechanisms/learned-wolf-execution-retirement.test.ts';s=(R/p).read_text().replace('import type { NightStageContext } from "../../../src/engine/night/contracts";','import type { TrustedNightStageRuntime as NightStageContext } from "../../../src/engine/night/trusted-runtime";');(D/p).write_text(s)
# These functions return actual stage references; retain callee preparation before the original runtime argument.
for p in list((R/'backend/tests').rglob('*.ts')):
 path=p.relative_to(R);q=D/path;s=q.read_text() if q.exists() else p.read_text();old=s
 for name in ['stage','mechanicalStage','ordinary']:
  s=re.sub(r'('+name+r'\([^\n]*?\))\.execute\(',r'executeNightStage(\1)(',s)
 if s==old:continue
 rel=os.path.relpath(R/'backend/tests/support/builders/night-stage-context',p.parent).replace(os.sep,'/')
 if not rel.startswith('.'):rel='./'+rel
 if not re.search(r'import[^;]*\bexecuteNightStage\b[^;]*night-stage-context',s,re.S):s+='\nimport { executeNightStage } from "'+rel+'";\n'
 q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
# A fixture-supplied custom gift program owns this World/event sink itself; the engine no longer supplies them.
p=D/'backend/tests/scenarios/mechanisms/gifted-gun-native-night.test.ts';s=p.read_text();old='grantDeathGun(ctx.world, 3, 5, ctx.currentDay(), ctx.events);';assert old in s;s=s.replace(old,'grantDeathGun(game.world, 3, 5, ctx.currentDay(), events);');p.write_text(s)
# Retired public-context names no longer used by these maintenance/type-only imports.
p=D/'backend/src/engine/night/contracts.ts';s=p.read_text().replace('  GameEvent,\n','');
for x in ['import type { NightAbilityActorQuery } from "../../features/night-abilities/actor-query-ports";\n','import type { NativeNightFailurePolicy } from "../../rulesets/native-night-failure-policy";\n','import type { NativeNightTargetPolicy } from "../../rulesets/native-night-target-policy";\n','import type { NativeNightEffects } from "../../rulesets/native-night-effects";\n']:s=s.replace(x,'')
s=s.replace('/**\n * 阶段 handler 使用的运行端口：请求、候选查询和效果写入均在当前阶段执行。\n * 异步行动返回后仍需检查 isCurrent 及具体原体许可；持有此上下文不自动获得领域提交权限。\n */\n','');p.write_text(s)
p=D/'backend/src/engine/night/trusted-runtime.ts';s=p.read_text().replace('  NightSummary,\n','').replace('import type { AliveComponent } from "../../domain/components/alive";\n','');a=s.index('import type {\n  NightPoisonClaim,');b=s.index('} from "../../domain/night-effects";',a)+len('} from "../../domain/night-effects";');s=s[:a]+'import type { NightAwakenedEffect } from "../../domain/night-effects";'+s[b:];p.write_text(s)
p=D/'backend/src/engine/phases/night-pipeline.ts';s=p.read_text().replace('import { NightStageState } from "../../rulesets/mechanism-api";\n','');p.write_text(s)
p=D/'backend/tests/scenarios/features/radiant-eclipse/paid-dream-effects.test.ts';s=p.read_text().replace('import { DreamNightFrame, type DreamNightLink } from "../../../../src/features/dreamer/night-frame";\n','').replace('import { readDreamNightLinks } from "../../../../src/features/dreamer/night-ports";\n','');p.write_text(s)
p=D/'backend/tests/unit/rulesets/rule-plan.test.ts';s=p.read_text().replace('NightStageHandler, NightStageContext','NightStageHandler');p.write_text(s)
print('Only TMP exact caller/type-import followups assembled; no parser/compiler/runtime/check invoked.')
