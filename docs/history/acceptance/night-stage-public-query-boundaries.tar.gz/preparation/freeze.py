from pathlib import Path
import subprocess,hashlib,json,difflib
R=Path('/home/hby/dev/AI-Werewolf-Arena');D=Path('/tmp/awa-h02-night-stage-owner-implementation');C=D/'candidates'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def js(p,v):write(D/p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
merge={'backend/src/rulesets/roles/contracts.ts','backend/src/rulesets/rule-plan.ts'};files=[];edits=[];patch=[]
for p in sorted(C.rglob('*.ts')):
 path=str(p.relative_to(C));after=p.read_bytes();q=R/path;physical=q.read_bytes() if q.exists() else None
 if physical==after:continue
 g=subprocess.run(['git','show',base+':'+path],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);git=g.stdout if g.returncode==0 else None
 modeout=subprocess.run(['git','ls-tree',base,'--',path],cwd=R,stdout=subprocess.PIPE,text=True).stdout;mode=modeout.split()[0] if modeout else None
 files.append({'path':path,'application':'root-merge-exact-only' if path in merge else 'full-candidate','gitBefore':{'commit':base,'present':git is not None,'mode':mode,'sha256':sha(git) if git is not None else None,'bytes':len(git) if git is not None else None},'physicalBefore':{'present':physical is not None,'sha256':sha(physical) if physical is not None else None,'bytes':len(physical) if physical is not None else None,'sameGit':physical==git},'candidate':{'sha256':sha(after),'bytes':len(after)}})
 if git is not None:write(D/'before-git'/path,git)
 if physical is not None:write(D/'before-current'/path,physical)
 a=(physical or b'').decode().splitlines(keepends=True);b=after.decode().splitlines(keepends=True)
 patch.extend(difflib.unified_diff(a,b,fromfile='a/'+path,tofile='b/'+path))
 for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if tag!='equal':edits.append({'path':path,'operation':tag,'oldLineStart':i+1,'newLineStart':k+1,'before':''.join(a[i:j]),'after':''.join(b[k:l])})
controls=[]
for path in ['backend/src/domain/request-lease.ts','backend/src/recording/reproduction/trace.ts','backend/src/features/dreamer/state-slot.ts','backend/src/features/mechanical-wolf/state.ts','backend/src/features/awakened-hidden-wolf/state.ts','backend/src/domain/role-execution-authority.ts']:
 raw=(R/path).read_bytes();g=subprocess.check_output(['git','show',base+':'+path],cwd=R);assert raw==g,path
 controls.append({'path':path,'sha256':sha(raw),'bytes':len(raw),'sameGit':True});write(D/'controls'/path,raw)
record={'kind':'h02-night-complete-owner-source-ready','baseCommit':base,'phase':'prepared-only; no parser/compiler/test/product/gate invoked','files':files,'controls':controls,'counts':{'files':len(files),'production':sum('/src/' in x['path'] for x in files),'testAndSupport':sum('/tests/' in x['path'] for x in files),'newAbsent':sum(not x['gitBefore']['present'] for x in files),'rootMergeOnly':len(merge),'exactTextEdits':len(edits)},'foreignPhysicalBefore':[x['path'] for x in files if not x['physicalBefore']['sameGit']],'limits':['First before34+14 at 8dd28e93 and superseded reference-return prototype remain separately; this record captures actual current Git and physical predecessors.','Builtin complete programs keep World/ref privately. Replaced callback actual context has no World/state/events/Catalog/requestFactory/nightActors/component-returning route.','Dispatch/Reflect bindings/context allocations and registry query API are intentional extension API changes, not arbitrary JavaScript observational equivalence.','Root owns roles/contracts and rule-plan: apply only exact listed deltas, never whole-file overwrite.','No types/runtime/head/proof executed. Four boundary declarations are prepared expected assertions.']}
js('source-ready.json',record);js('exact-edits.json',edits);write(D/'candidate.patch',''.join(patch).encode());js('root-shared-edits.json',[e for e in edits if e['path'] in merge])
print(json.dumps({'base':base,'counts':record['counts'],'foreign':record['foreignPhysicalBefore'],'readySHA':sha((D/'source-ready.json').read_bytes())}))
