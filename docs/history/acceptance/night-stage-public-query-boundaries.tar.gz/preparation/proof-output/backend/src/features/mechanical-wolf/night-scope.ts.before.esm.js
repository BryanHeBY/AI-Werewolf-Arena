import { COMPONENT } from "../../domain/components/names";
import { Camp, Role } from "../../domain/model";
import { captureNightLife, livingNightLife } from "../../domain/night-effects";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { getMechanicalState } from "./state";
export function captureMechanicalOwner(world, actorId, phaseCurrent) {
    const role = world.getComponent(actorId, COMPONENT.Role);
    const state = getMechanicalState(role);
    const life = captureNightLife(world, actorId);
    if (!phaseCurrent() ||
        !role ||
        role.role !== Role.MechanicalWolf ||
        world.getComponent(actorId, COMPONENT.Camp)?.camp !== Camp.Wolf ||
        !state ||
        !life)
        return null;
    const privateState = role.privateState;
    return {
        world,
        actorId,
        role,
        state,
        life,
        canAct: () => !isRoleExecutionRetired(role),
        isCurrent: () => phaseCurrent() &&
            world.getComponent(actorId, COMPONENT.Role) === role &&
            role.role === Role.MechanicalWolf &&
            world.getComponent(actorId, COMPONENT.Camp)?.camp === Camp.Wolf &&
            role.privateState === privateState &&
            getMechanicalState(role) === state &&
            livingNightLife(world, life),
    };
}
export function bindMechanicalSkill(scope, day) {
    const learned = scope.state.learned, mode = scope.state.mode;
    if (day < 2 ||
        !scope.isCurrent() ||
        !hasCurrentMechanicalMode(scope.world, scope.role, "skill") ||
        !learned ||
        learned.readyOnNight > day ||
        !mode ||
        mode.day !== day ||
        mode.kind !== "skill")
        return null;
    const skill = learned.skill, kind = skill.kind;
    return {
        skill,
        isCurrent: () => scope.isCurrent() &&
            hasCurrentMechanicalMode(scope.world, scope.role, "skill") &&
            scope.state.learned === learned &&
            learned.skill === skill &&
            skill.kind === kind &&
            scope.state.mode === mode &&
            mode.day === day &&
            mode.kind === "skill" &&
            learned.readyOnNight <= day,
    };
}
const modes = new WeakMap();
const committed = new WeakMap();
export function hasMechanicalNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
export function recordMechanicalNightCommit(world, day) {
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
export function recordMechanicalModeScope(world, scope, day) {
    const mode = scope.state.mode;
    if (scope.world !== world || day < 2 || !scope.isCurrent() || !mode || mode.day !== day)
        return false;
    let night = modes.get(world);
    if (night && night.day > day)
        return false;
    if (!night || night.day !== day) {
        night = { day, actors: new Map() };
        modes.set(world, night);
    }
    if (night.actors.has(scope.actorId))
        return false;
    night.actors.set(scope.actorId, { owner: scope, mode, kind: mode.kind });
    return true;
}
export function hasCurrentMechanicalMode(world, role, expectedKind) {
    const night = modes.get(world);
    if (!night)
        return false;
    for (const { owner, mode, kind } of night.actors.values()) {
        if (owner.role === role &&
            owner.isCurrent() &&
            owner.state.mode === mode &&
            mode.day === night.day &&
            mode.kind === kind &&
            kind === expectedKind)
            return true;
    }
    return false;
}
export function hasCurrentMechanicalKillMode(world, role) {
    return hasCurrentMechanicalMode(world, role, "kill");
}
