"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.TIME_CONSORT_LOCK_STAGE = void 0;
const names_1 = require("../../domain/components/names");
const identity_1 = require("../../domain/identity");
const state_slot_1 = require("./state-slot");
const night_frame_1 = require("./night-frame");
exports.TIME_CONSORT_LOCK_STAGE = {
    id: "time_consort_lock",
    priority: 50,
    async execute(ctx) {
        const day = ctx.currentDay(), actorId = (0, night_frame_1.beginTimeConsortNight)(ctx.world, day);
        if (actorId === null) {
            const id = (0, night_frame_1.timeConsortActorId)(ctx.world);
            if (id === null)
                throw new Error("time_consort_actor_missing");
            const reason = ctx.world.getComponent(id, names_1.COMPONENT.Alive).alive ? "exhausted" : "dead";
            ctx.events.push({
                timestamp: Date.now(),
                type: "time_consort_lock_skipped",
                payload: { actorId: id, day, reason },
                audience: Object.freeze([id]),
            });
            return;
        }
        const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role);
        if (!(0, state_slot_1.getTimeConsortState)(role, () => ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)))
            throw new Error("time_consort_actor_invalid");
        const request = ctx.makeRequest(actorId, ["lock_time"], {
            stage: "time_consort_lock",
            requiresAction: true,
            action_failure_policy: "error",
            allow_fallback: false,
            consort_candidates: (0, night_frame_1.timeConsortChoiceTargets)(ctx.world, day),
        });
        (0, night_frame_1.assertTimeConsortRosterCurrent)(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        (0, night_frame_1.assertTimeConsortRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("time_consort_lock_stale");
        if (action?.name !== "lock_time")
            throw new Error("time_consort_lock_action_missing");
        const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: identity_1.Phase.Night,
            day,
        });
        (0, night_frame_1.assertTimeConsortRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("time_consort_lock_stale");
        if (!validated.ok || validated.sanitizedCall?.name !== "lock_time")
            throw new Error("time_consort_lock_action_invalid");
        const args = validated.sanitizedCall.args;
        const targetId = args.abstain ? null : args.target_id;
        (0, night_frame_1.commitTimeConsortChoice)(ctx.world, actorId, day, targetId);
        ctx.events.push({
            timestamp: Date.now(),
            type: "time_consort_lock_committed",
            payload: {
                actorId,
                day,
                targetId,
            },
            audience: Object.freeze([actorId]),
        });
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.TIME_CONSORT_LOCK_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
