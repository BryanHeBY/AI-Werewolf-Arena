import { closeMerchantTrade, recordMerchantTrade } from "./state";
import { COMPONENT } from "../../domain/components/names";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { Camp, Role, Phase, WitchSelfHealRule } from "../../domain/model";
import { captureNightLife, livingNightLife } from "../../domain/night-effects";
import { grantNightAbility } from "../night-abilities/grant-ports";
import { canMerchantTrade, getMerchantState } from "./state";
const committed = new WeakMap();
export function hasMerchantNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
function recordCommit(world, day) {
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
export const MIRACLE_MERCHANT_STAGE = {
    id: "miracle_merchant",
    priority: 125,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const actorId of ctx.getAliveByRole(Role.MiracleMerchant)) {
            const role = ctx.world.getComponent(actorId, COMPONENT.Role), state = getMerchantState(role), life = captureNightLife(ctx.world, actorId);
            if (!state || !life || ctx.world.getComponent(actorId, COMPONENT.Camp)?.camp !== Camp.Good)
                continue;
            const privateState = role.privateState;
            const ownerCurrent = () => ctx.isCurrent() &&
                ctx.world.getComponent(actorId, COMPONENT.Role) === role &&
                role.role === Role.MiracleMerchant &&
                ctx.world.getComponent(actorId, COMPONENT.Camp)?.camp === Camp.Good &&
                role.privateState === privateState &&
                getMerchantState(role) === state &&
                livingNightLife(ctx.world, life);
            const current = () => ownerCurrent() && canMerchantTrade(state, day) && !isRoleExecutionRetired(role);
            if (!current())
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current())
                    break;
                const targets = new Map(ctx.world
                    .getAliveEntityIds()
                    .filter((id) => id !== actorId)
                    .map((id) => {
                    const targetRole = ctx.world.getComponent(id, COMPONENT.Role);
                    return [
                        id,
                        {
                            life: captureNightLife(ctx.world, id),
                            role: targetRole,
                            kind: targetRole.role,
                            camp: ctx.world.getComponent(id, COMPONENT.Camp)?.camp,
                            privateState: targetRole.privateState,
                        },
                    ];
                }));
                if (isRoleExecutionRetired(role))
                    break;
                let action = null;
                if (targets.size) {
                    const provider = ctx.actionProvider, getAction = provider.getAction, makeRequest = ctx.makeRequest, requestArgs = [
                        actorId,
                        ["bestow_ability"],
                        {
                            stage: "miracle_merchant",
                            requiresAction: false,
                            ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                        },
                    ], invoke = Reflect.apply.bind(Reflect);
                    if (isRoleExecutionRetired(role))
                        break;
                    const request = invoke(makeRequest, ctx, requestArgs), actionArgs = [request];
                    if (isRoleExecutionRetired(role))
                        break;
                    action = await invoke(getAction, provider, actionArgs);
                }
                if (!current())
                    break;
                if (action === null) {
                    const closeTrade = closeMerchantTrade;
                    if (isRoleExecutionRetired(role))
                        break;
                    closeTrade(state, day);
                    recordCommit(ctx.world, day);
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "merchant_trade_skipped",
                        payload: { actorId, day },
                    });
                    completed = true;
                    break;
                }
                if (action.name !== "bestow_ability")
                    continue;
                const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                    phase: Phase.Night,
                    day,
                });
                if (!current() || !valid.ok || valid.sanitizedCall?.name !== "bestow_ability")
                    continue;
                const { target_id: targetId, skill } = valid.sanitizedCall.args, target = targets.get(targetId);
                if (!target ||
                    !livingNightLife(ctx.world, target.life) ||
                    ctx.world.getComponent(targetId, COMPONENT.Role) !== target.role ||
                    target.role.role !== target.kind ||
                    ctx.world.getComponent(targetId, COMPONENT.Camp)?.camp !== target.camp ||
                    target.role.privateState !== target.privateState)
                    continue;
                const failure = target.camp === Camp.Wolf;
                if (isRoleExecutionRetired(role))
                    break;
                if (!failure) {
                    const base = {
                        id: "gift:miracle",
                        activation: "lucky",
                        source: { kind: "gift", actorId },
                        sourceDisclosed: false,
                        startsOnDay: day,
                        maxUses: 1,
                    };
                    if (skill === "check") {
                        const grant = grantNightAbility, grantArgs = [
                            ctx.world,
                            targetId,
                            {
                                ...base,
                                kind: "seer_check",
                                state: { lastTarget: null, lastIsWerewolf: null, lastResult: null, history: [] },
                            },
                            ctx.events,
                        ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                        if (isRoleExecutionRetired(role))
                            break;
                        grant(grantWorld, grantTarget, grantInput, grantEvents);
                    }
                    if (skill === "guard") {
                        const grant = grantNightAbility, grantArgs = [
                            ctx.world,
                            targetId,
                            { ...base, kind: "guard", state: { lastTarget: null } },
                            ctx.events,
                        ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                        if (isRoleExecutionRetired(role))
                            break;
                        grant(grantWorld, grantTarget, grantInput, grantEvents);
                    }
                    if (skill === "poison") {
                        const grant = grantNightAbility, grantArgs = [
                            ctx.world,
                            targetId,
                            {
                                ...base,
                                kind: "potion",
                                state: {
                                    heal: 0,
                                    poison: 1,
                                    selfHealRule: WitchSelfHealRule.Disabled,
                                    canSelfHeal: false,
                                    healUsedThisNight: false,
                                    poisonUsedThisNight: false,
                                },
                            },
                            ctx.events,
                        ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                        if (isRoleExecutionRetired(role))
                            break;
                        grant(grantWorld, grantTarget, grantInput, grantEvents);
                    }
                }
                const recordTrade = recordMerchantTrade;
                if (failure && isRoleExecutionRetired(role))
                    break;
                recordTrade(state, day, targetId, skill);
                recordCommit(ctx.world, day);
                if (failure)
                    (ctx.state.merchantBacklashes ??= []).push({ target: life, isCurrent: ownerCurrent });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "merchant_trade_committed",
                    payload: { actorId, day, targetId, skill },
                });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "merchant_trade_resolved",
                    payload: { actorId, day, targetId, skill, outcome: failure ? "backlash" : "granted" },
                });
                completed = true;
                break;
            }
            if (!completed && current())
                throw new Error("merchant_valid_action_missing");
        }
    },
};
