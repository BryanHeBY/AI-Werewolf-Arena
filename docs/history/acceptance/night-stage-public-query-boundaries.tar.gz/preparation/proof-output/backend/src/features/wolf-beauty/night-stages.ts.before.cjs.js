"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WOLF_BEAUTY_CHARM_STAGE = void 0;
const state_1 = require("./state");
const alive_1 = require("../../domain/components/alive");
const names_1 = require("../../domain/components/names");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const model_1 = require("../../domain/model");
const state_2 = require("./state");
const relation_1 = require("./relation");
const beauty_query_ports_1 = require("../animal-dream/beauty-query-ports");
const beauty_fact_ports_1 = require("../animal-dream/beauty-fact-ports");
exports.WOLF_BEAUTY_CHARM_STAGE = {
    id: "wolf_beauty_charm",
    priority: 450,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (!(0, beauty_query_ports_1.animalBeautyCharmAllowed)(ctx.world, day))
            return;
        for (const actorId of ctx.getAliveByRole(model_1.Role.WolfBeauty)) {
            if (!ctx.isCurrent())
                return;
            const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role), state = (0, state_2.getWolfBeautyState)(role), actorLife = ctx.world.getComponent(actorId, names_1.COMPONENT.Alive), actorVersion = (0, alive_1.aliveLifeVersion)(actorLife), policy = state?.deathLinkPolicy;
            const canAct = () => !(0, role_execution_authority_1.isRoleExecutionRetired)(role);
            if (ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Wolf ||
                !state ||
                state.lastActedDay === day ||
                !canAct())
                continue;
            const targets = new Map(ctx.world
                .getAliveEntityIds()
                .filter((id) => id !== actorId)
                .map((id) => {
                const life = ctx.world.getComponent(id, names_1.COMPONENT.Alive);
                return [id, { life, version: (0, alive_1.aliveLifeVersion)(life) }];
            }));
            const provider = ctx.actionProvider, getAction = provider.getAction, makeRequest = ctx.makeRequest;
            const requestActor = actorId;
            const requestTools = ["charm"];
            const requestExtras = {
                stage: "wolf_beauty",
                requiresAction: false,
            };
            const requestArgs = [requestActor, requestTools, requestExtras];
            const invokeRequest = Reflect.apply.bind(Reflect);
            if (!canAct())
                continue;
            const request = invokeRequest(makeRequest, ctx, requestArgs);
            const actionArgs = [request];
            const invokeAction = Reflect.apply.bind(Reflect);
            if (!canAct())
                continue;
            const action = await invokeAction(getAction, provider, actionArgs);
            const current = () => ctx.isCurrent() &&
                (0, beauty_query_ports_1.animalBeautyCharmAllowed)(ctx.world, day) &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Role) === role &&
                role.role === model_1.Role.WolfBeauty &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Wolf &&
                (0, state_2.getWolfBeautyState)(role) === state &&
                state.deathLinkPolicy === policy &&
                state.lastActedDay !== day &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Alive) === actorLife &&
                actorLife.alive &&
                actorVersion !== undefined &&
                (0, alive_1.aliveLifeVersion)(actorLife) === actorVersion;
            if (!current() || !canAct())
                continue;
            if (action !== null && action.name !== "charm")
                continue;
            let targetId = action === null ? null : action.args.target_id;
            if (action) {
                const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                    phase: model_1.Phase.Night,
                    day,
                });
                if (!current() || !result.ok || result.sanitizedCall?.name !== "charm" || !canAct())
                    continue;
                targetId = result.sanitizedCall.args.target_id;
            }
            if (targetId !== null) {
                const target = targets.get(targetId);
                if (!target ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Alive) !== target.life ||
                    !target.life.alive ||
                    target.version === undefined ||
                    (0, alive_1.aliveLifeVersion)(target.life) !== target.version)
                    continue;
            }
            const recordSelection = state_1.recordCharmSelection;
            if (!canAct())
                continue;
            recordSelection(state, targetId, day);
            (0, relation_1.bindCharm)(ctx.world, actorId, targetId);
            ctx.events.push({
                timestamp: Date.now(),
                type: "charm_applied",
                payload: { actorId, targetId, day },
            });
            if ((0, beauty_query_ports_1.isAnimalDreamBoard)(ctx.world))
                (0, beauty_fact_ports_1.appendAnimalBeautyNotice)(ctx.world, ctx.events, day);
        }
    },
};
