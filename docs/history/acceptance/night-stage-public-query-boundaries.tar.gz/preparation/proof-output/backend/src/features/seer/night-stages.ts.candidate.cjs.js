"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.SEER_NIGHT_STAGES = void 0;
const ports_1 = require("./ports");
const native_request_lease_1 = require("../../engine/night/native-request-lease");
const ports_2 = require("./ports");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const ports_3 = require("./ports");
const inspection_1 = require("../../engine/inspection");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const inventory_ports_2 = require("../night-abilities/inventory-ports");
const scope_ports_1 = require("../night-abilities/scope-ports");
const night_effects_1 = require("../../domain/night-effects");
const history_ports_1 = require("../night-abilities/history-ports");
const inspection_ports_1 = require("../cursed-fox/inspection-ports");
const seerCheckStage = {
    id: "seer_check",
    priority: 600,
    async execute(ctx) {
        if (ctx.nativeNightFailure.usesDemonController()) {
            const { executeDemonNativeNight } = await ctx.nativeNightEffects.loadSealedNightController();
            await executeDemonNativeNight(ctx, "seer_check");
            return;
        }
        for (const { actorId: seerId, ability } of ctx.nightActors.actors("seer_check", ctx.currentDay())) {
            if (ability.activation === "lucky" || ability.activation === "black_market")
                continue;
            ctx.nativeNightFailure.assertSeerSource(ability);
            ctx.nativeNightFailure.assertNativeActor(seerId, model_1.Role.Seer);
            const day = ctx.currentDay(), scope = (0, scope_ports_1.captureNightAbilityScope)(ctx.world, seerId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day);
            if (!scope?.isEligible())
                continue;
            const targets = new Map(ctx.world.getAliveEntityIds().map((id) => [id, (0, night_effects_1.captureNightLife)(ctx.world, id)]));
            const identities = new Map([...targets].flatMap(([id, life]) => life ? [[id, (0, inspection_ports_1.captureInspectionIdentity)(ctx.world, life)]] : []));
            if (!ctx.world.getAliveEntityIds().includes(seerId) ||
                (0, inventory_ports_1.activeNightAbility)(ctx.world.getComponent(seerId, names_1.COMPONENT.Role), "seer_check", ctx.currentDay(), ability.id) !== ability)
                continue;
            const legalTargets = ctx.world
                .getAliveEntityIds()
                .filter((id) => (0, ports_2.seerTargetAllowed)(ability.state, seerId, id) &&
                (0, history_ports_1.luckyTargetAllowed)(ctx.world, seerId, ability, day, "check", id));
            if (!legalTargets.length)
                continue;
            let delivery;
            let failed = false;
            try {
                let requestAbilityId;
                const req = ctx.makeRequest(seerId, ["check_identity"], {
                    stage: "seer",
                    ability_id: (requestAbilityId = ability.id),
                    requiresAction: ability.state.actionPolicy !== "awa_optional_v1",
                });
                if (!scope.isEligible()) {
                    ctx.nativeNightFailure.scopeStale("seer");
                    continue;
                }
                delivery = (0, native_request_lease_1.openNativeNightRequestDelivery)({
                    actorId: seerId,
                    day,
                    stage: "seer",
                    abilityId: requestAbilityId,
                    current: () => scope.isEligible(),
                }, req);
                if (!delivery)
                    continue;
                const provider = ctx.actionProvider;
                const getAction = provider.getAction;
                const actionArguments = [req];
                const invokeAction = Reflect.apply.bind(Reflect);
                if (!delivery.current())
                    continue;
                const action = await invokeAction(getAction, provider, actionArguments);
                if (!ctx.isCurrent())
                    return;
                if (!scope.isEligible()) {
                    ctx.nativeNightFailure.scopeStale("seer");
                    continue;
                }
                if (!delivery.current())
                    continue;
                if (action?.name !== "check_identity") {
                    ctx.nativeNightFailure.actionMissing("seer");
                    continue;
                }
                const result = ctx.toolGateway.validateAndSanitize(ctx.world, seerId, action, {
                    phase: model_1.Phase.Night,
                    day: ctx.currentDay(),
                    abilityId: ability.id,
                });
                if (!ctx.isCurrent())
                    return;
                if (!scope.isEligible()) {
                    ctx.nativeNightFailure.scopeStale("seer");
                    continue;
                }
                if (!delivery.current())
                    continue;
                if (!result.ok || !result.sanitizedCall) {
                    ctx.nativeNightFailure.actionInvalid("seer");
                    continue;
                }
                const targetId = result.sanitizedCall.args.target_id;
                const target = targets.get(targetId);
                if (!target ||
                    !(0, night_effects_1.livingNightLife)(ctx.world, target) ||
                    !identities.get(targetId)?.isCurrent())
                    continue;
                const mapping = ctx.nativeNightTargets.mappedTarget(() => day, () => targetId);
                const receipt = ctx.nativeNightTargets.reflectedTarget(() => day, () => seerId, () => targetId, "check");
                if (receipt && (ability.source.kind !== "native" || ability.source.role !== model_1.Role.Seer))
                    throw new Error("time_consort_seer_source_invalid");
                const effectiveId = receipt?.effectiveId ?? mapping?.effectiveId ?? targetId;
                const effectiveIdentity = identities.get(effectiveId);
                if (mapping && (!mapping.isCurrent() || !effectiveIdentity?.isCurrent()))
                    throw new Error("magician_inspection_target_stale");
                const inspection = (0, inspection_1.resolveInspection)(ctx.world, effectiveId, "camp", ctx.roleCatalog);
                if (!ctx.isCurrent())
                    return;
                if (!scope.isEligible() ||
                    !identities.get(targetId)?.isCurrent() ||
                    !(0, night_effects_1.livingNightLife)(ctx.world, target) ||
                    !(0, ports_2.seerTargetAllowed)(ability.state, seerId, targetId) ||
                    !(0, history_ports_1.luckyTargetAllowed)(ctx.world, seerId, ability, day, "check", targetId))
                    continue;
                if (mapping && (!mapping.isCurrent() || !effectiveIdentity?.isCurrent()))
                    throw new Error("magician_inspection_target_stale");
                if (!inspection)
                    continue;
                const isWerewolf = inspection.camp === model_1.Camp.Wolf;
                const seerRole = ctx.world.getComponent(seerId, names_1.COMPONENT.Role);
                if (!(0, inventory_ports_1.activeNightAbility)(seerRole, "seer_check", ctx.currentDay(), ability.id))
                    continue;
                const seerState = seerRole ? (0, ports_3.getSeerState)(seerRole, ability.id) : undefined;
                if (receipt && (!receipt.isCurrent() || !effectiveIdentity?.isCurrent()))
                    throw new Error("time_consort_inspection_target_stale");
                const effects = ctx.nativeNightEffects;
                const commitReflectedTarget = effects.commitReflectedTarget;
                const reflectedArguments = [
                    receipt,
                    day,
                    seerId,
                    "check",
                ];
                const invokeReflectedTarget = Reflect.apply.bind(Reflect);
                if (!delivery.current())
                    continue;
                invokeReflectedTarget(commitReflectedTarget, effects, reflectedArguments);
                if (seerState) {
                    ports_1.SEER_STATE_SLOT.allowedWrites.recordSeerInspection(seerState, targetId, isWerewolf, inspection);
                }
                (0, inspection_ports_1.commitFoxInspection)(ctx.world, ctx.state, target, day, () => scope.isOwnerCurrent(true));
                ctx.state.seerChecks.push({ seerId, targetId, isWerewolf, result: { ...inspection } });
                (0, inventory_ports_2.recordNightAbilityUse)(ability, ctx.currentDay(), true);
                ctx.nativeNightEffects.recordModifierTarget(day, seerId, "check", () => targetId);
                ctx.nativeNightEffects.commitNativeReflection("seer_check", ability, targetId, () => scope.life, () => scope.isOwnerCurrent() && !ability.disabled && !ability.deathExpired);
                (0, history_ports_1.recordOwnNightAction)(ctx.world, seerId, day, "check", targetId, false);
                delivery.complete();
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "seer_checked",
                    payload: {
                        actorId: seerId,
                        ...(ability.source.kind === "native" ? {} : { abilityId: ability.id }),
                        targetId,
                        isWerewolf,
                        result: { ...inspection },
                    },
                });
            }
            catch (error) {
                failed = true;
                throw error;
            }
            finally {
                if (failed) {
                    try {
                        delivery?.close();
                    }
                    catch {
                    }
                }
                else {
                    delivery?.close();
                }
            }
        }
    },
};
exports.SEER_NIGHT_STAGES = [seerCheckStage];
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    ...exports.SEER_NIGHT_STAGES
].map((handler) => Object.freeze([handler, handler.execute])));
