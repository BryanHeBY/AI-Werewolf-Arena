import { bindLegacyAwakenedProposals, bindSyntheticNightDamageCommands } from "../engine/night/trusted-runtime";
import { createBoundToolGateway } from "../engine/actions/tool-gateway";
import { bindPaidDreamNightProbe } from "../features/dreamer/night-links";
import { OWNED_NIGHT_STAGE_PROGRAMS as AnimalDreamNightStagesPrograms } from "../features/animal-dream/night-stages";
import { AWAKENED_NIGHT_STAGES, OWNED_NIGHT_STAGE_PROGRAMS as AwakenedHiddenWolfNightStagesPrograms } from "../features/awakened-hidden-wolf/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as BlackMarketMerchantNightStagePrograms } from "../features/black-market-merchant/night-stage";
import { OWNED_NIGHT_STAGE_PROGRAMS as CupidNightStagePrograms } from "../features/cupid/night-stage";
import { OWNED_NIGHT_STAGE_PROGRAMS as DeathActionsDeathAbilityActivationPrograms } from "../features/death-actions/death-ability-activation";
import { OWNED_NIGHT_STAGE_PROGRAMS as DemonHunterNightStagesPrograms } from "../features/demon-hunter/night-stages";
import { DREAMER_NIGHT_STAGE, OWNED_NIGHT_STAGE_PROGRAMS as DreamerNightStagesPrograms } from "../features/dreamer/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as EvilKnightNightFramePrograms } from "../features/evil-knight/night-frame";
import { OWNED_NIGHT_STAGE_PROGRAMS as FragrantPairSeerNightStagesPrograms } from "../features/fragrant-pair-seer/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as GhostBrideNightStagesPrograms } from "../features/ghost-bride/night-stages";
import { GRAVEKEEPER_FEEDBACK_STAGE, OWNED_NIGHT_STAGE_PROGRAMS as GravekeeperFeedbackPrograms } from "../features/gravekeeper/feedback";
import { OWNED_NIGHT_STAGE_PROGRAMS as GuardNightStagesPrograms } from "../features/guard/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as HybridNightStagePrograms } from "../features/hybrid/night-stage";
import { OWNED_NIGHT_STAGE_PROGRAMS as MagicianNightStagesPrograms } from "../features/magician/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as MechanicalWolfNightStagesPrograms } from "../features/mechanical-wolf/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as MiracleMerchantNightStagePrograms } from "../features/miracle-merchant/night-stage";
import { OWNED_NIGHT_STAGE_PROGRAMS as MistRavenNightStagesPrograms } from "../features/mist-raven/night-stages";
import { isOwnedRecipientAbilityProgram } from "../features/night-abilities/recipient-ability-stage";
import { OWNED_NIGHT_STAGE_PROGRAMS as NightmareNightStagesPrograms } from "../features/nightmare/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as NobleSecretBodyNightStagesPrograms } from "../features/noble-secret-body/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as PureWhiteNightStagesPrograms } from "../features/pure-white/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as RadiantEclipseNightStagesPrograms } from "../features/radiant-eclipse/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as RoleInspectionNightStagesPrograms } from "../features/role-inspection/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as ScholarMentorNightStagesPrograms } from "../features/scholar-mentor/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as SeerNightStagesPrograms } from "../features/seer/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as TimeWolfConsortNightStagesPrograms } from "../features/time-wolf-consort/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as TricksterNightStagesPrograms } from "../features/trickster/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as WitchNightStagesPrograms } from "../features/witch/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as WolfBeautyNightStagesPrograms } from "../features/wolf-beauty/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as WolfSorcererNightStagesPrograms } from "../features/wolf-sorcerer/night-stages";
import { OWNED_NIGHT_STAGE_PROGRAMS as WolfNightStagesPrograms } from "../features/wolf/night-stages";
const programs = [
    ...AnimalDreamNightStagesPrograms,
    ...AwakenedHiddenWolfNightStagesPrograms,
    ...BlackMarketMerchantNightStagePrograms,
    ...CupidNightStagePrograms,
    ...DeathActionsDeathAbilityActivationPrograms,
    ...DemonHunterNightStagesPrograms,
    ...DreamerNightStagesPrograms,
    ...EvilKnightNightFramePrograms,
    ...FragrantPairSeerNightStagesPrograms,
    ...GhostBrideNightStagesPrograms,
    ...GravekeeperFeedbackPrograms,
    ...GuardNightStagesPrograms,
    ...HybridNightStagePrograms,
    ...MagicianNightStagesPrograms,
    ...MechanicalWolfNightStagesPrograms,
    ...MiracleMerchantNightStagePrograms,
    ...MistRavenNightStagesPrograms,
    ...NightmareNightStagesPrograms,
    ...NobleSecretBodyNightStagesPrograms,
    ...PureWhiteNightStagesPrograms,
    ...RadiantEclipseNightStagesPrograms,
    ...RoleInspectionNightStagesPrograms,
    ...ScholarMentorNightStagesPrograms,
    ...SeerNightStagesPrograms,
    ...TimeWolfConsortNightStagesPrograms,
    ...TricksterNightStagesPrograms,
    ...WitchNightStagesPrograms,
    ...WolfBeautyNightStagesPrograms,
    ...WolfSorcererNightStagesPrograms,
    ...WolfNightStagesPrograms
];
const syntheticDamageStages = new WeakSet();
export function bindSyntheticNightDamageStage(handler) { syntheticDamageStages.add(handler); return handler; }
import { sourceNightStageHandler } from "./night-stage-registration";
export function bindNightStageContext(handler, runtime) {
    const source = sourceNightStageHandler(handler);
    let ports;
    if (source === DREAMER_NIGHT_STAGE)
        ports = bindPaidDreamNightProbe({ state: () => runtime.state, world: () => runtime.world });
    else if (AWAKENED_NIGHT_STAGES.some((known) => known === source))
        ports = bindLegacyAwakenedProposals(runtime);
    else if (source === GRAVEKEEPER_FEEDBACK_STAGE)
        ports = {
            get runFeedback() {
                const callee = GRAVEKEEPER_FEEDBACK_STAGE.execute;
                return () => executePreparedNightStage(GRAVEKEEPER_FEEDBACK_STAGE, callee, runtime);
            },
        };
    else if (syntheticDamageStages.has(handler))
        ports = bindSyntheticNightDamageCommands(runtime);
    return {
        get isCurrent() { const callee = runtime.isCurrent, invoke = Reflect.apply.bind(Reflect); return () => invoke(callee, runtime, []); },
        get previousExile() { return runtime.previousExile; },
        get actions() { return createBoundToolGateway(() => runtime.toolGateway, () => runtime.world); },
        get actionProvider() {
            const provider = runtime.actionProvider;
            return { get getAction() { const callee = provider.getAction, invoke = Reflect.apply.bind(Reflect); return (request) => invoke(callee, provider, [request]); } };
        },
        get currentDay() { const callee = runtime.currentDay, invoke = Reflect.apply.bind(Reflect); return () => invoke(callee, runtime, []); },
        get makeRequest() { const callee = runtime.makeRequest, invoke = Reflect.apply.bind(Reflect); return (actor, tools, extras) => invoke(callee, runtime, [actor, tools, extras]); },
        entityIds() { return runtime.world.entityIds(); },
        get getAliveByRole() { const callee = runtime.getAliveByRole, invoke = Reflect.apply.bind(Reflect); return (role) => invoke(callee, runtime, [role]); },
        get pickMajorityTarget() { const callee = runtime.pickMajorityTarget, invoke = Reflect.apply.bind(Reflect); return (votes) => invoke(callee, runtime, [votes]); },
        get pickMistKnife() { const callee = runtime.pickMistKnife; if (!callee)
            return callee; const invoke = Reflect.apply.bind(Reflect); return (ids) => invoke(callee, runtime, [ids]); },
        get shuffleWolves() { const callee = runtime.shuffleWolves, invoke = Reflect.apply.bind(Reflect); return (ids) => invoke(callee, runtime, [ids]); },
        get ports() { return ports; },
    };
}
export function executePreparedNightStage(handler, callee, runtime) {
    const invoke = Reflect.apply.bind(Reflect), source = sourceNightStageHandler(handler);
    const owned = programs.some(([known, program]) => known === source && program === callee) || isOwnedRecipientAbilityProgram(source, callee);
    const context = owned ? runtime : bindNightStageContext(handler, runtime);
    return invoke(callee, handler, [context]);
}
