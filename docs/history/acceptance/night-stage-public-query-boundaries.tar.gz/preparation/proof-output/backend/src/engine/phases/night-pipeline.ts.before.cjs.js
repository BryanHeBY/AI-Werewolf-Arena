"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NightPipeline = void 0;
const dream_night_effects_1 = require("../../domain/dream-night-effects");
const night_unit_1 = require("../../domain/night-unit");
const night_lifecycle_plan_1 = require("../../rulesets/night-lifecycle-plan");
const night_readability_1 = require("../../rulesets/night-readability");
const rule_plan_1 = require("../../rulesets/rule-plan");
const actor_query_ports_1 = require("../../features/night-abilities/actor-query-ports");
const ports_1 = require("../../features/fragrant-pair-seer/ports");
const ports_2 = require("../../features/noble-secret-body/ports");
const ports_3 = require("../../features/radiant-eclipse/ports");
const ports_4 = require("../../features/scholar-mentor/ports");
const ports_5 = require("../../features/mist-raven/ports");
const night_damage_composition_1 = require("../../rulesets/night-damage-composition");
const ports_6 = require("../../features/time-wolf-consort/ports");
const ports_7 = require("../../features/magician/ports");
const ports_8 = require("../../features/demon-hunter/ports");
const ports_9 = require("../../features/nightmare/ports");
const ports_10 = require("../../features/evil-knight/ports");
const ports_11 = require("../../features/demon-hunter/ports");
const names_1 = require("../../domain/components/names");
const status_marks_1 = require("../../domain/components/status-marks");
const model_1 = require("../../domain/model");
const night_stage_plan_1 = require("../../rulesets/night-stage-plan");
const context_1 = require("../../recording/session/context");
const recorder_1 = require("../../recording/session/recorder");
const action_request_factory_1 = require("../actions/action-request-factory");
const random_1 = require("../../domain/random");
const night_damage_composition_2 = require("../../rulesets/night-damage-composition");
const night_source_delivery_1 = require("../../rulesets/night-source-delivery");
const night_knife_admission_1 = require("../../rulesets/night-knife-admission");
const night_effects_1 = require("../../domain/night-effects");
const alive_1 = require("../../domain/components/alive");
const night_commit_admission_1 = require("../../rulesets/night-commit-admission");
class NightPipeline {
    world;
    toolGateway;
    damageResolutionSystem;
    events;
    stageRegistry;
    random;
    #rulePlan;
    constructor(dependencies) {
        this.world = dependencies.world;
        this.toolGateway = dependencies.toolGateway;
        this.damageResolutionSystem = dependencies.damageResolutionSystem;
        this.events = dependencies.events;
        this.stageRegistry = dependencies.stageRegistry ?? (0, night_stage_plan_1.getDefaultNightStageRegistry)();
        this.random = dependencies.random ?? (0, random_1.createRandom)();
        this.#rulePlan = dependencies.rulePlan;
    }
    async execute(config, actionProvider, day, options = {}) {
        (0, night_readability_1.assertNightSetupReady)({ world: () => this.world });
        const isCurrent = options.isCurrent ?? (() => true);
        if (!isCurrent())
            return (0, ports_2.attachNobleNightReceiver)({ interrupted: true }, (0, ports_2.createNobleNightAbortReceiver)());
        const pipeline = this;
        const prepare = this.#rulePlan
            ? this.#rulePlan.prepareNightPipelineLifecycle.bind(this.#rulePlan)
            : night_lifecycle_plan_1.prepareNightPipelineLifecycle;
        const lifecycle = prepare({
            get world() {
                return pipeline.world;
            },
            get events() {
                return pipeline.events;
            },
            get random() {
                return pipeline.random;
            },
        }, config, day, () => options.lifecycleHandoff);
        config = lifecycle.config;
        const rulePlan = (this.#rulePlan ??= rule_plan_1.RulePlan.compile(lifecycle.parameters));
        const { ownsWedding, ownsDemon, ownsNoble, ownsFragrant, ownsAnimal, ownsRadiant, ownsMist, animalNight, fragrantNight, nobleNight, radiantNight, mistNight, weddingNight, } = lifecycle;
        try {
            lifecycle.open(isCurrent);
            const readability = {
                world: () => this.world,
                config: () => config,
                ownsAnimal: () => ownsAnimal,
                ownsFragrant: () => ownsFragrant,
                ownsNoble: () => ownsNoble,
                ownsRadiant: () => ownsRadiant,
                ownsMist: () => ownsMist,
                ownsDemon: () => ownsDemon,
            };
            const assertReadable = () => (0, night_readability_1.assertNightReadable)(readability);
            assertReadable();
            const nativeProvider = ownsAnimal ||
                ownsRadiant ||
                ownsMist ||
                ownsDemon ||
                (0, ports_10.isEvilKnightBoard)(this.world) ||
                (0, ports_9.isNightmareBoard)(this.world) ||
                config.magician !== undefined ||
                config.scholarMentor !== undefined
                ? {
                    getAction: async (request) => {
                        assertReadable();
                        const action = await actionProvider.getAction(request);
                        assertReadable();
                        return action;
                    },
                }
                : actionProvider;
            if (ownsWedding)
                weddingNight.open(day, isCurrent);
            (0, night_commit_admission_1.assertNightCommitAdmission)({ world: () => this.world, day: () => day });
            (0, recorder_1.safeRecordLogicOp)({
                scope: "phase_pipeline",
                op: "night_pipeline_start",
                phase: model_1.Phase.Night,
                status: "ok",
                input: {
                    board_size: config.boardSize,
                },
            });
            const stageState = {
                wolfChatOrder: [],
                endedWolves: new Set(),
                wolfVotes: {},
                wolfTarget: null,
                seerChecks: [],
                poisonClaims: [],
                guardClaims: [],
                merchantBacklashes: [],
                blackMarketBacklashes: [],
                mechanicalEffects: { shields: [], attacks: [], failures: [] },
                awakenedEffects: { shields: [], attacks: [] },
            };
            const requests = new action_request_factory_1.GameActionRequestFactory(this.world, this.events, day);
            const stageCtx = {
                isCurrent,
                previousExile: options.previousExile ? structuredClone(options.previousExile) : null,
                world: this.world,
                get nightActors() {
                    return (0, actor_query_ports_1.bindNightAbilityActorQuery)(this.world);
                },
                get nativeNightFailure() {
                    return rulePlan.nativeNightFailure(() => this.world);
                },
                get nativeNightTargets() {
                    return rulePlan.nativeNightTargets(() => this);
                },
                get nativeNightEffects() {
                    return rulePlan.nativeNightEffects(() => this);
                },
                roleCatalog: this.stageRegistry.roleCatalog,
                toolGateway: this.toolGateway,
                events: this.events,
                actionProvider: nativeProvider,
                currentDay: () => day,
                get requestFactory() {
                    return action_request_factory_1.GameActionRequestFactory;
                },
                makeRequest: (actorId, allowedTools, context) => this.makeRequest(requests, actorId, allowedTools, context),
                getAliveByRole: (role) => this.getAliveByRole(role),
                ensureMarks: (entityId) => this.ensureMarks(entityId),
                pickMajorityTarget: (votes) => this.pickMajorityTarget(votes, config.tieBreaker?.wolfKillVote ?? "min_id"),
                pickMistKnife: (ids) => ids.length
                    ? ids[Math.floor(this.random.fork(`day:${day}:mist-knife`).next() * ids.length)]
                    : null,
                shuffleWolves: (ids) => (0, random_1.shuffled)(ids, this.random.fork(`day:${day}:wolf-order`)),
                state: stageState,
            };
            const knifeAdmission = {
                world: () => this.world,
                state: () => stageState,
                ownsWedding: () => ownsWedding,
                day: () => day,
            };
            for (const entry of rulePlan.nightPlan(this.stageRegistry, () => this.world).entries) {
                const stage = entry.handler;
                (0, ports_10.assertEvilKnightRosterCurrent)(this.world);
                if (!isCurrent())
                    return (0, night_unit_1.attachNightUnit)((0, ports_2.attachNobleNightReceiver)({ interrupted: true }, nobleNight.receiver), lifecycle.nightUnit);
                assertReadable();
                (0, night_knife_admission_1.discardStaleNightKnives)(knifeAdmission);
                (0, night_damage_composition_1.assertNightModifierBonusEffects)({ config: () => config, stageContext: () => stageCtx });
                await stage.execute(stageCtx);
                (0, night_damage_composition_1.assertNightModifierBonusEffects)({ config: () => config, stageContext: () => stageCtx });
                (0, ports_10.assertEvilKnightRosterCurrent)(this.world);
                assertReadable();
                if (!isCurrent())
                    return (0, night_unit_1.attachNightUnit)((0, ports_2.attachNobleNightReceiver)({ interrupted: true }, nobleNight.receiver), lifecycle.nightUnit);
                (0, night_knife_admission_1.discardStaleNightKnives)(knifeAdmission);
            }
            (0, night_knife_admission_1.discardStaleNightKnives)(knifeAdmission);
            const { demonSources, demonWolfSourceCurrent, demonKnifeProtection } = (0, night_source_delivery_1.prepareNightSourceDelivery)({
                ownsDemon: () => ownsDemon,
                world: () => this.world,
                day: () => day,
                claims: () => stageState,
            });
            const { dreamFrame, damage } = (0, night_damage_composition_2.composeNightDamage)({
                ownsRadiant: () => ownsRadiant,
                world: () => this.world,
                day: () => day,
                claims: () => stageState,
                config: () => config,
                stageContext: () => stageCtx,
                solver: () => this.damageResolutionSystem,
                aliveByRole: (role) => this.getAliveByRole(role()),
            });
            if (ownsNoble) {
                const payload = {
                    policy: "awa_noble_secret_body_v1",
                    actorId: (0, ports_2.checkpointNobleBodyAuthority)(this.world, false).bodyId,
                    day,
                };
                this.events.push({
                    timestamp: Date.now(),
                    type: "noble_body_native_damage_committed",
                    payload,
                    audience: Object.freeze([]),
                });
                (0, context_1.getSessionRecorder)()?.recordRequiredLogicOp({
                    scope: "resolution",
                    op: "noble_body_native_damage_committed",
                    phase: model_1.Phase.Night,
                    status: "ok",
                    output: payload,
                });
            }
            assertReadable();
            for (const reflection of damage.poisonReflections ?? [])
                this.events.push({
                    timestamp: Date.now(),
                    type: "mechanical_poison_reflected",
                    payload: { ...reflection, day },
                });
            const mist = ownsMist
                ? mistNight.captureDamage(this.world, day, stageState.wolfTarget)
                : null;
            if (mist?.extra && (0, night_effects_1.livingNightLife)(this.world, mist.extra)) {
                const id = mist.extra.id;
                if (!damage.deaths.includes(id))
                    damage.deaths.push(id);
                damage.deathSources[id] = [
                    ...new Set([...(damage.deathSources[id] ?? []), model_1.DeathCause.RavenClawKnife]),
                ];
            }
            if (!mist?.delayEligible)
                dreamFrame.expandInitialDamage((0, dream_night_effects_1.bindDreamLifeQueries)(this.world), damage);
            if (!mist?.delayEligible && !ownsNoble)
                (0, recorder_1.safeRecordLogicOp)({
                    scope: "resolution",
                    op: "night_damage_resolved",
                    phase: model_1.Phase.Night,
                    status: "ok",
                    output: {
                        deaths: damage.deaths,
                        death_sources: damage.deathSources,
                    },
                });
            const summary = {
                wolfTarget: stageState.wolfTarget,
                deaths: [...damage.deaths],
                seerChecks: stageState.seerChecks,
                interruptedBySelfDestruct: false,
            };
            const deathLives = ownsDemon
                ? (0, ports_11.originalDemonNightLives)(this.world)
                : new Map((mist?.delayEligible ? this.world.getAliveEntityIds() : damage.deaths).map((id) => {
                    const life = this.world.getComponent(id, names_1.COMPONENT.Alive);
                    return [id, { life, version: (0, alive_1.aliveLifeVersion)(life) }];
                }));
            lifecycle.finishPipeline();
            return (0, night_unit_1.attachNightUnit)((0, ports_2.attachNobleNightReceiver)({
                interrupted: false,
                summary,
                damage,
                dreamFrame,
                ...(mist ? { mistDelay: mist.delayEligible } : {}),
                deathLives,
                retaliationAttacks: stageState.retaliationAttacks,
                blocksPassiveNightShot: (0, ports_10.captureEvilKnightNightShotProtection)(stageState),
                inspectionAttacks: stageState.inspectionAttacks,
                foxInspections: stageState.foxInspections,
                ...(demonSources ? { demonSources, demonWolfSourceCurrent, demonKnifeProtection } : {}),
            }, nobleNight.receiver), lifecycle.nightUnit);
        }
        finally {
            lifecycle.abortPipeline();
        }
    }
    makeRequest(requests, actorId, allowedTools, context) {
        const { stage, requiresAction = true, ...extraContext } = context;
        return requests.create({
            phase: model_1.Phase.Night,
            actorId,
            allowedTools,
            stage,
            requiresAction,
            summary: { key: "request.summary.night_action" },
            context: {
                ...extraContext,
                ...((0, ports_5.isMistRavenBoard)(this.world) &&
                    (allowedTools.includes("kill_vote") || allowedTools.includes("speak_to_wolves"))
                    ? { wolf_kill_candidates: (0, ports_5.mistKnifeTargets)(this.world) ?? this.world.getAliveEntityIds() }
                    : {}),
                ...(((0, ports_1.isFragrantPairBoard)(this.world) &&
                    (allowedTools.includes("kill_vote") || allowedTools.includes("speak_to_wolves"))) ||
                    (0, ports_2.isNobleBodyBoard)(this.world) ||
                    (0, ports_3.isRadiantEclipseBoard)(this.world) ||
                    (0, ports_5.isMistRavenBoard)(this.world) ||
                    (0, ports_4.isScholarMentorBoard)(this.world) ||
                    (0, ports_6.isTimeConsortBoard)(this.world) ||
                    (0, ports_7.isMagicianBoard)(this.world) ||
                    (0, ports_10.isEvilKnightBoard)(this.world) ||
                    (0, ports_9.isNightmareBoard)(this.world) ||
                    (0, ports_8.isRedMoonBoard)(this.world)
                    ? { action_failure_policy: "error", allow_fallback: false }
                    : {}),
            },
        });
    }
    getAliveByRole(role) {
        return this.world.getAliveEntityIds().filter((id) => {
            const roleComp = this.world.getComponent(id, names_1.COMPONENT.Role);
            return roleComp?.role === role;
        });
    }
    ensureMarks(entityId) {
        let marks = this.world.getComponent(entityId, names_1.COMPONENT.StatusMarks);
        if (!marks) {
            marks = new status_marks_1.StatusMarksComponent();
            this.world.addComponent(entityId, names_1.COMPONENT.StatusMarks, marks);
        }
        return marks;
    }
    pickMajorityTarget(votes, strategy) {
        const entries = Object.entries(votes);
        if (entries.length === 0) {
            return null;
        }
        entries.sort((a, b) => {
            const voteDiff = b[1] - a[1];
            if (voteDiff !== 0) {
                return voteDiff;
            }
            return Number(a[0]) - Number(b[0]);
        });
        if (entries.length >= 2 && entries[0][1] === entries[1][1]) {
            if (strategy === "no_kill") {
                return null;
            }
        }
        return Number(entries[0][0]);
    }
}
exports.NightPipeline = NightPipeline;
