"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bindNativeNightEffects = bindNativeNightEffects;
const identity_1 = require("../domain/identity");
const ports_1 = require("../features/scholar-mentor/ports");
const ports_2 = require("../features/evil-knight/ports");
const ports_3 = require("../features/time-wolf-consort/ports");
const ports_4 = require("../features/demon-hunter/ports");
function bindNativeNightEffects(context) {
    return Object.freeze({
        commitReflectedTarget(receipt, day, sourceId, kind) {
            (0, ports_3.commitTimeConsortEffect)(context(), receipt, day, sourceId, kind);
        },
        recordModifierTarget(day, actorId, kind, targetId) {
            if ((0, ports_1.isScholarMentorBoard)(context().world))
                (0, ports_1.recordScholarMentorNativeTarget)(context().world, day, actorId, kind, targetId());
        },
        recordKnifeModifierTarget(targetId) {
            if ((0, ports_1.isScholarMentorBoard)(context().world)) {
                const actor = context()
                    .world.getAliveEntityIds()
                    .find((id) => (0, ports_1.scholarMentorKnifeEligible)(context().world, context().currentDay(), id));
                if (actor !== undefined)
                    (0, ports_1.recordScholarMentorNativeTarget)(context().world, context().currentDay(), actor, "kill", targetId());
            }
        },
        commitNativeReflection(kind, ability, targetId, source, isCurrent) {
            if ((0, ports_2.isEvilKnightBoard)(context().world)) {
                if (ability.source.kind !== "native" ||
                    ability.source.role !== (kind === "seer_check" ? identity_1.Role.Seer : identity_1.Role.Witch))
                    throw new Error(kind === "seer_check"
                        ? "evil_knight_seer_source_invalid"
                        : "evil_knight_witch_source_invalid");
                const reflection = (0, ports_2.commitEvilKnightReflection)(context().world, (0, ports_2.evilKnightNightBinding)(context().state, targetId), source(), kind, isCurrent);
                if (reflection)
                    (context().state.retaliationAttacks ??= []).push(reflection);
            }
        },
        loadSealedNightController: ports_4.loadDemonNativeNightController,
        loadSealedPotionController: ports_4.loadDemonNativePotionController,
    });
}
