const linksByState = new WeakMap();
function ownedLinks(state) {
    let links = linksByState.get(state);
    if (!links) {
        links = [];
        linksByState.set(state, links);
    }
    return links;
}
export function dreamNightLinksForAppend(state) {
    return ownedLinks(state);
}
export function readDreamNightLinks(state) {
    return ownedLinks(state);
}
export function installDreamNightLinks(state, links) {
    linksByState.set(state, links);
}
export function bindPaidDreamNightProbe(runtime) {
    return {
        get captureProbe() {
            const links = readDreamNightLinks(runtime.state());
            return () => {
                const frame = new ProbeDreamNightFrame(links);
                return {
                    protectedTargets: () => frame.protectedTargets(bindProbeDreamLifeQueries(runtime.world())),
                    linkedDeaths: (deaths) => frame.linkedDeaths(bindProbeDreamLifeQueries(runtime.world()), deaths),
                };
            };
        },
    };
}
import { DreamNightFrame as ProbeDreamNightFrame } from "./night-frame";
import { bindDreamLifeQueries as bindProbeDreamLifeQueries } from "../../domain/dream-night-effects";
