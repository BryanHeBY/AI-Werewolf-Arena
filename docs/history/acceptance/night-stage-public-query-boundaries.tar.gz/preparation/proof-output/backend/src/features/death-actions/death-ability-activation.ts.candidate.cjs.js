"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.DEATH_ABILITY_ACTIVATION_STAGE = void 0;
exports.hasDeathAbilityActivationCommit = hasDeathAbilityActivationCommit;
const names_1 = require("../../domain/components/names");
const death_abilities_1 = require("./death-abilities");
const committed = new WeakMap();
function hasDeathAbilityActivationCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
exports.DEATH_ABILITY_ACTIVATION_STAGE = {
    id: "death_ability_activation",
    priority: 900,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const actorId of ctx.world.getAliveEntityIds())
            for (const gun of (0, death_abilities_1.allDeathGuns)(ctx.world.getComponent(actorId, names_1.COMPONENT.Role))) {
                if (!ctx.isCurrent() || ctx.currentDay() !== day)
                    return;
                if (gun.armedOnNight !== null)
                    continue;
                (0, death_abilities_1.armDeathGun)(ctx.world, actorId, gun, day, ctx.events);
                if (gun.armedOnNight === day) {
                    const days = committed.get(ctx.world) ?? new Set();
                    days.add(day);
                    committed.set(ctx.world, days);
                }
            }
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.DEATH_ABILITY_ACTIVATION_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
