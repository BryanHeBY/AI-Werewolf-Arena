"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AWAKENED_NIGHT_STAGES = void 0;
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const night_effects_1 = require("../../domain/night-effects");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const native_installation_ports_1 = require("../night-abilities/native-installation-ports");
const inventory_ports_2 = require("../night-abilities/inventory-ports");
const inheritance_1 = require("./inheritance");
const night_scope_1 = require("./night-scope");
const state_1 = require("./state");
function owners(ctx, day, opening = false) {
    return ctx.world.getAliveEntityIds().flatMap((id) => {
        const owner = (0, night_scope_1.captureAwakenedOwner)(ctx.world, id, () => ctx.isCurrent() && ctx.currentDay() === day);
        return owner && (opening || (0, night_scope_1.currentAwakenedNight)(ctx.world, owner.role) === day) ? [owner] : [];
    });
}
const targets = (ctx, actorId, excludeSelf) => new Map(ctx.world
    .getAliveEntityIds()
    .filter((id) => !excludeSelf || id !== actorId)
    .map((id) => [id, (0, night_effects_1.captureNightLife)(ctx.world, id)]));
const effects = (ctx) => (ctx.state.awakenedEffects ??= { shields: [], attacks: [] });
const retry = (attempt) => (attempt ? { retry_attempt: attempt, retry_max: 2 } : {});
const openingStage = {
    id: "awakened_opening",
    priority: 250,
    async execute(ctx) {
        const day = ctx.currentDay();
        (0, night_scope_1.beginAwakenedNight)(ctx.world, day, owners(ctx, day, true));
    },
};
const mimicStage = {
    id: "awakened_mimic",
    priority: 580,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const owner of owners(ctx, day)) {
            if (!(0, state_1.canAwakenedMimic)(owner.state, day))
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!owner.isCurrent() || !(0, state_1.canAwakenedMimic)(owner.state, day) || !owner.canAct())
                    break;
                const candidates = targets(ctx, owner.actorId, true);
                const roles = new Map([...candidates.keys()].map((id) => {
                    const component = ctx.world.getComponent(id, names_1.COMPONENT.Role);
                    return [
                        id,
                        {
                            component,
                            role: component.role,
                            camp: ctx.world.getComponent(id, names_1.COMPONENT.Camp)?.camp,
                        },
                    ];
                }));
                if (!owner.canAct())
                    break;
                const action = candidates.size
                    ? await ctx.actionProvider.getAction(ctx.makeRequest(owner.actorId, ["awakened_mimic"], {
                        stage: "awakened_mimic",
                        requiresAction: false,
                        action_failure_policy: "error",
                        allow_fallback: false,
                        ...retry(attempt),
                    }))
                    : null;
                if (!owner.isCurrent() || !(0, state_1.canAwakenedMimic)(owner.state, day) || !owner.canAct())
                    break;
                if (action === null) {
                    if (!(0, state_1.closeAwakenedMimic)(owner.state, day, owner.canAct))
                        break;
                    (0, night_scope_1.recordAwakenedNightCommit)(ctx.world, day);
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "awakened_mimic_skipped",
                        payload: { actorId: owner.actorId, day },
                    });
                    completed = true;
                    break;
                }
                if (action.name !== "awakened_mimic")
                    continue;
                const valid = ctx.toolGateway.validateAndSanitize(ctx.world, owner.actorId, action, {
                    phase: model_1.Phase.Night,
                    day,
                });
                if (!owner.isCurrent() ||
                    !(0, state_1.canAwakenedMimic)(owner.state, day) ||
                    !valid.ok ||
                    valid.sanitizedCall?.name !== "awakened_mimic" ||
                    !owner.canAct())
                    continue;
                const targetId = valid.sanitizedCall.args.target_id, target = candidates.get(targetId), origin = roles.get(targetId);
                if (!target ||
                    !(0, night_effects_1.livingNightLife)(ctx.world, target) ||
                    !origin ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Role) !== origin.component ||
                    origin.component.role !== origin.role ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Camp)?.camp !== origin.camp)
                    continue;
                if (!owner.canAct())
                    break;
                if (!(0, state_1.learnAwakenedRole)(owner.state, targetId, origin.role, day, owner.canAct))
                    continue;
                (0, night_scope_1.recordAwakenedNightCommit)(ctx.world, day);
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "awakened_mimicked",
                    payload: { actorId: owner.actorId, day, targetId, role: owner.state.learned.role },
                });
                completed = true;
                break;
            }
            if (!completed && owner.isCurrent() && (0, state_1.canAwakenedMimic)(owner.state, day) && owner.canAct()) {
                if (targets(ctx, owner.actorId, true).size)
                    throw new Error("awakened_mimic_valid_action_missing");
                if (!owner.canAct())
                    continue;
                if (!(0, state_1.closeAwakenedMimic)(owner.state, day, owner.canAct))
                    continue;
                (0, night_scope_1.recordAwakenedNightCommit)(ctx.world, day);
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "awakened_mimic_skipped",
                    payload: { actorId: owner.actorId, day },
                });
            }
        }
    },
};
const skillStage = {
    id: "awakened_skill",
    priority: 650,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const owner of owners(ctx, day)) {
            const bound = (0, night_scope_1.bindAwakenedSkill)(owner, day), skill = bound?.skill;
            if (!bound || !skill || skill.kind === "wolf")
                continue;
            const tool = skill.kind === "poison" ? "awakened_poison" : "awakened_guard";
            const current = () => bound.isCurrent() && (0, state_1.awakenedSkillForNight)(owner.state, day) === skill && owner.canAct();
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current())
                    break;
                const candidates = targets(ctx, owner.actorId, false);
                if (!owner.canAct())
                    break;
                const action = await ctx.actionProvider.getAction(ctx.makeRequest(owner.actorId, [tool], {
                    stage: "awakened_skill",
                    requiresAction: false,
                    action_failure_policy: "error",
                    allow_fallback: false,
                    ...retry(attempt),
                }));
                if (!current())
                    break;
                if (action === null) {
                    if (!(0, state_1.skipAwakenedSkill)(owner.state, day, owner.canAct))
                        break;
                    (0, night_scope_1.recordAwakenedNightCommit)(ctx.world, day);
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "awakened_skill_skipped",
                        payload: { actorId: owner.actorId, day },
                    });
                    completed = true;
                    break;
                }
                if (action.name !== tool)
                    continue;
                const valid = ctx.toolGateway.validateAndSanitize(ctx.world, owner.actorId, action, {
                    phase: model_1.Phase.Night,
                    day,
                });
                if (!current() || !valid.ok || !valid.sanitizedCall)
                    continue;
                const call = valid.sanitizedCall;
                if (call.name !== "awakened_poison" && call.name !== "awakened_guard")
                    continue;
                const targetId = call.args.target_id, target = targetId === null ? null : candidates.get(targetId);
                if (targetId !== null && (!target || !(0, night_effects_1.livingNightLife)(ctx.world, target)))
                    continue;
                if (call.name === "awakened_poison" && skill.kind === "poison" && target) {
                    if (!owner.canAct())
                        break;
                    if (!(0, state_1.useAwakenedPoison)(owner.state, day, owner.canAct))
                        break;
                    (ctx.state.poisonClaims ??= []).push((0, night_effects_1.originalPoisonIntent)({
                        source: owner.life,
                        target,
                        isCurrent: () => bound.isCurrent(true),
                    }, {
                        family: "awakened",
                        day,
                        stage: "awakened_skill",
                        actorLife: owner.life,
                        requestedTargetId: targetId,
                        abilityId: "learned:awakened",
                    }));
                    ctx.ensureMarks(target.id).add(model_1.StatusMark.PoisonMark);
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "awakened_poison_used",
                        payload: { actorId: owner.actorId, day, targetId: target.id },
                    });
                }
                else if (call.name === "awakened_guard" && skill.kind === "guard") {
                    if (!owner.canAct())
                        break;
                    if (!(0, state_1.chooseAwakenedGuard)(owner.state, targetId, day, owner.canAct))
                        continue;
                    if (target)
                        effects(ctx).shields.push((0, night_effects_1.awakenedNightIntent)("awakened-shield", {
                            actorId: owner.actorId,
                            target,
                            isCurrent: () => bound.isCurrent(true),
                        }, {
                            family: "awakened",
                            day,
                            stage: "awakened_skill",
                            actorLife: owner.life,
                            requestedTargetId: targetId,
                            abilityId: "learned:awakened",
                        }));
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "awakened_guard_chosen",
                        payload: { actorId: owner.actorId, day, targetId },
                    });
                }
                else
                    continue;
                (0, night_scope_1.recordAwakenedNightCommit)(ctx.world, day);
                completed = true;
                break;
            }
            if (!completed && current())
                throw new Error("awakened_skill_valid_action_missing");
        }
    },
};
const attackStage = {
    id: "awakened_attack",
    priority: 660,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const owner of owners(ctx, day)) {
            const bound = (0, night_scope_1.bindAwakenedSkill)(owner, day);
            if (bound?.skill.kind !== "wolf")
                continue;
            const effectCurrent = () => bound.isCurrent() &&
                (0, inheritance_1.canAwakenedKnife)(owner.role, ctx.world, () => ctx.world.getComponent(owner.actorId, names_1.COMPONENT.Camp));
            const current = () => effectCurrent() && (0, state_1.canAwakenedExtraKnife)(owner.state, day) && owner.canAct();
            if (!current())
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current())
                    break;
                const candidates = targets(ctx, owner.actorId, false);
                if (!owner.canAct())
                    break;
                const action = await ctx.actionProvider.getAction(ctx.makeRequest(owner.actorId, ["awakened_attack"], {
                    stage: "awakened_attack",
                    requiresAction: false,
                    action_failure_policy: "error",
                    allow_fallback: false,
                    ...retry(attempt),
                }));
                if (!current())
                    break;
                let targetId = null;
                if (action !== null) {
                    if (action.name !== "awakened_attack")
                        continue;
                    const valid = ctx.toolGateway.validateAndSanitize(ctx.world, owner.actorId, action, {
                        phase: model_1.Phase.Night,
                        day,
                    });
                    if (!current() || !valid.ok || valid.sanitizedCall?.name !== "awakened_attack")
                        continue;
                    targetId = valid.sanitizedCall.args.target_id;
                }
                const target = targetId === null ? null : candidates.get(targetId);
                if (targetId !== null && (!target || !(0, night_effects_1.livingNightLife)(ctx.world, target)))
                    continue;
                if (!owner.canAct())
                    break;
                if (!(0, state_1.chooseAwakenedAttack)(owner.state, targetId, day, owner.canAct))
                    break;
                if (target)
                    effects(ctx).attacks.push((0, night_effects_1.awakenedNightIntent)("awakened-attack", { actorId: owner.actorId, target, isCurrent: effectCurrent }, {
                        family: "awakened",
                        day,
                        stage: "awakened_attack",
                        actorLife: owner.life,
                        requestedTargetId: targetId,
                        abilityId: "learned:awakened",
                    }));
                (0, night_scope_1.recordAwakenedNightCommit)(ctx.world, day);
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "awakened_attack_chosen",
                    payload: { actorId: owner.actorId, day, targetId },
                });
                completed = true;
                break;
            }
            if (!completed && current())
                throw new Error("awakened_attack_valid_action_missing");
        }
    },
};
const activationStage = {
    id: "awakened_activation",
    priority: 900,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const owner of owners(ctx, day)) {
            const learned = owner.state.learned;
            if (!learned || learned.activationNight !== null || !owner.isCurrent() || !owner.canAct())
                continue;
            let abilityId;
            let installedMirror = false;
            if (learned.skill.kind === "inspection") {
                if ((0, inventory_ports_1.allNightAbilities)(owner.role).some((ability) => ability.kind === "role_check" && ability.source.kind === "native") ||
                    (0, inventory_ports_1.retiredNightAbilityIds)(owner.role).some((id) => id.startsWith("native:role_check")))
                    throw new Error("awakened_mirror_native_binding_conflict");
                if (!owner.canAct())
                    continue;
                const installed = (0, native_installation_ports_1.installNativeAbility)(owner.role, "role_check", {
                    policy: "mirror",
                    lastTarget: null,
                    lastDay: null,
                    history: [],
                }, owner.canAct);
                if (installed === null)
                    continue;
                installedMirror = true;
                const ability = (0, inventory_ports_1.findNightAbility)(owner.role, "role_check");
                (0, inventory_ports_2.setNightAbilityStartDay)(ability, day + 1);
                abilityId = ability.id;
            }
            if (!owner.isCurrent() || owner.state.learned !== learned)
                throw new Error("awakened_activation_commit_invalid");
            if (!installedMirror && !owner.canAct())
                continue;
            const activated = (0, state_1.activateAwakenedLearning)(owner.state, day, abilityId, installedMirror ? undefined : owner.canAct);
            if (activated === "retired")
                continue;
            if (!activated)
                throw new Error("awakened_activation_commit_invalid");
            (0, night_scope_1.recordAwakenedNightCommit)(ctx.world, day);
            ctx.events.push({
                timestamp: Date.now(),
                type: "awakened_ready",
                payload: {
                    actorId: owner.actorId,
                    activationNight: day,
                    activeFromNight: day + 1,
                    role: learned.role,
                },
            });
        }
    },
};
exports.AWAKENED_NIGHT_STAGES = [
    openingStage,
    mimicStage,
    skillStage,
    attackStage,
    activationStage,
];
