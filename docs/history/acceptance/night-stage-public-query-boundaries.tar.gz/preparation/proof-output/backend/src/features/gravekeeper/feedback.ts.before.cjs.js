"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GRAVEKEEPER_FEEDBACK_STAGE = void 0;
exports.captureExileFeedback = captureExileFeedback;
const state_1 = require("./state");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const role_catalog_assembly_1 = require("../../rulesets/roles/role-catalog-assembly");
const inspection_1 = require("../../engine/inspection");
const state_2 = require("./state");
function captureExileFeedback(world, targetId, exileDay, catalog = (0, role_catalog_assembly_1.getDefaultRoleCatalog)()) {
    const result = (0, inspection_1.resolveInspection)(world, targetId, "camp", catalog);
    return result ? { exileDay, targetId, result: { ...result } } : null;
}
exports.GRAVEKEEPER_FEEDBACK_STAGE = {
    id: "gravekeeper_feedback",
    priority: 550,
    async execute(ctx) {
        const fact = ctx.previousExile, receivedDay = ctx.currentDay();
        if (!ctx.isCurrent() || !fact || fact.exileDay !== receivedDay - 1)
            return;
        for (const actorId of ctx.getAliveByRole(model_1.Role.Gravekeeper)) {
            if (!ctx.isCurrent())
                return;
            const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role);
            const state = role?.role === model_1.Role.Gravekeeper ? (0, state_2.getGravekeeperState)(role) : undefined;
            if (!state || state.history.some((report) => report.receivedDay === receivedDay))
                continue;
            (0, state_1.recordExileFeedback)(state, fact, receivedDay);
            ctx.events.push({
                timestamp: Date.now(),
                type: "gravekeeper_reported",
                payload: { ...fact, actorId, receivedDay, result: { ...fact.result } },
            });
        }
    },
};
