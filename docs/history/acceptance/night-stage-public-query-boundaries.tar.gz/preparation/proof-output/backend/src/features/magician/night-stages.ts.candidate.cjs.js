"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.MAGICIAN_EXCHANGE_STAGE = void 0;
const names_1 = require("../../domain/components/names");
const identity_1 = require("../../domain/identity");
const state_slot_1 = require("./state-slot");
const night_frame_1 = require("./night-frame");
exports.MAGICIAN_EXCHANGE_STAGE = {
    id: "magician_exchange",
    priority: 80,
    async execute(ctx) {
        const day = ctx.currentDay(), actorId = (0, night_frame_1.beginMagicianNight)(ctx.world, day);
        if (actorId === null)
            return;
        const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role);
        if (!(0, state_slot_1.getMagicianState)(role, () => ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)))
            throw new Error("magician_actor_invalid");
        const request = ctx.makeRequest(actorId, ["swap_targets"], {
            stage: "magician_exchange",
            requiresAction: true,
            action_failure_policy: "error",
            allow_fallback: false,
            swap_candidates: (0, night_frame_1.magicianChoiceTargets)(ctx.world, day),
        });
        (0, night_frame_1.assertMagicianRosterCurrent)(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        (0, night_frame_1.assertMagicianRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("magician_exchange_stale");
        if (action?.name !== "swap_targets")
            throw new Error("magician_exchange_action_missing");
        const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: identity_1.Phase.Night,
            day,
        });
        (0, night_frame_1.assertMagicianRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("magician_exchange_stale");
        if (!validated.ok || validated.sanitizedCall?.name !== "swap_targets")
            throw new Error("magician_exchange_action_invalid");
        const args = validated.sanitizedCall.args;
        const pair = args.abstain ? null : [args.first_id, args.second_id];
        (0, night_frame_1.commitMagicianExchange)(ctx.world, actorId, day, pair);
        ctx.events.push({
            timestamp: Date.now(),
            type: "magician_exchange_committed",
            payload: {
                actorId,
                day,
                pair: pair && [Math.min(pair[0], pair[1]), Math.max(pair[0], pair[1])],
            },
            audience: Object.freeze([actorId]),
        });
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.MAGICIAN_EXCHANGE_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
