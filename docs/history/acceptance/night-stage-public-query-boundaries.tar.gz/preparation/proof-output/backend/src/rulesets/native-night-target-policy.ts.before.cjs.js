"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bindNativeNightTargetPolicy = bindNativeNightTargetPolicy;
const ports_1 = require("../features/magician/ports");
const ports_2 = require("../features/time-wolf-consort/ports");
const ports_3 = require("../features/scholar-mentor/ports");
function bindNativeNightTargetPolicy(context) {
    return Object.freeze({
        mappedTarget(day, targetId) {
            return (0, ports_1.isMagicianBoard)(context().world)
                ? (0, ports_1.resolveMagicianNightTarget)(context().world, day(), targetId())
                : null;
        },
        reflectedTarget(day, sourceId, targetId, kind) {
            return (0, ports_2.isTimeConsortBoard)(context().world)
                ? (0, ports_2.resolveTimeConsortTarget)(context().world, day(), sourceId(), targetId(), kind)
                : null;
        },
        potionModifierHints(actorId) {
            return (0, ports_3.isScholarMentorBoard)(context().world)
                ? {
                    modifier_poison_blocked: (0, ports_3.scholarMentorBlocks)(context().world, context().currentDay(), actorId, "poison"),
                }
                : {};
        },
        potionKnifeHints() {
            return (0, ports_3.isScholarMentorBoard)(context().world)
                ? {
                    wolf_targets: [
                        ...new Set([
                            context().state.wolfTarget,
                            ...(context().state.modifierKnifeTargets ?? []),
                        ].filter((id) => id !== null)),
                    ],
                }
                : {};
        },
    });
}
