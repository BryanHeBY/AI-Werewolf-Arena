import { recordExileFeedback } from "./state";
import { COMPONENT } from "../../domain/components/names";
import { Role } from "../../domain/model";
import { getDefaultRoleCatalog } from "../../rulesets/roles/role-catalog-assembly";
import { resolveInspection } from "../../engine/inspection";
import { getGravekeeperState } from "./state";
export function captureExileFeedback(world, targetId, exileDay, catalog = getDefaultRoleCatalog()) {
    const result = resolveInspection(world, targetId, "camp", catalog);
    return result ? { exileDay, targetId, result: { ...result } } : null;
}
export const GRAVEKEEPER_FEEDBACK_STAGE = {
    id: "gravekeeper_feedback",
    priority: 550,
    async execute(ctx) {
        const fact = ctx.previousExile, receivedDay = ctx.currentDay();
        if (!ctx.isCurrent() || !fact || fact.exileDay !== receivedDay - 1)
            return;
        for (const actorId of ctx.getAliveByRole(Role.Gravekeeper)) {
            if (!ctx.isCurrent())
                return;
            const role = ctx.world.getComponent(actorId, COMPONENT.Role);
            const state = role?.role === Role.Gravekeeper ? getGravekeeperState(role) : undefined;
            if (!state || state.history.some((report) => report.receivedDay === receivedDay))
                continue;
            recordExileFeedback(state, fact, receivedDay);
            ctx.events.push({
                timestamp: Date.now(),
                type: "gravekeeper_reported",
                payload: { ...fact, actorId, receivedDay, result: { ...fact.result } },
            });
        }
    },
};
