"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PAIR_INSPECTION_STAGE = exports.FRAGRANT_BIND_STAGE = void 0;
const identity_1 = require("../../domain/identity");
const recorder_1 = require("../../recording/session/recorder");
const authority_1 = require("./authority");
const requests_1 = require("./requests");
const state_1 = require("./state");
async function execute(ctx, kind) {
    const day = ctx.currentDay(), actorId = (0, authority_1.fragrantChoiceActor)(ctx.world, day, kind);
    if (actorId === null)
        return;
    const name = kind === "bind" ? "bind_fragrant_pair" : "check_pair", candidates = (0, authority_1.fragrantChoiceCandidates)(ctx.world, day), request = ctx.makeRequest(actorId, [name], {
        stage: kind === "bind" ? "fragrant_bind" : "pair_inspection",
        requiresAction: true,
        allow_fallback: false,
        action_failure_policy: "error",
        ...(kind === "bind"
            ? { fragrant_pair_candidates: candidates }
            : { pair_check_candidates: candidates, ability_id: "native:pair_check" }),
    }), scope = (0, requests_1.openFragrantPairRequest)(ctx.world, day, kind, request);
    try {
        const raw = await ctx.actionProvider.getAction(request);
        if ((0, requests_1.fragrantPairRequestScope)(ctx.world, request) !== scope)
            throw Error("fragrant_request_unavailable");
        const call = (0, requests_1.readFragrantPairTool)(raw);
        if (!call || call.name !== name)
            throw Error("fragrant_required_action_invalid");
        const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, call, {
            phase: identity_1.Phase.Night,
            day,
            scope: scope,
            deferOperation: true,
        });
        if (!valid.ok || !valid.sanitizedCall || (0, requests_1.fragrantPairRequestScope)(ctx.world, request) !== scope)
            throw Error("fragrant_required_action_invalid");
        const receipt = (0, requests_1.commitFragrantPairChoice)(ctx.world, scope, valid.sanitizedCall);
        ctx.events.push("pairIds" in receipt
            ? {
                timestamp: Date.now(),
                type: "fragrant_pair_chosen",
                payload: { policy: state_1.FRAGRANT_PAIR_POLICY, ...receipt },
                audience: Object.freeze([actorId]),
            }
            : {
                timestamp: Date.now(),
                type: "fragrant_pair_inspected",
                payload: { policy: state_1.FRAGRANT_PAIR_POLICY, ...receipt },
                audience: Object.freeze([actorId]),
            });
        (0, recorder_1.safeRecordLogicOp)({
            scope: "gateway",
            op: "validate_tool_call",
            actorId,
            phase: identity_1.Phase.Night,
            status: "ok",
            input: { tool: call.name, args: call.args },
        });
        (0, recorder_1.safeRecordLogicOp)({
            scope: "phase_pipeline",
            op: kind === "bind" ? "fragrant_pair_chosen" : "fragrant_pair_inspected",
            actorId,
            phase: identity_1.Phase.Night,
            status: "ok",
            output: { policy: state_1.FRAGRANT_PAIR_POLICY, ...receipt },
        });
    }
    finally {
        (0, requests_1.closeFragrantPairRequest)(scope);
    }
}
exports.FRAGRANT_BIND_STAGE = {
    id: "fragrant_bind",
    priority: 150,
    execute: (ctx) => execute(ctx, "bind"),
};
exports.PAIR_INSPECTION_STAGE = {
    id: "pair_inspection",
    priority: 600,
    execute: (ctx) => execute(ctx, "pair"),
};
