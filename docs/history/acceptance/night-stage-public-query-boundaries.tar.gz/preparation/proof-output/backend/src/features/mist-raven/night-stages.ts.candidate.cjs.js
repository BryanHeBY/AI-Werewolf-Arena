"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.RAVEN_KNIFE_STAGE = exports.ALCHEMIST_MIST_STAGE = void 0;
const names_1 = require("../../domain/components/names");
const identity_1 = require("../../domain/identity");
const night_frame_1 = require("./night-frame");
const state_1 = require("./state");
exports.ALCHEMIST_MIST_STAGE = {
    id: "alchemist_mist",
    priority: 50,
    async execute(ctx) {
        const day = ctx.currentDay(), actorId = (0, night_frame_1.mistCasterId)(ctx.world, "alchemist"), candidates = (0, night_frame_1.mistChoiceTargets)(ctx.world, day);
        if (candidates.length < 3) {
            const state = (0, state_1.readAlchemistState)(ctx.world.getComponent(actorId, names_1.COMPONENT.Role)?.privateState.alchemist);
            const reason = !ctx.world.getAliveEntityIds().includes(actorId)
                ? "dead"
                : state?.mistRemaining === 0
                    ? "spent"
                    : "no_targets";
            ctx.events.push({
                timestamp: Date.now(),
                type: "alchemist_mist_skipped",
                payload: { actorId, day, reason },
                audience: Object.freeze([actorId]),
            });
            return;
        }
        const request = ctx.makeRequest(actorId, ["cast_mist"], {
            stage: "alchemist_mist",
            requiresAction: true,
            allow_fallback: false,
            action_failure_policy: "error",
            mist_candidates: candidates,
        });
        (0, night_frame_1.assertMistRosterCurrent)(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        (0, night_frame_1.assertMistRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("mist_choice_stale");
        if (action?.name !== "cast_mist")
            throw new Error("mist_choice_action_missing");
        const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: identity_1.Phase.Night,
            day,
        });
        (0, night_frame_1.assertMistRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || !result.ok || result.sanitizedCall?.name !== "cast_mist")
            throw new Error("mist_choice_action_invalid");
        (0, night_frame_1.commitMistChoice)(ctx.world, day, result.sanitizedCall.args.target_ids);
        const state = (0, state_1.readAlchemistState)(ctx.world.getComponent(actorId, names_1.COMPONENT.Role).privateState.alchemist);
        ctx.events.push({
            timestamp: Date.now(),
            type: "alchemist_mist_chosen",
            payload: { actorId, day, targetIds: state.mistHistory.at(-1).targetIds },
            audience: Object.freeze([actorId]),
        });
    },
};
exports.RAVEN_KNIFE_STAGE = {
    id: "raven_knife",
    priority: 450,
    async execute(ctx) {
        const day = ctx.currentDay(), actorId = (0, night_frame_1.mistCasterId)(ctx.world, "raven_claw_wolf"), candidates = (0, night_frame_1.ravenKnifeTargets)(ctx.world, day);
        if (!candidates.length) {
            const state = (0, state_1.readRavenState)(ctx.world.getComponent(actorId, names_1.COMPONENT.Role)?.privateState.ravenClaw);
            const reason = !ctx.world.getAliveEntityIds().includes(actorId)
                ? "dead"
                : state?.awakenedDay === null
                    ? "sealed"
                    : state?.extraRemaining === 0
                        ? "spent"
                        : "no_targets";
            ctx.events.push({
                timestamp: Date.now(),
                type: "raven_knife_skipped",
                payload: { actorId, day, reason },
                audience: Object.freeze([actorId]),
            });
            return;
        }
        const request = ctx.makeRequest(actorId, ["raven_knife"], {
            stage: "raven_knife",
            requiresAction: true,
            allow_fallback: false,
            action_failure_policy: "error",
            raven_candidates: candidates,
        });
        (0, night_frame_1.assertMistRosterCurrent)(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        (0, night_frame_1.assertMistRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("raven_knife_stale");
        if (action?.name !== "raven_knife")
            throw new Error("raven_knife_action_missing");
        const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: identity_1.Phase.Night,
            day,
        });
        (0, night_frame_1.assertMistRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || !result.ok || result.sanitizedCall?.name !== "raven_knife")
            throw new Error("raven_knife_action_invalid");
        (0, night_frame_1.commitRavenKnife)(ctx.world, day, result.sanitizedCall.args.target_id);
        ctx.events.push({
            timestamp: Date.now(),
            type: "raven_knife_chosen",
            payload: { actorId, day, targetId: result.sanitizedCall.args.target_id },
            audience: Object.freeze([actorId]),
        });
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.ALCHEMIST_MIST_STAGE, exports.RAVEN_KNIFE_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
