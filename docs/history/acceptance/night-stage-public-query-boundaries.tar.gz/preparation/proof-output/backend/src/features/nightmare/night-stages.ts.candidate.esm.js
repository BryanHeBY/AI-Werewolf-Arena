import { COMPONENT } from "../../domain/components/names";
import { Phase } from "../../domain/identity";
import { getNightmareShadowState } from "./state-slot";
import { assertNightmareRosterCurrent, beginNightmareNight, commitNightmareFear, } from "./night-frame";
export const NIGHTMARE_FEAR_STAGE = {
    id: "nightmare_fear",
    priority: 90,
    async execute(ctx) {
        const day = ctx.currentDay();
        const actorId = beginNightmareNight(ctx.world, day);
        if (actorId === null)
            return;
        const role = ctx.world.getComponent(actorId, COMPONENT.Role);
        if (!getNightmareShadowState(role, () => ctx.world.getComponent(actorId, COMPONENT.Camp)))
            throw new Error("nightmare_fear_actor_invalid");
        const request = ctx.makeRequest(actorId, ["fear"], {
            stage: "nightmare_fear",
            requiresAction: true,
            action_failure_policy: "error",
            allow_fallback: false,
        });
        assertNightmareRosterCurrent(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        assertNightmareRosterCurrent(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("nightmare_fear_stale");
        if (action?.name !== "fear")
            throw new Error("nightmare_fear_action_missing");
        const args = action.args;
        if (!args ||
            typeof args.abstain !== "boolean" ||
            (args.abstain
                ? args.target_id !== null
                : typeof args.target_id !== "number" || !Number.isSafeInteger(args.target_id)))
            throw new Error("nightmare_fear_action_invalid");
        const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: Phase.Night,
            day,
        });
        assertNightmareRosterCurrent(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("nightmare_fear_stale");
        if (!validated.ok || validated.sanitizedCall?.name !== "fear")
            throw new Error("nightmare_fear_action_invalid");
        const targetId = validated.sanitizedCall.args.target_id;
        commitNightmareFear(ctx.world, actorId, day, targetId);
        ctx.events.push({
            timestamp: Date.now(),
            type: "nightmare_fear_committed",
            payload: { actorId, day, targetId },
            audience: Object.freeze([actorId]),
        });
    },
};
export const OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    NIGHTMARE_FEAR_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
