"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.DEMON_HUNTER_NIGHT_STAGE = void 0;
const authority_1 = require("./authority");
exports.DEMON_HUNTER_NIGHT_STAGE = {
    id: "demon_hunter_action",
    priority: 650,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (!(0, authority_1.demonHunterNeedsTurn)(ctx.world, day))
            return;
        const { executeDemonHunterTurn } = await Promise.resolve().then(() => require("./controller"));
        const fact = await executeDemonHunterTurn({
            world: ctx.world,
            gateway: ctx.toolGateway,
            events: ctx.events,
            provider: ctx.actionProvider,
            day,
            construction: ctx,
        });
        ctx.events.push({
            timestamp: Date.now(),
            type: "demon_hunter_chosen",
            payload: fact,
            audience: Object.freeze([fact.actorId]),
        });
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.DEMON_HUNTER_NIGHT_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
