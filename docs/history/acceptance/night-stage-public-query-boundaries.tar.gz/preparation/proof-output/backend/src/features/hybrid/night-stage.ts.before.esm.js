import { COMPONENT } from "../../domain/components/names";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { RequestLease } from "../../domain/request-lease";
import { createVictoryComponent } from "../../domain/components/victory";
import { Camp, Phase, Role } from "../../domain/model";
import { captureNightLife, livingNightLife } from "../../domain/night-effects";
import { canChooseExemplar, getHybridState, commitHybridChoice } from "./state-slot";
const committed = new WeakMap();
export function hasHybridNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
const requestLease = RequestLease.window({
    actorId: (scope) => scope.actorId,
    phase: () => Phase.Night,
    day: (scope) => scope.day,
    stage: () => "hybrid",
    current: (scope) => scope.current(),
}, 120);
export const HYBRID_STAGE = {
    id: "hybrid",
    priority: 110,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (day !== 1)
            return;
        for (const actorId of ctx.getAliveByRole(Role.Hybrid)) {
            const role = ctx.world.getComponent(actorId, COMPONENT.Role);
            const state = getHybridState(role), life = captureNightLife(ctx.world, actorId);
            const victory = ctx.world.getComponent(actorId, COMPONENT.Victory);
            if (!state ||
                !life ||
                !victory ||
                ctx.world.getComponent(actorId, COMPONENT.Camp)?.camp !== Camp.Good)
                continue;
            const privateState = role.privateState, affiliations = victory.affiliations;
            const current = () => ctx.isCurrent() &&
                ctx.currentDay() === day &&
                ctx.world.getComponent(actorId, COMPONENT.Role) === role &&
                role.role === Role.Hybrid &&
                ctx.world.getComponent(actorId, COMPONENT.Camp)?.camp === Camp.Good &&
                role.privateState === privateState &&
                getHybridState(role) === state &&
                livingNightLife(ctx.world, life) &&
                ctx.world.getComponent(actorId, COMPONENT.Victory) === victory &&
                victory.affiliations === affiliations &&
                affiliations.length === 0 &&
                canChooseExemplar(state, day);
            const canAct = () => !isRoleExecutionRetired(role);
            if (!current() || !canAct())
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current() || !canAct())
                    break;
                const targets = new Map(ctx.world
                    .getAliveEntityIds()
                    .filter((id) => id !== actorId)
                    .map((id) => {
                    const targetRole = ctx.world.getComponent(id, COMPONENT.Role);
                    return [
                        id,
                        {
                            life: captureNightLife(ctx.world, id),
                            role: targetRole,
                            kind: targetRole.role,
                            camp: ctx.world.getComponent(id, COMPONENT.Camp)?.camp,
                            privateState: targetRole.privateState,
                        },
                    ];
                }));
                if (!targets.size)
                    throw new Error("hybrid_valid_action_missing");
                const provider = ctx.actionProvider, getAction = provider.getAction, makeRequest = ctx.makeRequest;
                const requestActor = actorId;
                const requestTools = ["choose_exemplar"];
                const requestExtras = {
                    stage: "hybrid",
                    requiresAction: true,
                    allow_fallback: false,
                    ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                };
                const requestArgs = [requestActor, requestTools, requestExtras];
                const invokeRequest = Reflect.apply.bind(Reflect);
                if (!canAct())
                    break;
                const request = invokeRequest(makeRequest, ctx, requestArgs);
                const requestScope = {
                    actorId,
                    day,
                    current: () => current() && canAct(),
                };
                requestLease.bind(requestScope, request);
                const turn = requestLease.openDelivery(requestScope, request);
                let bodyFailed = false;
                try {
                    if (!turn)
                        break;
                    const actionArgs = [request];
                    const invokeAction = Reflect.apply.bind(Reflect);
                    if (!canAct() || !turn.current())
                        break;
                    const action = await invokeAction(getAction, provider, actionArgs);
                    if (!current() || !canAct() || !turn.current())
                        break;
                    if (action?.name !== "choose_exemplar")
                        continue;
                    const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                        phase: Phase.Night,
                        day,
                    });
                    if (!current() ||
                        !valid.ok ||
                        valid.sanitizedCall?.name !== "choose_exemplar" ||
                        !canAct() ||
                        !turn.current())
                        continue;
                    const targetId = valid.sanitizedCall.args.target_id, target = targets.get(targetId);
                    if (!target ||
                        !livingNightLife(ctx.world, target.life) ||
                        ctx.world.getComponent(targetId, COMPONENT.Role) !== target.role ||
                        target.role.role !== target.kind ||
                        ctx.world.getComponent(targetId, COMPONENT.Camp)?.camp !== target.camp ||
                        target.role.privateState !== target.privateState ||
                        (target.camp !== Camp.Good && target.camp !== Camp.Wolf))
                        continue;
                    const membership = createVictoryComponent([{ kind: "faction", faction: target.camp }]);
                    const commitChoice = commitHybridChoice;
                    if (!canAct() || !turn.current())
                        continue;
                    commitChoice(state, day, targetId);
                    ctx.world.addComponent(actorId, COMPONENT.Victory, membership);
                    const days = committed.get(ctx.world) ?? new Set();
                    days.add(day);
                    committed.set(ctx.world, days);
                    turn.complete();
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "hybrid_exemplar_chosen",
                        payload: { actorId, day, targetId },
                    });
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "hybrid_affiliation_resolved",
                        payload: { actorId, day, targetId, faction: target.camp },
                    });
                    completed = true;
                    break;
                }
                catch (error) {
                    bodyFailed = true;
                    throw error;
                }
                finally {
                    try {
                        turn?.close();
                    }
                    catch (error) {
                        if (!bodyFailed)
                            throw error;
                    }
                }
            }
            if (!completed && current() && canAct())
                throw new Error("hybrid_valid_action_missing");
        }
    },
};
