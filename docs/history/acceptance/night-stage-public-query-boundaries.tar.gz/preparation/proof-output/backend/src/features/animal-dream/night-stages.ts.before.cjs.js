"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ANIMAL_FOX_STAGE = void 0;
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const identity_1 = require("../../domain/identity");
const authority_1 = require("./authority");
const requests_1 = require("./requests");
const facts_1 = require("./facts");
exports.ANIMAL_FOX_STAGE = {
    id: "fox_distract",
    priority: 150,
    async execute(ctx) {
        const day = ctx.currentDay(), actorId = (0, authority_1.animalFoxChoiceActor)(ctx.world, day);
        if (actorId !== null) {
            const request = ctx.makeRequest(actorId, ["fox_distract"], {
                stage: "fox_distract",
                requiresAction: true,
                allow_fallback: false,
                action_failure_policy: "error",
                fox_candidates: (0, authority_1.animalFoxChoiceCandidates)(ctx.world, day),
            }), scope = (0, requests_1.openAnimalRequest)(ctx.world, request);
            try {
                const raw = await ctx.actionProvider.getAction(request), call = (0, requests_1.readAnimalTool)(raw);
                if ((0, requests_1.animalRequestScope)(ctx.world, request) !== scope || call?.name !== "fox_distract")
                    throw Error("animal_required_action_invalid");
                const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, call, {
                    phase: identity_1.Phase.Night,
                    day,
                    scope: scope,
                    deferOperation: true,
                });
                if (!valid.ok || !valid.sanitizedCall)
                    throw Error("animal_required_action_invalid");
                const receipt = (0, requests_1.commitAnimalRequest)(ctx.world, scope, valid.sanitizedCall);
                if (!("targetId" in receipt))
                    throw Error("animal_receipt_invalid");
                (0, facts_1.appendAnimalFact)(ctx.world, ctx.events, "animal_fox_chosen", {
                    policy: game_contract_1.ANIMAL_DREAM_POLICY,
                    actorId,
                    ...receipt,
                });
                const effect = (0, authority_1.animalFoxEffect)(ctx.world);
                if (effect)
                    (0, facts_1.appendAnimalFact)(ctx.world, ctx.events, "animal_fox_effect", {
                        policy: game_contract_1.ANIMAL_DREAM_POLICY,
                        actorId,
                        ...effect,
                    });
            }
            finally {
                (0, requests_1.closeAnimalRequest)(scope);
            }
        }
        if (!ctx.isCurrent())
            throw Error("animal_night_revoked");
        (0, facts_1.appendAnimalKnifeNotices)(ctx.world, ctx.events, day);
        (0, facts_1.appendAnimalBeautyNotice)(ctx.world, ctx.events, day);
    },
};
