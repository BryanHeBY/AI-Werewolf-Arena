import { aliveLifeVersion } from "../../domain/components/alive";
import { COMPONENT } from "../../domain/components/names";
import { Camp, Role } from "../../domain/model";
import { captureNightLife, livingNightLife } from "../../domain/night-effects";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { awakenedSkillForNight, getAwakenedState } from "./state";
import { findNightAbility } from "../night-abilities/inventory-ports";
class CapturedAwakenedOwner {
    #world;
    actorId;
    role;
    state;
    life;
    canAct;
    isCurrent;
    constructor(world, record) {
        this.#world = world;
        this.actorId = record.actorId;
        this.role = record.role;
        this.state = record.state;
        this.life = record.life;
        this.canAct = record.canAct;
        this.isCurrent = record.isCurrent;
    }
    static belongsTo(scope, world) {
        return scope instanceof CapturedAwakenedOwner && scope.#world === world;
    }
}
export function captureAwakenedOwner(world, actorId, phaseCurrent) {
    const role = world.getComponent(actorId, COMPONENT.Role), state = getAwakenedState(role), life = captureNightLife(world, actorId);
    if (!phaseCurrent() ||
        !role ||
        role.role !== Role.AwakenedHiddenWolf ||
        world.getComponent(actorId, COMPONENT.Camp)?.camp !== Camp.Wolf ||
        !state ||
        !life)
        return null;
    const privateState = role.privateState;
    return new CapturedAwakenedOwner(world, {
        actorId,
        role,
        state,
        life,
        canAct: () => !isRoleExecutionRetired(role),
        isCurrent: (allowFirstDeath = false) => {
            const original = world.getComponent(actorId, COMPONENT.Alive) === life.life &&
                aliveLifeVersion(life.life) ===
                    life.version + (allowFirstDeath && !life.life.alive ? 1 : 0);
            return (phaseCurrent() &&
                world.getComponent(actorId, COMPONENT.Role) === role &&
                role.role === Role.AwakenedHiddenWolf &&
                world.getComponent(actorId, COMPONENT.Camp)?.camp === Camp.Wolf &&
                role.privateState === privateState &&
                getAwakenedState(role) === state &&
                original &&
                (allowFirstDeath || life.life.alive));
        },
    });
}
export function bindAwakenedSkill(owner, day) {
    const learned = owner.state.learned, skill = awakenedSkillForNight(owner.state, day);
    if (!owner.isCurrent() ||
        !learned ||
        !skill ||
        learned.activationNight === null ||
        learned.activeFromNight === null)
        return null;
    const { targetId, role, day: learnedDay, activationNight, activeFromNight } = learned, kind = skill.kind;
    return {
        skill,
        isCurrent: (allowFirstDeath = false) => owner.isCurrent(allowFirstDeath) &&
            owner.state.learned === learned &&
            learned.skill === skill &&
            skill.kind === kind &&
            learned.targetId === targetId &&
            learned.role === role &&
            learned.day === learnedDay &&
            learned.activationNight === activationNight &&
            learned.activeFromNight === activeFromNight,
    };
}
export function captureAwakenedMirrorScope(world, actorId, ability, day, phaseCurrent) {
    const owner = captureAwakenedOwner(world, actorId, phaseCurrent), learned = owner?.state.learned, skill = learned?.skill;
    if (!owner ||
        currentAwakenedNight(world, owner.role) !== day ||
        !learned ||
        learned.role !== Role.MirrorGirl ||
        learned.activationNight === null ||
        learned.activeFromNight === null ||
        day < learned.activeFromNight ||
        skill?.kind !== "inspection" ||
        skill.abilityId !== ability.id)
        return null;
    const { targetId, role, day: learnedDay, activationNight, activeFromNight } = learned, abilityId = skill.abilityId;
    return () => owner.isCurrent() &&
        currentAwakenedNight(world, owner.role) === day &&
        owner.state.learned === learned &&
        learned.skill === skill &&
        skill.kind === "inspection" &&
        skill.abilityId === abilityId &&
        learned.targetId === targetId &&
        learned.role === role &&
        learned.day === learnedDay &&
        learned.activationNight === activationNight &&
        learned.activeFromNight === activeFromNight &&
        findNightAbility(owner.role, "role_check", abilityId) === ability;
}
const nights = new WeakMap();
const committed = new WeakMap();
export function beginAwakenedNight(world, day, owners) {
    if (hasAwakenedNightCommit(world, day))
        throw new Error("awakened_night_reentry_after_commit");
    if (nights.get(world)?.day === day)
        throw new Error("awakened_night_reentry_after_commit");
    if ((nights.get(world)?.day ?? day) > day)
        throw new Error("awakened_night_clock_regressed");
    const currentOwners = owners.filter((owner) => CapturedAwakenedOwner.belongsTo(owner, world) && owner.isCurrent() && owner.canAct());
    nights.set(world, { day, owners: new Map(currentOwners.map((owner) => [owner.role, owner])) });
    if (currentOwners.length)
        recordAwakenedNightCommit(world, day);
}
export function currentAwakenedNight(world, role) {
    const night = nights.get(world), owner = night?.owners.get(role);
    return night && owner?.isCurrent() && livingNightLife(world, owner.life) ? night.day : null;
}
export function recordAwakenedNightCommit(world, day) {
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
export function hasAwakenedNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
