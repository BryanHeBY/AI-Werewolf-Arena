"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GUARD_NIGHT_STAGES = void 0;
const ports_1 = require("./ports");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const recorder_1 = require("../../recording/session/recorder");
const ports_2 = require("./ports");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const inventory_ports_2 = require("../night-abilities/inventory-ports");
const scope_ports_1 = require("../night-abilities/scope-ports");
const night_effects_1 = require("../../domain/night-effects");
const history_ports_1 = require("../night-abilities/history-ports");
const guardActionStage = {
    id: "guard_action",
    priority: 300,
    async execute(ctx) {
        if (ctx.nativeNightFailure.usesDemonController()) {
            const { executeDemonNativeNight } = await ctx.nativeNightEffects.loadSealedNightController();
            await executeDemonNativeNight(ctx, "guard");
            return;
        }
        for (const { actorId: guardId, ability } of ctx.nightActors.actors("guard", ctx.currentDay())) {
            if (ability.activation === "lucky" || ability.activation === "black_market")
                continue;
            ctx.nativeNightFailure.assertNativeActor(guardId, model_1.Role.Guard);
            const day = ctx.currentDay(), scope = (0, scope_ports_1.captureNightAbilityScope)(ctx.world, guardId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day);
            if (!scope?.isEligible())
                continue;
            const targets = new Map(ctx.world.getAliveEntityIds().map((id) => [id, (0, night_effects_1.captureNightLife)(ctx.world, id)]));
            if (!ctx.world.getAliveEntityIds().includes(guardId) ||
                (0, inventory_ports_1.activeNightAbility)(ctx.world.getComponent(guardId, names_1.COMPONENT.Role), "guard", ctx.currentDay(), ability.id) !== ability)
                continue;
            const req = ctx.makeRequest(guardId, ["guard"], { stage: "guard", ability_id: ability.id });
            if (!scope.isEligible()) {
                ctx.nativeNightFailure.scopeStale("guard");
                continue;
            }
            const action = await ctx.actionProvider.getAction(req);
            if (!ctx.isCurrent())
                return;
            if (!scope.isEligible()) {
                ctx.nativeNightFailure.scopeStale("guard");
                continue;
            }
            if (action?.name !== "guard") {
                ctx.nativeNightFailure.actionMissing("guard");
                continue;
            }
            const result = ctx.toolGateway.validateAndSanitize(ctx.world, guardId, action, {
                phase: model_1.Phase.Night,
                day: ctx.currentDay(),
                abilityId: ability.id,
            });
            if (!ctx.isCurrent())
                return;
            if (!scope.isEligible()) {
                ctx.nativeNightFailure.scopeStale("guard");
                continue;
            }
            if (!result.ok || !result.sanitizedCall) {
                ctx.nativeNightFailure.actionInvalid("guard");
                (0, recorder_1.safeRecordLogicOp)({
                    scope: "phase_pipeline",
                    op: "guard_action_rejected",
                    actorId: guardId,
                    phase: model_1.Phase.Night,
                    status: "rejected",
                });
                continue;
            }
            const currentRole = ctx.world.getComponent(guardId, names_1.COMPONENT.Role);
            if (!(0, inventory_ports_1.activeNightAbility)(currentRole, "guard", ctx.currentDay(), ability.id))
                continue;
            const abstain = result.sanitizedCall.args.abstain === true;
            const targetId = abstain ? null : result.sanitizedCall.args.target_id;
            const target = targetId === null ? null : targets.get(targetId);
            if (targetId !== null && (!target || !(0, night_effects_1.livingNightLife)(ctx.world, target)))
                continue;
            if (!abstain &&
                targetId !== null &&
                !(0, history_ports_1.luckyTargetAllowed)(ctx.world, guardId, ability, day, "guard", targetId))
                continue;
            if (!abstain && targetId !== null) {
                const receipt = ctx.nativeNightTargets.reflectedTarget(() => day, () => guardId, () => targetId, "guard");
                if (receipt && (ability.source.kind !== "native" || ability.source.role !== model_1.Role.Guard))
                    throw new Error("time_consort_guard_source_invalid");
                ctx.nativeNightEffects.commitReflectedTarget(receipt, day, guardId, "guard");
                const marks = ctx.ensureMarks(receipt?.effectiveId ?? targetId);
                marks.add(model_1.StatusMark.GuardMark);
                (ctx.state.guardClaims ??= []).push({ target: receipt?.scope ?? target, marks });
            }
            ctx.events.push({
                timestamp: Date.now(),
                type: "guard_applied",
                payload: {
                    actorId: guardId,
                    ...(ability.source.kind === "native" ? {} : { abilityId: ability.id }),
                    abstain,
                    targetId,
                },
            });
            (0, recorder_1.safeRecordLogicOp)({
                scope: "phase_pipeline",
                op: "guard_applied",
                actorId: guardId,
                phase: model_1.Phase.Night,
                status: "ok",
                output: { abstain, target_id: targetId },
            });
            const role = ctx.world.getComponent(guardId, names_1.COMPONENT.Role);
            const guardState = role ? (0, ports_2.getGuardState)(role, ability.id) : undefined;
            if (guardState) {
                ports_1.GUARD_STATE_SLOT.allowedWrites.recordGuardTarget(guardState, targetId);
            }
            (0, inventory_ports_2.recordNightAbilityUse)(ability, ctx.currentDay(), !abstain);
            ctx.nativeNightEffects.recordModifierTarget(day, guardId, "guard", () => targetId);
            if (!abstain && targetId !== null)
                (0, history_ports_1.recordOwnNightAction)(ctx.world, guardId, day, "guard", targetId, false);
        }
    },
};
exports.GUARD_NIGHT_STAGES = [guardActionStage];
