"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.TRICKSTER_EXCHANGE_STAGE = void 0;
const domain_1 = require("../../domain");
const identity_1 = require("../../domain/identity");
const state_slot_1 = require("./state-slot");
const night_frame_1 = require("./night-frame");
const exchange_ports_1 = require("../magician/exchange-ports");
exports.TRICKSTER_EXCHANGE_STAGE = {
    id: "trickster_exchange",
    priority: 100,
    async execute(ctx) {
        const day = ctx.currentDay(), actorId = (0, night_frame_1.beginTricksterNight)(ctx.world, day);
        if (actorId === null) {
            const id = (0, night_frame_1.tricksterActorId)(ctx.world);
            ctx.events.push({
                timestamp: Date.now(),
                type: "trickster_exchange_skipped",
                payload: {
                    actorId: id,
                    day,
                    reason: ctx.world.getComponent(id, domain_1.COMPONENT.Alive).alive ? "exhausted" : "dead",
                },
                audience: Object.freeze([id]),
            });
            return;
        }
        const role = ctx.world.getComponent(actorId, domain_1.COMPONENT.Role);
        if (!(0, state_slot_1.getTricksterState)(role, () => ctx.world.getComponent(actorId, domain_1.COMPONENT.Camp)))
            throw new Error("trickster_actor_invalid");
        const request = ctx.makeRequest(actorId, ["swap_exile_targets"], {
            stage: "trickster_exchange",
            requiresAction: true,
            action_failure_policy: "error",
            allow_fallback: false,
            trickster_candidates: (0, night_frame_1.tricksterChoiceTargets)(ctx.world, day),
            trickster_may_pass: (0, night_frame_1.tricksterMayPass)(ctx.world, day),
        });
        (0, night_frame_1.assertTricksterRosterCurrent)(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        (0, night_frame_1.assertTricksterRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("trickster_exchange_stale");
        if (action?.name !== "swap_exile_targets")
            throw new Error("trickster_exchange_action_missing");
        const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: identity_1.Phase.Night,
            day,
        });
        (0, night_frame_1.assertTricksterRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("trickster_exchange_stale");
        if (!validated.ok || validated.sanitizedCall?.name !== "swap_exile_targets")
            throw new Error("trickster_exchange_action_invalid");
        const args = validated.sanitizedCall.args, pair = args.abstain ? null : [args.first_id, args.second_id];
        (0, night_frame_1.commitTricksterExchange)(ctx.world, actorId, day, pair);
        ctx.events.push({
            timestamp: Date.now(),
            type: "trickster_exchange_committed",
            payload: { actorId, day, pair: pair && [Math.min(...pair), Math.max(...pair)] },
            audience: Object.freeze([actorId]),
        });
        if (pair && (0, exchange_ports_1.cancelMagicianExchangeIfMatching)(ctx.world, day, pair))
            (0, night_frame_1.cancelTricksterExchange)(ctx.world, day);
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.TRICKSTER_EXCHANGE_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
