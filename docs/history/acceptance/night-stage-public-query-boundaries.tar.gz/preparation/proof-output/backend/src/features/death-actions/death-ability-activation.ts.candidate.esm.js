import { COMPONENT } from "../../domain/components/names";
import { allDeathGuns, armDeathGun } from "./death-abilities";
const committed = new WeakMap();
export function hasDeathAbilityActivationCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
export const DEATH_ABILITY_ACTIVATION_STAGE = {
    id: "death_ability_activation",
    priority: 900,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const actorId of ctx.world.getAliveEntityIds())
            for (const gun of allDeathGuns(ctx.world.getComponent(actorId, COMPONENT.Role))) {
                if (!ctx.isCurrent() || ctx.currentDay() !== day)
                    return;
                if (gun.armedOnNight !== null)
                    continue;
                armDeathGun(ctx.world, actorId, gun, day, ctx.events);
                if (gun.armedOnNight === day) {
                    const days = committed.get(ctx.world) ?? new Set();
                    days.add(day);
                    committed.set(ctx.world, days);
                }
            }
    },
};
export const OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    DEATH_ABILITY_ACTIVATION_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
