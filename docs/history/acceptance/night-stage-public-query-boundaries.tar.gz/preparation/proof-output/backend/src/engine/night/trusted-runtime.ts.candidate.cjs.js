"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createNightStageState = createNightStageState;
exports.bindSyntheticNightDamageCommands = bindSyntheticNightDamageCommands;
exports.bindLegacyAwakenedProposals = bindLegacyAwakenedProposals;
function createNightStageState() {
    return {
        wolfChatOrder: [],
        endedWolves: new Set(),
        wolfVotes: {},
        wolfTarget: null,
        seerChecks: [],
        poisonClaims: [],
        guardClaims: [],
        merchantBacklashes: [],
        blackMarketBacklashes: [],
        mechanicalEffects: { shields: [], attacks: [], failures: [] },
        awakenedEffects: { shields: [], attacks: [] },
    };
}
function bindSyntheticNightDamageCommands(runtime) {
    return { addPoisonMark(id) { runtime.ensureMarks(id).add(model_1.StatusMark.PoisonMark); } };
}
function bindLegacyAwakenedProposals(runtime) {
    return {
        get appendShield() {
            const values = runtime.state.awakenedEffects.shields, callee = values.push, invoke = Reflect.apply.bind(Reflect);
            return (effect) => invoke(callee, values, [effect]);
        },
        get appendAttack() {
            const values = runtime.state.awakenedEffects.attacks, callee = values.push, invoke = Reflect.apply.bind(Reflect);
            return (effect) => invoke(callee, values, [effect]);
        },
        addWolfKillMark(id) { runtime.ensureMarks(id).add(model_1.StatusMark.WolfKillMark); },
    };
}
const model_1 = require("../../domain/model");
