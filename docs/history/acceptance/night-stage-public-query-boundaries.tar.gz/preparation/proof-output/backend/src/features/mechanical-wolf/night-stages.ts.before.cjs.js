"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MECHANICAL_NIGHT_STAGES = void 0;
const state_1 = require("./state");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const night_effects_1 = require("../../domain/night-effects");
const inspection_1 = require("../../engine/inspection");
const inheritance_1 = require("./inheritance");
const night_scope_1 = require("./night-scope");
const state_2 = require("./state");
function owners(ctx) {
    return ctx.world.getAliveEntityIds().flatMap((id) => {
        const owner = (0, night_scope_1.captureMechanicalOwner)(ctx.world, id, ctx.isCurrent);
        return owner ? [owner] : [];
    });
}
function targets(ctx, actorId, excludeSelf) {
    return new Map(ctx.world
        .getAliveEntityIds()
        .filter((id) => !excludeSelf || id !== actorId)
        .map((id) => [id, (0, night_effects_1.captureNightLife)(ctx.world, id)]));
}
function effects(ctx) {
    return (ctx.state.mechanicalEffects ??= { shields: [], attacks: [], failures: [] });
}
const modeStage = {
    id: "mechanical_mode",
    priority: 250,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const owner of owners(ctx)) {
            if (!owner.isCurrent())
                continue;
            (0, state_2.advanceMechanicalNight)(owner.state, day);
            if (!(0, state_2.canSelectMechanicalMode)(owner.state, day) || !owner.canAct())
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!owner.isCurrent() || !(0, state_2.canSelectMechanicalMode)(owner.state, day) || !owner.canAct())
                    break;
                const action = await ctx.actionProvider.getAction(ctx.makeRequest(owner.actorId, ["mechanical_mode"], {
                    stage: "mechanical_mode",
                    requiresAction: false,
                    ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                }));
                if (!owner.isCurrent() || !(0, state_2.canSelectMechanicalMode)(owner.state, day) || !owner.canAct())
                    break;
                let chosenMode = "skill";
                if (action !== null) {
                    if (action.name !== "mechanical_mode")
                        continue;
                    const valid = ctx.toolGateway.validateAndSanitize(ctx.world, owner.actorId, action, {
                        phase: model_1.Phase.Night,
                        day,
                    });
                    if (!owner.isCurrent() ||
                        !valid.ok ||
                        valid.sanitizedCall?.name !== "mechanical_mode" ||
                        !owner.canAct())
                        continue;
                    chosenMode = valid.sanitizedCall.args.mode;
                }
                if (!owner.canAct())
                    break;
                if (!(0, state_2.selectMechanicalMode)(owner.state, day, chosenMode, owner.canAct))
                    break;
                (0, night_scope_1.recordMechanicalModeScope)(ctx.world, owner, day);
                (0, night_scope_1.recordMechanicalNightCommit)(ctx.world, day);
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "mechanical_mode_selected",
                    payload: { actorId: owner.actorId, day, mode: owner.state.mode.kind },
                });
                completed = true;
                break;
            }
            if (!completed &&
                owner.isCurrent() &&
                (0, state_2.canSelectMechanicalMode)(owner.state, day) &&
                owner.canAct())
                throw new Error("mechanical_mode_valid_action_missing");
        }
    },
};
const mimicStage = {
    id: "mechanical_mimic",
    priority: 580,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const owner of owners(ctx)) {
            if (!(0, state_2.canMechanicalMimic)(owner.state, day))
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!owner.isCurrent() || !(0, state_2.canMechanicalMimic)(owner.state, day) || !owner.canAct())
                    break;
                const candidates = targets(ctx, owner.actorId, true);
                const targetRoles = new Map([...candidates.keys()].map((id) => {
                    const role = ctx.world.getComponent(id, names_1.COMPONENT.Role);
                    return [id, { component: role, role: role.role }];
                }));
                if (!owner.canAct())
                    break;
                const action = candidates.size
                    ? await ctx.actionProvider.getAction(ctx.makeRequest(owner.actorId, ["mimic_role"], {
                        stage: "mechanical_mimic",
                        requiresAction: false,
                        ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                    }))
                    : null;
                if (!owner.isCurrent() || !(0, state_2.canMechanicalMimic)(owner.state, day) || !owner.canAct())
                    break;
                if (action === null) {
                    if (!(0, state_2.closeMechanicalMimic)(owner.state, day, owner.canAct))
                        break;
                    (0, night_scope_1.recordMechanicalNightCommit)(ctx.world, day);
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "mechanical_mimic_skipped",
                        payload: { actorId: owner.actorId, day },
                    });
                    completed = true;
                    break;
                }
                if (action.name !== "mimic_role")
                    continue;
                const valid = ctx.toolGateway.validateAndSanitize(ctx.world, owner.actorId, action, {
                    phase: model_1.Phase.Night,
                    day,
                });
                if (!owner.isCurrent() ||
                    !valid.ok ||
                    valid.sanitizedCall?.name !== "mimic_role" ||
                    !(0, state_2.canMechanicalMimic)(owner.state, day) ||
                    !owner.canAct())
                    continue;
                const targetId = valid.sanitizedCall.args.target_id, target = candidates.get(targetId), targetRole = targetRoles.get(targetId);
                if (!target ||
                    !(0, night_effects_1.livingNightLife)(ctx.world, target) ||
                    !targetRole ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Role) !== targetRole.component ||
                    targetRole.component.role !== targetRole.role)
                    continue;
                if (!owner.canAct())
                    break;
                if (!(0, state_2.learnMechanicalRole)(owner.state, targetId, targetRole.role, day, owner.canAct))
                    continue;
                (0, night_scope_1.recordMechanicalNightCommit)(ctx.world, day);
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "mechanical_mimicked",
                    payload: {
                        actorId: owner.actorId,
                        day,
                        targetId,
                        role: owner.state.learned.role,
                        readyOnNight: day + 1,
                    },
                });
                completed = true;
                break;
            }
            if (!completed && owner.isCurrent() && (0, state_2.canMechanicalMimic)(owner.state, day) && owner.canAct())
                throw new Error("mechanical_mimic_valid_action_missing");
        }
    },
};
const skillStage = {
    id: "mechanical_skill",
    priority: 650,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const owner of owners(ctx)) {
            const skill = (0, state_2.mechanicalSkillForNight)(owner.state, day), bound = (0, night_scope_1.bindMechanicalSkill)(owner, day);
            if (!skill || !bound || !["inspection", "poison", "guard"].includes(skill.kind))
                continue;
            if (skill.kind === "poison" && skill.remaining === 0)
                continue;
            const tool = skill.kind === "inspection"
                ? "mechanical_inspect"
                : skill.kind === "poison"
                    ? "mechanical_poison"
                    : "mechanical_guard";
            const current = () => bound.isCurrent() &&
                (0, state_2.mechanicalSkillForNight)(owner.state, day) === skill &&
                (skill.kind !== "poison" || skill.remaining > 0) &&
                owner.canAct();
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current())
                    break;
                const candidates = targets(ctx, owner.actorId, skill.kind === "inspection");
                if (!owner.canAct())
                    break;
                const action = await ctx.actionProvider.getAction(ctx.makeRequest(owner.actorId, [tool], {
                    stage: "mechanical_skill",
                    requiresAction: false,
                    ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                }));
                if (!current())
                    break;
                if (action === null) {
                    if (!(0, state_2.closeMechanicalSkill)(owner.state, day, owner.canAct))
                        break;
                    (0, night_scope_1.recordMechanicalNightCommit)(ctx.world, day);
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "mechanical_skill_skipped",
                        payload: { actorId: owner.actorId, day },
                    });
                    completed = true;
                    break;
                }
                if (action.name !== tool)
                    continue;
                const valid = ctx.toolGateway.validateAndSanitize(ctx.world, owner.actorId, action, {
                    phase: model_1.Phase.Night,
                    day,
                });
                if (!current() || !valid.ok || !valid.sanitizedCall)
                    continue;
                const call = valid.sanitizedCall;
                if (!["mechanical_inspect", "mechanical_poison", "mechanical_guard"].includes(call.name) ||
                    !("target_id" in call.args))
                    continue;
                const targetId = call.args.target_id, target = targetId === null ? null : candidates.get(targetId);
                if (targetId !== null && (!target || !(0, night_effects_1.livingNightLife)(ctx.world, target)))
                    continue;
                if (call.name === "mechanical_inspect" && skill.kind === "inspection" && target) {
                    const result = (0, inspection_1.resolveInspection)(ctx.world, target.id, "role", ctx.roleCatalog);
                    if (!result || !current() || !(0, night_effects_1.livingNightLife)(ctx.world, target) || !owner.canAct())
                        continue;
                    if (!(0, state_1.recordMechanicalInspection)(skill, day, target, result, owner.canAct))
                        break;
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "role_inspected",
                        payload: { actorId: owner.actorId, day, targetId: target.id, result: { ...result } },
                    });
                }
                else if (call.name === "mechanical_poison" && skill.kind === "poison" && target) {
                    if (!owner.canAct())
                        break;
                    (ctx.state.poisonClaims ??= []).push((0, night_effects_1.originalPoisonIntent)({ source: owner.life, target }, {
                        family: "mechanical",
                        day,
                        stage: "mechanical_skill",
                        actorLife: owner.life,
                        requestedTargetId: targetId,
                        abilityId: "learned:mechanical",
                    }));
                    ctx.ensureMarks(target.id).add(model_1.StatusMark.PoisonMark);
                    (0, state_1.consumeMechanicalPoison)(skill);
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "mechanical_poison_used",
                        payload: { actorId: owner.actorId, day, targetId: target.id },
                    });
                }
                else if (call.name === "mechanical_guard" && skill.kind === "guard") {
                    if (!owner.canAct())
                        break;
                    const chosen = (0, state_2.chooseMechanicalGuard)(skill, targetId, day, owner.canAct);
                    if (!chosen)
                        break;
                    const { failed } = chosen;
                    if (failed)
                        effects(ctx).failures.push((0, night_effects_1.mechanicalNightIntent)("mechanical-failure", {
                            actorId: owner.actorId,
                            target: owner.life,
                            isCurrent: bound.isCurrent,
                        }, {
                            family: "mechanical",
                            day,
                            stage: "mechanical_skill",
                            actorLife: owner.life,
                            requestedTargetId: targetId,
                            abilityId: "learned:mechanical",
                        }));
                    else if (target)
                        effects(ctx).shields.push((0, night_effects_1.mechanicalNightIntent)("mechanical-shield", {
                            actorId: owner.actorId,
                            target,
                            isCurrent: bound.isCurrent,
                        }, {
                            family: "mechanical",
                            day,
                            stage: "mechanical_skill",
                            actorLife: owner.life,
                            requestedTargetId: targetId,
                            abilityId: "learned:mechanical",
                        }));
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "mechanical_guard_chosen",
                        payload: { actorId: owner.actorId, day, targetId, failed },
                    });
                }
                else
                    continue;
                (0, state_2.closeMechanicalSkill)(owner.state, day);
                (0, night_scope_1.recordMechanicalNightCommit)(ctx.world, day);
                completed = true;
                break;
            }
            if (!completed && current())
                throw new Error("mechanical_skill_valid_action_missing");
        }
    },
};
const attackStage = {
    id: "mechanical_attack",
    priority: 660,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const owner of owners(ctx)) {
            const learned = owner.state.learned, mode = owner.state.mode;
            if (learned?.skill.kind !== "wolf" || !mode)
                continue;
            const skill = learned.skill;
            const effectCurrent = () => owner.isCurrent() &&
                owner.state.learned === learned &&
                learned.skill === skill &&
                skill.kind === "wolf" &&
                owner.state.mode === mode &&
                mode.day === day &&
                mode.kind === "kill" &&
                (0, inheritance_1.canMechanicalKnife)(owner.role, ctx.world, () => ctx.world.getComponent(owner.actorId, names_1.COMPONENT.Camp));
            const current = () => effectCurrent() && (0, state_2.canMechanicalExtraKnife)(owner.state, day) && owner.canAct();
            if (!current())
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current())
                    break;
                const candidates = targets(ctx, owner.actorId, false);
                if (!owner.canAct())
                    break;
                const action = await ctx.actionProvider.getAction(ctx.makeRequest(owner.actorId, ["mechanical_attack"], {
                    stage: "mechanical_attack",
                    requiresAction: false,
                    ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                }));
                if (!current())
                    break;
                let targetId = null;
                if (action !== null) {
                    if (action.name !== "mechanical_attack")
                        continue;
                    const valid = ctx.toolGateway.validateAndSanitize(ctx.world, owner.actorId, action, {
                        phase: model_1.Phase.Night,
                        day,
                    });
                    if (!current() || !valid.ok || valid.sanitizedCall?.name !== "mechanical_attack")
                        continue;
                    targetId = valid.sanitizedCall.args.target_id;
                }
                const target = targetId === null ? null : candidates.get(targetId);
                if (targetId !== null && (!target || !(0, night_effects_1.livingNightLife)(ctx.world, target)))
                    continue;
                if (!owner.canAct())
                    break;
                if (target)
                    effects(ctx).attacks.push((0, night_effects_1.mechanicalNightIntent)("mechanical-attack", { actorId: owner.actorId, target, isCurrent: effectCurrent }, {
                        family: "mechanical",
                        day,
                        stage: "mechanical_attack",
                        actorLife: owner.life,
                        requestedTargetId: targetId,
                        abilityId: "learned:mechanical",
                    }));
                (0, state_1.closeMechanicalExtraKnife)(skill, target);
                (0, night_scope_1.recordMechanicalNightCommit)(ctx.world, day);
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "mechanical_attack_chosen",
                    payload: { actorId: owner.actorId, day, targetId },
                });
                completed = true;
                break;
            }
            if (!completed && current())
                throw new Error("mechanical_attack_valid_action_missing");
        }
    },
};
exports.MECHANICAL_NIGHT_STAGES = [modeStage, mimicStage, skillStage, attackStage];
