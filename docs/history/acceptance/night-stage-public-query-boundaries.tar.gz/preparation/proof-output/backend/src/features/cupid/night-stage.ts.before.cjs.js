"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CUPID_STAGE = void 0;
const names_1 = require("../../domain/components/names");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const request_lease_1 = require("../../domain/request-lease");
const victory_1 = require("../../domain/components/victory");
const model_1 = require("../../domain/model");
const night_effects_1 = require("../../domain/night-effects");
const state_slot_1 = require("./state-slot");
const relation_1 = require("./relation");
const requestLease = request_lease_1.RequestLease.window({
    actorId: (scope) => scope.actorId,
    phase: () => model_1.Phase.Night,
    day: (scope) => scope.day,
    stage: () => "cupid",
    current: (scope) => scope.current(),
}, 110);
exports.CUPID_STAGE = {
    id: "cupid",
    priority: 80,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (day !== 1)
            return;
        if ((0, relation_1.hasCupidNightCommit)(ctx.world, day))
            throw new Error("cupid_night_reentry_after_commit");
        for (const actorId of ctx.getAliveByRole(model_1.Role.Cupid)) {
            const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role), state = (0, state_slot_1.getCupidState)(role), life = (0, night_effects_1.captureNightLife)(ctx.world, actorId), victory = ctx.world.getComponent(actorId, names_1.COMPONENT.Victory);
            if (!state ||
                !life ||
                !victory ||
                ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Good)
                continue;
            const privateState = role.privateState, policy = state.policy, affiliations = victory.affiliations, membership = JSON.stringify(affiliations);
            const current = () => ctx.isCurrent() &&
                ctx.currentDay() === day &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Role) === role &&
                role.role === model_1.Role.Cupid &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Good &&
                role.privateState === privateState &&
                (0, state_slot_1.getCupidState)(role) === state &&
                state.policy === policy &&
                state.remaining === 1 &&
                state.choice === null &&
                (0, night_effects_1.livingNightLife)(ctx.world, life) &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Victory) === victory &&
                victory.affiliations === affiliations &&
                JSON.stringify(affiliations) === membership &&
                !(0, relation_1.hasCupidNightCommit)(ctx.world, day);
            const canAct = () => !(0, role_execution_authority_1.isRoleExecutionRetired)(role);
            if (!current() || !canAct())
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current() || !canAct())
                    break;
                const targets = new Map(ctx.world.getAliveEntityIds().map((id) => {
                    const targetRole = ctx.world.getComponent(id, names_1.COMPONENT.Role), targetVictory = ctx.world.getComponent(id, names_1.COMPONENT.Victory);
                    return [
                        id,
                        {
                            life: (0, night_effects_1.captureNightLife)(ctx.world, id),
                            role: targetRole,
                            kind: targetRole.role,
                            camp: ctx.world.getComponent(id, names_1.COMPONENT.Camp)?.camp,
                            privateState: targetRole.privateState,
                            victory: targetVictory,
                            affiliations: targetVictory.affiliations,
                            membership: JSON.stringify(targetVictory.affiliations),
                        },
                    ];
                }));
                if (targets.size < 2)
                    throw new Error("cupid_valid_action_missing");
                const makeRequest = ctx.makeRequest;
                const requestActor = actorId;
                const requestTools = ["choose_lovers"];
                const requestExtras = {
                    stage: "cupid",
                    requiresAction: true,
                    allow_fallback: false,
                    action_failure_policy: "error",
                    ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                };
                const requestArgs = [requestActor, requestTools, requestExtras];
                const invokeRequest = Reflect.apply.bind(Reflect);
                if (!canAct())
                    break;
                const request = invokeRequest(makeRequest, ctx, requestArgs);
                const requestScope = {
                    actorId,
                    day,
                    current: () => current() && canAct(),
                };
                requestLease.bind(requestScope, request);
                const turn = requestLease.openDelivery(requestScope, request);
                let bodyFailed = false;
                try {
                    if (!turn)
                        break;
                    if (!current() || !canAct() || !turn.current())
                        break;
                    const provider = ctx.actionProvider, getAction = provider.getAction;
                    const actionArgs = [request];
                    const invokeAction = Reflect.apply.bind(Reflect);
                    if (!canAct() || !turn.current())
                        break;
                    const action = await invokeAction(getAction, provider, actionArgs);
                    if (!current() || !canAct() || !turn.current())
                        break;
                    if (action?.name !== "choose_lovers")
                        continue;
                    const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                        phase: model_1.Phase.Night,
                        day,
                    });
                    if (!current() ||
                        !valid.ok ||
                        valid.sanitizedCall?.name !== "choose_lovers" ||
                        !canAct() ||
                        !turn.current())
                        continue;
                    const pairIds = [
                        valid.sanitizedCall.args.first_id,
                        valid.sanitizedCall.args.second_id,
                    ];
                    const selected = pairIds.map((id) => targets.get(id));
                    if (selected.some((target, index) => !target ||
                        !(0, night_effects_1.livingNightLife)(ctx.world, target.life) ||
                        ctx.world.getComponent(pairIds[index], names_1.COMPONENT.Role) !== target.role ||
                        target.role.role !== target.kind ||
                        ctx.world.getComponent(pairIds[index], names_1.COMPONENT.Camp)?.camp !== target.camp ||
                        target.role.privateState !== target.privateState ||
                        (target.camp !== model_1.Camp.Good && target.camp !== model_1.Camp.Wolf) ||
                        ctx.world.getComponent(pairIds[index], names_1.COMPONENT.Victory) !== target.victory ||
                        target.victory.affiliations !== target.affiliations ||
                        JSON.stringify(target.affiliations) !== target.membership))
                        continue;
                    const first = selected[0], second = selected[1], mixed = first.camp !== second.camp;
                    const record = Object.freeze({
                        actorId,
                        day: 1,
                        policy,
                        pairIds: Object.freeze(pairIds),
                        pairCamps: Object.freeze([first.camp, second.camp]),
                        groupId: "cupid_lovers",
                        mixed,
                    });
                    const memberIds = new Set(pairIds);
                    if (policy === "netease_2017_cupid_follows_lovers_v1")
                        memberIds.add(actorId);
                    if (!(0, relation_1.bindLovers)(ctx.world, record, [first.life, second.life], () => canAct() && turn.current()))
                        continue;
                    (0, state_slot_1.commitCupidChoice)(state, pairIds);
                    for (const id of memberIds)
                        ctx.world.addComponent(id, names_1.COMPONENT.Victory, (0, victory_1.createVictoryComponent)([
                            mixed
                                ? { kind: "relationship", groupId: record.groupId }
                                : { kind: "faction", faction: first.camp },
                        ]));
                    turn.complete();
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "cupid_lovers_chosen",
                        payload: { actorId, day: 1, pairIds: [...pairIds] },
                    });
                    for (const id of pairIds)
                        ctx.events.push({
                            timestamp: Date.now(),
                            type: "lover_recognized",
                            payload: { actorId: id, partnerId: pairIds.find((target) => target !== id) },
                        });
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "cupid_relation_resolved",
                        payload: record,
                    });
                    completed = true;
                    break;
                }
                catch (error) {
                    bodyFailed = true;
                    throw error;
                }
                finally {
                    try {
                        turn?.close();
                    }
                    catch (error) {
                        if (!bodyFailed)
                            throw error;
                    }
                }
            }
            if (!completed && current() && canAct())
                throw new Error("cupid_valid_action_missing");
        }
    },
};
