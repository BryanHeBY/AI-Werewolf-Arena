"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeDemonNativeNight = executeDemonNativeNight;
const domain_1 = require("../../domain");
const status_marks_1 = require("../../domain/components/status-marks");
const night_effects_1 = require("../../domain/night-effects");
const recorder_1 = require("../../recording/session/recorder");
const inspection_1 = require("../../engine/inspection");
const history_ports_1 = require("../night-abilities/history-ports");
const authority_1 = require("./authority");
const native_potion_requests_1 = require("./native-potion-requests");
const guard_contribution_1 = require("./guard-contribution");
const nativeAdd = status_marks_1.StatusMarksComponent.prototype.add;
async function executeDemonNativeNight(ctx, kind) {
    const { world } = ctx, day = ctx.currentDay(), actor = (0, authority_1.demonNativeNightActor)(world, kind);
    if (!actor)
        return;
    const frame = (0, authority_1.openDemonNativeNightFrame)(world, actor.actorId, actor.ability, kind, day);
    if (!frame)
        throw new Error("demon_hunter_native_night_unavailable");
    const guard = kind === "guard", name = guard ? "guard" : "check_identity", scope = Object.freeze({});
    let closed = false, committed = false;
    const request = new ctx.requestFactory(world, ctx.events, day).create({
        phase: domain_1.Phase.Night,
        actorId: actor.actorId,
        allowedTools: [name],
        stage: guard ? "guard" : "seer",
        requiresAction: true,
        summary: { key: "request.summary.night_action" },
        context: {
            ability_id: `native:${kind}`,
            allow_fallback: false,
            action_failure_policy: "error",
        },
    });
    (0, native_potion_requests_1.bindDemonNativeNightRequest)(world, request, scope, () => !closed && frame.isCurrent(), frame.targetCurrent, kind);
    const authorized = () => (0, native_potion_requests_1.demonWitchRequestCurrent)(world, request);
    try {
        if (!authorized())
            throw new Error("demon_hunter_native_night_revoked");
        const raw = await ctx.actionProvider.getAction(request);
        if (!authorized())
            throw new Error("demon_hunter_native_night_revoked");
        const call = (0, native_potion_requests_1.readDemonNativeNightTool)(raw);
        if (!call ||
            call.name !== name ||
            (call.args.target_id !== null &&
                !(0, native_potion_requests_1.demonWitchRequestTargetCurrent)(world, request, call.args.target_id)))
            throw new Error("demon_hunter_native_night_invalid");
        const valid = ctx.toolGateway.validateAndSanitize(world, actor.actorId, call, {
            phase: domain_1.Phase.Night,
            day,
            abilityId: `native:${kind}`,
            deferOperation: true,
        });
        if (!authorized() ||
            !valid.ok ||
            !valid.sanitizedCall ||
            (call.args.target_id !== null &&
                !(0, native_potion_requests_1.demonWitchRequestTargetCurrent)(world, request, call.args.target_id)))
            throw new Error("demon_hunter_native_night_invalid");
        const targetId = call.args.target_id;
        if (guard) {
            const target = targetId === null ? null : (0, night_effects_1.captureNightLife)(world, targetId);
            const marks = targetId === null ? null : world.getComponent(targetId, domain_1.COMPONENT.StatusMarks);
            if (targetId !== null && (!target || !marks))
                throw new Error("demon_hunter_native_guard_target_invalid");
            const contribution = targetId !== null && marks ? (0, guard_contribution_1.openNativeGuardContribution)(world, targetId, marks) : null;
            if (!authorized() || !frame.commitGuard(targetId))
                throw new Error("demon_hunter_native_guard_commit_revoked");
            if (targetId !== null && target && marks && contribution) {
                nativeAdd.call(marks, domain_1.StatusMark.GuardMark);
                (0, guard_contribution_1.commitNativeGuardContribution)(contribution);
                (ctx.state.guardClaims ??= []).push({
                    target: Object.freeze(target),
                    marks,
                    isCurrent: frame.sourceCurrent,
                    contribution,
                });
            }
            committed = true;
            (0, domain_1.settleRequestDelivery)(scope, true);
            ctx.events.push({
                timestamp: Date.now(),
                type: "guard_applied",
                payload: { actorId: actor.actorId, abstain: targetId === null, targetId },
            });
            (0, recorder_1.safeRecordLogicOp)({
                scope: "phase_pipeline",
                op: "guard_applied",
                actorId: actor.actorId,
                phase: domain_1.Phase.Night,
                status: "ok",
                output: { abstain: targetId === null, target_id: targetId },
            });
            if (targetId !== null)
                (0, history_ports_1.recordOwnNightAction)(world, actor.actorId, day, "guard", targetId, false);
        }
        else {
            if (targetId === null)
                throw new Error("demon_hunter_native_seer_target_invalid");
            const result = (0, inspection_1.resolveInspection)(world, targetId, "camp", ctx.roleCatalog);
            if (!result || !authorized() || !frame.commitSeer(targetId, result))
                throw new Error("demon_hunter_native_seer_commit_revoked");
            committed = true;
            (0, domain_1.settleRequestDelivery)(scope, true);
            const isWerewolf = result.camp === domain_1.Camp.Wolf;
            ctx.state.seerChecks.push({
                seerId: actor.actorId,
                targetId,
                isWerewolf,
                result: { ...result },
            });
            (0, history_ports_1.recordOwnNightAction)(world, actor.actorId, day, "check", targetId, false);
            ctx.events.push({
                timestamp: Date.now(),
                type: "seer_checked",
                payload: { actorId: actor.actorId, targetId, isWerewolf, result: { ...result } },
            });
        }
        (0, recorder_1.safeRecordLogicOp)({
            scope: "gateway",
            op: "validate_tool_call",
            actorId: actor.actorId,
            phase: domain_1.Phase.Night,
            status: "ok",
            input: { tool: call.name, args: call.args },
        });
    }
    finally {
        closed = true;
        if (!committed)
            (0, domain_1.settleRequestDelivery)(scope, false);
    }
}
