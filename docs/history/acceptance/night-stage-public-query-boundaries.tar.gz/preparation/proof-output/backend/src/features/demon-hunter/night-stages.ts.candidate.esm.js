import { demonHunterNeedsTurn } from "./authority";
export const DEMON_HUNTER_NIGHT_STAGE = {
    id: "demon_hunter_action",
    priority: 650,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (!demonHunterNeedsTurn(ctx.world, day))
            return;
        const { executeDemonHunterTurn } = await import("./controller");
        const fact = await executeDemonHunterTurn({
            world: ctx.world,
            gateway: ctx.toolGateway,
            events: ctx.events,
            provider: ctx.actionProvider,
            day,
            construction: ctx,
        });
        ctx.events.push({
            timestamp: Date.now(),
            type: "demon_hunter_chosen",
            payload: fact,
            audience: Object.freeze([fact.actorId]),
        });
    },
};
export const OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    DEMON_HUNTER_NIGHT_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
