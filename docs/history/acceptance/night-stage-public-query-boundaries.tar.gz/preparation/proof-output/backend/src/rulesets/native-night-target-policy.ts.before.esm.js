import { isMagicianBoard, resolveMagicianNightTarget, } from "../features/magician/ports";
import { isTimeConsortBoard, resolveTimeConsortTarget, } from "../features/time-wolf-consort/ports";
import { isScholarMentorBoard, scholarMentorBlocks } from "../features/scholar-mentor/ports";
export function bindNativeNightTargetPolicy(context) {
    return Object.freeze({
        mappedTarget(day, targetId) {
            return isMagicianBoard(context().world)
                ? resolveMagicianNightTarget(context().world, day(), targetId())
                : null;
        },
        reflectedTarget(day, sourceId, targetId, kind) {
            return isTimeConsortBoard(context().world)
                ? resolveTimeConsortTarget(context().world, day(), sourceId(), targetId(), kind)
                : null;
        },
        potionModifierHints(actorId) {
            return isScholarMentorBoard(context().world)
                ? {
                    modifier_poison_blocked: scholarMentorBlocks(context().world, context().currentDay(), actorId, "poison"),
                }
                : {};
        },
        potionKnifeHints() {
            return isScholarMentorBoard(context().world)
                ? {
                    wolf_targets: [
                        ...new Set([
                            context().state.wolfTarget,
                            ...(context().state.modifierKnifeTargets ?? []),
                        ].filter((id) => id !== null)),
                    ],
                }
                : {};
        },
    });
}
