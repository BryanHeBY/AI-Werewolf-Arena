const linksByState = new WeakMap();
function ownedLinks(state) {
    let links = linksByState.get(state);
    if (!links) {
        links = [];
        linksByState.set(state, links);
    }
    return links;
}
export function dreamNightLinksForAppend(state) {
    return ownedLinks(state);
}
export function readDreamNightLinks(state) {
    return ownedLinks(state);
}
export function installDreamNightLinks(state, links) {
    linksByState.set(state, links);
}
