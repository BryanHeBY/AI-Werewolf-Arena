"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasRecipientNightCommit = hasRecipientNightCommit;
exports.recordRecipientNightCommit = recordRecipientNightCommit;
exports.recipientAbilityStage = recipientAbilityStage;
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const night_effects_1 = require("../../domain/night-effects");
const abilities_1 = require("./abilities");
const abilities_2 = require("./abilities");
const ability_scope_1 = require("./ability-scope");
const night_action_history_1 = require("./night-action-history");
const inspection_1 = require("../../engine/inspection");
const ports_1 = require("../seer/ports");
const ports_2 = require("../guard/ports");
const ports_3 = require("../witch/ports");
const committed = new WeakMap();
function hasRecipientNightCommit(world, day, policy) {
    return committed.get(world)?.get(policy)?.has(day) ?? false;
}
function recordRecipientNightCommit(world, day, policy) {
    const policies = committed.get(world) ?? new Map(), days = policies.get(policy) ?? new Set();
    days.add(day);
    policies.set(policy, days);
    committed.set(world, policies);
}
const inspection_ports_1 = require("../cursed-fox/inspection-ports");
function isRecipient(ability, policy) {
    return (ability.activation === policy &&
        (policy === "black_market"
            ? ["seer_check", "potion"]
            : ["seer_check", "potion", "guard"]).includes(ability.kind));
}
function recipientAbilityStage(policy, priority) {
    return {
        id: policy === "lucky" ? "lucky_ability" : "black_market_recipient",
        priority,
        async execute(ctx) {
            const day = ctx.currentDay();
            for (const actorId of ctx.world.getAliveEntityIds()) {
                const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role);
                for (const ability of (0, abilities_1.allNightAbilities)(role).filter((ability) => isRecipient(ability, policy))) {
                    if ((0, abilities_1.abilityStatus)(ability, day) !== "active")
                        continue;
                    const scope = (0, ability_scope_1.captureNightAbilityScope)(ctx.world, actorId, ability, day, ctx.isCurrent);
                    if (!scope)
                        continue;
                    const current = () => scope.isEligible() &&
                        ability.activation === policy &&
                        (ability.kind !== "potion" || ability.state.poison > 0);
                    if (!current())
                        continue;
                    const tool = ability.kind === "seer_check"
                        ? "check_identity"
                        : ability.kind === "guard"
                            ? "guard"
                            : "use_potion";
                    const kind = ability.kind === "seer_check" ? "check" : ability.kind === "guard" ? "guard" : "poison";
                    const skip = () => {
                        (0, abilities_2.recordNightAbilityUse)(ability, day, false);
                        recordRecipientNightCommit(ctx.world, day, policy);
                        ctx.events.push({
                            timestamp: Date.now(),
                            type: "lucky_ability_skipped",
                            payload: { actorId, abilityId: ability.id, day, kind: ability.kind },
                        });
                    };
                    let completed = false;
                    for (let attempt = 0; attempt < 3; attempt++) {
                        if (!current())
                            break;
                        let effectAbilityId;
                        let effectRequestedTargetId = null;
                        const targets = new Map(ctx.world
                            .getAliveEntityIds()
                            .filter((id) => (0, night_action_history_1.luckyTargetAllowed)(ctx.world, actorId, ability, day, kind, id))
                            .map((id) => [id, (0, night_effects_1.captureNightLife)(ctx.world, id)]));
                        const identities = new Map([...targets].map(([id, life]) => [id, (0, inspection_ports_1.captureInspectionIdentity)(ctx.world, life)]));
                        if (ability.kind === "seer_check" && !targets.size) {
                            skip();
                            completed = true;
                            break;
                        }
                        const action = await ctx.actionProvider.getAction(ctx.makeRequest(actorId, [tool], {
                            stage: policy === "lucky" ? "lucky" : "black_market_recipient",
                            requiresAction: false,
                            ...(policy === "black_market"
                                ? { action_failure_policy: "error", allow_fallback: false }
                                : {}),
                            ability_id: ability.id,
                            ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                        }));
                        if (!current())
                            break;
                        if (action === null) {
                            skip();
                            completed = true;
                            break;
                        }
                        if (action.name !== tool)
                            continue;
                        const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                            phase: model_1.Phase.Night,
                            day,
                            abilityId: (effectAbilityId = ability.id),
                        });
                        if (!current() || !result.ok || !result.sanitizedCall)
                            continue;
                        const call = result.sanitizedCall;
                        if ((call.name === "guard" && call.args.abstain) ||
                            (call.name === "use_potion" && call.args.potion_type === model_1.PotionType.None)) {
                            skip();
                            completed = true;
                            break;
                        }
                        if (!["guard", "use_potion", "check_identity"].includes(call.name) ||
                            !("target_id" in call.args))
                            continue;
                        const target = call.args.target_id === null
                            ? undefined
                            : targets.get((effectRequestedTargetId = call.args.target_id));
                        if (!target || !(0, night_effects_1.livingNightLife)(ctx.world, target))
                            continue;
                        if (!(0, night_action_history_1.luckyTargetAllowed)(ctx.world, actorId, ability, day, kind, target.id))
                            continue;
                        if (call.name === "check_identity" && ability.kind === "seer_check") {
                            if (!identities.get(target.id)?.isCurrent())
                                continue;
                            const result = (0, inspection_1.resolveInspection)(ctx.world, target.id, "camp", ctx.roleCatalog);
                            if (!result ||
                                !current() ||
                                !identities.get(target.id)?.isCurrent() ||
                                !(0, night_effects_1.livingNightLife)(ctx.world, target) ||
                                !(0, night_action_history_1.luckyTargetAllowed)(ctx.world, actorId, ability, day, kind, target.id))
                                continue;
                            const isWerewolf = result.camp === model_1.Camp.Wolf;
                            ports_1.SEER_STATE_SLOT.allowedWrites.recordRecipientSeerInspection(ability, target, isWerewolf, result);
                            (0, inspection_ports_1.commitFoxInspection)(ctx.world, ctx.state, target, day, () => scope.isOwnerCurrent(true));
                            ctx.state.seerChecks.push({
                                seerId: actorId,
                                targetId: target.id,
                                isWerewolf,
                                result: { ...result },
                            });
                            ctx.events.push({
                                timestamp: Date.now(),
                                type: "seer_checked",
                                payload: {
                                    actorId,
                                    abilityId: ability.id,
                                    targetId: target.id,
                                    isWerewolf,
                                    result: { ...result },
                                },
                            });
                        }
                        else if (call.name === "guard" && ability.kind === "guard") {
                            const marks = ctx.ensureMarks(target.id);
                            marks.add(model_1.StatusMark.GuardMark);
                            (ctx.state.guardClaims ??= []).push({ target, marks });
                            ports_2.GUARD_STATE_SLOT.allowedWrites.recordRecipientGuardTarget(ability, target);
                            ctx.events.push({
                                timestamp: Date.now(),
                                type: "guard_applied",
                                payload: { actorId, abilityId: ability.id, abstain: false, targetId: target.id },
                            });
                        }
                        else if (call.name === "use_potion" &&
                            call.args.potion_type === model_1.PotionType.Poison &&
                            ability.kind === "potion" &&
                            ability.state.poison > 0) {
                            let effectSource;
                            (ctx.state.poisonClaims ??= []).push((0, night_effects_1.originalPoisonIntent)({
                                source: (effectSource = scope.life),
                                target,
                                ...(policy === "black_market"
                                    ? {
                                        isCurrent: () => ctx.isCurrent() &&
                                            ctx.currentDay() === day &&
                                            scope.isOwnerCurrent(true),
                                    }
                                    : {}),
                            }, {
                                family: policy === "lucky" ? "lucky" : "black-market",
                                day,
                                stage: policy === "lucky" ? "lucky" : "black_market_recipient",
                                actorLife: effectSource,
                                requestedTargetId: effectRequestedTargetId,
                                abilityId: effectAbilityId,
                            }));
                            ctx.ensureMarks(target.id).add(model_1.StatusMark.PoisonMark);
                            ports_3.WITCH_STATE_SLOT.allowedWrites.consumeRecipientPoison(ability);
                            ctx.events.push({
                                timestamp: Date.now(),
                                type: "witch_potion_used",
                                payload: {
                                    actorId,
                                    abilityId: ability.id,
                                    targetId: target.id,
                                    potionType: model_1.PotionType.Poison,
                                },
                            });
                        }
                        else
                            continue;
                        (0, abilities_2.recordNightAbilityUse)(ability, day, true);
                        (0, night_action_history_1.recordOwnNightAction)(ctx.world, actorId, day, kind, target.id, true, policy);
                        recordRecipientNightCommit(ctx.world, day, policy);
                        completed = true;
                        break;
                    }
                    if (!completed && current()) {
                        if (ability.kind === "seer_check" &&
                            !ctx.world
                                .getAliveEntityIds()
                                .some((id) => (0, night_action_history_1.luckyTargetAllowed)(ctx.world, actorId, ability, day, "check", id)))
                            skip();
                        else
                            throw new Error(policy === "black_market"
                                ? "black_market_recipient_valid_action_missing"
                                : "lucky_valid_action_missing");
                    }
                }
            }
        },
    };
}
