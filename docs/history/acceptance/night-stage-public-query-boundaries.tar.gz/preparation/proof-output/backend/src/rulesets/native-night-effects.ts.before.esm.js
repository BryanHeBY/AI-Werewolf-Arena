import { Role } from "../domain/identity";
import { isScholarMentorBoard, recordScholarMentorNativeTarget, scholarMentorKnifeEligible, } from "../features/scholar-mentor/ports";
import { isEvilKnightBoard, commitEvilKnightReflection, evilKnightNightBinding, } from "../features/evil-knight/ports";
import { commitTimeConsortEffect, } from "../features/time-wolf-consort/ports";
import { loadDemonNativeNightController, loadDemonNativePotionController, } from "../features/demon-hunter/ports";
export function bindNativeNightEffects(context) {
    return Object.freeze({
        commitReflectedTarget(receipt, day, sourceId, kind) {
            commitTimeConsortEffect(context(), receipt, day, sourceId, kind);
        },
        recordModifierTarget(day, actorId, kind, targetId) {
            if (isScholarMentorBoard(context().world))
                recordScholarMentorNativeTarget(context().world, day, actorId, kind, targetId());
        },
        recordKnifeModifierTarget(targetId) {
            if (isScholarMentorBoard(context().world)) {
                const actor = context()
                    .world.getAliveEntityIds()
                    .find((id) => scholarMentorKnifeEligible(context().world, context().currentDay(), id));
                if (actor !== undefined)
                    recordScholarMentorNativeTarget(context().world, context().currentDay(), actor, "kill", targetId());
            }
        },
        commitNativeReflection(kind, ability, targetId, source, isCurrent) {
            if (isEvilKnightBoard(context().world)) {
                if (ability.source.kind !== "native" ||
                    ability.source.role !== (kind === "seer_check" ? Role.Seer : Role.Witch))
                    throw new Error(kind === "seer_check"
                        ? "evil_knight_seer_source_invalid"
                        : "evil_knight_witch_source_invalid");
                const reflection = commitEvilKnightReflection(context().world, evilKnightNightBinding(context().state, targetId), source(), kind, isCurrent);
                if (reflection)
                    (context().state.retaliationAttacks ??= []).push(reflection);
            }
        },
        loadSealedNightController: loadDemonNativeNightController,
        loadSealedPotionController: loadDemonNativePotionController,
    });
}
