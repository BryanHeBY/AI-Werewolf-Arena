"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.BLACK_MARKET_TRADE_STAGE = exports.BLACK_MARKET_RECIPIENT_STAGE = void 0;
exports.hasBlackMarketNightCommit = hasBlackMarketNightCommit;
const state_1 = require("./state");
const names_1 = require("../../domain/components/names");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const model_1 = require("../../domain/model");
const alive_1 = require("../../domain/components/alive");
const night_effects_1 = require("../../domain/night-effects");
const grant_ports_1 = require("../night-abilities/grant-ports");
const gift_gun_ports_1 = require("../death-actions/gift-gun-ports");
const recipient_stage_ports_1 = require("../night-abilities/recipient-stage-ports");
const state_2 = require("./state");
const committed = new WeakMap();
function hasBlackMarketNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
function recordCommit(world, day) {
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
exports.BLACK_MARKET_RECIPIENT_STAGE = (0, recipient_stage_ports_1.recipientAbilityStage)("black_market", 140);
exports.BLACK_MARKET_TRADE_STAGE = {
    id: "black_market_merchant",
    priority: 130,
    async execute(ctx) {
        const day = ctx.currentDay();
        for (const actorId of ctx.getAliveByRole(model_1.Role.BlackMarketMerchant)) {
            const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role), state = (0, state_2.getBlackMarketState)(role), life = (0, night_effects_1.captureNightLife)(ctx.world, actorId);
            if (!state || !life || ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Good)
                continue;
            const privateState = role.privateState;
            const ownerCurrent = (paid = false) => ctx.isCurrent() &&
                ctx.currentDay() === day &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Role) === role &&
                role.role === model_1.Role.BlackMarketMerchant &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Good &&
                role.privateState === privateState &&
                (0, state_2.getBlackMarketState)(role) === state &&
                ((0, night_effects_1.livingNightLife)(ctx.world, life) ||
                    (paid &&
                        ctx.world.getComponent(actorId, names_1.COMPONENT.Alive) === life.life &&
                        !life.life.alive &&
                        (0, alive_1.aliveLifeVersion)(life.life) === life.version + 1));
            const current = () => ownerCurrent() && (0, state_2.canBlackMarketTrade)(state, day) && !(0, role_execution_authority_1.isRoleExecutionRetired)(role);
            if (!current())
                continue;
            const skip = () => {
                const closeTrade = state_1.closeBlackMarketTrade;
                if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                    return;
                closeTrade(state, day);
                recordCommit(ctx.world, day);
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "black_market_trade_skipped",
                    payload: { actorId, day },
                });
            };
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current())
                    break;
                const targets = new Map(ctx.world
                    .getAliveEntityIds()
                    .filter((id) => id !== actorId)
                    .map((id) => {
                    const targetRole = ctx.world.getComponent(id, names_1.COMPONENT.Role);
                    return [
                        id,
                        {
                            life: (0, night_effects_1.captureNightLife)(ctx.world, id),
                            role: targetRole,
                            kind: targetRole.role,
                            camp: ctx.world.getComponent(id, names_1.COMPONENT.Camp)?.camp,
                            privateState: targetRole.privateState,
                        },
                    ];
                }));
                if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                    break;
                let action = null;
                if (targets.size) {
                    const provider = ctx.actionProvider, getAction = provider.getAction, makeRequest = ctx.makeRequest, requestArgs = [
                        actorId,
                        ["black_market_trade"],
                        {
                            stage: "black_market_merchant",
                            requiresAction: false,
                            action_failure_policy: "error",
                            allow_fallback: false,
                            ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                        },
                    ], invoke = Reflect.apply.bind(Reflect);
                    if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                        break;
                    const request = invoke(makeRequest, ctx, requestArgs), actionArgs = [request];
                    if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                        break;
                    action = await invoke(getAction, provider, actionArgs);
                }
                if (!current())
                    break;
                if (action === null) {
                    skip();
                    completed = true;
                    break;
                }
                if (action.name !== "black_market_trade")
                    continue;
                const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                    phase: model_1.Phase.Night,
                    day,
                });
                if (!current() || !validated.ok || validated.sanitizedCall?.name !== "black_market_trade")
                    continue;
                const { target_id: targetId, skill } = validated.sanitizedCall.args, target = targets.get(targetId);
                if (!target ||
                    !(0, night_effects_1.livingNightLife)(ctx.world, target.life) ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Role) !== target.role ||
                    target.role.role !== target.kind ||
                    ctx.world.getComponent(targetId, names_1.COMPONENT.Camp)?.camp !== target.camp ||
                    target.role.privateState !== target.privateState)
                    continue;
                if (target.camp !== model_1.Camp.Good && target.camp !== model_1.Camp.Wolf)
                    throw new Error("black_market_target_camp_unsupported");
                const failed = target.camp === model_1.Camp.Wolf;
                if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                    break;
                if (!failed) {
                    if (skill === "gun") {
                        const grant = gift_gun_ports_1.grantDeathGun, grantArgs = [
                            ctx.world,
                            actorId,
                            targetId,
                            day,
                            ctx.events,
                        ], grantWorld = grantArgs[0], grantActor = grantArgs[1], grantTarget = grantArgs[2], grantDay = grantArgs[3], grantEvents = grantArgs[4];
                        if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                            break;
                        grant(grantWorld, grantActor, grantTarget, grantDay, grantEvents);
                    }
                    else {
                        const base = {
                            id: "gift:black-market",
                            activation: "black_market",
                            source: { kind: "gift", actorId },
                            sourceDisclosed: false,
                            startsOnDay: day + 1,
                            maxUses: 1,
                        };
                        if (skill === "check") {
                            const grant = grant_ports_1.grantNightAbility, grantArgs = [
                                ctx.world,
                                targetId,
                                {
                                    ...base,
                                    kind: "seer_check",
                                    state: {
                                        lastTarget: null,
                                        lastIsWerewolf: null,
                                        lastResult: null,
                                        history: [],
                                    },
                                },
                                ctx.events,
                            ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                            if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                                break;
                            grant(grantWorld, grantTarget, grantInput, grantEvents);
                        }
                        else {
                            const grant = grant_ports_1.grantNightAbility, grantArgs = [
                                ctx.world,
                                targetId,
                                {
                                    ...base,
                                    kind: "potion",
                                    state: {
                                        heal: 0,
                                        poison: 1,
                                        selfHealRule: model_1.WitchSelfHealRule.Disabled,
                                        canSelfHeal: false,
                                        healUsedThisNight: false,
                                        poisonUsedThisNight: false,
                                    },
                                },
                                ctx.events,
                            ], grantWorld = grantArgs[0], grantTarget = grantArgs[1], grantInput = grantArgs[2], grantEvents = grantArgs[3];
                            if ((0, role_execution_authority_1.isRoleExecutionRetired)(role))
                                break;
                            grant(grantWorld, grantTarget, grantInput, grantEvents);
                        }
                    }
                }
                const recordTrade = state_1.recordBlackMarketTrade;
                if (failed && (0, role_execution_authority_1.isRoleExecutionRetired)(role))
                    break;
                recordTrade(state, day, targetId, skill);
                recordCommit(ctx.world, day);
                const choice = state.choice;
                if (failed)
                    (ctx.state.blackMarketBacklashes ??= []).push({
                        target: life,
                        isCurrent: () => ownerCurrent(true) &&
                            state.choice === choice &&
                            choice.day === day &&
                            choice.targetId === targetId &&
                            choice.skill === skill,
                    });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "black_market_trade_committed",
                    payload: { actorId, day, targetId, skill },
                });
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "black_market_trade_resolved",
                    payload: { actorId, day, targetId, skill, outcome: failed ? "backlash" : "granted" },
                });
                completed = true;
                break;
            }
            if (!completed && current()) {
                if (ctx.world.getAliveEntityIds().some((id) => id !== actorId))
                    throw new Error("black_market_valid_action_missing");
                skip();
            }
        }
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.BLACK_MARKET_TRADE_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
