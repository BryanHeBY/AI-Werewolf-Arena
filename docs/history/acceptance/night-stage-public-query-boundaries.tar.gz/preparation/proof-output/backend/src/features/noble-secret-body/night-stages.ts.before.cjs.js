"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NOBLE_CHOICE_STAGE = exports.SECRET_BODY_STAGE = void 0;
const identity_1 = require("../../domain/identity");
const recorder_1 = require("../../recording/session/recorder");
const authority_1 = require("./authority");
const requests_1 = require("./requests");
const state_1 = require("./state");
async function execute(ctx, kind) {
    const day = ctx.currentDay(), actorId = (0, authority_1.nobleBodyChoiceActor)(ctx.world, day, kind);
    if (actorId === null)
        return;
    const name = kind === "body" ? "protect_secret_body" : "choose_servant", candidates = (0, authority_1.nobleBodyChoiceTargets)(ctx.world, day, kind), request = ctx.makeRequest(actorId, [name], {
        stage: kind === "body" ? "secret_body" : "night_noble",
        requiresAction: true,
        allow_fallback: false,
        action_failure_policy: "error",
        ...(kind === "body"
            ? { secret_body_candidates: candidates }
            : { servant_candidates: candidates }),
    }), scope = (0, requests_1.openNobleBodyRequest)(ctx.world, day, kind, request);
    try {
        const raw = await ctx.actionProvider.getAction(request);
        if ((0, requests_1.nobleBodyRequestScope)(ctx.world, request) !== scope)
            throw Error("noble_body_request_unavailable");
        const call = (0, requests_1.readNobleBodyTool)(raw);
        if (!call || call.name !== name)
            throw Error("noble_body_required_action_invalid");
        const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, call, {
            phase: identity_1.Phase.Night,
            day,
            scope: scope,
            deferOperation: true,
        });
        if (!valid.ok || !valid.sanitizedCall || (0, requests_1.nobleBodyRequestScope)(ctx.world, request) !== scope)
            throw Error("noble_body_required_action_invalid");
        const receipt = (0, requests_1.commitNobleBodyChoice)(ctx.world, scope, valid.sanitizedCall);
        ctx.events.push(kind === "body"
            ? {
                timestamp: Date.now(),
                type: "secret_body_chosen",
                payload: { policy: state_1.NOBLE_SECRET_BODY_POLICY, actorId, day, targetId: receipt.targetId },
                audience: Object.freeze([actorId]),
            }
            : {
                timestamp: Date.now(),
                type: "noble_servant_chosen",
                payload: {
                    policy: state_1.NOBLE_SECRET_BODY_POLICY,
                    actorId,
                    day,
                    targetId: receipt.targetId,
                    contractId: receipt.targetId === null ? null : `servant:night:${day}`,
                },
                audience: Object.freeze([actorId]),
            });
        (0, recorder_1.safeRecordLogicOp)({
            scope: "gateway",
            op: "validate_tool_call",
            actorId,
            phase: identity_1.Phase.Night,
            status: "ok",
            input: { tool: call.name, args: call.args },
        });
        (0, recorder_1.safeRecordLogicOp)({
            scope: "phase_pipeline",
            op: kind === "body" ? "secret_body_choice_committed" : "noble_servant_choice_committed",
            actorId,
            phase: identity_1.Phase.Night,
            status: "ok",
            output: { ...receipt, policy: state_1.NOBLE_SECRET_BODY_POLICY },
        });
    }
    finally {
        (0, requests_1.closeNobleBodyRequest)(scope);
    }
}
exports.SECRET_BODY_STAGE = {
    id: "secret_body_action",
    priority: 150,
    execute: (ctx) => execute(ctx, "body"),
};
exports.NOBLE_CHOICE_STAGE = {
    id: "night_noble_action",
    priority: 450,
    execute: (ctx) => execute(ctx, "noble"),
};
