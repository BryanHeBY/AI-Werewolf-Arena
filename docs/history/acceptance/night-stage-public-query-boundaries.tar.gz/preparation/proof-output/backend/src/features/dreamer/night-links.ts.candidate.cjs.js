"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dreamNightLinksForAppend = dreamNightLinksForAppend;
exports.readDreamNightLinks = readDreamNightLinks;
exports.installDreamNightLinks = installDreamNightLinks;
exports.bindPaidDreamNightProbe = bindPaidDreamNightProbe;
const linksByState = new WeakMap();
function ownedLinks(state) {
    let links = linksByState.get(state);
    if (!links) {
        links = [];
        linksByState.set(state, links);
    }
    return links;
}
function dreamNightLinksForAppend(state) {
    return ownedLinks(state);
}
function readDreamNightLinks(state) {
    return ownedLinks(state);
}
function installDreamNightLinks(state, links) {
    linksByState.set(state, links);
}
function bindPaidDreamNightProbe(runtime) {
    return {
        get captureProbe() {
            const links = readDreamNightLinks(runtime.state());
            return () => {
                const frame = new night_frame_1.DreamNightFrame(links);
                return {
                    protectedTargets: () => frame.protectedTargets((0, dream_night_effects_1.bindDreamLifeQueries)(runtime.world())),
                    linkedDeaths: (deaths) => frame.linkedDeaths((0, dream_night_effects_1.bindDreamLifeQueries)(runtime.world()), deaths),
                };
            };
        },
    };
}
const night_frame_1 = require("./night-frame");
const dream_night_effects_1 = require("../../domain/dream-night-effects");
