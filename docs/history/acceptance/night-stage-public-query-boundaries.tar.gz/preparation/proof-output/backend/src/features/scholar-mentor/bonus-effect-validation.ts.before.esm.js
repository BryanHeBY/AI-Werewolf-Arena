import { COMPONENT } from "../../domain/components/names";
import { aliveLifeVersion } from "../../domain/components/alive";
import { assertScholarMentorRosterCurrent } from "./night-frame";
import { readScholarMentorBonusEffectRecords } from "./bonus-effect-records";
export function assertScholarMentorBonusEffects(ctx) {
    assertScholarMentorRosterCurrent(ctx.world);
    for (const effect of readScholarMentorBonusEffectRecords(ctx.state)) {
        const target = effect.receipt.target;
        if (!effect.receipt.effectCurrent() ||
            (target &&
                (ctx.world.getComponent(target.id, COMPONENT.Alive) !== target.life ||
                    aliveLifeVersion(target.life) !== target.version)) ||
            (effect.marks &&
                target &&
                ctx.world.getComponent(target.id, COMPONENT.StatusMarks) !== effect.marks))
            throw new Error("scholar_mentor_bonus_effect_stale");
    }
}
