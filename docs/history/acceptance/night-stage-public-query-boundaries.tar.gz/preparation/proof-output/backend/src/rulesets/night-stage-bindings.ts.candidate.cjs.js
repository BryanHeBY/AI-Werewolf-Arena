"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bindSyntheticNightDamageStage = bindSyntheticNightDamageStage;
exports.bindNightStageContext = bindNightStageContext;
exports.executePreparedNightStage = executePreparedNightStage;
const trusted_runtime_1 = require("../engine/night/trusted-runtime");
const tool_gateway_1 = require("../engine/actions/tool-gateway");
const night_links_1 = require("../features/dreamer/night-links");
const night_stages_1 = require("../features/animal-dream/night-stages");
const night_stages_2 = require("../features/awakened-hidden-wolf/night-stages");
const night_stage_1 = require("../features/black-market-merchant/night-stage");
const night_stage_2 = require("../features/cupid/night-stage");
const death_ability_activation_1 = require("../features/death-actions/death-ability-activation");
const night_stages_3 = require("../features/demon-hunter/night-stages");
const night_stages_4 = require("../features/dreamer/night-stages");
const night_frame_1 = require("../features/evil-knight/night-frame");
const night_stages_5 = require("../features/fragrant-pair-seer/night-stages");
const night_stages_6 = require("../features/ghost-bride/night-stages");
const feedback_1 = require("../features/gravekeeper/feedback");
const night_stages_7 = require("../features/guard/night-stages");
const night_stage_3 = require("../features/hybrid/night-stage");
const night_stages_8 = require("../features/magician/night-stages");
const night_stages_9 = require("../features/mechanical-wolf/night-stages");
const night_stage_4 = require("../features/miracle-merchant/night-stage");
const night_stages_10 = require("../features/mist-raven/night-stages");
const recipient_ability_stage_1 = require("../features/night-abilities/recipient-ability-stage");
const night_stages_11 = require("../features/nightmare/night-stages");
const night_stages_12 = require("../features/noble-secret-body/night-stages");
const night_stages_13 = require("../features/pure-white/night-stages");
const night_stages_14 = require("../features/radiant-eclipse/night-stages");
const night_stages_15 = require("../features/role-inspection/night-stages");
const night_stages_16 = require("../features/scholar-mentor/night-stages");
const night_stages_17 = require("../features/seer/night-stages");
const night_stages_18 = require("../features/time-wolf-consort/night-stages");
const night_stages_19 = require("../features/trickster/night-stages");
const night_stages_20 = require("../features/witch/night-stages");
const night_stages_21 = require("../features/wolf-beauty/night-stages");
const night_stages_22 = require("../features/wolf-sorcerer/night-stages");
const night_stages_23 = require("../features/wolf/night-stages");
const programs = [
    ...night_stages_1.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_2.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stage_1.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stage_2.OWNED_NIGHT_STAGE_PROGRAMS,
    ...death_ability_activation_1.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_3.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_4.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_frame_1.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_5.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_6.OWNED_NIGHT_STAGE_PROGRAMS,
    ...feedback_1.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_7.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stage_3.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_8.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_9.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stage_4.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_10.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_11.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_12.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_13.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_14.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_15.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_16.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_17.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_18.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_19.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_20.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_21.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_22.OWNED_NIGHT_STAGE_PROGRAMS,
    ...night_stages_23.OWNED_NIGHT_STAGE_PROGRAMS
];
const syntheticDamageStages = new WeakSet();
function bindSyntheticNightDamageStage(handler) { syntheticDamageStages.add(handler); return handler; }
const night_stage_registration_1 = require("./night-stage-registration");
function bindNightStageContext(handler, runtime) {
    const source = (0, night_stage_registration_1.sourceNightStageHandler)(handler);
    let ports;
    if (source === night_stages_4.DREAMER_NIGHT_STAGE)
        ports = (0, night_links_1.bindPaidDreamNightProbe)({ state: () => runtime.state, world: () => runtime.world });
    else if (night_stages_2.AWAKENED_NIGHT_STAGES.some((known) => known === source))
        ports = (0, trusted_runtime_1.bindLegacyAwakenedProposals)(runtime);
    else if (source === feedback_1.GRAVEKEEPER_FEEDBACK_STAGE)
        ports = {
            get runFeedback() {
                const callee = feedback_1.GRAVEKEEPER_FEEDBACK_STAGE.execute;
                return () => executePreparedNightStage(feedback_1.GRAVEKEEPER_FEEDBACK_STAGE, callee, runtime);
            },
        };
    else if (syntheticDamageStages.has(handler))
        ports = (0, trusted_runtime_1.bindSyntheticNightDamageCommands)(runtime);
    return {
        get isCurrent() { const callee = runtime.isCurrent, invoke = Reflect.apply.bind(Reflect); return () => invoke(callee, runtime, []); },
        get previousExile() { return runtime.previousExile; },
        get actions() { return (0, tool_gateway_1.createBoundToolGateway)(() => runtime.toolGateway, () => runtime.world); },
        get actionProvider() {
            const provider = runtime.actionProvider;
            return { get getAction() { const callee = provider.getAction, invoke = Reflect.apply.bind(Reflect); return (request) => invoke(callee, provider, [request]); } };
        },
        get currentDay() { const callee = runtime.currentDay, invoke = Reflect.apply.bind(Reflect); return () => invoke(callee, runtime, []); },
        get makeRequest() { const callee = runtime.makeRequest, invoke = Reflect.apply.bind(Reflect); return (actor, tools, extras) => invoke(callee, runtime, [actor, tools, extras]); },
        entityIds() { return runtime.world.entityIds(); },
        get getAliveByRole() { const callee = runtime.getAliveByRole, invoke = Reflect.apply.bind(Reflect); return (role) => invoke(callee, runtime, [role]); },
        get pickMajorityTarget() { const callee = runtime.pickMajorityTarget, invoke = Reflect.apply.bind(Reflect); return (votes) => invoke(callee, runtime, [votes]); },
        get pickMistKnife() { const callee = runtime.pickMistKnife; if (!callee)
            return callee; const invoke = Reflect.apply.bind(Reflect); return (ids) => invoke(callee, runtime, [ids]); },
        get shuffleWolves() { const callee = runtime.shuffleWolves, invoke = Reflect.apply.bind(Reflect); return (ids) => invoke(callee, runtime, [ids]); },
        get ports() { return ports; },
    };
}
function executePreparedNightStage(handler, callee, runtime) {
    const invoke = Reflect.apply.bind(Reflect), source = (0, night_stage_registration_1.sourceNightStageHandler)(handler);
    const owned = programs.some(([known, program]) => known === source && program === callee) || (0, recipient_ability_stage_1.isOwnedRecipientAbilityProgram)(source, callee);
    const context = owned ? runtime : bindNightStageContext(handler, runtime);
    return invoke(callee, handler, [context]);
}
