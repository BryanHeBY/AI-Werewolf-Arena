"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCHOLAR_MENTOR_NIGHT_STAGES = void 0;
const domain_1 = require("../../domain");
const night_effects_1 = require("../../domain/night-effects");
const inspection_1 = require("../../engine/inspection");
const state_slot_1 = require("./state-slot");
const bonus_effect_records_1 = require("./bonus-effect-records");
const bonus_effect_validation_1 = require("./bonus-effect-validation");
const night_frame_1 = require("./night-frame");
const choose = {
    id: "scholar_mentor_choice",
    priority: 50,
    async execute(ctx) {
        const day = ctx.currentDay(), pending = (0, night_frame_1.beginScholarMentorNight)(ctx.world, day);
        for (const actorId of ctx.world.entityIds()) {
            const role = ctx.world.getComponent(actorId, domain_1.COMPONENT.Role), state = (0, state_slot_1.scholarMentorStateForRole)(role, () => ctx.world.getComponent(actorId, domain_1.COMPONENT.Camp));
            if (!state)
                continue;
            if (!pending.includes(actorId)) {
                const reason = day === 1
                    ? "first_night"
                    : ctx.world.getAliveEntityIds().includes(actorId)
                        ? "exhausted"
                        : "dead";
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "modifier_choice_skipped",
                    payload: { actorId, day, reason },
                    audience: Object.freeze([actorId]),
                });
                continue;
            }
            const modes = ["enhance", "weaken"].filter((mode) => state.remaining[mode] === 1);
            const request = ctx.makeRequest(actorId, ["modify_skill"], {
                stage: "scholar_mentor_choice",
                requiresAction: true,
                action_failure_policy: "error",
                allow_fallback: false,
                modifier_modes: modes,
                modifier_candidates: (0, night_frame_1.scholarMentorChoiceTargets)(ctx.world, day, actorId),
            });
            (0, night_frame_1.assertScholarMentorRosterCurrent)(ctx.world);
            const action = await ctx.actionProvider.getAction(request);
            (0, night_frame_1.assertScholarMentorRosterCurrent)(ctx.world);
            if (!ctx.isCurrent() || ctx.currentDay() !== day)
                throw new Error("scholar_mentor_choice_stale");
            if (action?.name !== "modify_skill")
                throw new Error("scholar_mentor_choice_missing");
            const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                phase: domain_1.Phase.Night,
                day,
            });
            (0, night_frame_1.assertScholarMentorRosterCurrent)(ctx.world);
            if (!ctx.isCurrent() || !result.ok || result.sanitizedCall?.name !== "modify_skill")
                throw new Error("scholar_mentor_choice_invalid");
            const { mode, target_id } = result.sanitizedCall.args;
            (0, night_frame_1.commitScholarMentorChoice)(ctx.world, day, actorId, mode, target_id);
            ctx.events.push({
                timestamp: Date.now(),
                type: "modifier_choice_committed",
                payload: { actorId, day, mode, targetId: target_id },
                audience: Object.freeze([actorId]),
            });
        }
        const result = (0, night_frame_1.settleScholarMentorChoices)(ctx.world, day);
        ctx.state.modifierDeaths = (0, night_frame_1.scholarMentorConflictDeaths)(ctx.world, day);
        if (result.conflict !== null)
            ctx.events.push({
                timestamp: Date.now(),
                type: "modifier_conflict_resolved",
                payload: { day, kind: result.conflict, targetId: result.pendingDeaths[0] },
                audience: Object.freeze([]),
            });
    },
};
function bonus(kind, priority) {
    return {
        id: "scholar_mentor_bonus_" + kind,
        priority,
        async execute(ctx) {
            const day = ctx.currentDay();
            for (const actorId of (0, night_frame_1.scholarMentorBonusActors)(ctx.world, day, kind)) {
                const request = ctx.makeRequest(actorId, ["bonus_action"], {
                    stage: "scholar_mentor_bonus",
                    requiresAction: true,
                    action_failure_policy: "error",
                    allow_fallback: false,
                    modifier_bonus_kind: kind,
                    modifier_bonus_candidates: (0, night_frame_1.scholarMentorBonusTargets)(ctx.world, day, actorId, kind),
                });
                (0, night_frame_1.assertScholarMentorRosterCurrent)(ctx.world);
                const action = await ctx.actionProvider.getAction(request);
                (0, night_frame_1.assertScholarMentorRosterCurrent)(ctx.world);
                if (!ctx.isCurrent() || ctx.currentDay() !== day)
                    throw new Error("scholar_mentor_bonus_stale");
                if (action?.name !== "bonus_action" || action.args.kind !== kind)
                    throw new Error("scholar_mentor_bonus_missing");
                const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                    phase: domain_1.Phase.Night,
                    day,
                });
                (0, night_frame_1.assertScholarMentorRosterCurrent)(ctx.world);
                if (!ctx.isCurrent() ||
                    !result.ok ||
                    result.sanitizedCall?.name !== "bonus_action" ||
                    result.sanitizedCall.args.kind !== kind)
                    throw new Error("scholar_mentor_bonus_invalid");
                const { target_id: targetId, abstain } = result.sanitizedCall.args;
                const receipt = (0, night_frame_1.captureScholarMentorBonus)(ctx.world, day, actorId, kind, targetId);
                const inspection = kind === "check" && targetId !== null
                    ? (0, inspection_1.resolveInspection)(ctx.world, targetId, "camp", ctx.roleCatalog)
                    : null;
                if (kind === "check" && targetId !== null && !inspection)
                    throw new Error("scholar_mentor_inspection_invalid");
                if (!receipt.isCurrent() || !ctx.isCurrent())
                    throw new Error("scholar_mentor_bonus_stale");
                receipt.commit();
                if (targetId !== null && receipt.target) {
                    if (kind === "check") {
                        ctx.state.seerChecks.push({
                            seerId: actorId,
                            targetId,
                            isWerewolf: inspection.camp === domain_1.Camp.Wolf,
                            result: { ...inspection },
                        });
                        (0, bonus_effect_records_1.scholarMentorBonusEffectRecordsForAppend)(ctx.state).push({ kind, receipt });
                    }
                    else {
                        const marks = ctx.ensureMarks(targetId);
                        if (kind === "guard") {
                            marks.add(domain_1.StatusMark.GuardMark);
                            (ctx.state.guardClaims ??= []).push({
                                target: receipt.target,
                                marks,
                                isCurrent: receipt.effectCurrent,
                            });
                        }
                        else if (kind === "poison") {
                            marks.add(domain_1.StatusMark.PoisonMark);
                            let effectSource;
                            (ctx.state.poisonClaims ??= []).push((0, night_effects_1.originalPoisonIntent)({
                                source: (effectSource = receipt.source),
                                target: receipt.target,
                                isCurrent: receipt.effectCurrent,
                            }, {
                                family: "scholar-mentor",
                                day,
                                stage: "scholar_mentor_bonus",
                                actorLife: effectSource,
                                requestedTargetId: targetId,
                                abilityId: "bonus:poison",
                            }));
                        }
                        else {
                            marks.add(domain_1.StatusMark.WolfKillMark);
                            (ctx.state.modifierKnifeTargets ??= []).push(targetId);
                        }
                        (0, bonus_effect_records_1.scholarMentorBonusEffectRecordsForAppend)(ctx.state).push({ kind, receipt, marks });
                    }
                }
                ctx.events.push({
                    timestamp: Date.now(),
                    type: "modifier_bonus_resolved",
                    payload: {
                        actorId,
                        day,
                        kind,
                        targetId,
                        abstain,
                        ...(inspection ? { isWerewolf: inspection.camp === domain_1.Camp.Wolf } : {}),
                    },
                    audience: Object.freeze([actorId]),
                });
            }
            (0, bonus_effect_validation_1.assertScholarMentorBonusEffects)(ctx);
        },
    };
}
exports.SCHOLAR_MENTOR_NIGHT_STAGES = [
    choose,
    bonus("guard", 350),
    bonus("kill", 450),
    bonus("poison", 550),
    bonus("check", 650),
];
