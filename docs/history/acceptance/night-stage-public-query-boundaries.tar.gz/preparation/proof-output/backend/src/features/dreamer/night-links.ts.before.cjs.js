"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dreamNightLinksForAppend = dreamNightLinksForAppend;
exports.readDreamNightLinks = readDreamNightLinks;
exports.installDreamNightLinks = installDreamNightLinks;
const linksByState = new WeakMap();
function ownedLinks(state) {
    let links = linksByState.get(state);
    if (!links) {
        links = [];
        linksByState.set(state, links);
    }
    return links;
}
function dreamNightLinksForAppend(state) {
    return ownedLinks(state);
}
function readDreamNightLinks(state) {
    return ownedLinks(state);
}
function installDreamNightLinks(state, links) {
    linksByState.set(state, links);
}
