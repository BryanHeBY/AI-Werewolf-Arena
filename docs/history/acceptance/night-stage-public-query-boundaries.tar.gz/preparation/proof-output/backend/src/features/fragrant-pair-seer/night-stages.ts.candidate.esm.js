import { Phase } from "../../domain/identity";
import { safeRecordLogicOp } from "../../recording/session/recorder";
import { fragrantChoiceActor, fragrantChoiceCandidates } from "./authority";
import { openFragrantPairRequest, fragrantPairRequestScope, readFragrantPairTool, commitFragrantPairChoice, closeFragrantPairRequest, } from "./requests";
import { FRAGRANT_PAIR_POLICY } from "./state";
async function execute(ctx, kind) {
    const day = ctx.currentDay(), actorId = fragrantChoiceActor(ctx.world, day, kind);
    if (actorId === null)
        return;
    const name = kind === "bind" ? "bind_fragrant_pair" : "check_pair", candidates = fragrantChoiceCandidates(ctx.world, day), request = ctx.makeRequest(actorId, [name], {
        stage: kind === "bind" ? "fragrant_bind" : "pair_inspection",
        requiresAction: true,
        allow_fallback: false,
        action_failure_policy: "error",
        ...(kind === "bind"
            ? { fragrant_pair_candidates: candidates }
            : { pair_check_candidates: candidates, ability_id: "native:pair_check" }),
    }), scope = openFragrantPairRequest(ctx.world, day, kind, request);
    try {
        const raw = await ctx.actionProvider.getAction(request);
        if (fragrantPairRequestScope(ctx.world, request) !== scope)
            throw Error("fragrant_request_unavailable");
        const call = readFragrantPairTool(raw);
        if (!call || call.name !== name)
            throw Error("fragrant_required_action_invalid");
        const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, call, {
            phase: Phase.Night,
            day,
            scope: scope,
            deferOperation: true,
        });
        if (!valid.ok || !valid.sanitizedCall || fragrantPairRequestScope(ctx.world, request) !== scope)
            throw Error("fragrant_required_action_invalid");
        const receipt = commitFragrantPairChoice(ctx.world, scope, valid.sanitizedCall);
        ctx.events.push("pairIds" in receipt
            ? {
                timestamp: Date.now(),
                type: "fragrant_pair_chosen",
                payload: { policy: FRAGRANT_PAIR_POLICY, ...receipt },
                audience: Object.freeze([actorId]),
            }
            : {
                timestamp: Date.now(),
                type: "fragrant_pair_inspected",
                payload: { policy: FRAGRANT_PAIR_POLICY, ...receipt },
                audience: Object.freeze([actorId]),
            });
        safeRecordLogicOp({
            scope: "gateway",
            op: "validate_tool_call",
            actorId,
            phase: Phase.Night,
            status: "ok",
            input: { tool: call.name, args: call.args },
        });
        safeRecordLogicOp({
            scope: "phase_pipeline",
            op: kind === "bind" ? "fragrant_pair_chosen" : "fragrant_pair_inspected",
            actorId,
            phase: Phase.Night,
            status: "ok",
            output: { policy: FRAGRANT_PAIR_POLICY, ...receipt },
        });
    }
    finally {
        closeFragrantPairRequest(scope);
    }
}
export const FRAGRANT_BIND_STAGE = {
    id: "fragrant_bind",
    priority: 150,
    execute: (ctx) => execute(ctx, "bind"),
};
export const PAIR_INSPECTION_STAGE = {
    id: "pair_inspection",
    priority: 600,
    execute: (ctx) => execute(ctx, "pair"),
};
export const OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    FRAGRANT_BIND_STAGE, PAIR_INSPECTION_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
