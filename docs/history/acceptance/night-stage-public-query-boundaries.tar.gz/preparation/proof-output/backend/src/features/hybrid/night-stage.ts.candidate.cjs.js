"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.HYBRID_STAGE = void 0;
exports.hasHybridNightCommit = hasHybridNightCommit;
const names_1 = require("../../domain/components/names");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const request_lease_1 = require("../../domain/request-lease");
const victory_1 = require("../../domain/components/victory");
const model_1 = require("../../domain/model");
const night_effects_1 = require("../../domain/night-effects");
const state_slot_1 = require("./state-slot");
const committed = new WeakMap();
function hasHybridNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
const requestLease = request_lease_1.RequestLease.window({
    actorId: (scope) => scope.actorId,
    phase: () => model_1.Phase.Night,
    day: (scope) => scope.day,
    stage: () => "hybrid",
    current: (scope) => scope.current(),
}, 120);
exports.HYBRID_STAGE = {
    id: "hybrid",
    priority: 110,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (day !== 1)
            return;
        for (const actorId of ctx.getAliveByRole(model_1.Role.Hybrid)) {
            const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role);
            const state = (0, state_slot_1.getHybridState)(role), life = (0, night_effects_1.captureNightLife)(ctx.world, actorId);
            const victory = ctx.world.getComponent(actorId, names_1.COMPONENT.Victory);
            if (!state ||
                !life ||
                !victory ||
                ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Good)
                continue;
            const privateState = role.privateState, affiliations = victory.affiliations;
            const current = () => ctx.isCurrent() &&
                ctx.currentDay() === day &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Role) === role &&
                role.role === model_1.Role.Hybrid &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Good &&
                role.privateState === privateState &&
                (0, state_slot_1.getHybridState)(role) === state &&
                (0, night_effects_1.livingNightLife)(ctx.world, life) &&
                ctx.world.getComponent(actorId, names_1.COMPONENT.Victory) === victory &&
                victory.affiliations === affiliations &&
                affiliations.length === 0 &&
                (0, state_slot_1.canChooseExemplar)(state, day);
            const canAct = () => !(0, role_execution_authority_1.isRoleExecutionRetired)(role);
            if (!current() || !canAct())
                continue;
            let completed = false;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!current() || !canAct())
                    break;
                const targets = new Map(ctx.world
                    .getAliveEntityIds()
                    .filter((id) => id !== actorId)
                    .map((id) => {
                    const targetRole = ctx.world.getComponent(id, names_1.COMPONENT.Role);
                    return [
                        id,
                        {
                            life: (0, night_effects_1.captureNightLife)(ctx.world, id),
                            role: targetRole,
                            kind: targetRole.role,
                            camp: ctx.world.getComponent(id, names_1.COMPONENT.Camp)?.camp,
                            privateState: targetRole.privateState,
                        },
                    ];
                }));
                if (!targets.size)
                    throw new Error("hybrid_valid_action_missing");
                const provider = ctx.actionProvider, getAction = provider.getAction, makeRequest = ctx.makeRequest;
                const requestActor = actorId;
                const requestTools = ["choose_exemplar"];
                const requestExtras = {
                    stage: "hybrid",
                    requiresAction: true,
                    allow_fallback: false,
                    ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
                };
                const requestArgs = [requestActor, requestTools, requestExtras];
                const invokeRequest = Reflect.apply.bind(Reflect);
                if (!canAct())
                    break;
                const request = invokeRequest(makeRequest, ctx, requestArgs);
                const requestScope = {
                    actorId,
                    day,
                    current: () => current() && canAct(),
                };
                requestLease.bind(requestScope, request);
                const turn = requestLease.openDelivery(requestScope, request);
                let bodyFailed = false;
                try {
                    if (!turn)
                        break;
                    const actionArgs = [request];
                    const invokeAction = Reflect.apply.bind(Reflect);
                    if (!canAct() || !turn.current())
                        break;
                    const action = await invokeAction(getAction, provider, actionArgs);
                    if (!current() || !canAct() || !turn.current())
                        break;
                    if (action?.name !== "choose_exemplar")
                        continue;
                    const valid = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                        phase: model_1.Phase.Night,
                        day,
                    });
                    if (!current() ||
                        !valid.ok ||
                        valid.sanitizedCall?.name !== "choose_exemplar" ||
                        !canAct() ||
                        !turn.current())
                        continue;
                    const targetId = valid.sanitizedCall.args.target_id, target = targets.get(targetId);
                    if (!target ||
                        !(0, night_effects_1.livingNightLife)(ctx.world, target.life) ||
                        ctx.world.getComponent(targetId, names_1.COMPONENT.Role) !== target.role ||
                        target.role.role !== target.kind ||
                        ctx.world.getComponent(targetId, names_1.COMPONENT.Camp)?.camp !== target.camp ||
                        target.role.privateState !== target.privateState ||
                        (target.camp !== model_1.Camp.Good && target.camp !== model_1.Camp.Wolf))
                        continue;
                    const membership = (0, victory_1.createVictoryComponent)([{ kind: "faction", faction: target.camp }]);
                    const commitChoice = state_slot_1.commitHybridChoice;
                    if (!canAct() || !turn.current())
                        continue;
                    commitChoice(state, day, targetId);
                    ctx.world.addComponent(actorId, names_1.COMPONENT.Victory, membership);
                    const days = committed.get(ctx.world) ?? new Set();
                    days.add(day);
                    committed.set(ctx.world, days);
                    turn.complete();
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "hybrid_exemplar_chosen",
                        payload: { actorId, day, targetId },
                    });
                    ctx.events.push({
                        timestamp: Date.now(),
                        type: "hybrid_affiliation_resolved",
                        payload: { actorId, day, targetId, faction: target.camp },
                    });
                    completed = true;
                    break;
                }
                catch (error) {
                    bodyFailed = true;
                    throw error;
                }
                finally {
                    try {
                        turn?.close();
                    }
                    catch (error) {
                        if (!bodyFailed)
                            throw error;
                    }
                }
            }
            if (!completed && current() && canAct())
                throw new Error("hybrid_valid_action_missing");
        }
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.HYBRID_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
