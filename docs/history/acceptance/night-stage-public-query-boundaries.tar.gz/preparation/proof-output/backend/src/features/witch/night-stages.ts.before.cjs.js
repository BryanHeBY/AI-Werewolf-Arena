"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WITCH_NIGHT_STAGES = void 0;
const ports_1 = require("./ports");
const night_effects_1 = require("../../domain/night-effects");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const policies_1 = require("./policies");
const ports_2 = require("./ports");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const inventory_ports_2 = require("../night-abilities/inventory-ports");
const history_ports_1 = require("../night-abilities/history-ports");
const scope_ports_1 = require("../night-abilities/scope-ports");
const resetNightRoleStateStage = {
    id: "reset_night_role_state",
    priority: 100,
    async execute(ctx) {
        if (ctx.nativeNightFailure.usesDemonController())
            return;
        for (const id of ctx.world.getAliveEntityIds()) {
            const role = ctx.world.getComponent(id, names_1.COMPONENT.Role);
            for (const ability of (0, inventory_ports_1.allNightAbilities)(role)) {
                if (ability.kind !== "potion")
                    continue;
                const witchState = ability.state;
                ports_1.WITCH_STATE_SLOT.allowedWrites.resetWitchNightState(witchState, () => ctx.currentDay());
            }
        }
    },
};
const witchActionStage = {
    id: "witch_action",
    priority: 500,
    async execute(ctx) {
        if (ctx.nativeNightFailure.usesDemonController()) {
            if (!ctx.nativeNightFailure.requiresDemonPotionTurn())
                return;
            const { executeDemonWitchTurn } = await ctx.nativeNightEffects.loadSealedPotionController();
            const result = await executeDemonWitchTurn({
                world: ctx.world,
                gateway: ctx.toolGateway,
                events: ctx.events,
                provider: ctx.actionProvider,
                day: ctx.currentDay(),
                wolfTarget: ctx.state.wolfTarget,
                construction: ctx,
            });
            if (result.poison)
                (ctx.state.poisonClaims ??= []).push(result.poison.claim);
            return;
        }
        for (const { actorId: witchId, ability } of ctx.nightActors.actors("potion", ctx.currentDay())) {
            if (ability.activation === "lucky" || ability.activation === "black_market")
                continue;
            if (ctx.nativeNightFailure.skipsEmptyBorrowedPotion(ability))
                continue;
            const day = ctx.currentDay();
            const ownership = (0, scope_ports_1.captureNightAbilityScope)(ctx.world, witchId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day);
            if (!ownership?.isEligible())
                continue;
            const close = () => {
                if (ownership.isOwnerCurrent() && !ability.disabled && !ability.deathExpired)
                    ports_1.WITCH_STATE_SLOT.allowedWrites.closeWitchPotionTurn(ability, day);
            };
            const both = (0, policies_1.nativePotionsCanCombine)(ability);
            for (let turn = 0; turn < (both ? 2 : 1); turn++) {
                if (!(0, inventory_ports_1.activeNightAbility)(ctx.world.getComponent(witchId, names_1.COMPONENT.Role), "potion", ctx.currentDay(), ability.id))
                    break;
                const used = await executePotionTurn(ctx, witchId, ability);
                if (!ctx.isCurrent())
                    return;
                if (!used) {
                    if (both)
                        close();
                    break;
                }
            }
            if (both)
                close();
        }
    },
};
exports.WITCH_NIGHT_STAGES = [resetNightRoleStateStage, witchActionStage];
async function executePotionTurn(ctx, witchId, ability) {
    ctx.nativeNightFailure.assertNativeActor(witchId, model_1.Role.Witch);
    ctx.nativeNightFailure.assertPotionSource(ability);
    const day = ctx.currentDay();
    const scope = (0, scope_ports_1.captureNightAbilityScope)(ctx.world, witchId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day);
    if (!scope?.isEligible())
        return false;
    ports_1.WITCH_STATE_SLOT.allowedWrites.refreshWitchSelfHeal(ability, day);
    const targets = new Map(ctx.world.getAliveEntityIds().map((id) => [id, (0, night_effects_1.captureNightLife)(ctx.world, id)]));
    const attribution = ability.source.kind === "native" ? {} : { abilityId: ability.id };
    let effectAbilityId;
    const req = ctx.makeRequest(witchId, ["use_potion"], {
        stage: "witch",
        ...ctx.nativeNightTargets.potionModifierHints(witchId),
        ability_id: (effectAbilityId = ability.id),
        ...((0, policies_1.witchKnifeVisible)(ability)
            ? {
                wolf_target: ctx.state.wolfTarget,
                ...ctx.nativeNightTargets.potionKnifeHints(),
            }
            : {}),
    });
    if (!scope.isEligible()) {
        ctx.nativeNightFailure.scopeStale("witch");
        return false;
    }
    const action = await ctx.actionProvider.getAction(req);
    if (!ctx.isCurrent())
        return false;
    if (!scope.isEligible()) {
        ctx.nativeNightFailure.scopeStale("witch");
        return false;
    }
    if (action?.name !== "use_potion") {
        ctx.nativeNightFailure.actionMissing("witch");
        ctx.events.push({
            timestamp: Date.now(),
            type: "witch_potion_skipped",
            payload: {
                actorId: witchId,
                ...attribution,
                targetId: null,
                potionType: model_1.PotionType.None,
                reason: "no_action",
            },
        });
        return false;
    }
    const result = ctx.toolGateway.validateAndSanitize(ctx.world, witchId, action, {
        phase: model_1.Phase.Night,
        day: ctx.currentDay(),
        abilityId: ability.id,
    });
    if (!ctx.isCurrent())
        return false;
    if (!scope.isEligible()) {
        ctx.nativeNightFailure.scopeStale("witch");
        return false;
    }
    if (!result.ok || !result.sanitizedCall) {
        ctx.nativeNightFailure.actionInvalid("witch");
        ctx.events.push({
            timestamp: Date.now(),
            type: "witch_potion_skipped",
            payload: {
                actorId: witchId,
                ...attribution,
                targetId: action.args.target_id ?? null,
                potionType: model_1.PotionType.None,
                reason: "invalid_action",
            },
        });
        return false;
    }
    const witch = ctx.world.getComponent(witchId, names_1.COMPONENT.Role);
    if (!(0, inventory_ports_1.activeNightAbility)(witch, "potion", ctx.currentDay(), ability.id))
        return false;
    const witchState = witch ? (0, ports_2.getWitchState)(witch, ability.id) : undefined;
    if (!witchState) {
        return false;
    }
    const targetId = result.sanitizedCall.args.target_id;
    const potion = result.sanitizedCall.args.potion_type;
    const requestedTarget = targets.get(targetId);
    if (potion !== model_1.PotionType.None &&
        (!requestedTarget || !(0, night_effects_1.livingNightLife)(ctx.world, requestedTarget)))
        return false;
    const mapping = potion !== model_1.PotionType.None
        ? ctx.nativeNightTargets.mappedTarget(() => day, () => targetId)
        : null;
    if (mapping && !mapping.isCurrent())
        throw new Error("magician_potion_target_stale");
    const receipt = potion === model_1.PotionType.Poison
        ? ctx.nativeNightTargets.reflectedTarget(() => day, () => witchId, () => targetId, "poison")
        : null;
    if (receipt && (ability.source.kind !== "native" || ability.source.role !== model_1.Role.Witch))
        throw new Error("time_consort_witch_source_invalid");
    const effectiveId = receipt?.effectiveId ?? mapping?.effectiveId ?? targetId;
    const target = receipt?.scope ?? mapping?.scope ?? requestedTarget;
    if (potion === "heal") {
        if (witchState.heal <= 0 ||
            witchState.healUsedThisNight ||
            (witchState.poisonUsedThisNight && !(0, policies_1.nativePotionsCanCombine)(ability)))
            return false;
        (0, inventory_ports_2.recordNightAbilityUse)(ability, day, true);
        ctx.ensureMarks(effectiveId).add(model_1.StatusMark.HealMark);
        ports_1.WITCH_STATE_SLOT.allowedWrites.consumeWitchHeal(witchState);
        ctx.events.push({
            timestamp: Date.now(),
            type: "witch_potion_used",
            payload: { actorId: witchId, ...attribution, targetId, potionType: model_1.PotionType.Heal },
        });
    }
    if (potion === "poison") {
        if (witchState.poison <= 0 ||
            witchState.poisonUsedThisNight ||
            (witchState.healUsedThisNight && !(0, policies_1.nativePotionsCanCombine)(ability)))
            return false;
        if (!(0, history_ports_1.luckyTargetAllowed)(ctx.world, witchId, ability, day, "poison", targetId))
            return false;
        const source = (0, night_effects_1.captureNightLife)(ctx.world, witchId);
        if (!source || !target)
            return false;
        ctx.nativeNightEffects.commitReflectedTarget(receipt, day, witchId, "poison");
        (0, inventory_ports_2.recordNightAbilityUse)(ability, day, true);
        (ctx.state.poisonClaims ??= []).push((0, night_effects_1.originalPoisonIntent)({ source, target }, {
            family: "witch",
            day,
            stage: "witch",
            actorLife: source,
            requestedTargetId: targetId,
            abilityId: effectAbilityId,
        }));
        ctx.ensureMarks(effectiveId).add(model_1.StatusMark.PoisonMark);
        ports_1.WITCH_STATE_SLOT.allowedWrites.consumeWitchPoison(witchState);
        ctx.nativeNightEffects.commitNativeReflection("poison", ability, targetId, () => source, () => scope.isOwnerCurrent() && !ability.disabled && !ability.deathExpired);
        (0, history_ports_1.recordOwnNightAction)(ctx.world, witchId, day, "poison", targetId, false);
        ctx.events.push({
            timestamp: Date.now(),
            type: "witch_potion_used",
            payload: { actorId: witchId, ...attribution, targetId, potionType: model_1.PotionType.Poison },
        });
    }
    if (potion === "none") {
        ctx.events.push({
            timestamp: Date.now(),
            type: "witch_potion_skipped",
            payload: { actorId: witchId, ...attribution, targetId, potionType: model_1.PotionType.None },
        });
    }
    if (potion === model_1.PotionType.None)
        (0, inventory_ports_2.recordNightAbilityUse)(ability, day, false);
    ctx.nativeNightEffects.recordModifierTarget(day, witchId, "poison", () => potion === model_1.PotionType.Poison ? targetId : null);
    return potion !== model_1.PotionType.None;
}
