"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WEDDING_KNIFE_STAGE = exports.WEDDING_CHAT_STAGE = void 0;
const domain_1 = require("../../domain");
const alive_1 = require("../../domain/components/alive");
const setup_1 = require("./setup");
const authority_1 = require("./authority");
exports.WEDDING_CHAT_STAGE = {
    id: "ghost_bride_chat",
    priority: 150,
    async execute(ctx) {
        const day = ctx.currentDay(), pair = (0, authority_1.weddingPair)(ctx.world);
        if (day === 1 ||
            !pair ||
            ![pair.brideId, pair.groomId].every((id) => ctx.world.getComponent(id, domain_1.COMPONENT.Alive)?.alive === true))
            return;
        for (const actorId of [pair.brideId, pair.groomId])
            await (0, setup_1.executeWeddingTurn)({
                world: ctx.world,
                gateway: ctx.toolGateway,
                events: ctx.events,
                provider: ctx.actionProvider,
                day,
                actorId,
                kind: "chat",
                tool: "speak_to_partner",
                stage: "ghost_bride_chat",
                isCurrent: ctx.isCurrent,
                construction: ctx,
            });
    },
};
exports.WEDDING_KNIFE_STAGE = {
    id: "ghost_bride_knife",
    priority: 400,
    async execute(ctx) {
        const day = ctx.currentDay(), capture = (0, authority_1.weddingNightCapture)(ctx.world, day);
        if (!capture)
            throw new Error("ghost_bride_capture_missing");
        for (const actorId of capture.actorIds) {
            const tool = capture.owner === "ordinary_pack" ? "kill_vote" : "wedding_kill_vote";
            await (0, setup_1.executeWeddingTurn)({
                world: ctx.world,
                gateway: ctx.toolGateway,
                events: ctx.events,
                provider: ctx.actionProvider,
                day,
                actorId,
                kind: "knife",
                tool,
                stage: capture.owner === "ordinary_pack" ? "wolf_vote" : "ghost_bride_knife",
                isCurrent: ctx.isCurrent,
                construction: ctx,
            });
        }
        const targetId = (0, authority_1.resolveWeddingKnife)(ctx.world, day);
        ctx.events.push({
            timestamp: Date.now(),
            type: "ghost_bride_knife_resolved",
            payload: { ...capture, actorIds: [...capture.actorIds], targetId },
            audience: Object.freeze(capture.owner === "ordinary_pack" ? [] : [...capture.actorIds].sort((a, b) => a - b)),
        });
        ctx.state.wolfTarget = targetId;
        if (targetId !== null && (0, authority_1.weddingKnifeCurrent)(ctx.world, day, targetId)) {
            const marks = ctx.ensureMarks(targetId), life = ctx.world.getComponent(targetId, domain_1.COMPONENT.Alive);
            marks.add(domain_1.StatusMark.WolfKillMark);
            ctx.state.wolfTargetScope = { targetId, life, version: (0, alive_1.aliveLifeVersion)(life), marks };
        }
    },
};
