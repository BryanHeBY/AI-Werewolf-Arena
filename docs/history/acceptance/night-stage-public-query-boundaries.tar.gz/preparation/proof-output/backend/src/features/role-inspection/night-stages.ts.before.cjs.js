"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MIRROR_INSPECTION_STAGE = exports.PSYCHIC_INSPECTION_STAGE = exports.ROLE_INSPECTION_STAGE = void 0;
const role_inspection_policy_1 = require("@ai-werewolf-arena/game-contract/role-inspection-policy");
const state_slot_1 = require("./state-slot");
const alive_1 = require("../../domain/components/alive");
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const ports_1 = require("../gargoyle/ports");
const inspection_1 = require("../../engine/inspection");
const night_scope_1 = require("./night-scope");
const role_inspection_policy_2 = require("@ai-werewolf-arena/game-contract/role-inspection-policy");
const rules_1 = require("./rules");
const scope_ports_1 = require("../night-abilities/scope-ports");
const mirror_scope_ports_1 = require("../awakened-hidden-wolf/mirror-scope-ports");
function finishOptionalInspection(ctx, actorId, ability, day, reason) {
    (0, inventory_ports_1.recordNightAbilityUse)(ability, day, false);
    ctx.events.push({
        timestamp: Date.now(),
        type: "role_inspection_skipped",
        payload: {
            actorId,
            ...(ability.source.kind === "native" ? {} : { abilityId: ability.id }),
            day,
            reason,
        },
    });
    (0, night_scope_1.recordRoleInspectionNightCommit)(ctx.world, day, ctx.isCurrent);
}
async function executeInspections(ctx, policy) {
    const day = ctx.currentDay();
    if (policy === "gargoyle")
        (0, night_scope_1.beginRoleInspectionNight)(ctx.world, day);
    for (const { actorId, ability } of ctx.nightActors.actors("role_check", day)) {
        if (!ctx.isCurrent())
            return;
        if ((0, role_inspection_policy_1.roleInspectionPolicy)(ability.state) !== policy)
            continue;
        const scope = (0, scope_ports_1.captureNightAbilityScope)(ctx.world, actorId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day);
        if (!scope)
            continue;
        const role = scope.role, gargoyleState = (0, ports_1.getGargoyleState)(role), state = ability.state, abilityId = ability.id;
        const source = ability.source, sourceKind = source.kind;
        const sourceOwner = source.kind === "native" ? source.role : source.actorId;
        const sourceAbilityId = source.kind === "copy" || source.kind === "transfer" ? source.abilityId : undefined;
        const awakenedCurrent = source.kind === "native" && source.role === model_1.Role.AwakenedHiddenWolf
            ? (0, mirror_scope_ports_1.captureAwakenedMirrorScope)(ctx.world, actorId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day)
            : () => true;
        const current = () => awakenedCurrent?.() === true &&
            scope.isEligible() &&
            (0, ports_1.getGargoyleState)(role) === gargoyleState &&
            (0, role_inspection_policy_1.roleInspectionPolicy)(state) === policy &&
            ability.source === source &&
            source.kind === sourceKind &&
            (source.kind === "native" ? source.role : source.actorId) === sourceOwner &&
            (source.kind === "copy" || source.kind === "transfer" ? source.abilityId : undefined) ===
                sourceAbilityId;
        const exhausted = () => policy === "gargoyle"
            ? (0, night_scope_1.recordRoleInspectionCompletion)(ctx.world, actorId, day, ability, ctx.isCurrent)
            : finishOptionalInspection(ctx, actorId, ability, day, "no_targets");
        if (!current())
            continue;
        if (!(0, rules_1.roleInspectionTargets)(ctx.world, actorId, state).length) {
            exhausted();
            continue;
        }
        let completed = false;
        for (let attempt = 0; attempt < 3; attempt++) {
            if (!current())
                break;
            const targets = new Map((0, rules_1.roleInspectionTargets)(ctx.world, actorId, state).map((id) => {
                const target = ctx.world.getComponent(id, names_1.COMPONENT.Alive);
                return [id, { target, version: (0, alive_1.aliveLifeVersion)(target) }];
            }));
            if (!targets.size) {
                exhausted();
                completed = true;
                break;
            }
            const request = ctx.makeRequest(actorId, ["inspect_role"], {
                stage: policy === "gargoyle"
                    ? "role_inspection"
                    : policy === "mirror"
                        ? "mirror_girl"
                        : "psychic",
                requiresAction: (0, role_inspection_policy_2.inspectionRequired)(state),
                ability_id: abilityId,
                ...(sourceKind === "native" && sourceOwner === model_1.Role.AwakenedHiddenWolf
                    ? { action_failure_policy: "error", allow_fallback: false }
                    : {}),
                ...(attempt ? { retry_attempt: attempt, retry_max: 2 } : {}),
            });
            if (!current())
                break;
            const action = await ctx.actionProvider.getAction(request);
            if (!current())
                break;
            if (action === null && !(0, role_inspection_policy_2.inspectionRequired)(state)) {
                finishOptionalInspection(ctx, actorId, ability, day, "passed");
                if (policy === "gargoyle")
                    (0, night_scope_1.recordRoleInspectionCompletion)(ctx.world, actorId, day, ability, ctx.isCurrent);
                completed = true;
                break;
            }
            if (action?.name !== "inspect_role")
                continue;
            const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                phase: model_1.Phase.Night,
                day,
                abilityId,
            });
            if (!current() || !validated.ok || validated.sanitizedCall?.name !== "inspect_role")
                continue;
            const targetId = validated.sanitizedCall.args.target_id, target = targets.get(targetId);
            const targetCurrent = () => !!target &&
                ctx.world.getComponent(targetId, names_1.COMPONENT.Alive) === target.target &&
                target.target.alive &&
                target.version !== undefined &&
                (0, alive_1.aliveLifeVersion)(target.target) === target.version;
            if (!targetCurrent() || !(0, rules_1.roleInspectionTargets)(ctx.world, actorId, state).includes(targetId))
                continue;
            const mapping = ctx.nativeNightTargets.mappedTarget(() => day, () => targetId);
            const result = (0, inspection_1.resolveInspection)(ctx.world, mapping?.effectiveId ?? targetId, "role", ctx.roleCatalog);
            if (!current() ||
                !targetCurrent() ||
                !result ||
                (mapping !== null && !mapping.isCurrent()) ||
                !(0, rules_1.roleInspectionTargets)(ctx.world, actorId, state).includes(targetId))
                continue;
            state_slot_1.ROLE_INSPECTION_STATE_SLOT.allowedWrites.appendState(state, targetId, day, result);
            (0, inventory_ports_1.recordNightAbilityUse)(ability, day, true);
            ctx.events.push({
                timestamp: Date.now(),
                type: "role_inspected",
                payload: {
                    actorId,
                    ...(ability.source.kind === "native" ? {} : { abilityId: ability.id }),
                    targetId,
                    day,
                    result: { ...result },
                },
            });
            if (policy === "gargoyle")
                (0, night_scope_1.recordRoleInspectionCompletion)(ctx.world, actorId, day, ability, ctx.isCurrent);
            else
                (0, night_scope_1.recordRoleInspectionNightCommit)(ctx.world, day, ctx.isCurrent);
            completed = true;
            break;
        }
        if (!completed && current()) {
            if ((0, rules_1.roleInspectionTargets)(ctx.world, actorId, state).length)
                throw new Error(policy === "gargoyle"
                    ? "role_inspection_required_action_missing"
                    : "role_inspection_valid_action_missing");
            exhausted();
        }
    }
}
exports.ROLE_INSPECTION_STAGE = {
    id: "role_inspection",
    priority: 180,
    execute: (ctx) => executeInspections(ctx, "gargoyle"),
};
exports.PSYCHIC_INSPECTION_STAGE = {
    id: "psychic_inspection",
    priority: 600,
    execute: (ctx) => executeInspections(ctx, "psychic"),
};
exports.MIRROR_INSPECTION_STAGE = {
    id: "mirror_inspection",
    priority: 600,
    execute: (ctx) => executeInspections(ctx, "mirror"),
};
