"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WOLF_SORCERER_EXCHANGE_STAGE = void 0;
const names_1 = require("../../domain/components/names");
const identity_1 = require("../../domain/identity");
const state_slot_1 = require("./state-slot");
const night_frame_1 = require("./night-frame");
exports.WOLF_SORCERER_EXCHANGE_STAGE = {
    id: "wolf_sorcerer_exchange",
    priority: 100,
    async execute(ctx) {
        const day = ctx.currentDay(), actorId = (0, night_frame_1.beginWolfSorcererNight)(ctx.world, day);
        if (actorId === null) {
            const id = (0, night_frame_1.wolfSorcererActorId)(ctx.world), own = ctx.world.getComponent(id, names_1.COMPONENT.Role);
            const state = (0, state_slot_1.getWolfSorcererState)(own, () => ctx.world.getComponent(id, names_1.COMPONENT.Camp));
            const reason = day < state.firstNight
                ? "not_started"
                : ctx.world.getComponent(id, names_1.COMPONENT.Alive).alive
                    ? "exhausted"
                    : "dead";
            ctx.events.push({
                timestamp: Date.now(),
                type: "wolf_sorcerer_exchange_skipped",
                payload: { actorId: id, day, reason },
                audience: Object.freeze([id]),
            });
            return;
        }
        const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role);
        if (!(0, state_slot_1.getWolfSorcererState)(role, () => ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)))
            throw new Error("wolf_sorcerer_actor_invalid");
        const request = ctx.makeRequest(actorId, ["swap_night_seats"], {
            stage: "wolf_sorcerer_exchange",
            requiresAction: true,
            action_failure_policy: "error",
            allow_fallback: false,
            sorcerer_candidates: (0, night_frame_1.wolfSorcererChoiceTargets)(ctx.world, day),
        });
        (0, night_frame_1.assertWolfSorcererRosterCurrent)(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        (0, night_frame_1.assertWolfSorcererRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("wolf_sorcerer_exchange_stale");
        if (action?.name !== "swap_night_seats")
            throw new Error("wolf_sorcerer_exchange_action_missing");
        const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: identity_1.Phase.Night,
            day,
        });
        (0, night_frame_1.assertWolfSorcererRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("wolf_sorcerer_exchange_stale");
        if (!validated.ok || validated.sanitizedCall?.name !== "swap_night_seats")
            throw new Error("wolf_sorcerer_exchange_action_invalid");
        const args = validated.sanitizedCall.args;
        const pair = args.abstain ? null : [args.first_id, args.second_id];
        (0, night_frame_1.commitWolfSorcererExchange)(ctx.world, actorId, day, pair);
        ctx.events.push({
            timestamp: Date.now(),
            type: "wolf_sorcerer_exchange_committed",
            payload: {
                actorId,
                day,
                pair: pair && [Math.min(pair[0], pair[1]), Math.max(pair[0], pair[1])],
            },
            audience: Object.freeze([actorId]),
        });
    },
};
