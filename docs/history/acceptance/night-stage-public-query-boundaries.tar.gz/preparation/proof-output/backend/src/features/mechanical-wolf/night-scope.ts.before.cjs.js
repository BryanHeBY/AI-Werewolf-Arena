"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.captureMechanicalOwner = captureMechanicalOwner;
exports.bindMechanicalSkill = bindMechanicalSkill;
exports.hasMechanicalNightCommit = hasMechanicalNightCommit;
exports.recordMechanicalNightCommit = recordMechanicalNightCommit;
exports.recordMechanicalModeScope = recordMechanicalModeScope;
exports.hasCurrentMechanicalMode = hasCurrentMechanicalMode;
exports.hasCurrentMechanicalKillMode = hasCurrentMechanicalKillMode;
const names_1 = require("../../domain/components/names");
const model_1 = require("../../domain/model");
const night_effects_1 = require("../../domain/night-effects");
const role_execution_authority_1 = require("../../domain/role-execution-authority");
const state_1 = require("./state");
function captureMechanicalOwner(world, actorId, phaseCurrent) {
    const role = world.getComponent(actorId, names_1.COMPONENT.Role);
    const state = (0, state_1.getMechanicalState)(role);
    const life = (0, night_effects_1.captureNightLife)(world, actorId);
    if (!phaseCurrent() ||
        !role ||
        role.role !== model_1.Role.MechanicalWolf ||
        world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp !== model_1.Camp.Wolf ||
        !state ||
        !life)
        return null;
    const privateState = role.privateState;
    return {
        world,
        actorId,
        role,
        state,
        life,
        canAct: () => !(0, role_execution_authority_1.isRoleExecutionRetired)(role),
        isCurrent: () => phaseCurrent() &&
            world.getComponent(actorId, names_1.COMPONENT.Role) === role &&
            role.role === model_1.Role.MechanicalWolf &&
            world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp === model_1.Camp.Wolf &&
            role.privateState === privateState &&
            (0, state_1.getMechanicalState)(role) === state &&
            (0, night_effects_1.livingNightLife)(world, life),
    };
}
function bindMechanicalSkill(scope, day) {
    const learned = scope.state.learned, mode = scope.state.mode;
    if (day < 2 ||
        !scope.isCurrent() ||
        !hasCurrentMechanicalMode(scope.world, scope.role, "skill") ||
        !learned ||
        learned.readyOnNight > day ||
        !mode ||
        mode.day !== day ||
        mode.kind !== "skill")
        return null;
    const skill = learned.skill, kind = skill.kind;
    return {
        skill,
        isCurrent: () => scope.isCurrent() &&
            hasCurrentMechanicalMode(scope.world, scope.role, "skill") &&
            scope.state.learned === learned &&
            learned.skill === skill &&
            skill.kind === kind &&
            scope.state.mode === mode &&
            mode.day === day &&
            mode.kind === "skill" &&
            learned.readyOnNight <= day,
    };
}
const modes = new WeakMap();
const committed = new WeakMap();
function hasMechanicalNightCommit(world, day) {
    return committed.get(world)?.has(day) ?? false;
}
function recordMechanicalNightCommit(world, day) {
    const days = committed.get(world) ?? new Set();
    days.add(day);
    committed.set(world, days);
}
function recordMechanicalModeScope(world, scope, day) {
    const mode = scope.state.mode;
    if (scope.world !== world || day < 2 || !scope.isCurrent() || !mode || mode.day !== day)
        return false;
    let night = modes.get(world);
    if (night && night.day > day)
        return false;
    if (!night || night.day !== day) {
        night = { day, actors: new Map() };
        modes.set(world, night);
    }
    if (night.actors.has(scope.actorId))
        return false;
    night.actors.set(scope.actorId, { owner: scope, mode, kind: mode.kind });
    return true;
}
function hasCurrentMechanicalMode(world, role, expectedKind) {
    const night = modes.get(world);
    if (!night)
        return false;
    for (const { owner, mode, kind } of night.actors.values()) {
        if (owner.role === role &&
            owner.isCurrent() &&
            owner.state.mode === mode &&
            mode.day === night.day &&
            mode.kind === kind &&
            kind === expectedKind)
            return true;
    }
    return false;
}
function hasCurrentMechanicalKillMode(world, role) {
    return hasCurrentMechanicalMode(world, role, "kill");
}
