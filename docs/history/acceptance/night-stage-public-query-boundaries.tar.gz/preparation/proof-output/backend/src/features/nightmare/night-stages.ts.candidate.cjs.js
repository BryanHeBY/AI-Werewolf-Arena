"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OWNED_NIGHT_STAGE_PROGRAMS = exports.NIGHTMARE_FEAR_STAGE = void 0;
const names_1 = require("../../domain/components/names");
const identity_1 = require("../../domain/identity");
const state_slot_1 = require("./state-slot");
const night_frame_1 = require("./night-frame");
exports.NIGHTMARE_FEAR_STAGE = {
    id: "nightmare_fear",
    priority: 90,
    async execute(ctx) {
        const day = ctx.currentDay();
        const actorId = (0, night_frame_1.beginNightmareNight)(ctx.world, day);
        if (actorId === null)
            return;
        const role = ctx.world.getComponent(actorId, names_1.COMPONENT.Role);
        if (!(0, state_slot_1.getNightmareShadowState)(role, () => ctx.world.getComponent(actorId, names_1.COMPONENT.Camp)))
            throw new Error("nightmare_fear_actor_invalid");
        const request = ctx.makeRequest(actorId, ["fear"], {
            stage: "nightmare_fear",
            requiresAction: true,
            action_failure_policy: "error",
            allow_fallback: false,
        });
        (0, night_frame_1.assertNightmareRosterCurrent)(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        (0, night_frame_1.assertNightmareRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("nightmare_fear_stale");
        if (action?.name !== "fear")
            throw new Error("nightmare_fear_action_missing");
        const args = action.args;
        if (!args ||
            typeof args.abstain !== "boolean" ||
            (args.abstain
                ? args.target_id !== null
                : typeof args.target_id !== "number" || !Number.isSafeInteger(args.target_id)))
            throw new Error("nightmare_fear_action_invalid");
        const validated = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: identity_1.Phase.Night,
            day,
        });
        (0, night_frame_1.assertNightmareRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("nightmare_fear_stale");
        if (!validated.ok || validated.sanitizedCall?.name !== "fear")
            throw new Error("nightmare_fear_action_invalid");
        const targetId = validated.sanitizedCall.args.target_id;
        (0, night_frame_1.commitNightmareFear)(ctx.world, actorId, day, targetId);
        ctx.events.push({
            timestamp: Date.now(),
            type: "nightmare_fear_committed",
            payload: { actorId, day, targetId },
            audience: Object.freeze([actorId]),
        });
    },
};
exports.OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    exports.NIGHTMARE_FEAR_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
