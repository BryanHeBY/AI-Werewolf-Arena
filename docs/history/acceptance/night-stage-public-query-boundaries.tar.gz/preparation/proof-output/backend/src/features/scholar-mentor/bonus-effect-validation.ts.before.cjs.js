"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertScholarMentorBonusEffects = assertScholarMentorBonusEffects;
const names_1 = require("../../domain/components/names");
const alive_1 = require("../../domain/components/alive");
const night_frame_1 = require("./night-frame");
const bonus_effect_records_1 = require("./bonus-effect-records");
function assertScholarMentorBonusEffects(ctx) {
    (0, night_frame_1.assertScholarMentorRosterCurrent)(ctx.world);
    for (const effect of (0, bonus_effect_records_1.readScholarMentorBonusEffectRecords)(ctx.state)) {
        const target = effect.receipt.target;
        if (!effect.receipt.effectCurrent() ||
            (target &&
                (ctx.world.getComponent(target.id, names_1.COMPONENT.Alive) !== target.life ||
                    (0, alive_1.aliveLifeVersion)(target.life) !== target.version)) ||
            (effect.marks &&
                target &&
                ctx.world.getComponent(target.id, names_1.COMPONENT.StatusMarks) !== effect.marks))
            throw new Error("scholar_mentor_bonus_effect_stale");
    }
}
