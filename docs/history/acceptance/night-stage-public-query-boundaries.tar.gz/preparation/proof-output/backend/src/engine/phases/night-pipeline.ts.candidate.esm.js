import { attachNightUnit } from "../../domain/night-unit";
import { prepareNightPipelineLifecycle, } from "../../rulesets/night-lifecycle-plan";
import { assertNightSetupReady, assertNightReadable } from "../../rulesets/night-readability";
import { RulePlan } from "../../rulesets/rule-plan";
import { bindNightAbilityActorQuery } from "../../features/night-abilities/actor-query-ports";
import { isFragrantPairBoard, } from "../../features/fragrant-pair-seer/ports";
import { createNobleNightAbortReceiver, attachNobleNightReceiver, checkpointNobleBodyAuthority, isNobleBodyBoard, } from "../../features/noble-secret-body/ports";
import { isRadiantEclipseBoard } from "../../features/radiant-eclipse/ports";
import { isScholarMentorBoard } from "../../features/scholar-mentor/ports";
import { mistKnifeTargets, isMistRavenBoard } from "../../features/mist-raven/ports";
import { assertNightModifierBonusEffects } from "../../rulesets/night-damage-composition";
import { isTimeConsortBoard } from "../../features/time-wolf-consort/ports";
import { isMagicianBoard } from "../../features/magician/ports";
import { isRedMoonBoard } from "../../features/demon-hunter/ports";
import { isNightmareBoard } from "../../features/nightmare/ports";
import { isEvilKnightBoard, assertEvilKnightRosterCurrent, captureEvilKnightNightShotProtection, } from "../../features/evil-knight/ports";
import { originalDemonNightLives } from "../../features/demon-hunter/ports";
import { COMPONENT } from "../../domain/components/names";
import { StatusMarksComponent } from "../../domain/components/status-marks";
import { Phase, DeathCause, } from "../../domain/model";
import { getDefaultNightStageRegistry } from "../../rulesets/night-stage-plan";
import { getSessionRecorder } from "../../recording/session/context";
import { safeRecordLogicOp } from "../../recording/session/recorder";
import { GameActionRequestFactory } from "../actions/action-request-factory";
import { createRandom, shuffled } from "../../domain/random";
import { composeNightDamage } from "../../rulesets/night-damage-composition";
import { prepareNightSourceDelivery } from "../../rulesets/night-source-delivery";
import { discardStaleNightKnives } from "../../rulesets/night-knife-admission";
import { livingNightLife } from "../../domain/night-effects";
import { aliveLifeVersion } from "../../domain/components/alive";
import { assertNightCommitAdmission } from "../../rulesets/night-commit-admission";
export class NightPipeline {
    world;
    toolGateway;
    damageResolutionSystem;
    events;
    stageRegistry;
    random;
    #rulePlan;
    constructor(dependencies) {
        this.world = dependencies.world;
        this.toolGateway = dependencies.toolGateway;
        this.damageResolutionSystem = dependencies.damageResolutionSystem;
        this.events = dependencies.events;
        this.stageRegistry = dependencies.stageRegistry ?? getDefaultNightStageRegistry();
        this.random = dependencies.random ?? createRandom();
        this.#rulePlan = dependencies.rulePlan;
    }
    async execute(config, actionProvider, day, options = {}) {
        assertNightSetupReady({ world: () => this.world });
        const isCurrent = options.isCurrent ?? (() => true);
        if (!isCurrent())
            return attachNobleNightReceiver({ interrupted: true }, createNobleNightAbortReceiver());
        const pipeline = this;
        const prepare = this.#rulePlan
            ? this.#rulePlan.prepareNightPipelineLifecycle.bind(this.#rulePlan)
            : prepareNightPipelineLifecycle;
        const lifecycle = prepare({
            get world() {
                return pipeline.world;
            },
            get events() {
                return pipeline.events;
            },
            get random() {
                return pipeline.random;
            },
        }, config, day, () => options.lifecycleHandoff);
        config = lifecycle.config;
        const rulePlan = (this.#rulePlan ??= RulePlan.compile(lifecycle.parameters));
        const { ownsWedding, ownsDemon, ownsNoble, ownsFragrant, ownsAnimal, ownsRadiant, ownsMist, animalNight, fragrantNight, nobleNight, radiantNight, mistNight, weddingNight, } = lifecycle;
        try {
            lifecycle.open(isCurrent);
            const readability = {
                world: () => this.world,
                config: () => config,
                ownsAnimal: () => ownsAnimal,
                ownsFragrant: () => ownsFragrant,
                ownsNoble: () => ownsNoble,
                ownsRadiant: () => ownsRadiant,
                ownsMist: () => ownsMist,
                ownsDemon: () => ownsDemon,
            };
            const assertReadable = () => assertNightReadable(readability);
            assertReadable();
            const nativeProvider = ownsAnimal ||
                ownsRadiant ||
                ownsMist ||
                ownsDemon ||
                isEvilKnightBoard(this.world) ||
                isNightmareBoard(this.world) ||
                config.magician !== undefined ||
                config.scholarMentor !== undefined
                ? {
                    getAction: async (request) => {
                        assertReadable();
                        const action = await actionProvider.getAction(request);
                        assertReadable();
                        return action;
                    },
                }
                : actionProvider;
            if (ownsWedding)
                weddingNight.open(day, isCurrent);
            assertNightCommitAdmission({ world: () => this.world, day: () => day });
            safeRecordLogicOp({
                scope: "phase_pipeline",
                op: "night_pipeline_start",
                phase: Phase.Night,
                status: "ok",
                input: {
                    board_size: config.boardSize,
                },
            });
            const stageState = createNightStageState();
            const requests = new GameActionRequestFactory(this.world, this.events, day);
            const stageCtx = {
                isCurrent,
                previousExile: options.previousExile ? structuredClone(options.previousExile) : null,
                world: this.world,
                get nightActors() {
                    return bindNightAbilityActorQuery(this.world);
                },
                get nativeNightFailure() {
                    return rulePlan.nativeNightFailure(() => this.world);
                },
                get nativeNightTargets() {
                    return rulePlan.nativeNightTargets(() => this);
                },
                get nativeNightEffects() {
                    return rulePlan.nativeNightEffects(() => this);
                },
                roleCatalog: this.stageRegistry.roleCatalog,
                toolGateway: this.toolGateway,
                events: this.events,
                actionProvider: nativeProvider,
                currentDay: () => day,
                get requestFactory() {
                    return GameActionRequestFactory;
                },
                makeRequest: (actorId, allowedTools, context) => this.makeRequest(requests, actorId, allowedTools, context),
                getAliveByRole: (role) => this.getAliveByRole(role),
                ensureMarks: (entityId) => this.ensureMarks(entityId),
                pickMajorityTarget: (votes) => this.pickMajorityTarget(votes, config.tieBreaker?.wolfKillVote ?? "min_id"),
                pickMistKnife: (ids) => ids.length
                    ? ids[Math.floor(this.random.fork(`day:${day}:mist-knife`).next() * ids.length)]
                    : null,
                shuffleWolves: (ids) => shuffled(ids, this.random.fork(`day:${day}:wolf-order`)),
                state: stageState,
            };
            const knifeAdmission = {
                world: () => this.world,
                state: () => stageState,
                ownsWedding: () => ownsWedding,
                day: () => day,
            };
            for (const entry of rulePlan.nightPlan(this.stageRegistry, () => this.world).entries) {
                const stage = entry.handler;
                assertEvilKnightRosterCurrent(this.world);
                if (!isCurrent())
                    return attachNightUnit(attachNobleNightReceiver({ interrupted: true }, nobleNight.receiver), lifecycle.nightUnit);
                assertReadable();
                discardStaleNightKnives(knifeAdmission);
                assertNightModifierBonusEffects({ config: () => config, stageContext: () => stageCtx });
                const execute = stage.execute;
                await executePreparedNightStage(stage, execute, stageCtx);
                assertNightModifierBonusEffects({ config: () => config, stageContext: () => stageCtx });
                assertEvilKnightRosterCurrent(this.world);
                assertReadable();
                if (!isCurrent())
                    return attachNightUnit(attachNobleNightReceiver({ interrupted: true }, nobleNight.receiver), lifecycle.nightUnit);
                discardStaleNightKnives(knifeAdmission);
            }
            discardStaleNightKnives(knifeAdmission);
            const { demonSources, demonWolfSourceCurrent, demonKnifeProtection } = prepareNightSourceDelivery({
                ownsDemon: () => ownsDemon,
                world: () => this.world,
                day: () => day,
                claims: () => stageState,
            });
            const { dreamFrame, damage } = composeNightDamage({
                ownsRadiant: () => ownsRadiant,
                world: () => this.world,
                day: () => day,
                claims: () => stageState,
                config: () => config,
                stageContext: () => stageCtx,
                solver: () => this.damageResolutionSystem,
                aliveByRole: (role) => this.getAliveByRole(role()),
            });
            if (ownsNoble) {
                const payload = {
                    policy: "awa_noble_secret_body_v1",
                    actorId: checkpointNobleBodyAuthority(this.world, false).bodyId,
                    day,
                };
                this.events.push({
                    timestamp: Date.now(),
                    type: "noble_body_native_damage_committed",
                    payload,
                    audience: Object.freeze([]),
                });
                getSessionRecorder()?.recordRequiredLogicOp({
                    scope: "resolution",
                    op: "noble_body_native_damage_committed",
                    phase: Phase.Night,
                    status: "ok",
                    output: payload,
                });
            }
            assertReadable();
            for (const reflection of damage.poisonReflections ?? [])
                this.events.push({
                    timestamp: Date.now(),
                    type: "mechanical_poison_reflected",
                    payload: { ...reflection, day },
                });
            const mist = ownsMist
                ? mistNight.captureDamage(this.world, day, stageState.wolfTarget)
                : null;
            if (mist?.extra && livingNightLife(this.world, mist.extra)) {
                const id = mist.extra.id;
                if (!damage.deaths.includes(id))
                    damage.deaths.push(id);
                damage.deathSources[id] = [
                    ...new Set([...(damage.deathSources[id] ?? []), DeathCause.RavenClawKnife]),
                ];
            }
            if (!mist?.delayEligible)
                dreamFrame.expandInitialDamage(bindDreamLifeQueries(this.world), damage);
            if (!mist?.delayEligible && !ownsNoble)
                safeRecordLogicOp({
                    scope: "resolution",
                    op: "night_damage_resolved",
                    phase: Phase.Night,
                    status: "ok",
                    output: {
                        deaths: damage.deaths,
                        death_sources: damage.deathSources,
                    },
                });
            const summary = {
                wolfTarget: stageState.wolfTarget,
                deaths: [...damage.deaths],
                seerChecks: stageState.seerChecks,
                interruptedBySelfDestruct: false,
            };
            const deathLives = ownsDemon
                ? originalDemonNightLives(this.world)
                : new Map((mist?.delayEligible ? this.world.getAliveEntityIds() : damage.deaths).map((id) => {
                    const life = this.world.getComponent(id, COMPONENT.Alive);
                    return [id, { life, version: aliveLifeVersion(life) }];
                }));
            lifecycle.finishPipeline();
            return attachNightUnit(attachNobleNightReceiver({
                interrupted: false,
                summary,
                damage,
                dreamFrame,
                ...(mist ? { mistDelay: mist.delayEligible } : {}),
                deathLives,
                retaliationAttacks: stageState.retaliationAttacks,
                blocksPassiveNightShot: captureEvilKnightNightShotProtection(stageState),
                inspectionAttacks: stageState.inspectionAttacks,
                foxInspections: stageState.foxInspections,
                ...(demonSources ? { demonSources, demonWolfSourceCurrent, demonKnifeProtection } : {}),
            }, nobleNight.receiver), lifecycle.nightUnit);
        }
        finally {
            lifecycle.abortPipeline();
        }
    }
    makeRequest(requests, actorId, allowedTools, context) {
        const { stage, requiresAction = true, ...extraContext } = context;
        return requests.create({
            phase: Phase.Night,
            actorId,
            allowedTools,
            stage,
            requiresAction,
            summary: { key: "request.summary.night_action" },
            context: {
                ...extraContext,
                ...(isMistRavenBoard(this.world) &&
                    (allowedTools.includes("kill_vote") || allowedTools.includes("speak_to_wolves"))
                    ? { wolf_kill_candidates: mistKnifeTargets(this.world) ?? this.world.getAliveEntityIds() }
                    : {}),
                ...((isFragrantPairBoard(this.world) &&
                    (allowedTools.includes("kill_vote") || allowedTools.includes("speak_to_wolves"))) ||
                    isNobleBodyBoard(this.world) ||
                    isRadiantEclipseBoard(this.world) ||
                    isMistRavenBoard(this.world) ||
                    isScholarMentorBoard(this.world) ||
                    isTimeConsortBoard(this.world) ||
                    isMagicianBoard(this.world) ||
                    isEvilKnightBoard(this.world) ||
                    isNightmareBoard(this.world) ||
                    isRedMoonBoard(this.world)
                    ? { action_failure_policy: "error", allow_fallback: false }
                    : {}),
            },
        });
    }
    getAliveByRole(role) {
        return this.world.getAliveEntityIds().filter((id) => {
            const roleComp = this.world.getComponent(id, COMPONENT.Role);
            return roleComp?.role === role;
        });
    }
    ensureMarks(entityId) {
        let marks = this.world.getComponent(entityId, COMPONENT.StatusMarks);
        if (!marks) {
            marks = new StatusMarksComponent();
            this.world.addComponent(entityId, COMPONENT.StatusMarks, marks);
        }
        return marks;
    }
    pickMajorityTarget(votes, strategy) {
        const entries = Object.entries(votes);
        if (entries.length === 0) {
            return null;
        }
        entries.sort((a, b) => {
            const voteDiff = b[1] - a[1];
            if (voteDiff !== 0) {
                return voteDiff;
            }
            return Number(a[0]) - Number(b[0]);
        });
        if (entries.length >= 2 && entries[0][1] === entries[1][1]) {
            if (strategy === "no_kill") {
                return null;
            }
        }
        return Number(entries[0][0]);
    }
}
import { createNightStageState } from "../night/trusted-runtime";
import { executePreparedNightStage } from "../../rulesets/night-stage-bindings";
import { bindDreamLifeQueries } from "../../domain/dream-night-effects";
