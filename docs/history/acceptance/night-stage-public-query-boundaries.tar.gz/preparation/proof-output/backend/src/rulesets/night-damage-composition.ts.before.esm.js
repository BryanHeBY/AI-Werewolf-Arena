import { bindDreamLifeQueries } from "../domain/dream-night-effects";
import { Role } from "@ai-werewolf-arena/game-contract";
import { DreamNightFrame } from "../features/dreamer/night-frame";
import { readDreamNightLinks } from "../features/dreamer/night-ports";
import { sealRadiantNightEffects } from "../features/radiant-eclipse/ports";
import { assertScholarMentorBonusEffects } from "../features/scholar-mentor/ports";
export function assertNightModifierBonusEffects(runtime) {
    if (runtime.config().scholarMentor)
        assertScholarMentorBonusEffects(runtime.stageContext());
}
export function composeNightDamage(runtime) {
    const radiantEffects = runtime.ownsRadiant()
        ? sealRadiantNightEffects(runtime.world(), runtime.day())
        : undefined;
    const dreamFrame = new DreamNightFrame(readDreamNightLinks(runtime.claims()), radiantEffects?.shelters);
    assertNightModifierBonusEffects(runtime);
    const damage = runtime.solver().resolve(runtime.world(), {
        intentNight: runtime.day(),
        radiantShelters: radiantEffects?.shelters,
        radiantBacklashes: radiantEffects?.backlashes,
        modifierDeaths: runtime.claims().modifierDeaths,
        protectedTargets: dreamFrame.protectedTargets(bindDreamLifeQueries(runtime.world())),
        immuneNightTargets: dreamFrame.immuneNightTargets(bindDreamLifeQueries(runtime.world())),
        consecutiveDeaths: dreamFrame.consecutiveDeaths(bindDreamLifeQueries(runtime.world())),
        poisonClaims: runtime.claims().poisonClaims,
        retaliationAttacks: runtime.claims().retaliationAttacks,
        nightImmunities: runtime.claims().nightImmunities,
        inspectionAttacks: runtime.claims().inspectionAttacks,
        foxInspections: runtime.claims().foxInspections,
        wolfImmuneTargets: runtime.aliveByRole(() => Role.CursedFox),
        guardClaims: runtime.claims().guardClaims,
        merchantBacklashes: runtime.claims().merchantBacklashes,
        blackMarketBacklashes: runtime.claims().blackMarketBacklashes,
        mechanicalEffects: runtime.claims().mechanicalEffects,
        awakenedEffects: runtime.claims().awakenedEffects,
    });
    return { dreamFrame, damage };
}
