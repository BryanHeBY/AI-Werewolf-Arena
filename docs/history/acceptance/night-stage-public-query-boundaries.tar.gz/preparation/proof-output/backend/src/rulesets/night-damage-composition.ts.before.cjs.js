"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertNightModifierBonusEffects = assertNightModifierBonusEffects;
exports.composeNightDamage = composeNightDamage;
const dream_night_effects_1 = require("../domain/dream-night-effects");
const game_contract_1 = require("@ai-werewolf-arena/game-contract");
const night_frame_1 = require("../features/dreamer/night-frame");
const night_ports_1 = require("../features/dreamer/night-ports");
const ports_1 = require("../features/radiant-eclipse/ports");
const ports_2 = require("../features/scholar-mentor/ports");
function assertNightModifierBonusEffects(runtime) {
    if (runtime.config().scholarMentor)
        (0, ports_2.assertScholarMentorBonusEffects)(runtime.stageContext());
}
function composeNightDamage(runtime) {
    const radiantEffects = runtime.ownsRadiant()
        ? (0, ports_1.sealRadiantNightEffects)(runtime.world(), runtime.day())
        : undefined;
    const dreamFrame = new night_frame_1.DreamNightFrame((0, night_ports_1.readDreamNightLinks)(runtime.claims()), radiantEffects?.shelters);
    assertNightModifierBonusEffects(runtime);
    const damage = runtime.solver().resolve(runtime.world(), {
        intentNight: runtime.day(),
        radiantShelters: radiantEffects?.shelters,
        radiantBacklashes: radiantEffects?.backlashes,
        modifierDeaths: runtime.claims().modifierDeaths,
        protectedTargets: dreamFrame.protectedTargets((0, dream_night_effects_1.bindDreamLifeQueries)(runtime.world())),
        immuneNightTargets: dreamFrame.immuneNightTargets((0, dream_night_effects_1.bindDreamLifeQueries)(runtime.world())),
        consecutiveDeaths: dreamFrame.consecutiveDeaths((0, dream_night_effects_1.bindDreamLifeQueries)(runtime.world())),
        poisonClaims: runtime.claims().poisonClaims,
        retaliationAttacks: runtime.claims().retaliationAttacks,
        nightImmunities: runtime.claims().nightImmunities,
        inspectionAttacks: runtime.claims().inspectionAttacks,
        foxInspections: runtime.claims().foxInspections,
        wolfImmuneTargets: runtime.aliveByRole(() => game_contract_1.Role.CursedFox),
        guardClaims: runtime.claims().guardClaims,
        merchantBacklashes: runtime.claims().merchantBacklashes,
        blackMarketBacklashes: runtime.claims().blackMarketBacklashes,
        mechanicalEffects: runtime.claims().mechanicalEffects,
        awakenedEffects: runtime.claims().awakenedEffects,
    });
    return { dreamFrame, damage };
}
