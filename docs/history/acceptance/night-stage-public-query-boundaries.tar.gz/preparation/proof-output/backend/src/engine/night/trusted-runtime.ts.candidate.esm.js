export function createNightStageState() {
    return {
        wolfChatOrder: [],
        endedWolves: new Set(),
        wolfVotes: {},
        wolfTarget: null,
        seerChecks: [],
        poisonClaims: [],
        guardClaims: [],
        merchantBacklashes: [],
        blackMarketBacklashes: [],
        mechanicalEffects: { shields: [], attacks: [], failures: [] },
        awakenedEffects: { shields: [], attacks: [] },
    };
}
export function bindSyntheticNightDamageCommands(runtime) {
    return { addPoisonMark(id) { runtime.ensureMarks(id).add(importedStatusMark.PoisonMark); } };
}
export function bindLegacyAwakenedProposals(runtime) {
    return {
        get appendShield() {
            const values = runtime.state.awakenedEffects.shields, callee = values.push, invoke = Reflect.apply.bind(Reflect);
            return (effect) => invoke(callee, values, [effect]);
        },
        get appendAttack() {
            const values = runtime.state.awakenedEffects.attacks, callee = values.push, invoke = Reflect.apply.bind(Reflect);
            return (effect) => invoke(callee, values, [effect]);
        },
        addWolfKillMark(id) { runtime.ensureMarks(id).add(importedStatusMark.WolfKillMark); },
    };
}
import { StatusMark as importedStatusMark } from "../../domain/model";
