"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EVIL_KNIGHT_FRAME_STAGE = void 0;
exports.installEvilKnightBoard = installEvilKnightBoard;
exports.isEvilKnightBoard = isEvilKnightBoard;
exports.assertEvilKnightRosterCurrent = assertEvilKnightRosterCurrent;
exports.assertEvilKnightNativeActor = assertEvilKnightNativeActor;
const names_1 = require("../../domain/components/names");
const identity_1 = require("../../domain/identity");
const night_effects_1 = require("../../domain/night-effects");
const reflection_1 = require("./reflection");
const night_bindings_1 = require("./night-bindings");
function abilityIdentity(ability) {
    const state = ability.state;
    return JSON.stringify([
        ability.id,
        ability.kind,
        ability.activation,
        ability.source,
        ability.sourceDisclosed,
        ability.startsOnDay,
        ability.expiresAfterDay,
        ability.maxUses,
        state.targetPolicy,
        state.actionPolicy,
        state.selfHealRule,
        state.knifeVisibility,
        state.potionPolicy,
        state.repeatPolicy,
        state.policy,
        state.inspectionPolicy,
        state.protectionPolicy,
    ]);
}
const installed = new WeakMap();
function installEvilKnightBoard(world) {
    if (installed.has(world))
        throw new Error("evil_knight_board_reinstall");
    installed.set(world, world.entityIds().map((id) => {
        const role = world.getComponent(id, names_1.COMPONENT.Role);
        if (!role)
            throw new Error("evil_knight_roster_missing");
        return {
            id,
            role,
            kind: role.role,
            camp: world.getComponent(id, names_1.COMPONENT.Camp)?.camp,
            state: role.privateState,
            refs: Object.entries(role.privateState),
            abilityRefs: Object.entries(role.privateState.abilities ?? {}),
            authorities: Object.values((role.privateState.abilities ?? {})).map((ability) => ({
                ability,
                state: ability.state,
                source: ability.source,
                identity: abilityIdentity(ability),
            })),
        };
    }));
}
function isEvilKnightBoard(world) {
    return installed.has(world);
}
function assertEvilKnightRosterCurrent(world) {
    for (const entry of installed.get(world) ?? []) {
        if (world.getComponent(entry.id, names_1.COMPONENT.Role) !== entry.role ||
            entry.role.role !== entry.kind ||
            world.getComponent(entry.id, names_1.COMPONENT.Camp)?.camp !== entry.camp ||
            entry.role.privateState !== entry.state ||
            entry.refs.some(([key, value]) => entry.state[key] !== value) ||
            entry.authorities.some((a) => a.ability.state !== a.state ||
                a.ability.source !== a.source ||
                abilityIdentity(a.ability) !== a.identity) ||
            Object.keys(entry.state.abilities ?? {}).length !==
                entry.abilityRefs.length ||
            entry.abilityRefs.some(([key, value]) => entry.state.abilities?.[key] !== value))
            throw new Error("evil_knight_roster_revoked");
    }
}
function assertEvilKnightNativeActor(world, actorId, expected) {
    if (!isEvilKnightBoard(world))
        return;
    assertEvilKnightRosterCurrent(world);
    const role = world.getComponent(actorId, names_1.COMPONENT.Role);
    if (role?.role !== expected || world.getComponent(actorId, names_1.COMPONENT.Camp)?.camp !== identity_1.Camp.Good)
        throw new Error("evil_knight_actor_identity_revoked");
}
exports.EVIL_KNIGHT_FRAME_STAGE = {
    id: "evil_knight_frame",
    priority: 50,
    async execute(ctx) {
        if (!isEvilKnightBoard(ctx.world))
            return;
        assertEvilKnightRosterCurrent(ctx.world);
        if ((0, night_bindings_1.hasEvilKnightNightBindings)(ctx.state))
            throw new Error("evil_knight_night_reentry");
        const bindings = new Map();
        for (const id of ctx.world.getAliveEntityIds()) {
            const life = (0, night_effects_1.captureNightLife)(ctx.world, id);
            const binding = life && (0, reflection_1.captureEvilKnight)(ctx.world, life);
            if (binding)
                bindings.set(id, binding);
        }
        (0, night_bindings_1.installEvilKnightNightBindings)(ctx.state, bindings);
        ctx.state.nightImmunities = [...bindings.values()];
    },
};
