"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RADIANT_SHELTER_STAGE = exports.ECLIPSE_SWALLOW_STAGE = void 0;
const names_1 = require("../../domain/components/names");
const identity_1 = require("../../domain/identity");
const inventory_ports_1 = require("../night-abilities/inventory-ports");
const scope_ports_1 = require("../night-abilities/scope-ports");
const shelter_state_1 = require("./shelter-state");
const shelter_state_slot_1 = require("./shelter-state-slot");
const night_frame_1 = require("./night-frame");
exports.ECLIPSE_SWALLOW_STAGE = {
    id: "eclipse_swallow",
    priority: 110,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (day < 2)
            return;
        const actorId = ctx.world
            .getAliveEntityIds()
            .find((id) => ctx.world.getComponent(id, names_1.COMPONENT.Role)?.role === identity_1.Role.EclipseMaid);
        if (actorId === undefined)
            return;
        (0, night_frame_1.openEclipseChoice)(ctx.world, day);
        const request = ctx.makeRequest(actorId, ["swallow_skill"], {
            stage: "eclipse_swallow",
            swallow_candidates: (0, night_frame_1.eclipseSwallowTargets)(ctx.world, day),
            allow_fallback: false,
            action_failure_policy: "error",
        });
        (0, night_frame_1.assertRadiantRosterCurrent)(ctx.world);
        const action = await ctx.actionProvider.getAction(request);
        (0, night_frame_1.assertRadiantRosterCurrent)(ctx.world);
        if (!ctx.isCurrent() || ctx.currentDay() !== day)
            throw new Error("eclipse_swallow_stale");
        if (action?.name !== "swallow_skill")
            throw new Error("eclipse_swallow_action_missing");
        const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
            phase: identity_1.Phase.Night,
            day,
        });
        if (!ctx.isCurrent() || !result.ok || result.sanitizedCall?.name !== "swallow_skill")
            throw new Error("eclipse_swallow_action_invalid");
        (0, night_frame_1.commitEclipseChoice)(ctx.world, day, result.sanitizedCall.args.target_id, ctx.events);
    },
};
exports.RADIANT_SHELTER_STAGE = {
    id: "radiant_shelter",
    priority: 120,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (day < 2)
            return;
        for (const { actorId, ability } of ctx.nightActors.actors("shelter", day)) {
            const scope = (0, scope_ports_1.captureNightAbilityScope)(ctx.world, actorId, ability, day, () => ctx.isCurrent() && ctx.currentDay() === day);
            if (!scope?.isEligible())
                throw new Error("radiant_shelter_owner_stale");
            const request = ctx.makeRequest(actorId, ["cast_shelter"], {
                stage: "radiant_shelter",
                ability_id: ability.id,
                shelter_candidates: (0, night_frame_1.shelterTargets)(ctx.world, day, actorId, ability.id),
                allow_fallback: false,
                action_failure_policy: "error",
            });
            const action = await ctx.actionProvider.getAction(request);
            if (!scope.isEligible())
                throw new Error("radiant_shelter_owner_stale");
            if (action?.name !== "cast_shelter")
                throw new Error("radiant_shelter_action_missing");
            const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                phase: identity_1.Phase.Night,
                day,
                abilityId: ability.id,
            });
            if (!scope.isEligible() || !result.ok || result.sanitizedCall?.name !== "cast_shelter")
                throw new Error("radiant_shelter_action_invalid");
            const target = result.sanitizedCall.args.target_id;
            const next = (0, shelter_state_1.selectShelter)((0, shelter_state_1.readShelterState)(ability.state), day, target, actorId, ctx.world.getAliveEntityIds());
            (0, night_frame_1.commitRadiantShelter)(ctx.world, day, actorId, ability, target, ctx.events);
            (0, inventory_ports_1.recordNightAbilityUse)(ability, day, target !== null);
            shelter_state_slot_1.SHELTER_STATE_SLOT.allowedWrites.recordShelterSelection(ability, next);
        }
    },
};
