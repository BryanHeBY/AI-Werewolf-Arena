import { recordCharmSelection } from "./state";
import { aliveLifeVersion } from "../../domain/components/alive";
import { COMPONENT } from "../../domain/components/names";
import { isRoleExecutionRetired } from "../../domain/role-execution-authority";
import { Role, Camp, Phase } from "../../domain/model";
import { getWolfBeautyState } from "./state";
import { bindCharm } from "./relation";
import { animalBeautyCharmAllowed, isAnimalDreamBoard } from "../animal-dream/beauty-query-ports";
import { appendAnimalBeautyNotice } from "../animal-dream/beauty-fact-ports";
export const WOLF_BEAUTY_CHARM_STAGE = {
    id: "wolf_beauty_charm",
    priority: 450,
    async execute(ctx) {
        const day = ctx.currentDay();
        if (!animalBeautyCharmAllowed(ctx.world, day))
            return;
        for (const actorId of ctx.getAliveByRole(Role.WolfBeauty)) {
            if (!ctx.isCurrent())
                return;
            const role = ctx.world.getComponent(actorId, COMPONENT.Role), state = getWolfBeautyState(role), actorLife = ctx.world.getComponent(actorId, COMPONENT.Alive), actorVersion = aliveLifeVersion(actorLife), policy = state?.deathLinkPolicy;
            const canAct = () => !isRoleExecutionRetired(role);
            if (ctx.world.getComponent(actorId, COMPONENT.Camp)?.camp !== Camp.Wolf ||
                !state ||
                state.lastActedDay === day ||
                !canAct())
                continue;
            const targets = new Map(ctx.world
                .getAliveEntityIds()
                .filter((id) => id !== actorId)
                .map((id) => {
                const life = ctx.world.getComponent(id, COMPONENT.Alive);
                return [id, { life, version: aliveLifeVersion(life) }];
            }));
            const provider = ctx.actionProvider, getAction = provider.getAction, makeRequest = ctx.makeRequest;
            const requestActor = actorId;
            const requestTools = ["charm"];
            const requestExtras = {
                stage: "wolf_beauty",
                requiresAction: false,
            };
            const requestArgs = [requestActor, requestTools, requestExtras];
            const invokeRequest = Reflect.apply.bind(Reflect);
            if (!canAct())
                continue;
            const request = invokeRequest(makeRequest, ctx, requestArgs);
            const actionArgs = [request];
            const invokeAction = Reflect.apply.bind(Reflect);
            if (!canAct())
                continue;
            const action = await invokeAction(getAction, provider, actionArgs);
            const current = () => ctx.isCurrent() &&
                animalBeautyCharmAllowed(ctx.world, day) &&
                ctx.world.getComponent(actorId, COMPONENT.Role) === role &&
                role.role === Role.WolfBeauty &&
                ctx.world.getComponent(actorId, COMPONENT.Camp)?.camp === Camp.Wolf &&
                getWolfBeautyState(role) === state &&
                state.deathLinkPolicy === policy &&
                state.lastActedDay !== day &&
                ctx.world.getComponent(actorId, COMPONENT.Alive) === actorLife &&
                actorLife.alive &&
                actorVersion !== undefined &&
                aliveLifeVersion(actorLife) === actorVersion;
            if (!current() || !canAct())
                continue;
            if (action !== null && action.name !== "charm")
                continue;
            let targetId = action === null ? null : action.args.target_id;
            if (action) {
                const result = ctx.toolGateway.validateAndSanitize(ctx.world, actorId, action, {
                    phase: Phase.Night,
                    day,
                });
                if (!current() || !result.ok || result.sanitizedCall?.name !== "charm" || !canAct())
                    continue;
                targetId = result.sanitizedCall.args.target_id;
            }
            if (targetId !== null) {
                const target = targets.get(targetId);
                if (!target ||
                    ctx.world.getComponent(targetId, COMPONENT.Alive) !== target.life ||
                    !target.life.alive ||
                    target.version === undefined ||
                    aliveLifeVersion(target.life) !== target.version)
                    continue;
            }
            const recordSelection = recordCharmSelection;
            if (!canAct())
                continue;
            recordSelection(state, targetId, day);
            bindCharm(ctx.world, actorId, targetId);
            ctx.events.push({
                timestamp: Date.now(),
                type: "charm_applied",
                payload: { actorId, targetId, day },
            });
            if (isAnimalDreamBoard(ctx.world))
                appendAnimalBeautyNotice(ctx.world, ctx.events, day);
        }
    },
};
export const OWNED_NIGHT_STAGE_PROGRAMS = Object.freeze([
    WOLF_BEAUTY_CHARM_STAGE
].map((handler) => Object.freeze([handler, handler.execute])));
